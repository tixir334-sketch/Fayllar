#!/data/data/com.termux/files/usr/bin/env bash
# AITube o'rnatish (Termux; oddiy Linux da ham ishlaydi)
set -e
cd "$(dirname "$0")"
echo "== AITube o'rnatilmoqda =="
if [ -n "$PREFIX" ] && [ -d "$PREFIX/bin" ] && command -v pkg >/dev/null 2>&1; then
  echo "[Termux] paketlar o'rnatilmoqda…"
  pkg update -y || true
  pkg install -y python ffmpeg python-pillow libjpeg-turbo freetype tmux ca-certificates curl unzip || \
  pkg install -y python ffmpeg libjpeg-turbo freetype tmux
  command -v termux-wake-lock >/dev/null 2>&1 || pkg install -y termux-api || true
else
  echo "[Linux] python3, ffmpeg va tmux ni o'zingiz o'rnating (apt install python3 python3-pip ffmpeg tmux)"
fi
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
$PY -c "import PIL" 2>/dev/null || $PY -m pip install --break-system-packages Pillow || $PY -m pip install Pillow
$PY -c "import requests" 2>/dev/null || $PY -m pip install --break-system-packages requests || $PY -m pip install requests
echo "[ixtiyoriy] edge-tts (sifatli ovoz) o'rnatilmoqda…"
$PY -m pip install --break-system-packages edge-tts 2>/dev/null || $PY -m pip install edge-tts 2>/dev/null || \
  echo "  edge-tts o'rnatilmadi - Google TTS ishlatiladi (bu normal)."
[ -f .env ] || cp .env.example .env
chmod 600 .env 2>/dev/null || true
chmod +x run.sh start.sh stop.sh 2>/dev/null || true
# Termux:Boot (telefon qayta yonganda avto-ishga tushirish)
if [ -d "$HOME/.termux" ]; then
  mkdir -p "$HOME/.termux/boot"
  printf '#!/data/data/com.termux/files/usr/bin/sh\ntermux-wake-lock\ncd "%s" && ./start.sh\n' "$(pwd)" > "$HOME/.termux/boot/aitube.sh"
  chmod +x "$HOME/.termux/boot/aitube.sh"
  echo "Termux:Boot skripti yaratildi (Termux:Boot ilovasi o'rnatilgan bo'lsa avto-ishga tushadi)."
fi
echo
echo "== Sozlash =="
$PY main.py setup
echo
echo "== O'z-o'zini sinash (tarmoqsiz, ~1-3 daqiqa) =="
$PY main.py selftest || echo "Selftest xato berdi - yuqoridagi xabarlarni o'qing."
echo
echo "Tayyor! Ishga tushirish:  ./start.sh   (to'xtatish: ./stop.sh, loglar: tmux attach -t aitube)"
