#!/usr/bin/env bash
# Fonda (tmux) ishga tushirish
cd "$(dirname "$0")"
if command -v tmux >/dev/null 2>&1; then
  tmux has-session -t aitube 2>/dev/null && { echo "Allaqachon ishlayapti: tmux attach -t aitube"; exit 0; }
  tmux new-session -d -s aitube "./run.sh"
  echo "Ishga tushdi. Loglarni ko'rish: tmux attach -t aitube (chiqish: Ctrl+B, keyin D)"
else
  nohup ./run.sh > data/logs/run.out 2>&1 &
  echo "Ishga tushdi (nohup). Log: data/logs/run.out"
fi
