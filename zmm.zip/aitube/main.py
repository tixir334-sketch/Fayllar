#!/usr/bin/env python3
"""AITube - boshqaruv nuqtasi.

Foydalanish:
  python main.py run          # doimiy ishlash (bot + jadval)
  python main.py setup        # interaktiv sozlash (.env yaratadi)
  python main.py auth         # YouTube ga ulanish (terminalda)
  python main.py yt-import F  # client_secret JSON dan kalitlarni olish
  python main.py make         # bitta epizodni hozir yasash
  python main.py upload       # tayyor epizodni yuklash
  python main.py status       # holat
  python main.py health       # tizim tekshiruvi
  python main.py selftest     # to'liq o'z-o'zini sinash (tarmoqsiz)
  python main.py gpu          # video kodlash: GPU (NVENC/QSV/AMF) yoki CPU — sinab ko'rish
  python main.py testbot      # adminga sinov xabari
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from aitube.config import Config  # noqa: E402


def cmd_setup():
    cfg = Config()
    print("=== AITube sozlash ===  (Enter = hozirgisini qoldirish)\n")

    def ask(key, prompt, secret=False):
        cur = cfg.masked(key) if secret else cfg.get(key)
        v = input(f"{prompt} [{cur}]: ").strip()
        if v:
            cfg.set(key, v)

    ask("TELEGRAM_BOT_TOKEN", "Telegram bot token (@BotFather)", True)
    ask("ADMIN_ID", "Sizning Telegram ID (@userinfobot)")
    ask("CHANNEL_NAME", "Kanal nomi")
    ask("GEMINI_API_KEYS", "Gemini API kalit(lar)i, vergul bilan (aistudio.google.com, bepul)", True)
    ask("GROQ_API_KEYS", "Groq API kalit(lar)i (console.groq.com, bepul) - ixtiyoriy", True)
    ask("OPENROUTER_API_KEYS", "OpenRouter kalit(lar)i (bepul modellar) - ixtiyoriy", True)
    ask("UPLOAD_TIMES", "Kunlik yuklash vaqtlari (HH:MM,HH:MM)")
    ask("TZ_OFFSET", "Vaqt zonasi (UTC dan soat farqi, O'zbekiston = 5)")
    ask("YT_CLIENT_ID", "YouTube OAuth Client ID (TV/Limited Input) - ixtiyoriy")
    ask("YT_CLIENT_SECRET", "YouTube OAuth Client Secret", True)
    print("\nTayyor. Keyingi qadamlar:\n  python main.py selftest\n  python main.py run   (Telegramda /auth)")


def cmd_run():
    from aitube.app import App
    app = App()
    app.log.info("AITube ishga tushmoqda…")
    if not app.tg.enabled():
        app.log.warning("TELEGRAM_BOT_TOKEN/ADMIN_ID sozlanmagan - hisobotlar faqat logga yoziladi")
    app.start_background(with_bot=True)
    from aitube import health
    items = health.check(app, network=True)
    app.n.say("🟢 <b>AITube ishga tushdi</b>\n" + health.format_report(items) +
              "\n\n/menu — boshqaruv paneli", markup=None)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        app.log.info("To'xtatildi")


def cmd_auth():
    from aitube.app import App
    app = App()
    if not app.yt.configured():
        print("YT_CLIENT_ID / YT_CLIENT_SECRET .env da yo'q. Avval: python main.py setup")
        return 1
    try:
        if app.cfg.get("YT_AUTH_MODE") == "loopback":
            raise RuntimeError("loopback")
        dev = app.yt.device_start()
        print(f"\n1) Brauzerda oching: {dev.get('verification_url') or dev.get('verification_uri')}")
        print(f"2) Kodni kiriting: {dev['user_code']}\n   (kutilmoqda…)")
        ok = app.yt.device_poll(dev)
    except Exception as e:
        print("Qurilma kodi usuli ishlamadi (", e, ") - telefon brauzeri usuliga o'tilmoqda.")
        ok = app.yt.loopback_auth(lambda url: print("\nHavolani SHU telefonda oching:\n" + url + "\n(kutilmoqda…)"))
    print("✅ Ulandi" if ok else "⌛ Vaqt tugadi")
    if ok:
        try:
            print(app.yt.channel())
        except Exception as e:
            print("Kanal ma'lumoti olinmadi:", e)
    return 0 if ok else 1


def cmd_yt_import():
    from aitube.youtube import parse_client_json
    if len(sys.argv) < 3:
        print("Foydalanish: python main.py yt-import /sdcard/Download/client_secret_....json")
        return 1
    cid, sec = parse_client_json(Path(sys.argv[2]).read_text(encoding="utf-8"))
    cfg = Config()
    cfg.set("YT_CLIENT_ID", cid)
    cfg.set("YT_CLIENT_SECRET", sec)
    print("✅ YouTube kalitlari .env ga yozildi. Endi Telegramda /auth yuboring.")
    return 0


def cmd_make():
    from aitube.app import App
    app = App()
    ep = app.pipeline.produce_next()
    print("Tayyor:" if ep else "Yasab bo'lmadi", ep and ep["video_path"])
    return 0 if ep else 1


def cmd_upload():
    from aitube.app import App
    app = App()
    return 0 if app.pipeline.upload_next_ready() else 1


def cmd_status():
    from aitube.app import App
    app = App()
    print(app.db.counts())
    for e in app.db.recent(10):
        print(f"#{e['gno']} [{e['status']}] {e['title']} {e['yt_url'] or ''}")


def cmd_health():
    from aitube.app import App
    from aitube import health
    app = App()
    for lvl, name, detail in health.check(app, network=True):
        print(lvl, name, "-", detail)


def cmd_testbot():
    from aitube.app import App
    app = App()
    mid = app.n.say("✅ AITube sinov xabari: bot admin bilan bog'langan.")
    print("Yuborildi" if mid else "Yuborib bo'lmadi (token/ADMIN_ID ni tekshiring)")
    return 0 if mid else 1


def cmd_selftest():
    from aitube.selftest import main as st
    return st()


def cmd_gpu():
    """GPU/CPU kodlovchilarni sinaydi va natijani chiqaradi (ffmpeg, drayver va sessiyalar)."""
    from aitube.hwenc import HW
    cfg = Config()
    HW.bind(cfg)
    HW.detect(force=True, everything=True)
    print(HW.describe(html=False))
    st = HW.status()
    print(f"\nffmpeg: {st['ffmpeg'] or '?'}")
    print("Tanlangan:", st["label"], "· rejim:", st["mode"], "(.env: ENCODER=auto|nvenc|qsv|amf|videotoolbox|cpu)")
    return 0


def main():
    cmds = {"gpu": cmd_gpu, "run": cmd_run, "setup": cmd_setup, "auth": cmd_auth, "yt-import": cmd_yt_import, "make": cmd_make, "upload": cmd_upload,
            "status": cmd_status, "health": cmd_health, "testbot": cmd_testbot, "selftest": cmd_selftest}
    if len(sys.argv) < 2 or sys.argv[1] not in cmds:
        print(__doc__)
        return 0
    return cmds[sys.argv[1]]() or 0


if __name__ == "__main__":
    sys.exit(main())
