# AITube DEVLOG (server yozuvlari)

Bu fayl har bir qilingan ishni bosqichma-bosqich yozib boradi, hech narsa unutilmasin.
Foydalanuvchi talablari ro'yxati (TALAB) va holati (✅ bajarildi / 🔧 jarayonda / ⏳ navbatda).

## TALABLAR
1. ✅ 1080p/30fps, ingliz so'zlar to'g'ri o'qilishi (2687+ so'z, /pron)
2. ✅ Animatsiyali sxema (server/user/baza, paketlar) + shisha kartalar
3. ✅ Ixcham kategoriyali menyu, hech funksiya yo'qolmagan
4. ✅ Video tayyor bo'lgach YouTube'da rejalashtirilgan yuklash + boshqaruv (/schedule)
5. ✅ Lug'at boshqaruvi: txt import/eksport, qidiruv (uz/en), qo'lda qo'shish
6. ✅ AI rasmlar suv belgisiz, har xil
7. ⏳ Jonli efir: nom/rasm, navbat, 5 daqiqalik uzluksiz bo'laklar, RAM, 10 daq ogohlantirish, to'xtat/xayrlashuv, tozalash
8. ✅ /retry: senariy qayta? ovoz qayta? (Ha/Yo'q)
9. ✅ Subtitr 6-band ustiga tushishi xatosi (render)
10. ⏳ Telegramga >49MB videoning 720p nusxasi (✅ telegram_copy yozildi)
11. ⏳ Har funksiya alohida oqimda, xatosiz; qattiq tekshiruv; zip

## JURNAL
- schedule.py, botsched.py (/schedule, /reschedule, /publish, /unschedule, /swap, /shift, /reslot), db: publish_at/pub_state, youtube.set_publish, scheduler._auto_schedule + reconcile.
- selftest_more.py: schedule_tests + schedule_e2e; fakeserver videos PUT status/publishAt.
- 8 ta namuna video (ep001-008) ko'rib chiqildi. Topilgan: fon hamma epizodda bir xil; 6-band sig'maydi (raqam doirasi min balandligi
  qotib qolgan) -> _item_layout hammasini sig'diradi; band chiqquncha ekran bo'sh -> xira "skeleton" kontur.
- bgfx.py: 8 fon uslubi (aurora, grid, network, rain, waves, hex, warp, beams), style_for(gno), BG_STYLE sozlamasi (auto|nom).
- sfx.py: whoosh/pop/tick/blip/chime/riser/thud sintezi (numpy'siz); video.py'da 3-kirish sifatida aralashadi (SFX, SFX_VOLUME);
  make_music(seed) har epizodda boshqa akkord/tremolo/aks-sado.
- telegram_copy(): >49MB videoga 720p siqilgan nusxa.
- lexicon.py + botdict.py (/sozlar, dc: tugmalar, txt hujjat qabul qilish .txt/.csv/.tsv, eksport, qidiruv uz/en + o'xshash).
- botretry.py: /retry,/remake,"regen:" tugma -> rt: dialog (senariy? -> ovoz?). pipeline.regenerate(keep,new_script,new_voice); tts.fresh;
  cleaner ovoz keshini 2 kun saqlaydi.
- imagegen.py (pollinations nologo / together / huggingface), render art+card, bgfx art fon, thumb 3 maket (gradient xatosi tuzatildi),
  pipeline.episode_art, fakeserver /prompt/ route, selftest_more.image_tests/image_e2e.

## Jonli translatsiya (stream) — bajarildi
- stream.py: producer/feeder/watcher oqimlari, doimiy ffmpeg (pusher), MPEG-TS remux (uzluksiz vaqt tamg'alari), RAMda faqat joriy+keyingi bo'lak, tugagach DROP_DELAY(3s)dan so'ng o'chirish, disk fayl RAMga o'qilib o'chiriladi.
- streamgen.py: davomiy bo'lak ssenariysi (gap o'rtasida uzish + davomi), xayrlashuv bo'lagi (oxirgi bo'lak davomi), LLM ishlamasa oddiy xayrlashuv.
- "Efir tugasinmi?" (WARN_SEC qolganda): Davom → cheksiz AI; To'xtat yoki 3 daqiqa javobsiz → xayrlashuv bo'lagi → efir tugaydi, admin ga xabar, hamma narsa tozalanadi.
- botstream.py: /stream paneli (nom, tavsif, rasm/AI rasm, navbat, tayyor video, video yuborish, AI bo'laklar, sifat/FPS/format/bitrate, kalit (yashirin), boshlash/to'xtatish/zudlik bilan).
- youtube.py: live_create/live_status/live_transition; fakeserver Live yo'llari; config STREAM_*; RES 480 qo'llab-quvvatlanadi.
- Sinov: selftest_more.stream_tests (navbat, uzluksizlik, Davom, taymaut, zudlik, RAM/disk limitlari, sink vaqt tamg'alari).

## HIDE_STATS: yuklashda publicStatsViewable=false; Stats.refresh har safar (stats jobi) ochilib qolganlarini qayta yopadi (youtube.hide_stats, publishAt saqlanadi).

## Yangi talab (stream tezlashtirish) — jarayonda
- Efir uzilishi: bo'laklar kech qolyapti. Talab: efirdan oldin 10 ta 10 daqiqalik bo'lak (parallel, async) tayyorlansin, so'ng efir yoqilsin; 10 daqiqalik bo'lak 30 soniyalik qismlarga bo'lib parallel render qilinsin; AI ham tez; hammasi bir vaqtda; kechikmaslik uchun ko'proq imkoniyatlar.
- Reja: bufer diskda (RAMda hamon faqat joriy+keyingi), ssenariy→ovoz(parallel)→30s qismlar(parallel threadlar)→audio bir marta→concat; STREAM_PREROLL/BUFFER/WORKERS/PART_SEC/PRESET.

## zip64
- Ovoz o'zgarishi tuzatildi: edge 6 urinish, google'ga tushgan sahnalar edge'da qayta yasaladi (video.make_audio, tts.synth_ex only=).
- STREAM_FIRST_SEC=90: birinchi AI bo'lak qisqa, stream tezroq boshlanadi.
- zip65: birinchi bo'lak qisqartirilmaydi (FIRST_SEC=0), lookahead 6, BUFFER 16.
- zip66: x264 yengil parametrlar (ref=1, bframes=0, mbtree=0 ...).
- zip67: TTS semafor 24, ishchilar 16 gacha.
- zip68: render jarayonlari nice(4).
- zip69: nice olib tashlandi (to'liq quvvat); render ishchisi 240 s javobsiz qolsa o'ldiriladi va qism oqimlarda qayta chiziladi (qotishdan himoya).
- zip70: STREAM_CRF=20 (sifat oshdi, avval 24). Stream testlari: 95 ✅, ❌ yo'q.

## zip71 — ko'p foydalanuvchili rejim (hamma ishlata oladi)
- accounts.py: hisoblar (PBKDF2 xesh, brauzerda xeshlanadi), seanslar, urinishlar cheklovi; hub.py: har hisobga alohida ish maydoni (data/users/<id>/),
  mini ilovadan (Telegram sendData) kirish/ro'yxatdan o'tish/chiqish; userbot.py: cheklangan menyu, 👤 Hisob, oson YouTube ulash;
  botpost.py: 📤 Post joylash (admin ham); botusers.py: /users, /throttle, /limits, /webapp.
- webapp/index.html: GitHub Pages uchun mini ilova (kirish, hisob yaratish, shartlar, «Hisob yaratildi!», hisobdan chiqish).
- tg.py: bitta jonli panel (tugma → tahrirlash, /buyruq → yangi panel + eskisi o'chadi), THROTTLE (0.4 s/chat), GLOBAL (25/s), bir xil tahrir yuborilmaydi.
- dispatch.py: ishchilar puli (aktor modeli), takroriy tugmalar birlashtiriladi; Gate: og'ir ishlar umumiy eshigi (admin ustuvor).
- hub: bo'sh ish maydonlari xotiradan chiqariladi (MAX_LOADED_APPS/APP_IDLE_SEC), kirganda avtomatik qayta ochiladi.
- Tuzatishlar: selftest FakeTTS.synth_ex(only=) (zip64 dan beri buzuq edi); foydalanuvchilarga tizim "Salomatlik" hisoboti yuborilmaydi.
- Sinov: `python main.py selftest-users` (112 tekshiruv) · o'lchov: `python tools/bench_scale.py` (masshtab raqamlari README da).

## zip72 — GPU kodlash, parallel ovoz, kalit aylanishi, katta stream tizimi (ko'p foydalanuvchi rejimi olib tashlandi)
- **hwenc.py (yangi)**: video kodlash menejeri. NVIDIA NVENC -> Intel QSV -> AMD AMF -> Apple VideoToolbox -> CPU (libx264 -> mpeg4).
  `ffmpeg -encoders` ro'yxati yetarli emas: har kodlovchi qisqa haqiqiy sinov bilan tekshiriladi (eng yaxshi parametr variantidan oddiygacha);
  GeForce sessiya chegarasi parallel sinov bilan o'lchanadi (ENC_SESSIONS=0) va parallel qismlar shu bilan cheklanadi;
  sifat BELGILANGAN: GPU da doimiy sifat (CQ=CRF-2) + bitrate chegarasi, CPU da CRF + maxrate; B-kadrsiz, kalit kadr har 2 s.
  GPU xato bersa: stream bo'lagi/fayl/video bo'lak darajasida CPU da qayta kodlanadi (bir bo'lakda kodlovchilar aralashmaydi),
  ketma-ket 2 xatodan keyin GPU 10 daqiqaga o'chiriladi va qayta sinaladi. Boshqaruv: `/gpu` (bot), `python main.py gpu`, ENCODER=auto|nvenc|qsv|amf|cpu.
- **Stream sifati belgilangan**: STREAM_AUTO=0 (sifat avtomatik tushirilmaydi), STREAM_BITRATE=0 -> o'lcham/fps ga qarab avto (1080p30 = 5500 kbit/s;
  avval 1800 edi), animatsiya fon kadr tezligi STREAM_BG_FPS=0 -> efir FPS iga teng (harakat tezligi soniyalarda — fps dan mustaqil, silliqligi fps ga bog'liq).
  Oddiy video uchun ham: `motion_cad(fps, motion)` (VIDEO_ANIM_FPS).
- **Ovoz parallel (video ham)**: `build()` endi hamma sahna ovozini bir vaqtda yaratadi (avval ketma-ket, workers=1); qayta urinishda 1-urinish kutishsiz;
  google TTS bo'laklari parallel; loudnorm+44.1k bitta ffmpeg o'tishida; AI rasm yo'q — talaffuz/ovoz/renderer ishlari kutishsiz ketadi
  (renderer ovozdan keyin yaratiladi: `build(renderer=callable)`).
- **Kalitlar navbat bilan va kutishsiz (llm.py)**: har yangi so'rov keyingi kalitdan boshlanadi (parallel so'rovlar hamma kalitga taqsimlanadi);
  429/5xx/tarmoq xatosida `time.sleep` yo'q — darhol keyingi kalit/model; kutish faqat hamma variant yiqilganda (hodisaga asoslangan, qisqa);
  `complete_many`/`complete_json_many`: ko'p so'rov parallel, har biri tugashi bilan natija beriladi; ssenariy uchun VIDEO_AI_RACE=2.
  util.http(up_retries=0): internet bor bo'lsa-yu so'rov yiqilsa, LLM chaqiruvi bir xil kalitda qayta urinmaydi.
- **streamsys.py (yangi) — stream bitta katta tizim**: Telemetry (pusher `-progress`: bitrate/tezlik/tashlangan kadr, CPU/RAM/disk, hodisalar jurnali),
  Watchdog (sekin uzatish, qotgan tayyorlov, kam disk/RAM, GPU->CPU xabari), PROFILES (tejamkor/standart/sifatli/maksimal),
  qo'shimcha manzillar (STREAM_EXTRA_RTMP, ffmpeg `tee`, asosiy uzilsa pusher qayta ishga tushadi, qo'shimcha uzilsa efir davom etadi),
  Planner (STREAM_AT / `/stream vaqt 21:30`). Panel: 📊 Tizim, 🎚 Profil; `/stream tizim|profil <nom>|vaqt HH:MM`.
- **AI rasm yaratish butunlay o'chirildi** (imagegen.DISABLED=True: .env dagi AI_IMAGES ahamiyatsiz; pipeline/stream/bot tugmalaridan olib tashlandi).
- **Ko'p foydalanuvchi rejimi olib tashlandi**: accounts.py, hub.py, userbot.py, botusers.py, webapp/, tools/bench_scale.py, selftest_users.py,
  README_KOPFOYDALANUVCHI.md, Gate, Config.parent, MULTIUSER/WEBAPP_URL/MAX_* sozlamalari. (data/users va data/accounts.db* tegilmagan — ma'lumot joyida.)
- Sinov: selftest_v2.py (125 tekshiruv: soxta-GPU ffmpeg, sessiyalar, CPU zaxirasi, kalit aylanishi, parallel ovoz, stream tizimi, sozlamalar).
- **Telefon GPU si (hwenc.py)**: Android MediaCodec (`h264_mediacodec`, NDK) — chip (getprop) bo'yicha apparat kodlovchi nomi
  (MediaTek `c2.mtk.avc.encoder`/`OMX.MTK.VIDEO.ENCODER.AVC`, Qualcomm, Exynos), bitrate rejimi (CBR/VBR), 8 variantli sinov zanjiri,
  haqiqiy ish o'lchamida faylga kodlab PSNR bilan tekshirish (buzuq rang/o'lcham rad etiladi), osilishdan himoya (MC_TIMEOUT),
  sessiyalar 2..6 o'lchanadi, avto-bitrate +25% (MC_BOOST), ilova boshlanganda fonda oldindan sinash, `/gpu` va sifat ekranida "Telefon",
  `/stream profil telefon`. selftest_v2: 8 ta yangi tekshiruv bloki (soxta MediaCodec: ok/nomsiz/buzuq rang/xato/osilish).
- **3D olam va o'qitish (zip72 davomi)**: icons3d.py (82 ta pseudo-3D ikonka: soya, qirra yorug'ligi, tebranganda quyosh nuridek sirpanuvchi yaltirash),
  cards.py (`parts` — 3D qism kartalari, `explain` — tushuncha kartasi: ta'rif + hayotiy misol + nima uchun kerak; diagramma tugunlari ham 3D),
  bgfx «world» (videodek jonli fon: nurlar, perspektiv pol, suzuvchi 3D ikonkalar, parallaks), sfx: boing/sparkle/ding,
  teach.py (AI uchun «0 dan o'rgat» doktrinasi: nima→nega→qanday→misol; kompyuter qismlari batafsil) — writer va streamgen ishlatadi,
  video parallel render (`VIDEO_PARALLEL`: qismlarga bo'lib bir nechta jarayonda + GPU sessiyalar), asinxron TTS (`tts.AsyncLoop`: bitta asyncio sikli),
  LLM kalit sog'lig'i (karantin 3+ ketma-ket xatoda, `LLM.report()` botda), stream: cheksiz zaxira, taymautsiz efir, «Efir tugasinmi?» so'ralmaydi.
