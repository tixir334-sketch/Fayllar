#!/usr/bin/env bash
# Doimiy ishlash sikli: xato yoki /restart bo'lsa 10 soniyadan keyin qayta ishga tushadi.
cd "$(dirname "$0")"
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
while true; do
  $PY main.py run
  echo "[run.sh] jarayon tugadi (kod $?), 10 soniyadan keyin qayta ishga tushadi…"
  sleep 10
done
