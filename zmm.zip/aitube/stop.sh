#!/usr/bin/env bash
cd "$(dirname "$0")"
tmux kill-session -t aitube 2>/dev/null
pkill -f "main.py run" 2>/dev/null
pkill -f "run.sh" 2>/dev/null
echo "To'xtatildi."
