# Yangiliklar (zip72)

Bu zipni eski papka o'rniga qo'yib ishga tushiring — `.env` (kalitlar), `data/` (YouTube token, bazalar), `__pycache__` va boshqa
barcha ma'lumotlar o'z joyida. Faqat kod o'zgargan/qo'shilgan.

## 1. GPU bilan kodlash (NVENC / QSV / AMF) — stream va videolar
```
python main.py gpu        # qaysi kodlovchi ishlashini tekshiradi
```
Botda: `/gpu` (holat, qayta sinash, tanlash) · `.env`: `ENCODER=auto|nvenc|qsv|amf|videotoolbox|mediacodec|cpu` (standart: `auto`).

* **auto**: NVIDIA NVENC → Intel QSV → AMD AMF → telefon MediaCodec → CPU. Har biri haqiqatan sinab ko'riladi (videokarta/drayver bo'lmasa CPU).
* **Sifat belgilangan**: GPU da doimiy sifat (CQ) + bitrate chegarasi, CPU da CRF + maxrate; stream sifati endi avtomatik tushmaydi
  (`STREAM_AUTO=0`). `STREAM_BITRATE=0` — o'lcham va FPS ga qarab avto (1080p30: 5500 kbit/s).
* **Xavfsiz**: GPU xato bersa (drayver, sessiya chegarasi) bo'lak avtomatik CPU da qayta kodlanadi; ketma-ket xatodan keyin GPU
  10 daqiqaga o'chiriladi va keyin qayta sinaladi. Stream uzilmaydi.
* **Sessiyalar**: GeForce drayverlarida bir vaqtda ochiladigan kodlash soni cheklangan — bot buni o'zi o'lchaydi (`ENC_SESSIONS=0`).
* Talab: NVIDIA — drayver + ffmpeg `h264_nvenc` bilan; Intel — `intel-media-va-driver`/oneVPL + ffmpeg `h264_qsv`. (`ffmpeg -encoders | grep -E "nvenc|qsv"`)

## 2. Ovoz va AI — parallel, kutishsiz
* Video yasashda hamma sahna ovozi bir vaqtda yaratiladi (stream kabi).
* AI kalitlari navbat bilan ishlatiladi (har so'rov keyingi kalitdan), xatoda uyqusiz keyingisiga o'tiladi, ko'p so'rov parallel.
* `time.sleep` bilan kutish olib tashlandi: javob kelishi bilan keyingi bosqich darhol boshlanadi.

## 3. Animatsiya FPS ga bog'liq
`STREAM_BG_FPS=0` (avto) — fon animatsiyasi efir FPS iga teng silliqlikda; harakat tezligi soniyalarda — FPS dan mustaqil.
Videolar uchun `VIDEO_ANIM_FPS` (0 = avto).

## 4. Stream — bitta katta tizim
Botda `/stream`: **📊 Tizim** (kodlash, uzatish bitrate/tezligi, zaxira, tayyorlash tezligi, CPU/RAM/disk, hodisalar),
**🎚 Profil** (tejamkor / standart / sifatli / maksimal), nazoratchi (sekin uzatish, qotgan tayyorlov, kam disk/RAM, GPU→CPU haqida xabar),
qo'shimcha manzillar (`STREAM_EXTRA_RTMP=rtmp://...,rtmps://...` — bir vaqtda bir nechta platformaga), rejalashtirish (`/stream vaqt 21:30`).

## 5. Olib tashlangan
* Ko'p foydalanuvchi rejimi (hisoblar, mini ilova, /users, /limits, /webapp). `data/users` va `data/accounts.db` ga tegilmadi — kerak bo'lmasa o'zingiz o'chirasiz.
* AI rasm yaratish (kodda butunlay o'chirilgan).

Sinov: `python main.py selftest` (tarmoqsiz, GPU kerak emas — GPU yo'li soxta ffmpeg bilan sinaladi).

## 6. Telefon GPU si (Termux · Redmi Note 15: MediaTek Helio G100 Ultra, Mali-G57 MC2)
* Telefonda video kodlash GPU/video chipi Android **MediaCodec** orqali ishlaydi (ffmpeg `h264_mediacodec`). `ENCODER=auto` uni o'zi
  sinaydi (yoki `ENCODER=mediacodec`). Termux'da: `pkg upgrade ffmpeg`, so'ng `python main.py gpu` yoki botda `/gpu`.
* MediaTek uchun apparat kodlovchi nomi bilan ochiladi (`c2.mtk.avc.encoder`), dasturiy kodlovchi tasodifan tanlanmaydi.
  Bitrate rejimi (stream: CBR, video: VBR), B-kadrsiz, kalit kadr har 2 s — MediaTek CQ rejimini qo'llamaydi.
* **Sifat tekshiruvi**: har variant haqiqiy ish o'lchamida (masalan 1920×1080 — 16 ga karrali emas) faylga kodlanadi va PSNR bilan
  solishtiriladi; rang yoki o'lcham buzuq bo'lsa rad etiladi. Osilib qolsa 25 soniyada to'xtatiladi — CPU ga o'tiladi.
* Telefon kodlovchisi bir xil bitrate da x264 dan zaifroq, shuning uchun **avto-bitrate +25%** (1080p30: 5500 → 6875 kbit/s).
  `STREAM_BITRATE` ni qo'lda bersangiz o'zgarmaydi.
* ⚠ Android 15+ (HyperOS 2) da Termux'dagi NDK MediaCodec JVM'siz ishlamasligi mumkin (ffmpeg hujjati). Unda `/gpu` sababini
  ko'rsatadi va CPU bilan ishlaydi — hech narsa buzilmaydi. Kadr chizish (Pillow) CPU da qoladi: GPU faqat kodlashni tezlatadi.
* Telefon uchun tayyor profil: `/stream profil telefon` (720p · 30 fps · avto bitrate).

## 7. 3D «yangi olam»: kartalar, ikonkalar, jonli fon, o'qitish
* **82 ta 3D ikonka** (cpu, gpu, ram, ssd, motherboard, psu, fan, tower, monitor, user, db, gear, ... ): soyasi bor, tebranadi va tebranganda
  quyosh nuridek yaltiraydi. Diagramma tugunlari ham shu 3D ikonkalar bilan chiziladi.
* **Yangi sahna turlari:** `parts` (2-6 ta 3D karta: nom + vazifa, birin-ketin chiqadi) va `explain` (tushuncha kartasi: ta'rif, hayotiy misol,
  nima uchun kerak). Ovoz bilan sinxron, yangi tovushlar bilan (sakrash, yaltirash, qo'ng'iroq).
* **Jonli fon («world»):** harakatlanuvchi nur-nurlar, perspektiv pol, suzib yuruvchi 3D ikonkalar (parallaks) — epizodlarning ko'pchiligida.
* **AI prompti:** «0 dan o'rgat» doktrinasi (teach.py): hech bir atama oldindan tushuntirilmasdan ishlatilmaydi; har tushuncha nima→nega→qanday→
  hayotiy misol→raqamli misol→xato; kompyuter yig'ishda CPU, GPU, RAM, SSD, ona plata, quvvat bloki va ularning nega kerakligi batafsil.
* **Tezlik:** video endi stream kabi qismlarga bo'lib parallel chiziladi (`VIDEO_PARALLEL=1`; to'lqin/musiqa yoqilgan bo'lsa ketma-ket),
  ovoz asinxron (bitta asyncio sikli), AI kalitlari sog'lig'i kuzatiladi (xato bergan kalit vaqtincha karantinga olinadi).
* **Stream:** zaxira cheksiz (faqat disk himoyasi), efir 20 daqiqa taymaut bilan o'zi ochilmaydi, «Efir tugasinmi?» so'ralmaydi.
* GPU va CPU birga ishlaydi: **CPU kadrlarni chizadi, GPU/MediaCodec kodlaydi** (bir faylda ikki xil kodlovchi aralashtirilmaydi — o'ynatishda buzilish xavfi).

