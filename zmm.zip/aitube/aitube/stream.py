"""Jonli translatsiya (YouTube Live) yadrosi.

Tuzilma (har bir qism alohida oqimda):
  producer  - navbatdan keyingi bo'lakni tayyorlaydi (tayyor video fayl yoki AI ssenariy -> ovoz -> kadrlar),
              diskdagi faylni RAMga o'qib, faylni o'chiradi. RAMda faqat JORIY va KEYINGI bo'lak turadi.
  feeder    - bo'lakni MPEG-TS ga o'tkazib (uzluksiz vaqt tamg'alari bilan) bitta doimiy ffmpeg (pusher)ga uzatadi;
              bo'lak tugagach DROP_DELAY soniya kutib RAMdan o'chiradi.
  watcher   - ogohlantirish ("Efir tugasinmi?"), 3 daqiqa taymaut, pusher/YouTube salomatligi, tozalash.
Bo'laklar orasida bir xil renderer, ovoz, mavzu, fon animatsiyasi vaqti va oxirgi kadr saqlanadi: tomoshabin
chegarani sezmaydi."""
from __future__ import annotations

import copy
import math
import os
import queue
import shutil
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import bgfx, pronounce, streamgen
from .config import Config
from .render import Renderer
from .renderpool import RenderPool
from .util import esc, fmt_dur, human_size, log, run, tb_short
from .hwenc import HW, HW_ERR, MC_BOOST, auto_kbps
from .streamsys import StreamSystem, build_output, parse_extra
from .video import VideoBuilder, VideoError

KV = "stream:cur"
MAX_QUEUE = 60


class StreamError(Exception):
    pass


class _HwFail(StreamError):
    """GPU kodlovchi xato berdi: butun bo'lak CPU da qayta kodlanadi (bir bo'lakda kodlovchilar aralashmasin)."""


class _Cancel(Exception):
    pass


class StreamCfg:
    """Asosiy sozlamalar ustiga translatsiya sozlamalarini qo'yuvchi qobiq (asosiy video sozlamalari o'zgarmaydi)."""
    int = Config.int
    float = Config.float
    bool = Config.bool
    list = Config.list
    size = Config.size
    base_size = Config.base_size

    def __init__(self, cfg, over: dict):
        self._cfg = cfg
        self.over = dict(over)

    def get(self, key, default=None):
        if key in self.over:
            return str(self.over[key])
        return self._cfg.get(key, default)

    def __getattr__(self, name):
        return getattr(self._cfg, name)


def _ffprobe_dur(path) -> float:
    rc, out, _ = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                     timeout=60)
    try:
        return max(0.0, float(out.strip().splitlines()[0]))
    except (ValueError, IndexError):
        return 0.0


def _has_audio(path) -> bool:
    rc, out, _ = run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index",
                      "-of", "csv=p=0", str(path)], timeout=60)
    return rc == 0 and bool(out.strip())


def valid_fps(v) -> int:
    try:
        v = int(v)
    except (TypeError, ValueError):
        return 25
    return v if 10 <= v <= 60 and 44100 % v == 0 else 25


class Stream:
    """Bitta ilova uchun yagona translatsiya boshqaruvchisi (bir vaqtda bitta efir)."""

    def __init__(self, app):
        self.app = app
        self.cfg, self.db = app.cfg, app.db
        self.lock = threading.RLock()
        self.cv = threading.Condition(self.lock)
        self.s: dict = self.db.kv_json(KV, None) or {}
        self.end_evt = threading.Event()
        self.skip_evt = threading.Event()
        self.threads: list = []
        self.sys = StreamSystem(self)      # telemetriya, nazoratchi, profillar, qo'shimcha manzillar, rejalashtirish
        self._reset_runtime()
        if self.s.get("state") in ("starting", "live", "ending"):
            old = self.s.get("broadcast_id")
            self.s["state"] = "ended"
            self.s["note"] = "dastur qayta ishga tushganda efir uzildi"
            self._save()
            if old:
                threading.Thread(target=self._yt_complete, args=(old,), daemon=True, name="stream-recover").start()
            app.n.say("⚠️ <b>Translatsiya uzildi:</b> dastur qayta ishga tushdi. YouTube Studio'da efir holatini "
                      "tekshiring. Yangi efir: /stream")

    # ------------------------------------------------------------------ holat
    def _reset_runtime(self):
        self.cur = None                 # hozir efirda bo'lak (ticket)
        self.cur_t0 = 0.0
        self.ready: list = []           # tayyor bo'laklar (diskda, efir tartibida)
        self.pp = None                  # faol AI element uchun oldindan tayyorlovchi
        self.job: dict = {}             # hozir chizilayotgan bo'lak (progress)
        self.speed = 0.0                # tayyorlash tezligi (efir tezligiga nisbatan, x)
        self.t_off = 0.0                # fon animatsiyasi uzluksiz vaqti
        self.pool = None
        self.rpool = None
        self.rproc = None
        self.spec_base = None
        self.tts_workers = 3
        self.threads_each = 0
        self.ready_dir = None
        self.go_evt = threading.Event()
        self.fl = threading.Lock()
        self.pstage = {}
        self.bench = 0.0
        self.workers = 2
        self.chunks: list = []          # joriy fayl elementining qolgan bo'laklari
        self.gen = None                 # faol AI element holati
        self.last_gen = None
        self.stopping = False
        self.farewell_made = False
        self.killed = False
        self.cancel_gen = False
        self.t_out = 0.0                # efirga uzatilgan jami vaqt (uzluksiz tamg'a uchun)
        self.pusher = None
        self.pusher_err: list = []
        self.restarts = 0
        self.renderer = None
        self.last_content = None
        self.filler = None
        self.prep_info = ""             # producer hozir nima qilayotgani
        self.prep_t0 = 0.0
        self.asked = None               # {"msg": id, "t0": time}
        self.slow = False
        self.played = 0
        self.play_log: list = []        # efirda o'ynalgan bo'laklar yorliqlari (tashxis/sinov uchun)
        self.live_t0 = 0.0
        self.yt = {}
        self.yt_bad = 0
        self.params: dict = {}
        self.ready_evt = threading.Event()
        self.init_evt = threading.Event()
        self.end_evt = threading.Event()
        self.skip_evt = threading.Event()
        self.work = None

    @property
    def nxt(self):
        r = self.ready
        return r[0] if r else None

    @property
    def state(self) -> str:
        return self.s.get("state", "")

    def active(self) -> bool:
        return self.state in ("starting", "live", "ending")

    def _save(self):
        try:
            self.db.kv_set_json(KV, self.s)
        except Exception as e:  # noqa: BLE001
            log.warning("Stream holati saqlanmadi: %s", e)

    def say(self, text, markup=None):
        return self.app.n.say(text, markup=markup)

    # ------------------------------------------------------------------ qoralama
    def _join_old(self):
        for th in self.threads:
            if th is not threading.current_thread():
                th.join(timeout=10)
        self.threads = []

    def create(self, title: str, desc: str = "", topic: str = "") -> dict:
        self._join_old()
        with self.lock:
            if self.active():
                raise StreamError("Efir ketayotgan paytda yangisini yaratib bo'lmaydi")
            self._cleanup_files(full=True)
            self._reset_runtime()
            self.s = {"id": uuid.uuid4().hex[:8], "title": title.strip()[:100] or "Jonli translatsiya",
                      "desc": desc.strip()[:4000], "topic": (topic or title).strip()[:300], "thumb": "", "queue": [],
                      "state": "draft", "infinite": False, "created": time.time()}
            self._save()
            return self.s

    def exists(self) -> bool:
        return bool(self.s.get("id")) and self.state in ("draft", "starting", "live", "ending")

    def set_field(self, key, value):
        with self.lock:
            if key in ("title", "desc", "topic"):
                self.s[key] = str(value).strip()[:4000 if key == "desc" else 300]
            self._save()

    def thumb_path(self) -> Path:
        d = self.cfg.dirs["work"] / "stream"
        d.mkdir(parents=True, exist_ok=True)
        return d / "thumb.jpg"

    def set_thumb(self, src: Path | None):
        """Efir rasmi: yuborilgan rasm 1280x720 JPEG ga keltiriladi. None: o'chiradi."""
        from PIL import Image, ImageOps
        with self.lock:
            dst = self.thumb_path()
            if src is None:
                try:
                    dst.unlink()
                except OSError:
                    pass
                self.s["thumb"] = ""
            else:
                im = Image.open(src)
                im.load()
                im = ImageOps.fit(im.convert("RGB"), (1280, 720), Image.LANCZOS)
                im.save(dst, "JPEG", quality=90)
                self.s["thumb"] = str(dst)
            self._save()

    def _load_thumb(self):
        from PIL import Image
        p = self.s.get("thumb")
        if p and Path(p).exists():
            try:
                im = Image.open(p)
                im.load()
                return im.convert("RGB")
            except Exception:  # noqa: BLE001
                return None
        return None

    # ------------------------------------------------------------------ navbat
    def _item(self, kind, title, **kw) -> dict:
        it = {"id": uuid.uuid4().hex[:6], "kind": kind, "title": title[:80], "est": 0.0}
        it.update(kw)
        return it

    def add_file(self, path, title="", gno=None, owned=False) -> dict:
        p = Path(path)
        if not p.exists():
            raise StreamError("Video fayl topilmadi")
        dur = _ffprobe_dur(p)
        if dur < 1:
            raise StreamError("Video o'qib bo'lmadi (ffprobe)")
        with self.lock:
            if len(self.s.get("queue", [])) >= MAX_QUEUE:
                raise StreamError(f"Navbat to'lgan (maks. {MAX_QUEUE})")
            if self.state not in ("draft", "live"):
                raise StreamError("Avval translatsiya yarating")
            it = self._item("file", title or p.stem, path=str(p), gno=gno, est=dur, owned=bool(owned))
            self.s.setdefault("queue", []).append(it)
            self._save()
            self.cv.notify_all()
            return it

    def add_gen(self, topic: str, segs: int | None = None) -> dict:
        segs = self.cfg.int("STREAM_GEN_SEGS") if segs is None else segs
        with self.lock:
            if len(self.s.get("queue", [])) >= MAX_QUEUE:
                raise StreamError(f"Navbat to'lgan (maks. {MAX_QUEUE})")
            if self.state not in ("draft", "live"):
                raise StreamError("Avval translatsiya yarating")
            seg_s = self.cfg.float("STREAM_SEG_SEC")
            it = self._item("gen", topic, topic=topic[:300], segs=int(segs), est=(segs * seg_s if segs else math.inf))
            self.s.setdefault("queue", []).append(it)
            self._save()
            self.cv.notify_all()
            return it

    def remove(self, item_id) -> bool:
        with self.lock:
            q = self.s.get("queue", [])
            for i, it in enumerate(q):
                if it["id"] == item_id:
                    q.pop(i)
                    self._drop_item_files(it)
                    self._save()
                    return True
        return False

    def move(self, item_id, delta: int) -> bool:
        with self.lock:
            q = self.s.get("queue", [])
            for i, it in enumerate(q):
                if it["id"] == item_id:
                    j = max(0, min(len(q) - 1, i + delta))
                    q.insert(j, q.pop(i))
                    self._save()
                    return True
        return False

    def clear_queue(self):
        with self.lock:
            for it in self.s.get("queue", []):
                self._drop_item_files(it)
            self.s["queue"] = []
            self._save()

    def _drop_item_files(self, it):
        if it.get("owned") and it.get("path"):
            try:
                Path(it["path"]).unlink()
            except OSError:
                pass

    # ------------------------------------------------------------------ sozlamalar
    def _bg_step(self, fps: int) -> int:
        """Fon animatsiyasi qadami (necha kadrda bir yangilanadi). STREAM_BG_FPS=0 (avto) — animatsiya kadr tezligi
        efir FPS iga TENG (har kadr yangilanadi, silliq); aks holda berilgan kadr/s ga yaqin. Harakat TEZLIGI (soniyadagi
        siljish) fps dan qat'i nazar bir xil — faqat silliqlik fps ga bog'liq."""
        bgf = self.cfg.int("STREAM_BG_FPS")
        return 1 if bgf <= 0 else max(1, int(round(fps / max(4, min(bgf, fps)))))

    def _params(self) -> dict:
        c = self.cfg
        fps = valid_fps(c.get("STREAM_FPS"))
        fmt = "shorts" if c.get("STREAM_FORMAT").lower().startswith("short") else "landscape"
        res = c.int("STREAM_RES")
        res = 480 if res <= 480 else 1080 if res >= 1080 else 720
        kb = c.int("STREAM_BITRATE")
        if kb <= 0:                                  # 0 = avto (o'lcham va fps ga qarab)
            kbps = auto_kbps(res, fps)
            if HW.peek() == "mediacodec":            # telefon apparat kodlovchisi bir xil bitrate da x264 dan zaifroq: sifat uchun +25%
                kbps = int(kbps * MC_BOOST)
        else:
            kbps = max(300, min(25000, kb))
        return {"res": res, "fps": fps, "fmt": fmt, "kbps": kbps,
                "seg": max(5.0, c.float("STREAM_SEG_SEC")), "warn": c.float("STREAM_WARN_SEC"),
                "ask_to": c.float("STREAM_ASK_TIMEOUT"), "drop": max(0.0, c.float("STREAM_DROP_DELAY")),
                "midcut": c.bool("STREAM_MIDCUT"),
                "wait": (0.0 if c.float("STREAM_PREROLL_WAIT") <= 0 else max(60.0, c.float("STREAM_PREROLL_WAIT"))),   # 0 = cheksiz kutish
                "cap": max(0, c.int("STREAM_BUFFER_CAP")),                                                               # 0 = zaxira CHEKSIZ
                "batch": max(1, min(10, c.int("STREAM_BATCH"))),
                "step": self._bg_step(fps),
                "buffer": max(1, min(30, c.int("STREAM_BUFFER"))),
                "preroll": max(1, min(30, c.int("STREAM_PREROLL"))),
                "part": max(5.0, c.float("STREAM_PART_SEC")),
                "crf": max(10, min(40, c.int("STREAM_CRF") or 20)),
                "preset": (c.get("STREAM_PRESET") or "superfast").strip().lower()
                if (c.get("STREAM_PRESET") or "").strip().lower() in
                ("ultrafast", "superfast", "veryfast", "faster", "fast") else "superfast"}

    def _scfg(self) -> StreamCfg:
        p = self.params
        return StreamCfg(self.cfg, {"VIDEO_RES": p["res"], "VIDEO_FPS": p["fps"], "VIDEO_FORMAT": p["fmt"],
                                    "MUSIC": "1" if self.cfg.bool("STREAM_MUSIC") else "0", "VIDEO_CRF": "24"})

    # ------------------------------------------------------------------ boshlash
    def start(self) -> str | None:
        """Efirni boshlaydi (alohida oqimda). Xato matnini qaytaradi yoki None."""
        self._join_old()
        try:                                         # kodlovchi (GPU/telefon/CPU) lock'dan TASHQARIDA sinab olinadi (bir marta, keshlanadi)
            HW.bind(self.cfg)
            HW.detect()
        except Exception as e:  # noqa: BLE001
            log.warning("Kodlovchini aniqlab bo'lmadi: %s", e)
        with self.lock:
            if self.state != "draft":
                return "Efir qoralamasi yo'q yoki allaqachon ketyapti"
            if not self.s.get("queue"):
                return "Navbat bo'sh: avval kamida bitta video yoki AI bo'lak qo'shing"
            if self.cfg.get("STREAM_MODE") == "api":
                if not self.app.yt.authorized():
                    return "YouTube ulanmagan (/yt). Yoki /set STREAM_MODE manual va RTMP kalit kiriting"
            elif not self.cfg.get("STREAM_TEST") and not self.cfg.get("STREAM_KEY"):
                return "RTMP kalit kiritilmagan (Translatsiya → Sozlamalar → Kalit)"
            self._reset_runtime()
            self.params = self._params()
            self.work = self.cfg.dirs["work"] / "stream" / self.s["id"]
            shutil.rmtree(self.work, ignore_errors=True)
            self.work.mkdir(parents=True, exist_ok=True)
            self.ready_dir = self.work / "ready"
            self.ready_dir.mkdir(parents=True, exist_ok=True)
            cpu = os.cpu_count() or 2
            w = self.cfg.int("STREAM_WORKERS")
            w = w if w > 0 else max(2, min(16, cpu))        # barcha yadrolar (10 tagacha) ishlaydi
            self.workers = max(1, min(16, w))
            self.threads_each = max(1, cpu // self.workers)
            self.tts_workers = 24          # barcha sahna ovozlari bir vaqtda (har biri alohida qayta uriniladi)
            self.s["queue_backup"] = copy.deepcopy(self.s.get("queue", []))
            self.s["state"] = "starting"
            self.s["started"] = time.time()
            self.s["infinite"] = not self.cfg.bool("STREAM_ASK_END")     # so'ralmaydi: kontent tugasa AI bo'laklar cheksiz davom etadi
            self._save()
        for fn, name in ((self._producer, "stream-gen"), (self._feeder, "stream-feed"), (self._watcher, "stream-watch")):
            th = threading.Thread(target=self._guard, args=(fn, name), daemon=True, name=name)
            th.start()
            self.threads.append(th)
        threading.Thread(target=self._go_live, daemon=True, name="stream-start").start()
        return None

    def _guard(self, fn, name):
        """Oqim yiqilsa xato yoziladi, adminga aytiladi va oqim qayta ishga tushadi (efir to'xtamaydi)."""
        fails = 0
        while not self.end_evt.is_set():
            try:
                fn()
                return
            except Exception as e:  # noqa: BLE001
                fails += 1
                log.error("%s oqimi xatosi: %s\n%s", name, e, tb_short(1200))
                if fails in (1, 5):
                    self.app.n.error(f"Translatsiya ({name}) xatosi", f"{type(e).__name__}: {e}")
                if fails >= 20:
                    self.say("🛑 Translatsiya ichki xato tufayli to'xtatildi.")
                    self.kill("ichki xato")
                    return
                self.end_evt.wait(min(30, 2 * fails))

    def _go_live(self):
        try:
            self._init_renderer()
            self._benchmark()
            self.filler = self._make_filler()
            self.init_evt.set()
            self.sys.start()
            need = self.params["preroll"]
            self.say(f"⏳ <b>Efir tayyorlanmoqda:</b> oldin <b>{need}</b> ta bo'lak (har biri ~{fmt_dur(self.params['seg'])}) "
                     "tayyorlanadi, so'ng efir ochiladi.\n" + self.sys.encoder_line() +
                     "\n<i>Tezlashtirish: «▶️ Hozir boshlash» tayyor bo'laklar bilan darhol yoqadi.</i>", markup={"inline_keyboard": [[{"text": "▶️ Hozir boshlash", "callback_data": "st:now"},
                                                                  {"text": "📡 Panel", "callback_data": "st:home"}]]})
            t0 = time.time()
            while True:
                if self.end_evt.is_set():
                    return
                with self.lock:
                    n = len(self.ready)
                    more = self._has_work()
                if n >= need or (n > 0 and not more) or (n > 0 and self.go_evt.is_set()):
                    break
                if n > 0 and self.params["wait"] > 0 and time.time() - t0 > self.params["wait"]:
                    self.say(f"⏱ Preroll vaqti ({fmt_dur(self.params['wait'])}) tugadi: tayyor <b>{n}</b> ta bo'lak bilan "
                             "efir boshlanmoqda; qolganlari efir davomida tayyorlanadi.")
                    break
                if time.time() - t0 > 4 * 3600:
                    if n > 0 and self.params["wait"] > 0:
                        break
                    if n == 0 and time.time() - t0 > 6 * 3600:
                        raise StreamError("Birinchi bo'lak 6 soatda tayyor bo'lmadi")
                self.ready_evt.wait(2)
                self.ready_evt.clear()
            if self.end_evt.is_set():
                return
            self._open_broadcast()
            self._ensure_pusher()
            with self.lock:
                self.s["state"] = "live"
                self.live_t0 = time.time()
                self._save()
                self.cv.notify_all()
            url = self.s.get("url") or ""
            self.say(f"🔴 <b>Efir boshlandi!</b>\n{esc(self.s['title'])}" + (f"\n{url}" if url else ""),
                     markup={"inline_keyboard": [[{"text": "📡 Boshqaruv", "callback_data": "st:home"}]]})
        except _Cancel:
            return
        except Exception as e:  # noqa: BLE001
            log.error("Efirni boshlash xatosi: %s\n%s", e, tb_short(1500))
            self.say(f"❌ <b>Efirni boshlab bo'lmadi:</b> {esc(str(e)[:400])}")
            self.kill("boshlash xatosi", notify=False, final_state="draft")

    # ------------------------------------------------------------------ YouTube Live
    def _open_broadcast(self):
        c = self.cfg
        if c.get("STREAM_MODE") == "api":
            yt = self.app.yt
            info = yt.live_create(self.s["title"], self.s.get("desc", ""), c.get("STREAM_PRIVACY") or "public")
            self.s.update(broadcast_id=info["broadcast_id"], url=info["url"], rtmp=info["rtmp"], key=info["key"])
            self._save()
            th = self.thumb_path()
            if self.s.get("thumb") and th.exists():
                try:
                    yt.set_thumbnail(info["broadcast_id"], th)
                except Exception as e:  # noqa: BLE001
                    log.warning("Efir rasmi qo'yilmadi: %s", e)
        else:
            self.s["rtmp"], self.s["key"] = c.get("STREAM_RTMP_URL"), c.get("STREAM_KEY")
            self.s["url"] = ""
        self._save()

    def _yt_complete(self, bid):
        try:
            self.app.yt.live_transition(bid, "complete")
        except Exception as e:  # noqa: BLE001
            log.info("Efirni yakunlash: %s", str(e)[:200])

    def _out_target(self) -> list:
        """Pusher chiqishi: sinov fayli | bitta YouTube manzili | YouTube + qo'shimcha manzillar (tee)."""
        url = (self.s.get("rtmp") or "").rstrip("/") + "/" + (self.s.get("key") or "")
        return build_output(url, parse_extra(self.cfg.get("STREAM_EXTRA_RTMP")), self.cfg.get("STREAM_TEST"))

    def _ensure_pusher(self):
        """Doimiy ffmpeg (RTMP/fayl) ishlayotganini ta'minlaydi; o'lgan bo'lsa qayta ishga tushiradi.
        `-progress` orqali uzatish ko'rsatkichlari (bitrate, tezlik, tashlangan kadrlar) nazoratga uzatiladi."""
        with self.lock:
            p = self.pusher
            if p is not None and p.poll() is None:
                return p
            if p is not None:
                self.restarts += 1
                self.sys.tel.event("w", f"pusher qayta ishga tushirilmoqda ({self.restarts})")
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-re", "-f", "mpegts", "-i", "pipe:0", "-c", "copy",
                   "-progress", "pipe:1", "-stats_period", "2"] + self._out_target()
            self.pusher_err = []
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.pusher = p
            self.sys.tel.reset_push()

            def drain(proc=p, buf=self.pusher_err):
                for line in proc.stderr:
                    buf.append(line.decode("utf-8", "replace").strip())
                    del buf[:-12]

            def progress_reader(proc=p):
                try:
                    for line in proc.stdout:
                        self.sys.tel.feed_line(line.decode("utf-8", "replace"))
                except (OSError, ValueError):
                    pass

            threading.Thread(target=drain, daemon=True, name="stream-pusher-log").start()
            threading.Thread(target=progress_reader, daemon=True, name="stream-progress").start()
            return p

    def _push(self, chunk: bytes):
        for attempt in range(4):
            try:
                p = self._ensure_pusher()
                p.stdin.write(chunk)
                p.stdin.flush()
                return
            except (BrokenPipeError, OSError, ValueError):
                log.warning("Pusher uzildi (urinish %d): %s", attempt + 1, " | ".join(self.pusher_err[-2:]))
                try:
                    if self.pusher:
                        self.pusher.kill()
                except OSError:
                    pass
                if self.end_evt.wait(min(5, 1 + attempt)):
                    return
        raise StreamError("RTMP ga yozib bo'lmadi: " + " | ".join(self.pusher_err[-2:]))

    # ------------------------------------------------------------------ renderer / filler
    def _init_renderer(self):
        sc = self._scfg()
        seed = int(self.s["id"], 16) % 997
        art = self._load_thumb()          # faqat foydalanuvchi yuborgan rasm (AI rasm yaratilmaydi)
        bgs = (self.cfg.get("BG_STYLE") or "auto").strip().lower()
        style = bgfx.style_for(seed) if bgs not in bgfx.STYLES else bgs
        rargs = dict(accent_idx=seed, episode_label="LIVE", channel=self.cfg.get("CHANNEL_NAME"), style=style, seed=seed,
                     art=art, card=art)
        self.renderer = Renderer(sc, **rargs)
        self.renderer.show_progress = False
        # parallel qismlar uchun renderer puli (har ishchiga bittadan; Renderer oqim-xavfsiz emas)
        if self.pool is not None:
            self.pool.shutdown(wait=False, cancel_futures=True)
        self.rpool = queue.Queue()
        self.rpool.put(self.renderer)
        for _ in range(self.workers):
            r = Renderer(sc, accent_idx=seed, episode_label="LIVE", channel=self.cfg.get("CHANNEL_NAME"),
                         style=style, seed=seed, art=art, card=art)
            r.show_progress = False
            self.rpool.put(r)
        self.pool = ThreadPoolExecutor(max_workers=self.workers, thread_name_prefix="stream-part")
        # haqiqiy parallel: har ishchi alohida jarayon (Python GIL cheklovisiz). Ishlamasa oqimlarga o'tiladi.
        if self.rproc is not None:
            self.rproc.close()
            self.rproc = None
        npr = self.cfg.int("STREAM_PROCS")
        npr = (min(8, os.cpu_count() or 2) if npr == 0 else npr)
        if npr > 0:
            self.rproc = RenderPool(npr, self.cfg.root)
            safe = {k: v for k, v in self.cfg.overrides.items()
                    if not any(x in k.upper() for x in ("KEY", "TOKEN", "SECRET", "PASSWORD"))}
            self.spec_base = {"rkey": f"{seed}:{sc.get('VIDEO_RES')}:{sc.get('VIDEO_FPS')}:{sc.get('VIDEO_FORMAT')}:{style}",
                              "rargs": rargs,
                              "cfg": {"root": str(self.cfg.root), "env_file": str(self.cfg.env_file), "overrides": safe,
                                      "over": dict(sc.over)}}

    def _codec(self, still=True, force_cpu=False) -> list:
        """Stream kodeki (kodek + SIFAT + piksel formati + kalit kadr har 2 s). GPU (NVENC/QSV/AMF) bo'lsa — doimiy sifat (CQ)
        + bitrate chegarasi; bo'lmasa libx264 (CRF + tanlangan preset). Sifat kodlovchiga qarab tushib ketmaydi."""
        p = self.params or self._params()
        return HW.venc("stream", p["fps"], p["kbps"], p.get("crf", 20), p["preset"], p["res"], still=still,
                       force_cpu=force_cpu)

    def _venc(self, still=True) -> list:
        """_codec + kadr tezligi (`-r`) — to'g'ridan-to'g'ri ffmpeg buyrug'iga qo'yish uchun."""
        p = self.params or self._params()
        return self._codec(still=still) + ["-r", str(p["fps"])]

    def _bench_costs(self):
        """O'lchov: (to'liq kadr chizish s, bitta kadr kodlash s, piksellar). Eng yomon holat: har kadrda mazmun qayta chiziladi."""
        rd = self.rpool.get_nowait()
        try:
            p = self.params
            W, H = self._scfg().size
            n = 6
            scn = {"type": "bullets", "heading": "Test", "bullets": ["Birinchi nuqta", "Ikkinchi nuqta", "Uchinchi nuqta"],
                   "narration": "x", "chapter": ""}
            t0 = time.time()
            for i in range(n):
                rd.frame(scn, 3, 1.0, None, 0.0, t=i * 0.3, age=1.0 + i * 0.1)
            full = (time.time() - t0) / n
        finally:
            self.rpool.put(rd)
        codec = self._codec(still=False)
        t0 = time.time()
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
               f"testsrc2=s={W}x{H}:r={p['fps']}:d=3"] + codec + (["-threads", "1"] if not HW.is_hw(codec) else []) \
              + ["-f", "null", "-"]
        rc, _, err = run(cmd, timeout=120)
        if rc != 0 and HW.is_hw(codec):            # GPU o'lchovda yiqildi: CPU bilan qayta o'lchaymiz
            HW.report(codec, False, err)
            codec = self._codec(still=False, force_cpu=True)
            t0 = time.time()
            rc, _, err = run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                              f"testsrc2=s={W}x{H}:r={p['fps']}:d=3"] + codec + ["-threads", "1", "-f", "null", "-"], timeout=120)
        enc = (time.time() - t0) / (3 * p["fps"]) if rc == 0 else 0.03
        return full, max(enc, 1e-4), W * H

    def _estimate(self, costs, res, fps, ultrafast=False) -> float:
        """Taxminiy tayyorlash tezligi (x real vaqt) berilgan sifat uchun."""
        full, enc, px0 = costs
        W, H = (res * 16 // 9, res) if self.params["fmt"] != "shorts" else (res, res * 16 // 9)
        k = (W * H) / float(px0)
        step = self._bg_step(fps)
        per_frame = full * k * 1.6 / step + enc * k * (0.7 if ultrafast else 1.0)
        par = max(1, min(self.workers, os.cpu_count() or 1))
        nm = HW.pick()
        if nm != "cpu":                       # GPU: bir vaqtda ochiladigan sessiyalar soni bilan cheklangan
            par = max(1, min(par, HW.sessions(nm)))
        return par / per_frame / fps * 0.8

    def _benchmark(self):
        """Qurilma tezligini o'lchaydi; sekin bo'lsa (STREAM_AUTO=1) sifatni avtomatik tushiradi — efir uzilmasligi uchun."""
        try:
            costs = self._bench_costs()
        except Exception as e:  # noqa: BLE001
            log.info("Tezlik o'lchovi bajarilmadi: %s", e)
            return
        p = self.params
        target = max(1.0, self.cfg.float("STREAM_TARGET_SPEED"))
        self.bench = self._estimate(costs, p["res"], p["fps"])
        log.info("Stream o'lchovi: kadr %.0fms, kodlash %.0fms (%dpx) -> ~%.1fx real vaqt", costs[0] * 1000, costs[1] * 1000,
                 costs[2], self.bench)
        if self.bench < target and self.cfg.bool("STREAM_AUTO"):
            opts = [(p["res"], p["fps"], False)]
            for res, fps in ((720, 25), (720, 20), (480, 25), (480, 20), (480, 15)):
                if (res, fps) != (p["res"], p["fps"]) and res <= p["res"] and fps <= p["fps"]:
                    opts.append((res, fps, True))
            if p["res"] >= 720:
                opts.insert(1, (p["res"], p["fps"], True))
            best = None
            for res, fps, uf in opts:
                e = self._estimate(costs, res, fps, uf)
                best = (res, fps, uf, e)
                if e >= target:
                    break
            res, fps, uf, e = best
            if (res, fps, uf) != (p["res"], p["fps"], False):
                old = f"{p['res']}p/{p['fps']}fps"
                old_est = self.bench
                with self.lock:
                    p["res"], p["fps"] = res, fps
                    p["step"] = self._bg_step(fps)
                    p["kbps"] = min(p["kbps"], 1200 if res <= 480 else p["kbps"])
                    if uf:
                        p["preset"] = "ultrafast"
                self._init_renderer()          # yangi o'lchamda renderer puli
                self.bench = e
                self.say(f"⚙️ <b>Qurilma sekin</b> (taxminan {old_est:.1f}× o'rniga): efir uzilmasligi uchun "
                         f"sifat avtomatik <b>{res}p / {fps} fps</b>{' / ultrafast' if uf else ''} ga tushirildi (oldin {old}). "
                         f"Taxminiy tezlik: <b>{e:.1f}×</b>. O'chirish: /set STREAM_AUTO 0")
                return
        if self.bench < 1.2:
            self.say(f"⚠️ <b>Qurilma sekin:</b> taxminiy tezlik <b>{self.bench:.1f}×</b>. /stream → ⚙️ Sifat: "
                     "<b>480p</b>, <b>20 fps</b>, STREAM_PRESET=<b>ultrafast</b> tanlang. "
                     f"Preroll {fmt_dur(self.params['wait'])} dan oshmaydi.")
        elif self.bench < 3:
            self.say(f"ℹ️ Tayyorlash tezligi taxminan <b>{self.bench:.1f}×</b>: {self.params['preroll']} ta bo'lak "
                     f"~{fmt_dur(self.params['seg'] * self.params['preroll'] / self.bench)} oladi. "
                     "Kutmaslik uchun «▶️ Hozir boshlash» ni bosing.")

    def _make_filler(self) -> dict | None:
        """Keyingi bo'lak kech qolsa ko'rsatiladigan qisqa 'kuting' lavhasi."""
        try:
            rd = self.renderer
            text = {"uz": "Keyingi qism tayyorlanmoqda…", "en": "Next part is being prepared…"}.get(
                (self.cfg.get("LANGUAGE") or "uz").lower()[:2], "…")
            img = rd.frame({"type": "title", "title": self.s["title"], "label": "LIVE", "subtitle": text,
                            "narration": "", "chapter": ""}, 0, 1.0, None, 0.0, t=0.0, age=99.0)
            png = self.work / "filler.png"
            img.save(png)
            out = self.work / "filler.mp4"
            fps = self.params["fps"]
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-framerate", str(fps), "-i", str(png),
                   "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", "4"] + self._venc() + [
                   "-c:a", "aac", "-b:a", "96k", "-ar", "44100", "-ac", "1", "-shortest",
                   "-movflags", "+faststart", str(out)]
            rc, _, err = run(cmd, timeout=120)
            if rc != 0 or not out.exists():
                log.warning("Kuting lavhasi yasalmadi: %s", err[-200:])
                return None
            tk = {"kind": "filler", "label": "kuting", "dur": 4.0, "data": out.read_bytes()}
            out.unlink()
            png.unlink()
            return tk
        except Exception as e:  # noqa: BLE001
            log.warning("Kuting lavhasi xatosi: %s", e)
            return None

    # ------------------------------------------------------------------ producer
    # Tayyorlash tuzilmasi (hammasi alohida oqimlarda, bir vaqtda):
    #   prepper (har AI element uchun)  : ssenariy (LLM) -> ovoz (parallel TTS) -> vaqt rejasi  [keyingi 2 bo'lak oldindan]
    #   producer                        : tayyor rejani ~STREAM_PART_SEC soniyalik qismlarga bo'lib parallel chizadi/kodlaydi,
    #                                     ulaydi va diskka (ready/) tayyor bo'lak sifatida qo'yadi
    #   feeder                          : tayyor bo'lakni diskdan RAMga olib efirga uzatadi (RAMda faqat joriy bo'lak)
    def _has_work(self) -> bool:
        if self.stopping:
            return not self.farewell_made
        pp = self.pp
        return bool(self.chunks or pp or (self.gen and (self.gen["left"] is None or self.gen["left"] > 0))
                    or self.s.get("queue") or self.s.get("infinite"))

    def _room(self) -> bool:
        """Yangi bo'lak tayyorlashga joy bormi. Zaxira CHEKSIZ (STREAM_BUFFER_CAP=0): vaqt/soni bo'yicha chegara yo'q — faqat
        diskni to'ldirib yubormaslik himoyasi (STREAM_MIN_DISK_MB). Zaxira bo'sh bo'lsa har doim tayyorlanadi."""
        cap = self.params.get("cap", 0)
        if cap and len(self.ready) >= cap:
            return False
        if not self.ready:
            return True
        try:
            mn = max(200, self.cfg.int("STREAM_MIN_DISK_MB")) * 1024 * 1024
            if shutil.disk_usage(str(self.work or ".")).free < mn:
                return False
        except (OSError, TypeError):
            pass
        return True

    def _producer(self):
        while not self.end_evt.is_set() and not self.init_evt.is_set():
            self.init_evt.wait(0.5)
        while not self.end_evt.is_set():
            with self.cv:
                while not self.end_evt.is_set() and not (self._room() and self._has_work()
                                                        and self.state in ("starting", "live")):
                    self.cv.wait(1.0)
            if self.end_evt.is_set():
                return
            self.prep_t0 = time.time()
            try:
                tk = self._make_next()
            except _Cancel:
                self.cancel_gen = False
                self.prep_info = ""
                continue
            except Exception as e:  # noqa: BLE001
                self.prep_info = ""
                self.job = {}
                log.error("Bo'lak tayyorlash xatosi: %s\n%s", e, tb_short(1500))
                self.app.n.error("Translatsiya: bo'lak tayyorlanmadi", f"{type(e).__name__}: {e}")
                self.end_evt.wait(20)
                continue
            self.prep_info = ""
            self.job = {}
            if tk is None:
                self.end_evt.wait(1)
                continue
            tk["made_in"] = time.time() - self.prep_t0
            if tk["kind"] in ("gen", "file") and tk["made_in"] > 0:
                sp = tk["dur"] / tk["made_in"]
                self.speed = sp if not self.speed else 0.6 * self.speed + 0.4 * sp
                if self.played > 0 and not self.ready and sp < 1.0:
                    self.slow = True
            with self.cv:
                if self.stopping and tk["kind"] != "farewell":
                    self._drop_ticket(tk)
                    continue
                self.ready.append(tk)
                if tk["kind"] == "farewell":
                    self.farewell_made = True
                self.cv.notify_all()
            self.ready_evt.set()

    def _drop_ticket(self, tk):
        tk["data"] = None
        p = tk.get("path")
        if p:
            try:
                Path(p).unlink()
            except OSError:
                pass

    def _make_next(self) -> dict | None:
        with self.lock:
            if self.stopping:
                if self.farewell_made:
                    return None
                mode = "farewell"
            elif self.chunks:
                mode = "chunk"
            elif self.gen and (self.pp or self.gen["left"] is None or self.gen["left"] > 0):
                mode = "gen"
            else:
                mode = ""
                q = self.s.get("queue", [])
                if q:
                    item = q.pop(0)
                    self._save()
                    if item["kind"] == "file":
                        self._begin_file(item)
                        mode = "chunk"
                    else:
                        self.gen = {"item": item["id"], "title": self.s["title"], "topic": item["topic"],
                                    "seg_no": 0, "left": (item["segs"] or None), "summaries": [], "covered": [],
                                    "carry": "", "tail": "", "hook": item["topic"]}
                        mode = "gen"
                elif self.s.get("infinite"):
                    if self.last_gen:
                        self.gen = self.last_gen
                        self.gen["left"] = None
                    else:
                        self.gen = {"item": "inf", "title": self.s["title"], "topic": self.s.get("topic") or self.s["title"],
                                    "seg_no": 0, "left": None, "summaries": [], "covered": [], "carry": "", "tail": "",
                                    "hook": self.s.get("topic") or self.s["title"]}
                    mode = "gen"
                else:
                    return None
        if mode == "chunk":
            return self._make_chunk()
        if mode == "farewell":
            self._stop_prepper()
            return self._make_gen_seg(final=True)
        return self._make_gen_seg(final=False)

    # ---- yordamchilar: ishchi puli, renderer puli, kodek
    def _tick(self, n):
        """Chizilgan kadrlar hisobi (parallel qismlardan) — panelda foiz va kadr/s ko'rsatish uchun."""
        with self.fl:
            self.job["frames"] = self.job.get("frames", 0) + n

    def _borrow(self):
        while True:
            try:
                return self.rpool.get(timeout=0.5)
            except queue.Empty:
                if self.end_evt.is_set():
                    raise _Cancel()

    def _release(self, r):
        self.rpool.put(r)

    # ---- fayl elementlari
    def _begin_file(self, item):
        seg = self.params["seg"]
        dur = item.get("est") or _ffprobe_dur(item["path"])
        n = max(1, int(round(dur / seg)))
        L = dur / n
        self.chunks = [{"item": item, "i": i, "n": n, "ss": i * L, "len": L if i < n - 1 else max(0.5, dur - i * L)}
                       for i in range(n)]

    def _make_chunk(self) -> dict:
        """Fayl bo'lagi: video ~PART_SEC soniyalik qismlarga bo'linib parallel qayta kodlanadi, ovoz bir marta kodlanadi."""
        with self.lock:
            ch = self.chunks.pop(0)
        item = ch["item"]
        p = self.params
        self.last_content = None      # fayldan keyin AI bo'lak yangi sahna bilan boshlanadi
        W, H = self._scfg().size
        fps = p["fps"]
        label = item["title"] + (f" ({ch['i'] + 1}/{ch['n']})" if ch["n"] > 1 else "")
        self.prep_info = f"fayl tayyorlanmoqda: {label}"
        wd = self.work / f"c{uuid.uuid4().hex[:6]}"
        wd.mkdir(parents=True, exist_ok=True)
        out = self.ready_dir / f"{uuid.uuid4().hex[:8]}.mp4"
        src = item["path"]
        vf = (f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,"
              f"setsar=1,fps={fps}")
        # qismlar uzunligi kadrlarga karrali: chegarada siljish bo'lmaydi
        total_f = max(1, int(round(ch["len"] * fps)))
        per = max(1, int(round(p["part"] * fps)))
        ranges = [(f0, min(total_f, f0 + per)) for f0 in range(0, total_f, per)]
        if len(ranges) > 1 and ranges[-1][1] - ranges[-1][0] < fps:
            last = ranges.pop()
            ranges[-1] = (ranges[-1][0], last[1])
        total = total_f / fps
        cur = {"codec": self._codec(still=False), "tag": ""}
        te = self.threads_each
        procs: list = []             # VIDEO qismlari jarayonlari (GPU xatosida faqat shular to'xtatiladi)
        aprocs: list = []            # ovoz qismi jarayoni (GPU xatosidan ta'sirlanmaydi)
        lock = threading.Lock()
        done = [0]
        abort = threading.Event()

        def run_ff(cmd, path, hw=False, video=True):
            def stop():
                return self.cancel_gen or self.end_evt.is_set() or (video and abort.is_set())
            if stop():
                raise _Cancel()
            pr = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            with lock:
                (procs if video else aprocs).append(pr)
            errs: list = []
            th = threading.Thread(target=lambda: errs.extend(l.decode("utf-8", "replace") for l in pr.stderr), daemon=True)
            th.start()
            while True:
                try:
                    pr.wait(timeout=0.2)         # tugashi bilan darhol uyg'onadi (uyqu bilan so'rash yo'q)
                    break
                except subprocess.TimeoutExpired:
                    if stop():
                        pr.kill()
                        pr.wait()
                        raise _Cancel()
            th.join(timeout=3)
            if pr.returncode != 0 or not Path(path).exists() or Path(path).stat().st_size < 300:
                msg = "".join(errs)[-300:]
                if hw and HW_ERR.search(msg):
                    raise _HwFail("Video tayyorlanmadi (GPU kodlovchi): " + msg)
                raise StreamError("Video tayyorlanmadi (ffmpeg): " + msg)

        def vpart(i, f0, f1):
            codec = cur["codec"]
            pth = wd / f"p{i:03d}{cur['tag']}.mp4"
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{ch['ss'] + f0 / fps:.4f}",
                   "-t", f"{(f1 - f0) / fps:.4f}", "-i", src, "-map", "0:v:0", "-an", "-vf", vf] + codec + [
                   "-threads", str(te), "-frames:v", str(f1 - f0), str(pth)]
            hw = HW.is_hw(codec)
            # GPU: bir vaqtda ochiladigan kodlash sessiyalari soni cheklangan — navbat kutiladi
            with HW.session(codec, cancel=lambda: self.cancel_gen or self.end_evt.is_set() or abort.is_set()):
                try:
                    run_ff(cmd, pth, hw)
                except _HwFail:
                    raise
                except StreamError:                 # bitta qism yiqilsa — bir marta qayta urinadi
                    pth.unlink(missing_ok=True)
                    run_ff(cmd, pth, hw)
            with lock:
                done[0] += 1
                self.job.update(done=done[0], frames=min(total_f, done[0] * per))
            return pth

        aud = wd / "a.m4a"

        def apart():
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{ch['ss']:.3f}", "-t", f"{total:.4f}", "-i", src]
            if _has_audio(src):
                cmd += ["-map", "0:a:0"]
            else:
                cmd += ["-f", "lavfi", "-t", f"{total:.4f}", "-i", "anullsrc=r=44100:cl=mono", "-map", "1:a:0"]
            cmd += ["-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "1", "-t", f"{total:.4f}", str(aud)]
            run_ff(cmd, aud, video=False)

        self.job = {"label": label, "stage": "video qismlari", "done": 0, "total": len(ranges), "t0": time.time(),
                    "frames": 0, "frames_total": total_f}
        fa = self.pool.submit(apart)

        def launch():
            return [self.pool.submit(vpart, i, f0, f1) for i, (f0, f1) in enumerate(ranges)]

        futs = launch()
        try:
            try:
                paths = [f.result() for f in futs]
            except _HwFail as e:
                # GPU xato berdi: ishlayotgan qismlar to'xtatiladi, butun fayl bo'lagi CPU da qayta kodlanadi
                abort.set()
                with lock:
                    for pr in procs:
                        try:
                            pr.kill()
                        except OSError:
                            pass
                for f in futs:
                    f.cancel()
                from concurrent.futures import wait as _wait
                _wait(futs, timeout=60)
                abort.clear()
                HW.report(cur["codec"], False, str(e))
                self.sys.tel.event("w", "GPU kodlash xato berdi — fayl bo'lagi CPU da qayta kodlanmoqda")
                cur["codec"], cur["tag"] = self._codec(still=False, force_cpu=True), "c"
                done[0] = 0
                self.job.update(done=0, frames=0)
                futs = launch()
                paths = [f.result() for f in futs]
            fa.result()
        except BaseException:
            abort.set()
            for f in futs + [fa]:
                f.cancel()
            with lock:
                for pr in procs + aprocs:
                    try:
                        pr.kill()
                    except OSError:
                        pass
            shutil.rmtree(wd, ignore_errors=True)
            raise
        HW.report(cur["codec"], True)
        lst = wd / "parts.txt"
        lst.write_text("".join(f"file '{pp.name}'\n" for pp in paths), encoding="utf-8")
        rc, _, err = run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                          "-i", str(aud), "-map", "0:v:0", "-map", "1:a:0", "-c", "copy", "-t", f"{total:.4f}",
                          "-movflags", "+faststart", str(out)], timeout=900, cwd=str(wd))
        shutil.rmtree(wd, ignore_errors=True)
        if rc != 0 or not out.exists() or out.stat().st_size < 1000:
            out.unlink(missing_ok=True)
            raise StreamError("Fayl qismlari ulanmadi: " + err[-300:])
        dur = _ffprobe_dur(out) or ch["len"]
        if item.get("owned") and ch["i"] == ch["n"] - 1:
            self._drop_item_files(item)
        return {"kind": "file", "label": label, "dur": dur, "path": str(out), "data": None, "item": item["id"]}

    # ---- AI bo'laklar: tayyorlovchi (ssenariy + ovoz + reja) va chizuvchi
    def _prepare(self, st: dict, final: bool, cancel) -> dict:
        """Ssenariy (LLM) -> talaffuz -> ovoz (parallel TTS) -> vaqt rejasi. Chizishsiz. st ni yangilaydi (davom ettirish uchun)."""
        app = self.app
        sc = self._scfg()
        p = self.params
        no = st["seg_no"] + 1
        name = "xayrlashuv" if final else f"AI bo'lak #{no}"
        if final:
            base = dict(st)
            base["carry"] = ""
            base["tail"] = ""
        else:
            base = st
        seg = None
        tt0 = time.time()
        self.pstage = {"txt": f"{name}: ssenariy yozilmoqda (AI)", "t0": tt0}
        try:
            first_s = self.cfg.float("STREAM_FIRST_SEC")
            seg = streamgen.write_segment(sc, app.llm, base, final=final, say=lambda m: None,
                                          seconds=(first_s if (no == 1 and not final and first_s >= 30) else None))
            log.info("Stream %s: ssenariy %.1fs (%d sahna)", name, time.time() - tt0, len(seg["scenes"]))
            if cancel():
                raise _Cancel()
            scenes = streamgen.build_scenes(sc, base, seg, first=(st["seg_no"] == 0 and not final), final=final,
                                            midcut=p["midcut"])
        except _Cancel:
            raise
        except Exception as e:  # noqa: BLE001
            if not final:
                raise
            log.warning("Xayrlashuv ssenariysi LLM dan olinmadi (%s) — oddiy xayrlashuv ishlatiladi", e)
            scenes = streamgen.fallback_goodbye(sc, self.s["title"])
            seg = {"summary": "", "covered": [], "carry_out": "", "scenes": []}
        return self._voice_bundle(sc, st, seg, scenes, final, name, no, cancel)

    def _voice_bundle(self, sc, st, seg, scenes, final, name, no, cancel, stage=True) -> dict:
        """Talaffuz -> ovoz (barcha sahnalar bir vaqtda) -> vaqt rejasi. `st` faqat seg_no (lead) uchun o'qiladi."""
        app = self.app
        p = self.params
        th_p = threading.Thread(target=lambda: pronounce.build(sc, self.db, app.llm, scenes), daemon=True,
                                name="stream-pron")
        th_p.start()
        th_p.join(timeout=max(3.0, self.cfg.float("PRON_WAIT") or 10.0))   # talaffuz lug'ati ixtiyoriy: uzoq kutilmaydi
        tt1 = time.time()
        if stage:
            self.pstage = {"txt": f"{name}: ovoz va reja", "t0": tt1}
        vb = VideoBuilder(sc, app.tts)
        cont = no > 1 or final
        vb.lead_first = 0.06 if cont else 0.45
        vb.pad_last = 1.6 if final else 0.10
        vb.extra_v = []
        vb.motion_step = p["step"]
        vb.tick = self._tick
        vb.cancel = cancel
        wd = self.work / f"g{uuid.uuid4().hex[:6]}"
        pr = vb.prepare_stream(scenes, wd, portrait=(p["fmt"] == "shorts"), tts_workers=self.tts_workers,
                               progress=(lambda i, n, inf="": self.pstage.update(txt=f"{name}: ovoz {i}/{n} sahna"))
                               if stage else None)
        log.info("Stream %s: ovoz+reja %.1fs", name, time.time() - tt1)
        if stage:
            self.pstage = {}
        head = next((s.get("heading") for s in scenes if s.get("heading")), "")
        return {"vb": vb, "scenes": scenes, "wd": wd, "seg": seg, "final": final, "no": no, "pr": pr,
                "label": ("Xayrlashuv" if final else f"AI #{no}") + (f": {head}" if head else ""),
                "dur": pr["total_f"] / vb.fps(), "carry": seg.get("carry_out", ""), "tail": scenes[-1].get("narration", ""),
                "summary": seg.get("summary", ""), "covered": seg.get("covered", [])}

    def _apply_bundle_state(self, st: dict, b: dict):
        """Tayyorlangan bo'lak hisobga olinadi: keyingi ssenariy shundan davom etadi."""
        with self.lock:
            st["seg_no"] += 1
            if st["left"] is not None:
                st["left"] -= 1
            st["summaries"].append(b["summary"])
            st["covered"] = (st.get("covered", []) + b["covered"])[-30:]
            st["carry"] = b["carry"]
            st["tail"] = b["tail"]
            self.last_gen = st

    def _prepper(self, pp: dict):
        """AI element uchun bo'laklarni PARTIYALAB tayyorlaydi: bitta reja -> barcha qismlar parallel yoziladi ->
        barcha bo'laklarning ovozi bir vaqtda yasaladi. Render bilan bir vaqtda ishlaydi."""
        st = pp["st"]
        sc = self._scfg()
        B = max(1, self.params["batch"])
        cancel = lambda: self.end_evt.is_set() or pp["cancel"]  # noqa: E731
        try:
            while not cancel():
                with self.cv:
                    lim = 6 if B == 1 else 1
                    while not (cancel() or len(pp["q"]) + pp["pending"] <= lim - (1 if B == 1 else 0)):
                        self.cv.wait(0.5)
                if cancel():
                    return
                if B == 1:
                    # ketma-ket rejim: har bo'lak ssenariysi oldingisidan keyin, 5 ta AI poygasi bilan; gap o'rtasida uzish ishlaydi
                    with self.lock:
                        if st["left"] is not None and st["left"] <= 0:
                            return
                    try:
                        b = self._prepare(st, False, cancel)
                    except _Cancel:
                        return
                    except VideoError as e:
                        if "bekor" in str(e):
                            return
                        raise
                    if cancel():
                        shutil.rmtree(b["wd"], ignore_errors=True)
                        return
                    self._apply_bundle_state(st, b)
                    with self.cv:
                        pp["q"].append(b)
                        self.cv.notify_all()
                    continue
                with self.lock:
                    left = st["left"]
                    if left is not None and left <= 0:
                        return
                    m = B if left is None else min(B, left)
                    first_no = st["seg_no"] + 1
                tt0 = time.time()
                self.pstage = {"txt": f"AI bo'laklar #{first_no}–{first_no + m - 1}: ssenariy ({m} ta bir vaqtda)", "t0": tt0}
                try:
                    segs = streamgen.write_batch(sc, self.app.llm, st, m)
                except Exception as e:  # noqa: BLE001
                    log.warning("Partiya ssenariysi yozilmadi (%s) — bittalab yoziladi", str(e)[:150])
                    segs = [streamgen.write_segment(sc, self.app.llm, st, final=False)]
                    m = 1
                log.info("Stream partiya: %d bo'lak ssenariysi %.1fs", len(segs), time.time() - tt0)
                if cancel():
                    return
                bundles = []
                for seg in segs:                       # tartib bo'yicha: sarlavha, davomiylik holati
                    no = st["seg_no"] + 1
                    scenes = streamgen.build_scenes(sc, st, seg, first=(st["seg_no"] == 0), final=False, midcut=False)
                    with self.lock:
                        st["seg_no"] += 1
                        if st["left"] is not None:
                            st["left"] -= 1
                        st["summaries"].append(seg.get("summary", ""))
                        st["covered"] = (st.get("covered", []) + seg.get("covered", []))[-30:]
                        st["carry"] = ""
                        st["tail"] = scenes[-1].get("narration", "")
                        self.last_gen = st
                    bundles.append((no, seg, scenes))
                results: dict = {}
                with self.cv:
                    pp["pending"] += len(bundles)
                self.pstage = {"txt": f"ovoz: {len(bundles)} bo'lak bir vaqtda", "t0": time.time()}

                def voice(i, no, seg, scenes):
                    try:
                        results[i] = self._voice_bundle(sc, st, seg, scenes, False, f"AI bo'lak #{no}", no, cancel, stage=False)
                    except BaseException as e:  # noqa: BLE001
                        results[i] = e

                ths = []
                for i, (no, seg, scenes) in enumerate(bundles):
                    th = threading.Thread(target=voice, args=(i, no, seg, scenes), daemon=True, name="stream-voice")
                    th.start()
                    ths.append(th)
                for i, th in enumerate(ths):           # tayyor bo'lgani zahoti, tartibda navbatga qo'yiladi
                    th.join()
                    r = results.get(i)
                    with self.cv:
                        pp["pending"] -= 1
                        if isinstance(r, BaseException):
                            if not cancel():
                                log.error("Bo'lak ovozi yasalmadi: %s", r)
                                raise r
                            return
                        if cancel():
                            shutil.rmtree(r["wd"], ignore_errors=True)
                            return
                        pp["q"].append(r)
                        self.cv.notify_all()
                self.pstage = {}
        except Exception as e:  # noqa: BLE001
            log.error("Tayyorlovchi xatosi: %s\n%s", e, tb_short(1200))
            pp["err"] = e
        finally:
            self.pstage = {}
            with self.cv:
                pp["done"] = True
                self.cv.notify_all()

    def _start_prepper(self, st):
        pp = {"st": st, "q": [], "done": False, "cancel": False, "err": None, "pending": 0}
        th = threading.Thread(target=self._prepper, args=(pp,), daemon=True, name="stream-prep")
        pp["th"] = th
        self.pp = pp
        th.start()

    def _stop_prepper(self):
        pp = self.pp
        self.pp = None
        if pp is None:
            return
        pp["cancel"] = True
        with self.cv:
            self.cv.notify_all()
        for b in pp["q"]:
            shutil.rmtree(b["wd"], ignore_errors=True)
        pp["q"] = []
        pp["th"].join(timeout=1)       # LLM so'rovi tugaguncha kutilmaydi (natijasi tashlanadi)

    def _make_gen_seg(self, final=False) -> dict:
        with self.lock:
            st = self.gen if not final else (self.last_gen or {
                "title": self.s["title"], "topic": self.s.get("topic") or self.s["title"], "seg_no": 0,
                "summaries": [], "covered": [], "carry": "", "tail": "", "left": 0})
        if final:
            self.prep_info = "xayrlashuv bo'lagi: tayyorlanmoqda…"
            b = self._prepare(st, True, lambda: self.end_evt.is_set())
        else:
            if self.pp is None or self.pp["st"] is not st:
                self._stop_prepper()
                self._start_prepper(st)
            pp = self.pp
            self.prep_info = f"AI bo'lak #{st['seg_no'] + 1}: ssenariy va ovoz tayyorlanmoqda…"
            with self.cv:
                while not pp["q"]:
                    if self.end_evt.is_set() or self.stopping or self.cancel_gen:
                        raise _Cancel()
                    if pp["done"]:
                        break
                    self.cv.wait(0.5)
                if not pp["q"]:
                    err = pp.get("err")
                    self.pp = None
                    if err is not None:
                        raise StreamError(f"AI bo'lak tayyorlanmadi: {type(err).__name__}: {err}")
                    with self.lock:
                        self.gen = None
                    return None
                b = pp["q"].pop(0)
                self.cv.notify_all()
        self.job = {"label": b["label"], "stage": "video qismlari", "done": 0, "total": 1, "t0": time.time(),
                    "frames": 0, "frames_total": b["pr"]["total_f"]}
        tk = self._render_bundle(b)
        if not final:
            with self.cv:
                pp = self.pp
                if pp and pp["done"] and not pp["q"]:
                    self.pp = None
                    with self.lock:
                        self.gen = None
        return tk

    def _render_bundle(self, b: dict) -> dict:
        p = self.params
        final = b["final"]
        vb, scenes, wd = b["vb"], b["scenes"], b["wd"]
        vb.prev_content = self.last_content
        vb.cancel = lambda: (self.cancel_gen and not final) or self.end_evt.is_set()
        out = self.ready_dir / f"{uuid.uuid4().hex[:8]}.mp4"

        def prog(stage, a, n, info=""):
            self.job.update(stage="video qismlari", done=a, total=n)
            self.prep_info = f"{b['label']}: qismlar {a}/{n}"

        try:
            codec = self._codec()
            res = vb.render_stream(b["pr"], scenes, wd, out, self._borrow, self._release, self.pool, p["part"],
                                   codec, self.t_off, prog, threads_each=self.threads_each,
                                   remote=self.rproc, spec_base=self.spec_base,
                                   fallback_args=(self._codec(force_cpu=True) if HW.is_hw(codec) else None))
        except (VideoError, _Cancel) as e:
            out.unlink(missing_ok=True)
            shutil.rmtree(wd, ignore_errors=True)
            if isinstance(e, _Cancel) or "bekor" in str(e) or self.end_evt.is_set():
                raise _Cancel()
            raise
        except BaseException:
            out.unlink(missing_ok=True)
            shutil.rmtree(wd, ignore_errors=True)
            raise
        shutil.rmtree(wd, ignore_errors=True)
        with self.lock:
            self.t_off += res["duration"]
            self.last_content = vb.last_content
        return {"kind": "farewell" if final else "gen", "label": b["label"][:70], "dur": float(res["duration"]),
                "path": str(out), "data": None, "restore": None}

    def _check_cancel(self, final):
        if self.end_evt.is_set() or (self.cancel_gen and not final):
            raise _Cancel()

    # ------------------------------------------------------------------ feeder
    def _feeder(self):
        while not self.end_evt.is_set():
            with self.cv:
                while not self.end_evt.is_set() and self.state != "live":
                    self.cv.wait(0.5)
                if self.end_evt.is_set():
                    return
                tk = self.ready.pop(0) if self.ready else None
                if tk is not None:
                    self.cv.notify_all()
            if tk is None:
                tk = self.filler
                if tk is None:
                    self.end_evt.wait(0.5)
                    continue
                tk = dict(tk)
            if tk.get("path"):
                try:
                    tk["data"] = Path(tk["path"]).read_bytes()      # diskdan RAMga: faqat joriy bo'lak RAMda
                except OSError as e:
                    log.error("Tayyor bo'lak fayli o'qilmadi: %s", e)
                    continue
                finally:
                    try:
                        Path(tk["path"]).unlink()
                    except OSError:
                        pass
            with self.lock:
                self.cur, self.cur_t0 = tk, time.time()
            try:
                self._play(tk)
            finally:
                last = tk["kind"] == "farewell"
                self.end_evt.wait(self.params["drop"])     # bo'lak tugagach DROP_DELAY soniya kutiladi
                tk["data"] = None                          # RAMdan o'chirish
                with self.lock:
                    self.cur = None
                    if tk["kind"] != "filler":
                        self.played += 1
                    self.play_log.append((tk["kind"], tk["label"], round(tk["dur"], 2)))
                    del self.play_log[:-200]
            if last and not self.end_evt.is_set():
                self._finish()
                return

    def _play(self, tk):
        off = self.t_out
        cmd = ["ffmpeg", "-loglevel", "error", "-i", "pipe:0", "-c", "copy", "-bsf:v", "h264_mp4toannexb",
               "-output_ts_offset", f"{off:.3f}", "-muxdelay", "0", "-muxpreload", "0", "-f", "mpegts", "pipe:1"]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        data = tk["data"]

        def feed():
            try:
                mv = memoryview(data)
                for i in range(0, len(mv), 1 << 20):
                    proc.stdin.write(mv[i:i + (1 << 20)])
            except (BrokenPipeError, OSError, ValueError):
                pass
            finally:
                try:
                    proc.stdin.close()
                except OSError:
                    pass

        threading.Thread(target=feed, daemon=True, name="stream-remux-in").start()
        try:
            while True:
                chunk = proc.stdout.read(188 * 348)
                if not chunk:
                    break
                if self.skip_evt.is_set() or self.end_evt.is_set():
                    self.skip_evt.clear()
                    break
                self._push(chunk)
        finally:
            try:
                proc.kill()
            except OSError:
                pass
            proc.wait()
        self.t_out = off + tk["dur"] + 0.02

    def _finish(self):
        """Xayrlashuv bo'lagi efirda tugadi: efirni yopadi, adminni xabardor qiladi, hammasini tozalaydi."""
        self.say(f"✅ <b>Translatsiya tugadi:</b> {esc(self.s['title'])}\n"
                 f"Davomiyligi: {fmt_dur(time.time() - self.live_t0)} · bo'laklar: {self.played}",
                 markup={"inline_keyboard": [[{"text": "📡 Yangi translatsiya", "callback_data": "st:new"}]]})
        self.kill("tugadi", notify=False, final_state="ended")

    # ------------------------------------------------------------------ watcher
    def remaining(self) -> float:
        """Efirda yana qancha tayyor/rejadagi kontent bor (soniya); cheksiz bo'lsa inf."""
        with self.lock:
            if self.s.get("infinite") or (self.gen and self.gen.get("left") is None):
                return math.inf
            r = 0.0
            if self.cur and self.cur["kind"] != "filler":
                r += max(0.0, self.cur["dur"] - (time.time() - self.cur_t0))
            for tk in self.ready:
                r += tk["dur"]
            for ch in self.chunks:
                r += ch["len"]
            if self.pp:
                r += sum(b["dur"] for b in self.pp["q"])
            if self.gen and self.gen.get("left"):
                r += self.gen["left"] * self.params["seg"]
            for it in self.s.get("queue", []):
                r += it.get("est", 0) or 0
            return r

    def _watcher(self):
        last_yt = 0.0
        while not self.end_evt.is_set():
            self.end_evt.wait(2)
            if self.end_evt.is_set() or self.state != "live":
                continue
            try:
                now = time.time()
                if self.asked and now - self.asked["t0"] >= self.params["ask_to"]:
                    self._ask_timeout()
                elif (not self.asked and not self.stopping and not self.s.get("infinite")
                      and now - self.live_t0 > 20 and self.remaining() <= self.params["warn"]):
                    self._ask_end()
                ps = self.pstage
                if ps and now - ps.get("t0", now) > 180 and ps.get("warned") != ps.get("txt"):
                    ps["warned"] = ps.get("txt")
                    self.say(f"⚠️ <b>{esc(ps.get('txt', ''))}</b> 3 daqiqadan beri davom etyapti: AI yoki ovoz provayderi sekin/limitda. "
                             "Kalitlar holatini (/keys) tekshiring; bot o'zi qayta urinadi.")
                if now - last_yt > 30 and self.cfg.get("STREAM_MODE") == "api" and self.s.get("broadcast_id"):
                    last_yt = now
                    self._yt_check()
            except Exception as e:  # noqa: BLE001
                log.warning("Watcher xatosi: %s", e)

    def _yt_check(self):
        yt = self.app.yt
        try:
            st = yt.live_status(self.s["broadcast_id"])
        except Exception as e:  # noqa: BLE001
            log.info("Efir holati olinmadi: %s", str(e)[:150])
            return
        self.yt = st
        if st["life"] in ("testing", "ready") and st["stream"] == "active" and time.time() - self.live_t0 > 25:
            try:
                yt.live_transition(self.s["broadcast_id"], "live")
            except Exception as e:  # noqa: BLE001
                log.info("live ga o'tkazilmadi: %s", str(e)[:150])
        if st["life"] == "complete" and not self.stopping:
            self.say("⚠️ YouTube efirni yakunladi (tashqaridan). Translatsiya to'xtatildi.")
            self.kill("YouTube yakunladi", notify=False)
        if st["health"] in ("bad", "noData"):
            self.yt_bad += 1
            if self.yt_bad == 3:
                self.say(f"⚠️ YouTube efir signali: <b>{esc(st['health'])}</b>. Internet/bitrate (/stream → Sifat) ni tekshiring.")
        else:
            self.yt_bad = 0

    # ------------------------------------------------------------------ "Efir tugasinmi?"
    def _ask_end(self):
        rem = self.remaining()
        txt = (f"⏳ <b>Efir tugasinmi?</b>\nQolgan kontent: ~{fmt_dur(rem)}.\n"
               f"<b>Davom</b> — AI videolar cheksiz davom etadi.\n<b>To'xtat</b> — xayrlashuv bo'lagi qo'shilib efir tugaydi.\n"
               f"<i>{fmt_dur(self.params['ask_to'])} ichida javob bo'lmasa — «To'xtat» deb qabul qilinadi.</i>")
        mid = self.say(txt, markup={"inline_keyboard": [[{"text": "▶️ Davom", "callback_data": "st:cont"},
                                                          {"text": "⏹ To'xtat", "callback_data": "st:end"}]]})
        self.asked = {"msg": mid, "t0": time.time()}

    def _del_ask(self):
        a = self.asked
        self.asked = None
        if a and a.get("msg"):
            try:
                self.app.tg.api("deleteMessage", {"chat_id": self.app.tg.admin, "message_id": a["msg"]}, retries=1)
            except Exception:  # noqa: BLE001
                pass

    def _ask_timeout(self):
        self._del_ask()
        self.say("⏱ Javob berilmadi — <b>To'xtat</b> deb qabul qilindi. Xayrlashuv bo'lagi tayyorlanmoqda.")
        self.request_stop()

    def answer(self, cont: bool) -> str:
        if not self.asked:
            return "ℹ️ Bu so'rov muddati o'tgan yoki allaqachon javob berilgan."
        self._del_ask()
        if cont:
            with self.cv:
                self.s["infinite"] = True
                self._save()
                self.cv.notify_all()
            return "▶️ Davom etadi: AI bo'laklar cheksiz yaratiladi. To'xtatish: /stream → ⏹."
        self.request_stop()
        return "⏹ To'xtatildi: xayrlashuv bo'lagi tayyorlanmoqda, efir shundan so'ng tugaydi."

    # ------------------------------------------------------------------ to'xtatish
    def request_stop(self) -> bool:
        """Yumshoq to'xtatish: joriy bo'lak tugaydi, so'ng AI xayrlashuv bo'lagi, so'ng efir tugaydi."""
        if self.state == "starting":
            self.kill("to'xtatildi", final_state="draft")
            return True
        with self.cv:
            if self.state != "live" or self.stopping:
                return False
            self.stopping = True
            self.s["ending"] = True
            self.s["infinite"] = False
            for it in self.s.get("queue", []):
                self._drop_item_files(it)
            self.s["queue"] = []
            self.chunks = []
            self.gen = None
            keep = []
            for tk in self.ready:
                if tk["kind"] == "farewell":
                    keep.append(tk)
                else:
                    self._drop_ticket(tk)
            self.ready = keep
            if self.pp:
                self.pp["cancel"] = True
            self.cancel_gen = True
            self._save()
            self.cv.notify_all()
        self._del_ask()
        return True

    def go_now(self) -> bool:
        """Preroll tugashini kutmay, tayyor bo'laklar bilan efirni darhol boshlaydi."""
        if self.state != "starting":
            return False
        self.go_evt.set()
        self.ready_evt.set()
        return True

    def skip(self):
        self.skip_evt.set()

    def kill(self, why="", notify=True, final_state="ended"):
        """Zudlik bilan tugatish: pusher yopiladi, YouTube efiri yakunlanadi, RAM va disk tozalanadi."""
        with self.cv:
            if self.end_evt.is_set() and self.state in ("ended", "draft"):
                return
            self.end_evt.set()
            self.cancel_gen = True
            self.cv.notify_all()
        try:
            self.sys.stop()
        except Exception:  # noqa: BLE001
            pass
        p = self.pusher
        if p is not None:
            try:
                p.stdin.close()
            except OSError:
                pass
            try:
                p.wait(timeout=8)
            except Exception:  # noqa: BLE001
                try:
                    p.kill()
                except OSError:
                    pass
        bid = self.s.get("broadcast_id")
        if bid and self.cfg.get("STREAM_MODE") == "api":
            self._yt_complete(bid)
        self._del_ask()
        with self.lock:
            for tk in [self.cur, self.filler] + list(self.ready):
                if tk:
                    self._drop_ticket(tk)
            self.cur = self.filler = None
            self.ready = []
            rp, self.rproc = self.rproc, None
            if rp:
                rp.close()
            pool, self.pool = self.pool, None
            if self.pp:
                self.pp["cancel"] = True
            if pool:
                pool.shutdown(wait=False, cancel_futures=True)
            self.renderer = None
            self.last_content = None
            self._cleanup_files(full=(final_state == "ended"))
            self.s["state"] = final_state
            self.s["ending"] = False
            self.s["ended"] = time.time()
            backup = self.s.pop("queue_backup", None)
            if final_state == "ended":
                self.s["queue"] = []
            elif backup is not None:
                self.s["queue"] = backup
            self._save()
        if notify and why:
            self.say(f"⏹ Translatsiya to'xtatildi ({esc(why)}).")

    def _cleanup_files(self, full=True):
        """Barcha vaqtinchalik videolar (kutayotgan keyingi bo'laklar ham) o'chiriladi. Asl epizod fayllari tegilmaydi."""
        w = self.work or (self.cfg.dirs["work"] / "stream" / (self.s.get("id") or "x"))
        shutil.rmtree(w, ignore_errors=True)
        base = self.cfg.dirs["work"] / "stream"
        if full:
            for it in self.s.get("queue", []):
                self._drop_item_files(it)
        if full and base.exists():
            for p in base.iterdir():
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=True)
        self.chunks = []

    def discard(self):
        """Qoralamani o'chiradi."""
        with self.lock:
            if self.active():
                return False
            self._cleanup_files(full=True)
            try:
                self.thumb_path().unlink()
            except OSError:
                pass
            self.s = {}
            self.db.kv_del(KV)
            return True

    # ------------------------------------------------------------------ holat matni
    def ram_bytes(self) -> int:
        n = 0
        for tk in (self.cur,):
            if tk and tk.get("data"):
                n += len(tk["data"])
        return n

    def status_text(self) -> str:
        s = self.s
        if not s.get("id"):
            return "📡 <b>Translatsiya yo'q.</b> Yangisini yarating."
        st = self.state
        icon = {"draft": "📝", "starting": "⏳", "live": "🔴", "ending": "🟠", "ended": "⚪"}.get(st, "•")
        lines = [f"{icon} <b>{esc(s['title'])}</b> · {st}{' (tugatilmoqda)' if s.get('ending') else ''}"]
        if st in ("starting", "live") and s.get("url"):
            lines.append(esc(s["url"]))
        p = self.params or self._params()
        lines.append(f"🎞 {p['res']}p · {p['fps']} fps · {'vertikal' if p['fmt'] == 'shorts' else 'gorizontal'} · "
                     f"{p['kbps']} kbit/s · bo'lak {fmt_dur(p['seg'])}")
        lines.append(self.sys.encoder_line())
        if st in ("starting", "live"):
            with self.lock:
                cur, nxt = self.cur, self.nxt
                if self.live_t0 and st == "live":
                    lines.append(f"⏱ Efirda: {fmt_dur(time.time() - self.live_t0)} · o'ynalgan bo'laklar: {self.played}")
                if cur:
                    left = max(0.0, cur["dur"] - (time.time() - self.cur_t0))
                    lines.append(f"▶️ Hozir: <b>{esc(cur['label'])}</b> · qoldi {fmt_dur(left)}")
                if nxt:
                    lines.append(f"⏭ Keyingi: <b>{esc(nxt['label'])}</b> · {fmt_dur(nxt['dur'])} · diskda tayyor")
                tot_buf = sum(t["dur"] for t in self.ready)
                lines.append(f"📦 Zaxira: <b>{len(self.ready)}{('/' + str(self.params['cap'])) if self.params.get('cap') else ''}</b> bo'lak"
                             f"{'' if self.params.get('cap') else ' (cheksiz)'} · {fmt_dur(tot_buf)}"
                             + (f" · preroll {len(self.ready)}/{self.params['preroll']}" if st == "starting" else ""))
                if self._has_work() and self._room():
                    j = self.job or {}
                    extra = (f" · {j.get('stage', '')} {j.get('done', 0)}/{j.get('total', 0)}" if j else "")
                    lines.append(f"🛠 Tayyorlanmoqda: {esc(self.prep_info or '…')}{extra} "
                                 f"({fmt_dur(time.time() - self.prep_t0) if self.prep_t0 else ''})")
                    ft = j.get("frames_total") or 0
                    if ft and j.get("frames"):
                        el = max(0.1, time.time() - j.get("t0", time.time()))
                        fr = j["frames"] / el
                        lines.append(f"🎞 Kadrlar: {j['frames']}/{ft} ({100 * j['frames'] // ft}%) · {fr:.0f} kadr/s"
                                     f" · bo'lak tugashiga ~{fmt_dur((ft - j['frames']) / max(fr, 0.1))}")
                elif not nxt and not self._has_work():
                    lines.append("⏭ Keyingi: yo'q")
                if self.bench and not self.speed:
                    lines.append(f"🧪 Taxminiy tezlik: <b>{self.bench:.1f}×</b> real vaqt")
                ps = self.pstage
                if ps:
                    lines.append(f"🧠 {esc(ps.get('txt', ''))} · {fmt_dur(time.time() - ps.get('t0', time.time()))}")
                if self.speed:
                    lines.append(f"⚡ Tayyorlash tezligi: <b>{self.speed:.1f}×</b> real vaqt · ishchilar: {self.workers}")
            rem = self.remaining()
            lines.append("♾ Cheksiz AI davom" if math.isinf(rem) else f"⌛ Kontent qoldi: ~{fmt_dur(rem)}")
            lines.append(f"💾 RAM: {human_size(self.ram_bytes())} (faqat joriy bo'lak; zaxira diskda)")
            if self.yt:
                lines.append(f"📶 YouTube: {esc(self.yt.get('life', ''))} · signal {esc(self.yt.get('health', '') or '—')}")
            tel = self.sys.tel
            if tel.fresh(30.0):
                pu = tel.push
                sp = f"{pu['speed']:.2f}×" if pu.get("speed") is not None else "—"
                lines.append(f"📡 Uzatish: <b>{tel.avg_kbps():.0f}</b> kbit/s · tezlik {sp} · tashlangan kadr {pu.get('drop', 0)}")
            if self.restarts:
                lines.append(f"🔁 Pusher qayta ishga tushirilgan: {self.restarts}")
            if self.slow:
                lines.append("⚠️ Zaxira tugab qoldi: tayyorlash efirdan sekin. /stream → Sifat: 480p/FPS kamaytiring yoki "
                             "STREAM_WORKERS oshiring, STREAM_PRESET=ultrafast qiling.")
            if self.stopping:
                lines.append("🟠 To'xtatish so'ralgan: xayrlashuv bo'lagi keyin efirga chiqadi.")
        q = s.get("queue", [])
        if q:
            lines.append("")
            lines.append("<b>Navbat</b>")
            for i, it in enumerate(q, 1):
                if it["kind"] == "gen":
                    lines.append(f"{i}. 🤖 {esc(it['title'][:40])} · {('∞' if not it.get('segs') else str(it['segs']) + ' bo`lak')}")
                else:
                    lines.append(f"{i}. 🎬 {esc(it['title'][:40])} · {fmt_dur(it.get('est', 0))}")
        elif st == "draft":
            lines.append("\n<i>Navbat bo'sh.</i>")
        return "\n".join(lines)
