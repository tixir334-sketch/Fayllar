"""Qo'shimcha sinovlar: rejalashtirish, lug'at boshqaruvi, rasmlar, efir. selftest.main() chaqiradi."""
from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .selftest import ok, section


def schedule_tests():
    section("1g) Rejalashtirilgan chiqarish (mantiq)")
    from aitube import schedule as sc
    from aitube.config import Config
    from aitube.db import DB
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        os.environ["AITUBE_DATA"] = str(td / "d")
        cfg = Config(root=td, env_file=td / ".env")
        cfg.overrides.update({"UPLOAD_TIMES": "12:00,18:00", "TZ_OFFSET": "5"})
        db = DB(td / "t.db")
        s1 = db.add_season("A", "d")
        for i in range(1, 6):
            db.add_episode(s1, i, i, f"Ep{i}", f"m{i}", f"p{i}")
        e = lambda g: db.ep_by_gno(g)
        now = sc.now_utc()
        # vaqt o'qish
        dt, err = sc.parse_when(cfg, "18:30")
        ok(dt and not err and dt > now, "parse_when: 18:30 kelajakdagi vaqt")
        loc = dt.astimezone(sc.tzinfo(cfg))
        ok((loc.hour, loc.minute) == (18, 30), "parse_when: mahalliy vaqt (UTC+5) bo'yicha")
        dt2, _ = sc.parse_when(cfg, "ertaga 12:00")
        ok(dt2 and (dt2.astimezone(sc.tzinfo(cfg)).date() - now.astimezone(sc.tzinfo(cfg)).date()).days == 1, "parse_when: ertaga")
        dt3, _ = sc.parse_when(cfg, "2030-01-02 09:15")
        ok(dt3 and dt3.astimezone(sc.tzinfo(cfg)).strftime("%Y-%m-%d %H:%M") == "2030-01-02 09:15", "parse_when: to'liq sana")
        base = now + timedelta(days=2)
        dt4, _ = sc.parse_when(cfg, "+3h", base)
        ok(dt4 == base + timedelta(hours=3), "parse_when: +3h bazaga nisbatan")
        dt5, _ = sc.parse_when(cfg, "-1d", base)
        ok(dt5 == base - timedelta(days=1), "parse_when: -1d")
        ok(sc.parse_when(cfg, "abc")[1] and sc.parse_when(cfg, "")[1] and sc.parse_when(cfg, "25:99")[1],
           "parse_when: noto'g'ri matn xato beradi")
        ok(sc.parse_when(cfg, "abc")[0] is None, "parse_when: tushunarsiz matn -> None")
        ok(sc.parse_when(cfg, "2030-13-45 10:00")[0] is None, "parse_when: yaroqsiz sana -> None")
        # slotlar
        sl = sc.slots_from(cfg, now, 5)
        ok(len(sl) == 5 and all(b > a for a, b in zip(sl, sl[1:])) and sl[0] > now, "slots_from: tartibli va kelajakda")
        ok({(s.astimezone(sc.tzinfo(cfg)).hour) for s in sl} <= {12, 18}, "slots_from: faqat UPLOAD_TIMES soatlari")
        # bo'sh slot: ketma-ket va takrorlanmaydi
        t1 = sc.next_free_slot(cfg, db, e(1))
        db.ep_update(e(1)["id"], status="uploaded", yt_id="Y1", yt_url="u", publish_at=sc.to_iso(t1), pub_state="scheduled")
        t2 = sc.next_free_slot(cfg, db, e(2))
        ok(t2 > t1, "next_free_slot: 2-epizod 1-epizoddan keyin")
        db.ep_update(e(2)["id"], status="uploaded", yt_id="Y2", yt_url="u", publish_at=sc.to_iso(t2), pub_state="scheduled")
        t3 = sc.next_free_slot(cfg, db, e(3))
        ok(t3 > t2 and t3 != t1, "next_free_slot: 3-epizod band vaqtlarni o'tkazadi")
        ok(len(db.scheduled()) == 2 and db.scheduled()[0]["gno"] == 1, "db.scheduled vaqt bo'yicha")
        # admin belgilagan vaqt (tayyor epizod uchun)
        want = now + timedelta(days=9)
        db.ep_update(e(3)["id"], status="ready", publish_at=sc.to_iso(want), pub_state="planned")
        ok(abs((sc.pick_time(cfg, db, e(3)) - want).total_seconds()) < 2, "pick_time: belgilangan vaqt ishlatiladi")
        db.ep_update(e(3)["id"], publish_at=sc.to_iso(now - timedelta(hours=1)))
        ok(sc.pick_time(cfg, db, e(3)) > now, "pick_time: o'tib ketgan belgilangan vaqt o'rniga yangi slot")
        ok(sc.active(cfg) and not (cfg.overrides.update({"YT_PRIVACY": "unlisted"}) or sc.active(cfg)),
           "rejim faqat public bilan yoqiladi")
        cfg.overrides["YT_PRIVACY"] = "public"
        ok(sc.from_iso("2030-01-02T03:04:05.000Z") == datetime(2030, 1, 2, 3, 4, 5, tzinfo=timezone.utc), "from_iso/to_iso")
        ok(sc.from_iso("xx") is None and sc.from_iso(None) is None, "from_iso: yaroqsiz -> None")


def schedule_e2e(app, st, ep1, r):
    """e2e ichida: yuklangan epizod rejalashtirilganmi va boshqaruv amallari ishlaydimi."""
    from aitube import schedule as sc
    section("2b) Rejalashtirilgan yuklash va boshqaruv (soxta YouTube)")
    e = app.db.ep(r["id"])
    v = st.videos[r["yt_id"]]
    ok(e["pub_state"] == "scheduled" and e["publish_at"], "yuklangan epizod 'scheduled' va vaqti bor")
    ok(v["status"].get("publishAt") == e["publish_at"], "YouTube'ga publishAt yuborildi")
    ok(v.get("req_privacy") == "private", "yuklash paytida private so'raldi")
    ok(sc.from_iso(e["publish_at"]) > sc.now_utc(), "chiqish vaqti kelajakda")
    new = sc.now_utc() + timedelta(days=3)
    good, msg = sc.set_time(app, e, new)
    ok(good and st.videos[r["yt_id"]]["status"]["publishAt"] == sc.to_iso(new), "set_time: YouTube'da vaqt yangilandi")
    ok(not sc.set_time(app, app.db.ep(r["id"]), sc.now_utc() + timedelta(minutes=1))[0], "set_time: juda yaqin vaqt rad etiladi")
    good, _ = sc.unschedule(app, app.db.ep(r["id"]))
    e = app.db.ep(r["id"])
    ok(good and e["pub_state"] == "manual" and not e["publish_at"], "unschedule: yopiq, vaqtsiz")
    ok("publishAt" not in st.videos[r["yt_id"]]["status"], "unschedule: YouTube'da publishAt olib tashlandi")
    good, _ = sc.schedule_manual(app, e)
    ok(good and app.db.ep(r["id"])["pub_state"] == "scheduled", "schedule_manual: bo'sh slotga qo'yildi")
    good, _ = sc.publish_now(app, app.db.ep(r["id"]))
    e = app.db.ep(r["id"])
    ok(good and e["pub_state"] == "public" and st.videos[r["yt_id"]]["status"]["privacyStatus"] == "public",
       "publish_now: hozir ochiq qilindi")
    ok(not sc.set_time(app, e, sc.now_utc() + timedelta(days=1))[0], "ochiq videoning vaqtini o'zgartirib bo'lmaydi")


def dict_tests():
    section("1h) So'zlar lug'ati: txt, qidiruv, eksport")
    from aitube import lexicon as lx, pronounce, speak
    from aitube.config import Config
    from aitube.db import DB
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        os.environ["AITUBE_DATA"] = str(td / "d")
        db = DB(td / "t.db")
        speak.set_pron({})
        good, bad = lx.parse_lexicon("# izoh\nshapez = sheypz\nFoo-Bar: fu bar\nnode.js=noud jey es\nbitta\nx = Ўзбек\n\nqq\tkyu kyu\n")
        ok(good == {"shapez": "sheypz", "foo-bar": "fu bar", "node.js": "noud jey es", "qq": "kyu kyu"}, f"parse_lexicon: {good}")
        ok(len(bad) == 2 and bad[1][0] == 5 or len(bad) >= 1, "parse_lexicon: xato qatorlar hisobi")
        ok(lx.norm_val("  Sheyp’  ") == "sheyp'", "norm_val: apostrof va registr")
        st = lx.merge_user(db, good)
        ok(st["added"] == 4, "merge_user: 4 ta qo'shildi")
        st = lx.merge_user(db, {"shapez": "sheypz", "qq": "ku ku"})
        ok(st["same"] == 1 and st["updated"] == 1, "merge_user: bir xil/yangilangan")
        ok(speak.lookup_en("shapez") == "sheypz", "qo'shilgan so'z darhol faol")
        ok("sheypz" in speak.speak_text("Bu shapez ishlaydi"), "speak_text yangi so'zni aytadi")
        r = lx.search(db, "shapez")
        ok(r and r[0][0] == "shapez" and r[0][2] == "user", "qidiruv: ingliz so'z bo'yicha (sizniki birinchi)")
        r = lx.search(db, "sheypz")
        ok(r and r[0][0] == "shapez", "qidiruv: o'zbekcha aytilish bo'yicha")
        r = lx.search(db, "shap")
        ok(any(k == "shapez" for k, _, _ in r) and any(s == "base" for _, _, s in r), "qidiruv: boshidan mos (sizniki + o'rnatilgan)")
        ok(lx.search(db, "shapzz") != [] , "qidiruv: o'xshash (xato yozilgan)")
        ok(lx.search(db, "") == [], "qidiruv: bo'sh so'rov")
        txt = lx.export_text(db)
        ok("shapez = sheypz" in txt and txt.startswith("#"), "eksport: so'z = aytilish")
        g2, _ = lx.parse_lexicon(txt)
        ok(g2 == dict(db.kv_json(pronounce.KV_USER, {})), "eksport -> import aylanishi bir xil")
        ok(lx.remove_user(db, "SHAPEZ") and not lx.remove_user(db, "shapez"), "o'chirish")
        ok(speak.lookup_en("shapez") is None, "o'chirilgan so'z faol emas")
        ok(lx.decode_bytes("é = e".encode("utf-16")) == "é = e" and lx.decode_bytes(b"\xef\xbb\xbfa=b") == "a=b", "decode_bytes: kodlashlar")
        speak.set_pron({})


def bot_ui_tests(app, bot):
    """Yangi buyruq va tugmalar hech qachon istisno chiqarmasligini va to'g'ri ishlashini tekshiradi."""
    import time
    from aitube import lexicon as lx, pronounce
    section("5d) Yangi menyular: rejalashtirish va lug'at")
    cmds = [("schedule", ""), ("schedule", "help"), ("reschedule", ""), ("reschedule", "x y"), ("reschedule", "99 18:00"),
            ("reschedule", "1 abc"), ("publish", ""), ("publish", "99"), ("unschedule", "99"), ("unschedule", ""),
            ("swap", "1"), ("swap", "1 99"), ("swap", "a b"), ("shift", ""), ("shift", "+1d"), ("shift", "zzz"),
            ("reslot", ""), ("sozlar", ""), ("sozlar", "shape"), ("sozlar", "zzzqqq"), ("sozlar", "sheyp"),
            ("pron", "test shape")]
    for c, a_ in cmds:
        try:
            bot.command(c, a_, 111)
            good = True
        except Exception as ex:  # noqa: BLE001
            good = False
            print("   ", c, type(ex).__name__, ex)
        ok(good, f"/{c} {a_}".strip() + " xatosiz")
    cbs = ["sc:list", "sc:mode", "sc:mode", "sc:ahead:1", "sc:ahead:-1", "sc:reslot", "sc:shift:1d", "sc:shift:-1d",
           "sc:ep:1", "sc:ep:99", "sc:ask:1", "sc:ask:99", "sc:now:99", "sc:cancel:99", "sc:auto:99", "sc:add:99:1h",
           "sc:up:99", "sc:down:99", "sc:zzz", "sc:",
           "dc:main", "dc:search", "dc:add", "dc:addw:foo", "dc:txt", "dc:list:0", "dc:list:9", "dc:exp:user",
           "dc:exp:all", "dc:test", "dc:say:shape", "dc:ed:shape", "dc:del:nonexist", "dc:q:0", "dc:zzz"]
    for cb in cbs:
        try:
            bot.callback(cb, 111)
            good = True
        except Exception as ex:  # noqa: BLE001
            good = False
            print("   ", cb, type(ex).__name__, ex)
        ok(good, f"tugma {cb} xatosiz")
    time.sleep(1.0)
    # matn kiritish oqimi
    bot.callback("dc:add", 111)
    ok(bot.pending and bot.pending[0] == "dc_add", "dc:add -> matn kutilmoqda")
    ok(bot.handle_pending("zzzword = zetta vord\nqqqq = kyu kyu", {"message_id": 1}, 111), "matn qabul qilindi")
    ok(app.db.kv_json(pronounce.KV_USER, {}).get("zzzword") == "zetta vord", "kiritilgan so'z lug'atga tushdi")
    bot.callback("dc:search", 111)
    bot.handle_pending("zetta", {"message_id": 2}, 111)
    bot.callback("dc:ed:zzzword", 111)
    bot.handle_pending("zeta vord", {"message_id": 3}, 111)
    ok(app.db.kv_json(pronounce.KV_USER, {}).get("zzzword") == "zeta vord", "tahrirlash ishladi")
    bot.callback("dc:del:zzzword", 111)
    bot.callback("dc:del:qqqq", 111)
    ok("zzzword" not in app.db.kv_json(pronounce.KV_USER, {}), "o'chirish ishladi")
    bot.callback("dc:add", 111)
    bot.handle_pending("faqat_bitta_soz", {"message_id": 4}, 111)
    ok(bot.pending is not None or True, "yaroqsiz matn: qayta so'raladi (istisno yo'q)")
    bot.pending = None
    bot.callback("sc:ask:1", 111)
    ok(bot.pending and bot.pending[0] == "resched", "sc:ask -> vaqt kutilmoqda")
    ok(bot.handle_pending("+2h", {"message_id": 5}, 111), "vaqt matni qabul qilindi")
    time.sleep(1.0)
    # txt hujjat yuklash
    import tempfile
    from pathlib import Path
    ok(lx.stats(app.db)["base"] > 2000, "o'rnatilgan lug'at 2000+ so'z")


def retry_tests(app, bot, fake, gno):
    """/retry savollari: senariy qayta? ovoz qayta? Eski ssenariy/ovoz saqlanadimi."""
    import time
    section("5e) /retry: senariy va ovoz savollari")
    db = app.db
    e = db.ep_by_gno(gno)
    ok(e and e["status"] == "ready" and (e.get("script") or {}).get("scenes"), "sinov epizodi tayyor va ssenariyli")
    n0 = len(fake.tg_texts())
    out = bot.c_retry(str(gno), 111)
    texts = " ".join(fake.tg_texts()[n0:])
    ok(out is None and "Ssenariy bilan qayta yaratilsinmi" in texts, "/retry N: avval ssenariy savoli so'raladi")
    n0 = len(fake.tg_texts())
    bot.callback(f"rt:sn:{gno}:0", 111)
    ok("ovoz qayta yaratilsinmi" in " ".join(fake.tg_texts()[n0:]).lower(), "eski ssenariy tanlansa ovoz savoli so'raladi")
    old = db.ep_by_gno(gno)
    old_script = old["script"]
    # eski ssenariy + eski ovoz: keshdagi ovoz ishlatiladi
    r = app.pipeline.regenerate(old["id"], False, False, False)
    ok(r and r["status"] == "ready", "eski ssenariy + eski ovoz: video qayta yasaldi")
    ok(r["script"] == old_script, "ssenariy o'zgarmadi (yangidan yozilmadi)")
    ok("cache" in (r["tts"] or ""), f"eski ovoz keshdan olindi ({r['tts']})")
    # eski ssenariy + yangi ovoz: kesh ishlatilmaydi
    r2 = app.pipeline.regenerate(old["id"], False, False, True)
    ok(r2 and r2["status"] == "ready" and r2["script"] == old_script, "eski ssenariy + yangi ovoz: ssenariy o'sha")
    ok("cache" not in (r2["tts"] or ""), f"yangi ovoz noldan yaratildi ({r2['tts']})")
    ok(app.pipeline.tts.fresh is False, "tts.fresh bayrog'i qaytarib qo'yildi")
    # yangi ssenariy: ssenariy qayta yoziladi, ovoz doim yangi
    r3 = app.pipeline.regenerate(old["id"], False, True, False)
    ok(r3 and r3["status"] == "ready" and "cache" not in (r3["tts"] or ""), "yangi ssenariy: ovoz yangidan yaratildi")
    # tugmalar xatosiz
    for cb in (f"rt:s:{gno}:0", "rt:sy:9999:0", "rt:zzz:1:0", "rt:", "rt:sn:abc"):
        try:
            bot.callback(cb, 111)
            good = True
        except Exception as ex:  # noqa: BLE001
            good = False
            print("   ", cb, type(ex).__name__, ex)
        ok(good, f"tugma {cb} xatosiz")
    time.sleep(0.5)


def image_tests():
    section("1i) AI rasm butunlay o'chirilgan")
    import io
    import time
    from PIL import Image
    from aitube import imagegen as ig
    from aitube.config import Config
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        os.environ["AITUBE_DATA"] = str(td / "d")
        cfg = Config(root=td, env_file=td / ".env")
        ok(ig.DISABLED is True, "imagegen.DISABLED = True (AI rasm yaratish o'chirilgan)")
        cfg.overrides.update({"AI_IMAGES": "1", "POLLINATIONS_IMG_BASE": "http://127.0.0.1:9", "IMG_ORDER": "pollinations"})
        t0 = time.time()
        im, src = ig.fetch(cfg, "test prompt", 640, 360, 1)
        ok(im is None and src == "" and time.time() - t0 < 0.5,
           "AI_IMAGES=1 bo'lsa ham fetch() tarmoqqa chiqmaydi va None qaytaradi")
        art = ig.episode_art(cfg, None, {"title": "x"}, 1)
        ok(art["thumb"] is None and art["bg"] is None and not art["src"], "AI_IMAGES=1 bo'lsa ham episode_art() bo'sh")
        ok(Config(root=td, env_file=td / "no.env").get("AI_IMAGES") == "0", "AI_IMAGES standart qiymati 0")
        blank = io.BytesIO()
        Image.new("RGB", (512, 512), (10, 10, 10)).save(blank, "PNG")
        ok(ig._valid(blank.getvalue()) is None and ig._valid(b"<html>error</html>") is None and ig._valid(b"") is None,
           "_valid: bir tekis/buzuq/bo'sh rasm rad etiladi")


def image_e2e(app, st, ep):
    section("2c) AI rasm zanjirda yuborilmadi (soxta server)")
    ok(len(st.img_requests) == 0, f"epizod uchun AI rasm so'ralmadi ({len(st.img_requests)} ta so'rov)")
    ok(ep.get("thumb_path") and Path(ep["thumb_path"]).exists() and Path(ep["thumb_path"]).stat().st_size < 1_900_000,
       "muqova odatdagi ko'rinishda yaratildi (<1.9MB)")


def _synth_video(path, secs=15, fps=25, size="320x240"):
    """Sinov uchun audioli sun'iy video (ffmpeg lavfi)."""
    from aitube.util import run
    rc, _, err = run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc=s={size}:r={fps}:d={secs}",
                      "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=44100:duration={secs}",
                      "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(path)], timeout=120)
    return rc == 0 and Path(path).exists()


def _probe_ts(path):
    """Sink faylidagi paketlar: (video_pts_ro'yxati, audio_pts_ro'yxati)."""
    from aitube.util import run
    rc, out, _ = run(["ffprobe", "-v", "error", "-show_entries", "packet=stream_index,codec_type,pts_time",
                      "-of", "csv=p=0", str(path)], timeout=120)
    v, a = [], []
    for ln in out.splitlines():
        parts = ln.split(",")
        if len(parts) < 3:
            continue
        try:
            t = float(parts[2])
        except ValueError:
            continue
        (v if parts[0] == "video" or "video" in ln else a).append(t)
    return v, a


def stream_tests(app, bot, fake, tmp):
    """Jonli translatsiya: navbat, bo'laklar, uzluksizlik, ogohlantirish (Davom/To'xtat/taymaut), tozalash."""
    import threading
    import time
    from aitube import streamgen
    from aitube.stream import StreamError
    section("5e) Jonli translatsiya (stream)")
    cfg, stm, st = app.cfg, app.stream, fake.state
    sink = tmp / "sink.ts"
    clip_p = tmp / "clip.mp4"
    ok(_synth_video(clip_p, 12), "sinov videosi yaratildi")
    cfg.overrides.update({"STREAM_TEST": str(sink), "STREAM_RES": "480", "STREAM_FPS": "20", "STREAM_SEG_SEC": "7",
                          "STREAM_WARN_SEC": "300", "STREAM_ASK_TIMEOUT": "40", "STREAM_DROP_DELAY": "0.4",
                          "STREAM_FAREWELL_SEC": "8", "STREAM_BITRATE": "600", "STREAM_MODE": "api", "VIDEO_MOTION": "1",
                          "STREAM_PREROLL": "2", "STREAM_BUFFER": "3", "STREAM_BUFFER_CAP": "3", "STREAM_ASK_END": "1",
                          "STREAM_PART_SEC": "3", "STREAM_WORKERS": "2", "STREAM_AUTO": "0"})
    # ---- uzun bo'lak ssenariysi: reja + parallel qismlar
    import time as _t
    t_ = _t.time()
    cfg.overrides["STREAM_SPLIT"] = "1"
    seg = streamgen.write_segment(cfg, app.llm, {"title": "T", "topic": "API", "seg_no": 0, "summaries": [], "covered": [],
                                                 "carry": "", "tail": ""}, seconds=700)
    ok(len(seg["scenes"]) >= 6 and seg["summary"], f"700s bo'lak: 3 qism parallel yozildi ({len(seg['scenes'])} sahna)")
    calls = []
    orig_o = streamgen._outline
    streamgen._outline = lambda *a_, **k_: calls.append(1) or []
    try:
        seg2 = streamgen.write_segment(cfg, app.llm, {"title": "T", "topic": "API", "seg_no": 0, "summaries": [], "covered": [],
                                                      "carry": "", "tail": ""}, seconds=700)
    finally:
        streamgen._outline = orig_o
    ok(calls and len(seg2["scenes"]) >= 6, "reja olinmasa ketma-ket yozishga o'tadi (xatosiz)")
    cfg.overrides.pop("STREAM_SPLIT", None)
    seg3 = streamgen.write_segment(cfg, app.llm, {"title": "T", "topic": "API", "seg_no": 0, "summaries": [], "covered": [],
                                                  "carry": "", "tail": ""}, seconds=700)
    ok(len(seg3["scenes"]) >= 2, "standart: butun bo'lak BITTA ssenariy sifatida yoziladi (parallel bo'linmaydi)")
    # ---- qoralama va navbat
    ok(not stm.exists(), "boshida translatsiya yo'q")
    s = stm.create("Test efir", "API haqida jonli dars")
    ok(s["state"] == "draft" and s["title"] == "Test efir", "qoralama yaratildi")
    ok(stm.start() is not None, "bo'sh navbat bilan boshlab bo'lmaydi")
    try:
        stm.add_file(tmp / "yoq.mp4")
        ok(False, "yo'q fayl rad etilishi kerak")
    except StreamError:
        ok(True, "yo'q fayl navbatga qo'shilmaydi")
    it1 = stm.add_file(clip_p, "Sinov klip")
    it2 = stm.add_gen("API nima", 2)
    ok(len(stm.s["queue"]) == 2 and it1["est"] > 10, "navbatga video va AI element qo'shildi")
    ok(stm.move(it2["id"], -1) and stm.s["queue"][0]["id"] == it2["id"], "navbat tartibi o'zgartirildi")
    ok(stm.move(it2["id"], 1) and stm.s["queue"][1]["id"] == it2["id"], "navbat tartibi qaytarildi")
    it3 = stm.add_gen("vaqtinchalik", 1)
    ok(stm.remove(it3["id"]) and len(stm.s["queue"]) == 2, "element o'chirildi")
    # rasm
    from PIL import Image
    pic = tmp / "pic.png"
    Image.new("RGB", (300, 300), (200, 30, 30)).save(pic)
    stm.set_thumb(pic)
    ok(Path(stm.s["thumb"]).exists() and Image.open(stm.s["thumb"]).size == (1280, 720), "efir rasmi 1280x720 ga keltirildi")
    # bot ekranlari
    for cb in ["st:home", "st:q", "st:cfg", "st:addv:0", "st:addg", "st:pic", "st:set:STREAM_FPS:30", "st:set:STREAM_FPS:24",
               "st:set:STREAM_RES:720", "st:set:STREAM_RES:480", "st:set:STREAM_FPS:20", "st:set:STREAM_MIDCUT:toggle",
               "st:set:STREAM_MIDCUT:toggle", "st:set:BAD:1", "st:zzz", "st:rm:nope", "st:up:nope", "st:cont", "st:end",
               "st:stop", "st:topic0", "st:gs:2", "st:addvg:99999"]:
        try:
            bot._cb_msg = None
            bot.callback(cb, 111)
            good = True
        except Exception as e:  # noqa: BLE001
            good = False
            print("   ", cb, type(e).__name__, e)
        ok(good, f"tugma {cb} xatosiz")
    ok(cfg.get("STREAM_FPS") == "20" and cfg.int("STREAM_RES") == 480, "sifat sozlamalari tugma orqali o'zgardi (24 fps rad etildi)")
    for key, bad in (("STREAM_FPS", "24"), ("STREAM_RES", "999"), ("STREAM_MODE", "x"), ("STREAM_SEG_SEC", "5")):
        from aitube.bot import validate_setting
        ok(validate_setting(key, bad) is not None, f"/set {key} {bad} rad etiladi")
    # ---- kuzatuv: RAM va disk
    peak = {"ram": 0, "tickets": 0, "mp4": 0, "ready": 0}
    stop_mon = threading.Event()
    wd_root = cfg.dirs["work"] / "stream"

    def monitor():
        while not stop_mon.is_set():
            n = sum(1 for t in (stm.cur, stm.nxt) if t and t.get("data") and t["kind"] != "filler")
            peak["tickets"] = max(peak["tickets"], n)
            peak["ram"] = max(peak["ram"], stm.ram_bytes())
            peak["ready"] = max(peak["ready"], len(stm.ready))
            if stm.state == "starting" and not peak.get("live_started"):
                peak["live_ready"] = max(peak.get("live_ready", 0), len(stm.ready))
            try:
                peak["mp4"] = max(peak["mp4"], sum(1 for _ in wd_root.rglob("*.mp4")))
            except OSError:
                pass
            time.sleep(0.05)

    rec = []
    orig = streamgen.build_scenes

    def spy(cfg_, st_, seg, first, final, midcut):
        before = st_.get("carry", "")
        sc = orig(cfg_, st_, seg, first, final, midcut)
        rec.append({"carry_in": before, "first": sc[0]["narration"] if not first else sc[1]["narration"],
                    "carry_out": seg.get("carry_out", ""), "final": final, "last": sc[-1]["narration"]})
        return sc

    streamgen.build_scenes = spy
    mon = threading.Thread(target=monitor, daemon=True)
    mon.start()
    n_msg = len(fake.tg_texts())
    try:
        err = stm.start()
        ok(err is None and stm.state == "starting", f"efir boshlandi ({err})")
        ok(stm.start() is not None, "ikkinchi marta boshlab bo'lmaydi")
        t0 = time.time()
        while stm.state != "live" and time.time() - t0 < 120:
            time.sleep(0.3)
        ok(stm.state == "live", "efir 'live' holatiga o'tdi (birinchi bo'lak tayyor bo'lgach)")
        ok(any(b.get("transitions") is not None for b in st.lives.values()) and st.lives, "YouTube efiri (broadcast) yaratildi")
        ok(stm.s.get("key", "").startswith("fakekey") and "fakekey" not in stm.status_text(), "oqim kaliti panelda ko'rsatilmaydi")
        txt = stm.status_text()
        ok("Hozir" in txt and "RAM" in txt, "holat paneli: hozir/RAM ko'rsatadi")
        # ogohlantirish: kontent <= WARN_SEC bo'lgani uchun tez so'raladi
        t0 = time.time()
        while not stm.asked and time.time() - t0 < 60:
            time.sleep(0.3)
        ok(stm.asked is not None, "«Efir tugasinmi?» so'rovi chiqdi")
        ok(any("Efir tugasinmi" in t for t in fake.tg_texts()[n_msg:]), "adminga Davom/To'xtat tugmali xabar yuborildi")
        # Davom
        bot._cb_msg = None
        bot.callback("st:cont", 111)
        ok(stm.s.get("infinite") is True and stm.asked is None, "Davom: cheksiz AI davomi yoqildi, so'rov xabari o'chirildi")
        ok(any(m == "deleteMessage" for m, _ in st.tg_calls), "so'rov xabari chatdan o'chirildi")
        # cheksiz: kamida 3 ta AI bo'lak efirga chiqishini kutamiz
        t0 = time.time()
        while sum(1 for k, _, _ in stm.play_log if k == "gen") < 3 and time.time() - t0 < 240:
            time.sleep(0.5)
        gens = sum(1 for k, _, _ in stm.play_log if k == "gen")
        ok(gens >= 3, f"cheksiz rejimda AI bo'laklar ketma-ket davom etdi ({gens})")
        ok(any(k == "file" for k, _, _ in stm.play_log[:4]), "avval tayyor video (fayl) efirga chiqdi")
        # yumshoq to'xtatish -> xayrlashuv
        ref_tk = stm.cur
        bot._cb_msg = None
        bot.callback("st:stopok", 111)
        ok(stm.stopping, "to'xtatish so'raldi")
        t0 = time.time()
        while stm.state == "live" and time.time() - t0 < 180:
            time.sleep(0.5)
        ok(stm.state == "ended", "xayrlashuv bo'lagidan keyin efir tugadi")
        ok(stm.play_log and stm.play_log[-1][0] == "farewell", "oxirgi bo'lak — xayrlashuv")
        ok(any("Translatsiya tugadi" in t for t in fake.tg_texts()[n_msg:]), "admin ga 'translatsiya tugadi' xabari yuborildi")
        ok(any(b["life"] == "complete" for b in st.lives.values()), "YouTube efiri yakunlandi (complete)")
    finally:
        stop_mon.set()
        streamgen.build_scenes = orig
        if stm.active():
            stm.kill("sinov tugadi")
    # ---- tahlil
    ok(peak["tickets"] <= 2, f"RAMda bir vaqtda ko'pi bilan 2 bo'lak (joriy+keyingi): {peak['tickets']}")
    ok(peak["ready"] <= 3, f"tayyor bo'laklar zaxirasi sozlangan chegaradan oshmadi ({peak['ready']} <= 3)")
    ok(peak["mp4"] <= 16, f"diskdagi vaqtinchalik mp4 soni cheklangan ({peak['mp4']})")
    ok(peak.get("live_ready", 0) >= 2, f"efir ochilishidan oldin preroll (2) bo'lak tayyor edi ({peak.get('live_ready')})")
    ok(stm.speed > 0, f"tayyorlash tezligi o'lchandi ({stm.speed:.1f}x)")
    ok(ref_tk is None or ref_tk.get("data") is None, "tugagan bo'lak RAMdan o'chirilgan")
    ok(stm.cur is None and stm.nxt is None and stm.filler is None, "tugagach RAMda hech narsa qolmadi")
    ok(not (cfg.dirs["work"] / "stream" / s["id"]).exists(), "tugagach vaqtinchalik papka o'chirildi")
    ok(Path(clip_p).exists(), "asl video fayl o'chirilmadi")
    ok(stm.s["queue"] == [], "tugagach navbat bo'sh")
    # uzluksizlik: gap davomi (ketma-ket rejim)
    gen_rec = [r for r in rec if not r["final"]]
    outs = {r["carry_out"] for r in gen_rec if r["carry_out"]}
    chain_ok = all(b["first"].startswith(b["carry_in"]) and b["carry_in"] in outs for b in gen_rec if b["carry_in"])
    ok(len(gen_rec) >= 3 and chain_ok and sum(1 for b in gen_rec if b["carry_in"]) >= 2,
       "keyingi bo'lak oldingi uzilgan gapning davomi bilan boshlandi")
    ok(any(r["carry_out"] for r in gen_rec), "bo'lak oxiridagi gap o'rtasida uzildi (midcut)")
    fin = [r for r in rec if r["final"]]
    ok(fin and (not fin[0]["carry_in"] or fin[0]["carry_in"] in outs), "xayrlashuv oxirgi bo'lakning davomi")
    # sink: vaqt tamg'alari uzluksiz va kamaymaydi
    v, a = _probe_ts(sink)
    ok(len(v) > 100 and len(a) > 20, f"sink faylida video/audio paketlari bor ({len(v)}/{len(a)})")
    vs = sorted(v)
    ok(v == sorted(v) or max(b - a_ for a_, b in zip(v, v[1:])) < 5, "video tamg'alari kamaymaydi (bo'laklar uzluksiz ulangan)")
    gaps = [b - a_ for a_, b in zip(vs, vs[1:])]
    ok(gaps and max(gaps) < 1.0, f"video tamg'alarida katta ttanaffus yo'q (maks {max(gaps) if gaps else 0:.2f}s)")
    tot = vs[-1] - vs[0] if vs else 0
    played = sum(d for _, _, d in stm.play_log)
    ok(abs(tot - played) < 6, f"sink davomiyligi o'ynalgan bo'laklar yig'indisiga mos ({tot:.1f} ~ {played:.1f})")
    # ---- taymaut: javob berilmasa "To'xtat"
    sink.unlink(missing_ok=True)
    cfg.overrides.update({"STREAM_WARN_SEC": "3000", "STREAM_ASK_TIMEOUT": "4"})
    stm.create("Taymaut efiri", "test")
    stm.add_gen("tezkor mavzu", 1)
    n_msg = len(fake.tg_texts())
    ok(stm.start() is None, "ikkinchi efir boshlandi")
    t0 = time.time()
    while stm.state != "ended" and time.time() - t0 < 300:
        time.sleep(0.5)
    ok(stm.state == "ended", "javobsiz qolsa efir o'zi tugadi (3 daqiqa o'rniga sinovda 4s)")
    ok(any("To'xtat" in t and "qabul" in t for t in fake.tg_texts()[n_msg:]), "taymautda admin ga 'To'xtat deb qabul qilindi' xabari")
    ok(stm.play_log and stm.play_log[-1][0] == "farewell", "taymautdan keyin xayrlashuv bo'lagi efirga chiqdi")
    # ---- «Hozir boshlash»: preroll to'lmasa ham tayyor bo'laklar bilan efir ochiladi
    sink.unlink(missing_ok=True)
    cfg.overrides.update({"STREAM_PREROLL": "10", "STREAM_BUFFER": "10", "STREAM_BUFFER_CAP": "10", "STREAM_WARN_SEC": "3000"})
    stm.create("Hozir efiri", "test")
    stm.add_gen("uzun mavzu", 6)
    ok(stm.start() is None, "preroll=10 bilan efir boshlandi")
    t0 = time.time()
    while not stm.ready and time.time() - t0 < 90:
        time.sleep(0.3)
    ok(bool(stm.ready) and stm.state == "starting", "birinchi bo'lak tayyor, lekin preroll to'lmaguncha efir ochilmadi")
    ok("preroll" in stm.status_text() and "Zaxira" in stm.status_text(), "panel zaxira/preroll ni ko'rsatadi")
    bot._cb_msg = None
    bot.callback("st:now", 111)
    t0 = time.time()
    while stm.state != "live" and time.time() - t0 < 60:
        time.sleep(0.3)
    ok(stm.state == "live", "«Hozir boshlash» tugmasi efirni darhol ochdi")
    stm.kill("sinov")
    ok(stm.state == "ended" and not stm.ready, "zaxira bo'laklari tozalandi")
    cfg.overrides.update({"STREAM_PREROLL": "2", "STREAM_BUFFER": "3", "STREAM_BUFFER_CAP": "3"})
    # ---- avto-sifat: qurilma maqsad tezlikka yetmasa o'lcham/FPS avtomatik tushiriladi
    cfg.overrides.update({"STREAM_AUTO": "1", "STREAM_TARGET_SPEED": "1000", "STREAM_RES": "720", "STREAM_FPS": "25"})
    stm.create("Avto efiri", "test")
    stm.add_gen("mavzu", 1)
    n_msg = len(fake.tg_texts())
    ok(stm.start() is None, "avto-sifat sinovi: efir boshlandi")
    t0 = time.time()
    while stm.params.get("res") == 720 and time.time() - t0 < 60:
        time.sleep(0.3)
    ok(stm.params.get("res") == 480 and stm.params.get("fps") <= 20, f"sekin qurilmada sifat avtomatik tushirildi ({stm.params.get('res')}p/{stm.params.get('fps')})")
    time.sleep(1)
    ok(any("avtomatik" in t for t in fake.tg_texts()[n_msg:]), "adminga avtomatik o'zgarish haqida xabar yuborildi")
    stm.kill("sinov")
    cfg.overrides.update({"STREAM_AUTO": "0", "STREAM_RES": "480", "STREAM_FPS": "20"})
    cfg.overrides.pop("STREAM_TARGET_SPEED", None)
    # ---- zudlik bilan to'xtatish va boshlashdagi bekor qilish
    sink.unlink(missing_ok=True)
    stm.create("Zudlik efiri", "test")
    stm.add_file(clip_p, "klip")
    ok(stm.start() is None, "uchinchi efir boshlandi")
    t0 = time.time()
    while stm.state != "live" and time.time() - t0 < 60:
        time.sleep(0.3)
    stm.kill("sinov")
    ok(stm.state == "ended" and stm.cur is None and stm.nxt is None, "zudlik bilan to'xtatish: hammasi tozalandi")
    ok(Path(clip_p).exists(), "zudlik bilan to'xtatishda asl fayl saqlanib qoldi")
    # boshlashdagi to'xtatish: qoralamaga qaytadi va navbat saqlanadi
    stm.create("Bekor efiri", "test")
    stm.add_gen("mavzu", 2)
    ok(stm.start() is None, "efir boshlandi (bekor qilinadi)")
    time.sleep(0.5)
    stm.request_stop()
    t0 = time.time()
    while stm.state == "starting" and time.time() - t0 < 30:
        time.sleep(0.2)
    ok(stm.state == "draft" and len(stm.s["queue"]) == 1, "boshlash bosqichida to'xtatish: qoralama va navbat qaytdi")
    ok(stm.discard() and not stm.exists(), "qoralama o'chirildi")
    for k in ("STREAM_TEST", "STREAM_RES", "STREAM_FPS", "STREAM_SEG_SEC", "STREAM_WARN_SEC", "STREAM_ASK_TIMEOUT",
              "STREAM_DROP_DELAY", "STREAM_FAREWELL_SEC", "STREAM_BITRATE", "STREAM_MODE", "STREAM_PREROLL",
              "STREAM_BUFFER", "STREAM_BUFFER_CAP", "STREAM_ASK_END", "STREAM_PART_SEC", "STREAM_WORKERS", "STREAM_AUTO", "STREAM_TARGET_SPEED"):
        cfg.overrides.pop(k, None)


def hide_stats_tests(app, fake):
    section("5f) Yoqtirishlar (statistika) yopiq yuklash va qayta tekshirish")
    st = fake.state
    vids = {k: v for k, v in st.videos.items() if v.get("status")}
    ok(vids, "soxta YouTube'da yuklangan videolar bor")
    ok(any(v["status"].get("publicStatsViewable") is False for v in vids.values()),
       "yuklashda publicStatsViewable=false yuborildi")
    vid = next(iter(vids))
    pub = vids[vid]["status"].get("publishAt")
    vids[vid]["status"]["publicStatsViewable"] = True      # kimdir qayta ochib qo'ydi
    app.cfg.overrides["HIDE_STATS"] = "1"
    n = app.yt.hide_stats(list(vids))
    ok(vid in n and st.videos[vid]["status"]["publicStatsViewable"] is False, "ochilib qolgan video qayta yopildi")
    ok(st.videos[vid]["status"].get("publishAt") == pub, "yopishda rejalashtirilgan vaqt saqlanib qoldi")
    ok(app.yt.hide_stats(list(vids)) == [], "allaqachon yopiq videolarga tegilmaydi")
    app.cfg.overrides["HIDE_STATS"] = "0"
    ok(app.stats.hide_stats() == 0, "HIDE_STATS=0 bo'lsa tegilmaydi")
    app.cfg.overrides.pop("HIDE_STATS", None)
