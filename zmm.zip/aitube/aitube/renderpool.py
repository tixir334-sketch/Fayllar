"""Render ishchi jarayonlari puli (subprocess + pickle; multiprocessing ishlatilmaydi)."""
from __future__ import annotations

import pickle
import queue
import struct
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from .util import log


class RemoteUnavailable(Exception):
    """Ishchi jarayonni ishga tushirib bo'lmadi (chaqiruvchi oqimlarga o'tadi)."""


class RemoteCancelled(Exception):
    pass


def _read_exact(f, n):
    buf = b""
    while len(buf) < n:
        chunk = f.read(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def _lower_prio():
    try:
        os.nice(4)
    except Exception:  # noqa: BLE001
        pass


STALL_SEC = 240


class _Worker:
    def __init__(self, root):
        self.proc = subprocess.Popen([sys.executable, "-m", "aitube.renderworker"], cwd=str(root), stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        msg = self.recv()
        if not msg or msg[0] != "ready":
            self.kill()
            raise RemoteUnavailable("ishchi jarayon tayyor bo'lmadi")

    def send(self, obj):
        b = pickle.dumps(obj, protocol=4)
        self.proc.stdin.write(struct.pack(">I", len(b)))
        self.proc.stdin.write(b)
        self.proc.stdin.flush()

    def recv(self):
        hdr = _read_exact(self.proc.stdout, 4)
        if hdr is None:
            return None
        data = _read_exact(self.proc.stdout, struct.unpack(">I", hdr)[0])
        return pickle.loads(data) if data is not None else None

    def alive(self):
        return self.proc.poll() is None

    def kill(self):
        try:
            self.proc.kill()
        except OSError:
            pass
        try:
            self.proc.wait(timeout=3)
        except Exception:  # noqa: BLE001
            pass


class RenderPool:
    def __init__(self, n: int, root):
        self.n = max(1, n)
        self.root = Path(root)
        self.idle: queue.Queue = queue.Queue()
        self.made = 0
        self.lock = threading.Lock()
        self.broken = False
        self.closed = False

    def _get(self) -> _Worker:
        while True:
            try:
                w = self.idle.get_nowait()
                if w.alive():
                    return w
                with self.lock:
                    self.made -= 1
                continue
            except queue.Empty:
                pass
            with self.lock:
                if self.made < self.n:
                    self.made += 1
                    mk = True
                else:
                    mk = False
            if mk:
                try:
                    return _Worker(self.root)
                except Exception as e:  # noqa: BLE001
                    with self.lock:
                        self.made -= 1
                    self.broken = True
                    raise RemoteUnavailable(str(e)) from e
            try:
                w = self.idle.get(timeout=0.5)
                if w.alive():
                    return w
                with self.lock:
                    self.made -= 1
            except queue.Empty:
                if self.closed:
                    raise RemoteCancelled()

    def run(self, spec: dict, cancel=None, on_tick=None) -> str:
        """Qismni ishchi jarayonda chizadi. Bekor qilinsa ishchi o'ldiriladi (RemoteCancelled)."""
        if self.broken or self.closed:
            raise RemoteUnavailable("pul ishlamayapti")
        w = self._get()
        stop = threading.Event()
        killed = [False]
        stalled = [False]
        last = [time.time()]

        def watch():
            while not stop.wait(0.3):
                if (cancel and cancel()) or self.closed:
                    killed[0] = True
                    w.kill()
                    return
                if time.time() - last[0] > STALL_SEC:      # qotib qolgan ishchi o'ldiriladi, qism qayta chiziladi
                    stalled[0] = True
                    w.kill()
                    return

        th = threading.Thread(target=watch, daemon=True, name="render-watch")
        th.start()
        ok = False
        try:
            w.send(spec)
            while True:
                msg = w.recv()
                last[0] = time.time()
                if msg is None:
                    if stalled[0]:
                        raise RemoteUnavailable("ishchi qotib qoldi (%d s javobsiz)" % STALL_SEC)
                    if killed[0]:
                        raise RemoteCancelled()
                    raise RemoteUnavailable("ishchi jarayon to'xtadi")
                if msg[0] == "tick":
                    if on_tick:
                        on_tick(msg[1])
                    continue
                if msg[0] == "ok":
                    ok = True
                    return msg[1]
                raise RuntimeError(msg[1])
        except (BrokenPipeError, OSError) as e:
            if killed[0]:
                raise RemoteCancelled() from e
            raise RemoteUnavailable(str(e)) from e
        finally:
            stop.set()
            if ok and w.alive():
                self.idle.put(w)
            else:
                w.kill()
                with self.lock:
                    self.made -= 1

    def close(self):
        self.closed = True
        while True:
            try:
                self.idle.get_nowait().kill()
            except queue.Empty:
                break
