"""Fasl rejasi: har bir fasl o'zaro bog'langan epizodlar zanjiri."""
from __future__ import annotations

import json

from .llm import LLM, LLMError
from .text import tr
from .util import clip, log, significant

KINDS = ("code", "system", "project", "explainer", "tool", "history")

PLAN_SYSTEM = """You are the showrunner of a serialized YouTube channel called "{channel}".
Channel niche: {niche}.
Audience language: {lang_name}. All titles/topics/promises MUST be in that language.
You design SEASONS: ordered chains of episodes where every episode builds on the previous one
and ends by teasing the next. The channel must feel like ONE continuous story/course, with a mix of
formats: coding lessons, systems/infrastructure deep-dives, mini-projects, tool reviews, explainers
and tech history. Titles must be honest, specific and curiosity-driven (no lies, no clickbait spam).
Return STRICT JSON only (no markdown, no comments)."""

PLAN_PROMPT = """TASK: plan_season
Design the next season with exactly {n} episodes.

Rules:
- Episode k+1 must logically depend on episode k (use what was built/learned before).
- Mix kinds: {kinds}. At least 3 different kinds in the season.
- Each episode: "title" (<= 70 chars), "topic" (1-2 sentences: what exactly is covered), "promise"
  (what the viewer will be able to do/understand after watching), "kind".
- Titles must not duplicate existing titles listed in context.
- The first episode must hook new viewers and start the season's story; the last must wrap up and
  open the door to the next season.
- Content must be practical, accurate and teachable in about {minutes} minutes each.
- If "season_continues_from" is present, this season continues directly after that episode.
- If "admin_topics" is present, weave those topics into the plan early.

JSON format:
{{"season_theme": "...", "season_description": "2-3 sentences",
  "episodes": [{{"title": "...", "topic": "...", "promise": "...", "kind": "code"}}]}}

KONTEKST (JSON):
{ctx}
"""


def performance_hints(db) -> str:
    ups = [e for e in db.uploaded(50) if (e.get("views") or 0) >= 0]
    if len(ups) < 3:
        return ""
    ranked = sorted(ups, key=lambda e: e.get("views") or 0, reverse=True)
    top = ", ".join(f"«{clip(e['title'], 50)}» ({e['views']} ko'rish)" for e in ranked[:3])
    low = ", ".join(f"«{clip(e['title'], 50)}» ({e['views']})" for e in ranked[-2:])
    return f"Eng yaxshi: {top}. Eng past: {low}. Yaxshi ishlagan mavzu uslubiga yaqinroq bo'l."


def validate_plan(obj, n, existing_titles) -> list:
    errs = []
    if not isinstance(obj, dict):
        return ["javob JSON ob'ekt emas"]
    eps = obj.get("episodes")
    if not isinstance(eps, list):
        return ["'episodes' ro'yxati yo'q"]
    if len(eps) < max(3, n - 2):
        errs.append(f"epizodlar soni kam: {len(eps)} (kerak {n})")
    seen = set(t.lower() for t in existing_titles)
    for i, e in enumerate(eps[:n], 1):
        if not isinstance(e, dict):
            errs.append(f"{i}-epizod ob'ekt emas")
            continue
        for f in ("title", "topic", "promise"):
            if not str(e.get(f, "")).strip():
                errs.append(f"{i}-epizodda '{f}' bo'sh")
        t = str(e.get("title", "")).strip().lower()
        if t and t in seen:
            errs.append(f"{i}-epizod sarlavhasi takrorlangan: {t}")
        seen.add(t)
    if not str(obj.get("season_theme", "")).strip():
        errs.append("'season_theme' bo'sh")
    return errs


def plan_season(cfg, db, llm: LLM, say=lambda m: None) -> dict:
    """Yangi fasl rejalashtiradi va epizodlarni DB ga 'planned' holatida yozadi."""
    n = max(3, cfg.int("SEASON_LENGTH"))
    lang = tr(cfg.get("LANGUAGE"))
    last = db.last_season()
    existing = [r["title"] for r in db.q("SELECT title FROM episodes")]
    ctx = {
        "channel": cfg.get("CHANNEL_NAME"),
        "existing_titles": existing[-60:],
        "performance_hints": performance_hints(db),
    }
    topics = db.kv_json("topic_queue", []) or []
    if topics:
        ctx["admin_topics"] = topics
    if last:
        eps = db.season_episodes(last["id"])
        ctx["previous_season"] = {
            "theme": last["theme"],
            "episodes": [{"title": e["title"], "summary": clip(e.get("summary") or e["promise"] or "", 200)}
                         for e in eps if e["status"] != "skipped"],
        }
        tail = db.prev_episode(db.next_gno())
        if tail:
            ctx["season_continues_from"] = {"title": tail["title"],
                                            "summary": clip(tail.get("summary") or tail["promise"] or "", 300)}
    system = PLAN_SYSTEM.format(channel=cfg.get("CHANNEL_NAME"), niche=cfg.get("CHANNEL_NICHE"),
                                lang_name=lang["lang_name"])
    prompt = PLAN_PROMPT.format(n=n, kinds=", ".join(KINDS), minutes=cfg.int("EPISODE_MINUTES"),
                                ctx=json.dumps(ctx, ensure_ascii=False, indent=1))
    obj, label, errs = None, "", []
    for attempt in range(3):
        obj, label = llm.complete_json(system, prompt + (
            "\n\nOLDINGI JAVOBDAGI XATOLAR (tuzat):\n- " + "\n- ".join(errs) if errs else ""))
        errs = validate_plan(obj, n, existing)
        if not errs:
            break
        log.warning("Reja xatolari (%d/3): %s", attempt + 1, errs)
    if errs:
        raise LLMError("Fasl rejasi yaroqsiz: " + "; ".join(errs[:4]))

    sid = db.add_season(clip(str(obj["season_theme"]).strip(), 120),
                        clip(str(obj.get("season_description", "")).strip(), 600))
    gno = db.next_gno()
    created = []
    for i, e in enumerate(obj["episodes"][:n], 1):
        kind = str(e.get("kind", "code")).lower()
        kind = kind if kind in KINDS else "code"
        eid = db.add_episode(sid, i, gno, clip(str(e["title"]).strip(), 80), str(e["topic"]).strip(),
                             str(e["promise"]).strip(), kind, {"planner": label})
        created.append((gno, e["title"], kind))
        gno += 1
    if topics:
        db.kv_set_json("topic_queue", [])
    log.info("Yangi fasl #%d: %s (%d epizod, %s)", sid, obj["season_theme"], len(created), label)
    say(f"🗓 <b>Yangi fasl rejalandi</b> (#{sid})\n<b>{obj['season_theme']}</b>\n"
        + "\n".join(f"{g}. {t} <i>[{k}]</i>" for g, t, k in created)
        + f"\n\n🤖 {label}")
    return {"season_id": sid, "episodes": created, "label": label}


def ensure_plan(cfg, db, llm, say=lambda m: None, min_ahead=2):
    """Rejalashtirilgan epizodlar yetarli bo'lishini ta'minlaydi (fasllar uzluksiz davom etadi)."""
    if len(db.planned()) < min_ahead:
        return plan_season(cfg, db, llm, say)
    return None
