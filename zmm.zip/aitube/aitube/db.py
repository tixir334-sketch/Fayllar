"""SQLite ma'lumotlar bazasi: fasllar, epizodlar (ketma-ket bog'langan), kv."""
from __future__ import annotations

import sqlite3
import threading

from .util import iso_now, json_dumps, json_loads

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS seasons(
  id INTEGER PRIMARY KEY AUTOINCREMENT, theme TEXT, description TEXT,
  playlist_id TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS episodes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, season_id INTEGER, num INTEGER, gno INTEGER,
  kind TEXT, topic TEXT, title TEXT, promise TEXT, status TEXT,
  plan_json TEXT, script_json TEXT, summary TEXT,
  video_path TEXT, thumb_path TEXT, srt_path TEXT, duration REAL, size_bytes INTEGER,
  yt_id TEXT, yt_url TEXT, uploaded TEXT, created TEXT, updated TEXT,
  tries INTEGER DEFAULT 0, error TEXT,
  views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0,
  llm TEXT, tts TEXT, render_sec REAL);
CREATE INDEX IF NOT EXISTS ix_ep_gno ON episodes(gno);
CREATE INDEX IF NOT EXISTS ix_ep_status ON episodes(status);
CREATE TABLE IF NOT EXISTS regen(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ep_id INTEGER, gno INTEGER, title TEXT,
  video_path TEXT, thumb_path TEXT, duration REAL, size_bytes INTEGER, created TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS seen_comments(id TEXT PRIMARY KEY, ts TEXT);
"""

EP_COLS = {
    "season_id", "num", "gno", "kind", "topic", "title", "promise", "status", "plan_json",
    "script_json", "summary", "video_path", "thumb_path", "srt_path", "duration",
    "size_bytes", "yt_id", "yt_url", "uploaded", "tries", "error", "views", "likes",
    "comments", "llm", "tts", "render_sec", "publish_at", "pub_state",
}
# prev uchun hisobga olinadigan holatlar (skript yozilgan epizodlar)
DONE_STATES = ("scripted", "rendered", "ready", "uploaded")


def _ep(r):
    if r is None:
        return None
    d = dict(r)
    d["script"] = json_loads(d.get("script_json"), None)
    d["plan"] = json_loads(d.get("plan_json"), {}) or {}
    return d


class DB:
    def __init__(self, path):
        self.path = str(path)
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        self.conn.row_factory = sqlite3.Row
        with self.lock:
            try:
                self.conn.execute("PRAGMA journal_mode=WAL")
            except sqlite3.DatabaseError:
                pass
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.executescript(SCHEMA)
            cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(episodes)")}
            for c in ("publish_at", "pub_state"):      # rejalashtirilgan chiqarish (eski bazalar uchun)
                if c not in cols:
                    self.conn.execute(f"ALTER TABLE episodes ADD COLUMN {c} TEXT")
            self.conn.commit()

    # ------------------------------------------------------------ past daraja
    def q(self, sql, args=(), one=False):
        with self.lock:
            cur = self.conn.execute(sql, args)
            rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows

    def x(self, sql, args=()):
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur.lastrowid

    # ------------------------------------------------------------------- kv
    def kv_get(self, key, default=None):
        r = self.q("SELECT value FROM kv WHERE key=?", (key,), one=True)
        return r["value"] if r else default

    def kv_set(self, key, value):
        self.x("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (key, str(value)))

    def kv_del(self, key):
        self.x("DELETE FROM kv WHERE key=?", (key,))

    def kv_json(self, key, default=None):
        return json_loads(self.kv_get(key), default)

    def kv_set_json(self, key, obj):
        self.kv_set(key, json_dumps(obj))

    # --------------------------------------------------------------- fasllar
    def add_season(self, theme, description):
        return self.x("INSERT INTO seasons(theme,description,created) VALUES(?,?,?)",
                      (theme, description, iso_now()))

    def season(self, sid):
        r = self.q("SELECT * FROM seasons WHERE id=?", (sid,), one=True)
        return dict(r) if r else None

    def set_playlist(self, sid, pid):
        self.x("UPDATE seasons SET playlist_id=? WHERE id=?", (pid, sid))

    def seasons(self):
        return [dict(r) for r in self.q("SELECT * FROM seasons ORDER BY id")]

    def rename_season(self, sid, theme):
        self.x("UPDATE seasons SET theme=? WHERE id=?", (theme, sid))

    def last_season(self):
        r = self.q("SELECT * FROM seasons ORDER BY id DESC LIMIT 1", one=True)
        return dict(r) if r else None

    def season_size(self, sid):
        r = self.q("SELECT COUNT(*) c FROM episodes WHERE season_id=? AND status!='skipped'",
                   (sid,), one=True)
        return r["c"]

    # -------------------------------------------------------------- epizodlar
    def next_gno(self):
        r = self.q("SELECT COALESCE(MAX(gno),0)+1 n FROM episodes", one=True)
        return r["n"]

    def add_episode(self, season_id, num, gno, title, topic, promise, kind="code", plan=None):
        now = iso_now()
        return self.x(
            "INSERT INTO episodes(season_id,num,gno,kind,topic,title,promise,status,plan_json,created,updated)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (season_id, num, gno, kind, topic, title, promise, "planned", json_dumps(plan or {}), now, now))

    def ep(self, eid):
        return _ep(self.q("SELECT * FROM episodes WHERE id=?", (eid,), one=True))

    def ep_by_gno(self, gno):
        return _ep(self.q("SELECT * FROM episodes WHERE gno=? ORDER BY id DESC", (gno,), one=True))

    def ep_update(self, eid, **fields):
        sets, args = [], []
        for k, v in fields.items():
            if k == "script":
                k, v = "script_json", json_dumps(v)
            elif k == "plan":
                k, v = "plan_json", json_dumps(v)
            if k not in EP_COLS:
                raise KeyError(f"noma'lum ustun: {k}")
            sets.append(f"{k}=?")
            args.append(v)
        sets.append("updated=?")
        args.append(iso_now())
        args.append(eid)
        self.x(f"UPDATE episodes SET {', '.join(sets)} WHERE id=?", args)

    def by_status(self, *statuses, order="gno ASC", limit=None):
        ph = ",".join("?" * len(statuses))
        sql = f"SELECT * FROM episodes WHERE status IN ({ph}) ORDER BY {order}"
        if limit:
            sql += f" LIMIT {int(limit)}"
        return [_ep(r) for r in self.q(sql, statuses)]

    def planned(self):
        return self.by_status("planned")

    def prev_episode(self, gno):
        ph = ",".join("?" * len(DONE_STATES))
        r = self.q(f"SELECT * FROM episodes WHERE gno<? AND status IN ({ph}) ORDER BY gno DESC LIMIT 1",
                   (gno, *DONE_STATES), one=True)
        return _ep(r)

    def prev_uploaded(self, gno):
        r = self.q("SELECT * FROM episodes WHERE gno<? AND status='uploaded' AND yt_id IS NOT NULL "
                   "AND yt_id!='' ORDER BY gno DESC LIMIT 1", (gno,), one=True)
        return _ep(r)

    def next_planned_after(self, gno):
        r = self.q("SELECT * FROM episodes WHERE gno>? AND status IN ('planned','scripted','rendered','ready') "
                   "ORDER BY gno ASC LIMIT 1", (gno,), one=True)
        return _ep(r)

    def recent(self, n=10):
        return [_ep(r) for r in self.q("SELECT * FROM episodes WHERE status!='planned' "
                                       "ORDER BY gno DESC LIMIT ?", (n,))]

    def season_episodes(self, sid):
        return [_ep(r) for r in self.q("SELECT * FROM episodes WHERE season_id=? ORDER BY gno", (sid,))]

    # --------------------------------------------------------------- qayta yaratilganlar
    def regen_add(self, **f):
        cols = ("ep_id", "gno", "title", "video_path", "thumb_path", "duration", "size_bytes", "created", "note")
        return self.x(f"INSERT INTO regen({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                      tuple(f.get(c) for c in cols))

    def regen_list(self, gno=None):
        if gno is None:
            return [dict(r) for r in self.q("SELECT * FROM regen ORDER BY id DESC")]
        return [dict(r) for r in self.q("SELECT * FROM regen WHERE gno=? ORDER BY id DESC", (gno,))]

    def regen_get(self, rid):
        r = self.q("SELECT * FROM regen WHERE id=?", (rid,), one=True)
        return dict(r) if r else None

    def regen_del(self, rid):
        self.x("DELETE FROM regen WHERE id=?", (rid,))

    def all_episodes(self):
        return [_ep(r) for r in self.q("SELECT * FROM episodes ORDER BY gno DESC, id DESC")]

    def uploaded(self, limit=200):
        return [_ep(r) for r in self.q("SELECT * FROM episodes WHERE status='uploaded' "
                                       "ORDER BY gno DESC LIMIT ?", (limit,))]

    def scheduled(self):
        """YouTube'ga yuklangan, lekin hali chiqmagan (rejalashtirilgan) epizodlar, vaqt bo'yicha."""
        return [_ep(r) for r in self.q("SELECT * FROM episodes WHERE status='uploaded' AND pub_state='scheduled' "
                                       "ORDER BY publish_at ASC, gno ASC")]

    def with_planned_time(self):
        """Hali yuklanmagan, lekin admin vaqt belgilab qo'ygan epizodlar."""
        return [_ep(r) for r in self.q("SELECT * FROM episodes WHERE status!='uploaded' AND pub_state='planned' "
                                       "AND publish_at IS NOT NULL ORDER BY gno ASC")]

    def counts(self):
        out = {}
        for r in self.q("SELECT status, COUNT(*) c FROM episodes GROUP BY status"):
            out[r["status"]] = r["c"]
        return out

    # ------------------------------------------------------------- izohlar
    def comment_seen(self, cid):
        return self.q("SELECT 1 FROM seen_comments WHERE id=?", (cid,), one=True) is not None

    def comment_mark(self, cid):
        self.x("INSERT OR IGNORE INTO seen_comments(id,ts) VALUES(?,?)", (cid, iso_now()))
