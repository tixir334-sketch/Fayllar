"""Barcha komponentlarni bir joyga yig'uvchi ilova obyekti."""
from __future__ import annotations

import threading
import time

from .config import Config
from .db import DB
from .hwenc import HW
from .llm import LLM
from .pipeline import Pipeline
from .scheduler import JobRunner, Scheduler
from .security import Guard, harden_files
from .stats import Stats
from .stream import Stream
from .tg import GLOBAL, THROTTLE, Notifier, Telegram
from .tts import TTS
from .util import NET, fmt_dur, setup_logging
from .youtube import YouTube


class App:
    def __init__(self, cfg: Config | None = None, mock: bool = False):
        """Yagona (admin) ilova: barcha komponentlar bir joyda. Ko'p foydalanuvchi rejimi olib tashlangan."""
        self.cfg = cfg or Config()
        self.log = setup_logging(self.cfg)
        self.db = DB(self.cfg.db_path)
        mock_fn = None
        if mock:
            from .mockllm import mock_llm
            mock_fn = mock_llm
        self.llm = LLM(self.cfg, mock=mock_fn)
        self.tts = TTS(self.cfg)
        self.yt = YouTube(self.cfg)
        self.tg = Telegram(self.cfg)
        self.n = Notifier(self.tg)
        HW.bind(self.cfg)                    # GPU/CPU kodlash menejeri shu sozlamalarni o'qiydi
        self.pipeline = Pipeline(self.cfg, self.db, self.llm, self.tts, self.yt, self.tg, self.n)
        self.stats = Stats(self.cfg, self.db, self.yt, self.n)
        THROTTLE.set(self.cfg.get("THROTTLE_SEC"))
        GLOBAL.rate = max(1.0, min(30.0, self.cfg.float("TG_RATE", 25)))
        self.jobs = JobRunner(self.n)
        self.sched = Scheduler(self)
        self.guard = Guard(self.cfg, self.db, self.n)
        harden_files(self.cfg)
        NET.on_event = self._net_event
        self.stream = Stream(self)
        self.bot = None
        self.started = time.time()

    def _net_event(self, ev, secs):
        """Internet holati o'zgarganda adminga bir marta xabar beradi."""
        if ev == "down":
            self.n.say("🌐 <b>Internet uzildi.</b> Jarayon to'xtab turibdi — aloqa qaytishi bilan "
                       "to'xtagan joyidan o'zi davom etadi (qo'l bilan hech narsa qilish shart emas).")
        elif ev == "up":
            self.n.say(f"✅ <b>Internet qaytdi</b> ({fmt_dur(secs)} uzilgan edi). Jarayon davom etmoqda.")
            self.n.flush_outbox()
        elif ev == "giveup":
            self.n.say("⚠️ Internet uzoq vaqt qaytmadi, joriy ish to'xtatildi. /retry bilan davom ettirasiz.")

    def _warm_encoder(self):
        """Kodlovchini (NVENC/QSV/AMF/MediaCodec) ilova boshlanganda fonda sinaydi: panel va efir keyin kutib qolmaydi."""
        try:
            HW.bind(self.cfg)
            HW.detect()
        except Exception as e:  # noqa: BLE001
            self.log.warning("Kodlovchini oldindan sinab bo'lmadi: %s", e)

    def start_background(self, with_bot=True):
        from .bot import Bot
        self.jobs.start()
        self.sched.start()
        self.stream.sys.start_planner()          # rejalashtirilgan efir (STREAM_AT)
        threading.Thread(target=self._warm_encoder, daemon=True, name="hw-warm").start()   # GPU/telefon kodlovchisini oldindan sinash
        if with_bot and self.tg.token:
            self.bot = Bot(self)
            self.bot.start()

    def close(self):
        """Ilovani to'xtatish: oqimlar to'xtaydi, baza yopiladi (ma'lumot diskda qoladi)."""
        try:
            self.sched.stop_flag.set()
            self.jobs.stop()
        finally:
            try:
                with self.db.lock:
                    self.db.conn.commit()
                    self.db.conn.close()
            except Exception:  # noqa: BLE001
                pass
