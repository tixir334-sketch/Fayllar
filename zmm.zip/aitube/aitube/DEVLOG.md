
## Stream tezlashtirish (bajarildi)
- video.py: `_audio_scene` (parallel TTS), `render_range` (kadrlar oralig'i, ovozsiz), `mix_audio`, `prepare_stream`, `render_stream` (30s qismlar parallel + AAC bir marta + concat -c copy).
- streamgen.write_segment: 10 daqiqalik bo'lak ~5 daqiqalik ketma-ket LLM chaqiruvlariga bo'linadi.
- stream.py: tayyor bo'laklar DISKda (`ready/`), RAMda faqat joriy; preroll (STREAM_PREROLL) tayyor bo'lgach efir ochiladi; `st:now` darhol boshlaydi;
  prepper oqimi keyingi 2 bo'lak ssenariy+ovozini oldindan tayyorlaydi; renderer puli + ThreadPool; fayllar ham qismlab parallel kodlanadi;
  zaxira (STREAM_BUFFER) kamaysa yangisi tayyorlanadi; panelda zaxira/tezlik (x real vaqt). Kalitlar: STREAM_PREROLL/BUFFER/WORKERS/PART_SEC/PRESET.
- Sinov: stream_tests (84→89+ tekshiruv) hammasi o'tdi.

## Stream: bor kuch bilan (bajarildi)
- Ishchilar: avto = barcha yadro (10 tagacha); TTS parallel 3-8; tayyorlovchi 3 bo`lak oldinda.
- streamgen: 10 daqiqalik bo`lak uchun avval qisqa reja, so`ng 2 qism BIR VAQTDA (parallel) yoziladi; xato bo`lsa ketma-ket.
- Qism (30s) yiqilsa bir marta qayta uriniladi (video render va fayl kodlash).


## Stream: sekin qurilma uchun (bajarildi)
- Fon animatsiyasi STREAM_BG_FPS (12) kadr/s da yangilanadi, oraliq kadrlar takrorlanadi (CPU 2-3x kam).
- Efir boshida tezlik o`lchovi (_benchmark): chizish+kodlash -> taxminiy x real vaqt; sekin bo`lsa admin ga aniq tavsiya.
- STREAM_PREROLL_WAIT (1200s): shundan so`ng tayyor bo`laklar bilan efir ochiladi.
- Panelda kadrlar foizi, kadr/s va bo`lak tugash vaqti.


## Stream: AI poygasi (bajarildi)
- llm.complete_race / complete_json(race=n): 5 ta har xil provayder/model BIR VAQTDA, birinchi yaroqli JSON olinadi (STREAM_AI_RACE=5). Sabab: bitta osilib qolgan provayder 9 daqiqagacha kutdirardi.
- Talaffuz lug`ati so`rovi 25s dan oshsa kutilmaydi. Ovoz: hamma sahna bir vaqtda, xato bergan sahna o`zi 3 martagacha qayta uriniladi.


## Stream: partiyalab tayyorlash (bajarildi)
- streamgen.write_batch: butun reja (syllabus) 1 ta tez AI so`rovida, so`ng barcha ~3 daqiqalik qismlar parallel (6 ta pul, har biri 3 AI poygasi). STREAM_BATCH=5 bo`lak bir vaqtda.
- stream._prepper: partiya ssenariysi -> barcha bo`laklar ovozi bir vaqtda (umumiy 16 ta TTS semafori) -> tayyor bo`lgani zahoti tartibda navbatga.
- Partiya rejimida bo`laklar mustaqil: gap o`rtasida uzish (midcut) faqat xayrlashuv/bittalab zaxira yo`lida.


## Stream: partiyalab tayyorlash (bajarildi)
- streamgen.write_batch: bitta reja (syllabus) + barcha ~3 daqiqalik qismlar parallel -> STREAM_BATCH (5) bo`lak BIR VAQTDA; ovozlar ham hammasi birdan (umumiy chegara 16).
- Partiyada gap o`rtasida uzish (midcut) o`chiq (bo`laklar mustaqil); xayrlashuv eski yo`l bilan.


## Stream: ketma-ket ssenariy + 5 AI poygasi (bajarildi)
- STREAM_BATCH=1 (standart): bo`laklar ketma-ket, har bir ssenariy bitta so`rov, 5 ta AI poygalashadi; midcut ishlaydi. STREAM_SPLIT=1/BATCH>1 ixtiyoriy parallel rejimlar.


## Stream: kuchli optimizatsiya (bajarildi)
- render_range: asos kadr (fon+mazmun) qayta ishlatiladi, animatsiya holati STREAM_BG_FPS (8) bo`yicha kvantlanadi, har kadrda faqat subtitr.
- Render qismlari alohida jarayonlarda (renderworker.py + renderpool.py, subprocess+pickle, GIL yo`q; STREAM_PROCS=0 avto, -1 o`chiq). Ishlamasa oqimlarga o`tadi.
- Efir boshida o`lchov va avto-sifat (STREAM_AUTO=1, STREAM_TARGET_SPEED=2.0): sekin qurilmada 720p/25 -> 720p/20 -> 480p... + ultrafast.

