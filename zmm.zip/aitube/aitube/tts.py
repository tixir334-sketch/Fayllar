"""Bepul ovoz: Edge TTS (edge-tts paketi) -> Google TTS (requests orqali) -> (ixtiyoriy) jimlik.

Barcha natijalar 44.1kHz mono 16-bit WAV ga o'tkaziladi (davomiylik `wave` moduli bilan o'lchanadi).
"""
from __future__ import annotations

import asyncio
import json
import random
import re
import struct
import tempfile
import threading
import time
import wave
from pathlib import Path

from .text import tts_prepare
from .util import NET, http, is_net_error, log, run, sha1

SR = 44100


# Ovoz variantlari: nom -> (edge ovozi, tezlik, ton, tavsif). O'zbek tilida faqat 2 ta tabiiy ovoz bor
# (Sardor - yigit, Madina - qiz); variantlar tezlik va tonni o'zgartirib hosil qilinadi.
VOICE_PRESETS = {
    "yigit1": ("uz-UZ-SardorNeural", "+0%", "+0Hz", "👦 Yigit — tabiiy"),
    "yigit2": ("uz-UZ-SardorNeural", "-6%", "-12Hz", "👦 Yigit — chuqur, vazmin"),
    "yigit3": ("uz-UZ-SardorNeural", "+10%", "+4Hz", "👦 Yigit — tez, energik"),
    "qiz1": ("uz-UZ-MadinaNeural", "+0%", "+0Hz", "👧 Qiz — tabiiy"),
    "qiz2": ("uz-UZ-MadinaNeural", "+8%", "+6Hz", "👧 Qiz — yengil, quvnoq"),
    "qiz3": ("uz-UZ-MadinaNeural", "-8%", "-3Hz", "👧 Qiz — sokin, mayin"),
}
VOICE_ALIASES = {"male": "yigit1", "boy": "yigit1", "erkak": "yigit1", "ogil": "yigit1",
                 "female": "qiz1", "girl": "qiz1", "ayol": "qiz1"}


class Tts_state:
    upgraded = False


class AsyncLoop:
    """Hamma edge-tts ulanishlari BITTA asyncio hodisa sikli ichida bir vaqtda (asinxron) ishlaydi: har chaqiruvga alohida sikl/oqim
    ochilmaydi — o'nlab sahna ovozi tarmoqda parallel, kam resurs bilan yaratiladi (telefonda ham tez)."""
    _lock = threading.Lock()
    _loop = None
    _thread = None

    @classmethod
    def get(cls):
        with cls._lock:
            if cls._loop is None or cls._thread is None or not cls._thread.is_alive() or cls._loop.is_closed():
                loop = asyncio.new_event_loop()
                ready = threading.Event()

                def runner():
                    asyncio.set_event_loop(loop)
                    loop.call_soon(ready.set)
                    loop.run_forever()

                th = threading.Thread(target=runner, daemon=True, name="tts-async")
                th.start()
                ready.wait(5)
                cls._loop, cls._thread = loop, th
            return cls._loop

    @classmethod
    def run(cls, coro, timeout: float = 135.0):
        """Korutinani umumiy siklda ishga tushirib natijani kutadi (chaqiruvchi oqim bloklanadi, sikl esa boshqalar bilan band)."""
        fut = asyncio.run_coroutine_threadsafe(coro, cls.get())
        try:
            return fut.result(timeout=timeout)
        except Exception:
            fut.cancel()
            raise


class TTSError(Exception):
    pass


def wav_duration(path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())


def write_silence(path, seconds: float):
    n = int(SR * max(0.05, seconds))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(struct.pack("<h", 0) * n)


def concat_wavs(paths, out):
    with wave.open(str(out), "wb") as o:
        o.setnchannels(1)
        o.setsampwidth(2)
        o.setframerate(SR)
        for p in paths:
            with wave.open(str(p), "rb") as w:
                if (w.getnchannels(), w.getsampwidth(), w.getframerate()) != (1, 2, SR):
                    raise TTSError(f"WAV formati mos emas: {p}")
                o.writeframes(w.readframes(w.getnframes()))


def to_wav(src, dst, normalize=True) -> None:
    """Istalgan audio faylni 44.1k mono wav ga o'giradi (ffmpeg). Normallashtirish va 44.1k ga tekislash BIR o'tishda
    bajariladi (loudnorm 192 kHz ga chiqargani uchun filtr zanjiriga aresample qo'shilgan) — ikkinchi ffmpeg kerak emas."""
    base = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le"]
    if normalize:
        rc, _, err = run(base + ["-af", f"loudnorm=I=-16:TP=-1.5:LRA=11,aresample={SR}", str(dst)], timeout=180)
        if rc == 0 and Path(dst).exists() and Path(dst).stat().st_size > 1000:
            try:
                with wave.open(str(dst), "rb") as w:
                    if w.getframerate() == SR and w.getnchannels() == 1:
                        return
            except wave.Error:
                pass
            tmp = str(dst) + ".re.wav"          # kamdan-kam: format mos kelmasa — qayta tekislaymiz
            rc2, _, _ = run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(dst), "-ar", str(SR), "-ac", "1",
                             "-c:a", "pcm_s16le", tmp], timeout=120)
            if rc2 == 0:
                Path(tmp).replace(dst)
                return
    rc, _, err = run(base + [str(dst)], timeout=180)
    if rc != 0:
        raise TTSError(f"ffmpeg audio o'tkazish xatosi: {err[-300:]}")


def split_for_google(text: str, limit: int = 180) -> list:
    sents = re.split(r"(?<=[.!?])\s+", text)
    chunks, cur = [], ""
    for s in sents:
        if len(s) > limit:
            parts = re.split(r"(?<=[,;:])\s+", s)
        else:
            parts = [s]
        for p in parts:
            while len(p) > limit:
                cut = p.rfind(" ", 0, limit)
                cut = cut if cut > 40 else limit
                if cur:
                    chunks.append(cur)
                    cur = ""
                chunks.append(p[:cut].strip())
                p = p[cut:].strip()
            if not cur:
                cur = p
            elif len(cur) + 1 + len(p) <= limit:
                cur += " " + p
            else:
                chunks.append(cur)
                cur = p
    if cur:
        chunks.append(cur)
    return [c for c in chunks if c.strip()]


class TTS:
    def __init__(self, cfg):
        self.cfg = cfg
        self.last_provider = ""
        self.disabled: set = set()
        self.fresh = False      # True: keshdagi eski ovoz o'rniga hammasi noldan yaratiladi

    def providers(self):
        return [p for p in self.cfg.list("TTS_ORDER") if p in ("edge", "google")]

    # ---------------------------------------------------------------- provayderlar
    _edge_upgraded = False

    def _upgrade_edge(self) -> bool:
        """Edge 403 (eski versiya rad etilgan) bo'lsa edge-tts ni bir marta avtomatik yangilaydi."""
        import sys
        if Tts_state.upgraded:
            return False
        Tts_state.upgraded = True
        log.warning("Edge TTS 403: edge-tts yangilanmoqda…")
        for extra in (["--break-system-packages"], []):
            rc, _, err = run([sys.executable, "-m", "pip", "install", "-U", "edge-tts"] + extra, timeout=240)
            if rc == 0:
                for m in [m for m in sys.modules if m == "edge_tts" or m.startswith("edge_tts.")]:
                    del sys.modules[m]
                log.info("edge-tts yangilandi")
                return True
        log.warning("edge-tts yangilanmadi: %s", err[-200:])
        return False

    def _edge(self, text, out_wav, spec=None):
        """Edge TTS. So'z chegaralarini [(offset_s, dur_s, matn)] ko'rinishida qaytaradi (bo'lmasa [])."""
        try:
            import edge_tts  # type: ignore
        except ImportError:
            raise TTSError("edge-tts o'rnatilmagan (pip install edge-tts)")
        voice, rate, pitch = spec or (self.cfg.get("TTS_VOICE"), self.cfg.get("TTS_RATE"), self.cfg.get("TTS_PITCH"))
        bounds: list = []
        with tempfile.TemporaryDirectory() as td:
            mp3 = Path(td) / "e.mp3"

            async def go():
                try:
                    com = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch or "+0Hz",
                                               boundary="WordBoundary")
                except TypeError:   # eski versiyada boundary parametri yo'q
                    com = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch or "+0Hz")

                async def pump():
                    with open(mp3, "wb") as f:
                        async for ch in com.stream():
                            kind = ch.get("type")
                            if kind == "audio":
                                f.write(ch["data"])
                            elif kind == "WordBoundary":
                                bounds.append((float(ch["offset"]) / 1e7, float(ch["duration"]) / 1e7,
                                               str(ch.get("text", ""))))

                await asyncio.wait_for(pump(), timeout=120)

            try:
                AsyncLoop.run(go())
            except Exception as e:
                if "403" in str(e) and self._upgrade_edge():
                    return self._edge(text, out_wav, spec)      # yangilangan paket bilan bir marta qayta urinish
                raise TTSError(f"edge-tts: {type(e).__name__}: {str(e)[:160]}"
                               + (" | 403: Microsoft eski edge-tts versiyasini rad etdi. Termux'da: "
                                  "pip install -U edge-tts" if "403" in str(e) else ""))
            if not mp3.exists() or mp3.stat().st_size < 800:
                raise TTSError("edge-tts bo'sh audio qaytardi")
            to_wav(mp3, out_wav)
        return bounds

    def _google(self, text, out_wav):
        lang = self.cfg.get("TTS_LANG")
        chunks = split_for_google(text)
        if not chunks:
            raise TTSError("matn bo'sh")
        base = self.cfg.get("GTTS_BASE")
        with tempfile.TemporaryDirectory() as td:
            def fetch(i, ch):
                r = http("GET", base, params={"ie": "UTF-8", "q": ch, "tl": lang, "client": "tw-ob",
                                              "ttsspeed": "1"}, retries=3, backoff=0.3, timeout=(15, 40), wait_net=True)
                if r.status_code != 200 or len(r.content) < 500:
                    raise TTSError(f"google tts HTTP {r.status_code} (bo'lak {i + 1}/{len(chunks)}, til={lang})")
                mp3 = Path(td) / f"g{i}.mp3"
                mp3.write_bytes(r.content)
                wavp = Path(td) / f"g{i}.wav"
                to_wav(mp3, wavp, normalize=False)
                return wavp

            # bo'laklar PARALLEL yuklanadi (ketma-ket kutish va uyqu yo'q); tartib saqlanadi
            if len(chunks) == 1:
                parts = [fetch(0, chunks[0])]
            else:
                from concurrent.futures import ThreadPoolExecutor
                with ThreadPoolExecutor(max_workers=min(6, len(chunks))) as ex:
                    parts = list(ex.map(lambda t: fetch(*t), enumerate(chunks)))
            joined = Path(td) / "all.wav"
            concat_wavs(parts, joined)
            to_wav(joined, out_wav)

    # ---------------------------------------------------------------- asosiy
    def synth(self, text: str, out_wav, allow_silent=None, spec=None) -> str:
        """Matnni ovozga aylantiradi (talaffuz filtri bilan). Ishlatilgan provayder nomini qaytaradi.
        spec=(ovoz, tezlik, ton) berilsa, umumiy sozlamalarga tegmasdan shu ovozda yasaydi
        (boshqa jarayonlarga xalaqit bermaydi)."""
        return self.synth_ex(text, out_wav, allow_silent, spec)[0]

    def synth_ex(self, text: str, out_wav, allow_silent=None, spec=None, prepared=False, only=None):
        """synth() ning kengaytirilgani: (provayder, so'z_chegaralari) qaytaradi.
        prepared=True bo'lsa matn allaqachon aytilish shaklida (speak.speak_words) va qayta o'zgartirilmaydi."""
        out_wav = Path(out_wav)
        text = text.strip() if prepared else tts_prepare(text)
        if not text:
            raise TTSError("ovozlashtirish uchun matn bo'sh")
        voice, rate, pitch = spec or (self.cfg.get("TTS_VOICE"), self.cfg.get("TTS_RATE"), self.cfg.get("TTS_PITCH"))
        lang = self.cfg.get("TTS_LANG")

        def cache_for(name):
            key = sha1(name, voice, rate, pitch, text) if name == "edge" else sha1(name, lang, text)
            return self.cfg.dirs["cache"] / ("tts_" + key + ".wav")

        errors = []
        plist = [p for p in self.providers() if not only or p == only]
        for pi, name in enumerate(plist):
            if name in self.disabled:
                continue
            max_tries = 6 if pi == 0 else 2      # asosiy ovoz (edge) 6 marta uriniladi: videoning o'rtasida ovoz almashmasin
            cache = cache_for(name)
            side = cache.with_suffix(".json")
            if not self.fresh and cache.exists() and cache.stat().st_size > 2000:
                out_wav.write_bytes(cache.read_bytes())
                self.last_provider = "cache"
                bounds = []
                try:
                    bounds = [tuple(b) for b in json.loads(side.read_text(encoding="utf-8"))] if side.exists() else []
                except (OSError, ValueError):
                    pass
                return "cache", bounds
            tries, nwait = 0, 0
            while tries < max_tries:
                tries += 1
                try:
                    bounds = []
                    if name == "edge":
                        bounds = self._edge(text, out_wav, (voice, rate, pitch)) or []
                    else:
                        getattr(self, "_" + name)(text, out_wav)
                    if wav_duration(out_wav) < 0.3:
                        raise TTSError("audio juda qisqa")
                    cache.write_bytes(out_wav.read_bytes())
                    if bounds:
                        try:
                            side.write_text(json.dumps(bounds), encoding="utf-8")
                        except OSError:
                            pass
                    self.last_provider = name
                    return name, bounds
                except Exception as e:
                    errors.append(f"{name}: {e}")
                    log.warning("TTS %s xato (%d): %s", name, tries, e)
                    if "o'rnatilmagan" in str(e):
                        self.disabled.add(name)
                        break
                    if is_net_error(e) and nwait < 8:   # internet uzilgan: qaytguncha kutib, shu sahnadan davom etadi
                        nwait += 1
                        if NET.wait_online()[0]:
                            tries -= 1
                            continue
                    if tries > 1:   # 1-qayta urinish DARHOL; keyingilarida qisqa tasodifiy tanaffus (parallel oqimlar to'qnashmasin)
                        time.sleep(min(0.25 * (tries - 1), 1.5) * (0.5 + random.random()))
        if allow_silent is None:
            allow_silent = self.cfg.bool("TTS_ALLOW_SILENT")
        if allow_silent:
            words = max(1, len(text.split()))
            write_silence(out_wav, words / 2.3 + 0.5)
            self.last_provider = "silent"
            return "silent", []
        raise TTSError("Hech bir ovoz provayderi ishlamadi: " + " | ".join(errors[-4:]))
