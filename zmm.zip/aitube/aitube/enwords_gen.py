"""Umumiy ingliz so'z boyligi (kod misollari, ibora va texnik gaplarda uchraydigan so'zlar) - ingliz aytilishi."""

RAW = """
# ---------------- kod misollarida ko'p uchraydigan so'zlar
hello=helou; world=uerld; name=neym; names=neymlar; age=eyj; price=prays; prices=praysiz; total=toutl; result=rizalt
results=rizaltlar; number=namber; numbers=namberlar; num=nam; text=tekst; first=ferst; second=sekond; third=serd
last=last; next=nekst; previous=privyes; prev=priv; current=karent; new=nyu; old=ould; item=aytem; items=aytemlar
line=layn; lines=laynlar; word=uerd; words=uerdlar; letter=leter; letters=leterlar; char=char; chars=charlar
sentence=sentens; paragraph=paragraf; title=taytl; titles=taytllar; subtitle=sabtaytl; description=diskripshn
label=leybl; caption=kepshn; heading=heding; header=heder; footer=futer; content=kontent; message=mesij
data=deyta; info=info; information=informeyshn; detail=diteyl; details=diteylz; summary=sameri; example=igzempl
examples=igzemplar; sample=sempl; demo=demo; test=test; temp=temp; temporary=temporeri; tmp=ti em pi; foo=fu; bar=bar
baz=bez; spam=spem; eggs=egz; lorem=lorem; ipsum=ipsam; john=jon; doe=dou; alice=elis; bob=bob; user1=yuzer van
student=styudent; students=styudentlar; teacher=ticher; person=person; people=pipl; employee=emploi; employees=emploilar
customer=kastomer; product=prodakt; order=order; book=buk; books=buklar; car=kar; cars=karlar; animal=animal; dog=dog
cat=ket; fruit=frut; apple=epl; apples=eplz; banana=banana; orange=orinj; color=kolor; red=red; green=grin; blue=blu
yellow=yelou; black=blek; white=uayt; pink=pink; purple=perpl; gray=grey; grey=grey; brown=braun; city=siti
country=kantri; street=strit; address=adres; phone=foun; email=imeyl; mail=meyl; date=deyt; time=taym; day=dey; days=deylar
week=uik; month=mans; year=yer; hour=auer; minute=minit; second=sekond; today=tudey; tomorrow=tumorou; yesterday=yesterdey
now=nau; later=leyter; soon=sun; always=olueyz; never=never; sometimes=samtaymz; often=ofn; again=agen; once=uans; twice=tuays
start=start; started=startid; end=end; begin=bigin; stop=stop; finish=finish; done=dan; ready=redi; wait=ueyt; sleep=slip
go=gou; come=kam; run=ran; running=raning; walk=uok; jump=jamp; move=muv; moving=muving; turn=tern; stay=stey
get=get; got=got; give=giv; take=teyk; make=meyk; made=meyd; put=put; set=set; use=yuz; used=yuzd; using=yuzing
usage=yusij; call=kol; called=kold; calling=koling; ask=ask; answer=ansr; question=kueschn; questions=kueschnlar
say=sey; said=sed; tell=tel; speak=spik; talk=tok; listen=lisn; hear=hir; see=si; look=luk; watch=uoch; show=shou
shown=shoun; hide=hayd; hidden=hidn; find=faynd; found=faund; search=serch; try=tray; tried=trayd; trying=traying
want=uont; need=nid; needs=nidz; like=layk; love=lav; hate=heyt; know=nou; think=sink; believe=biliv; remember=rimember
forget=forget; learn=lern; learned=lernd; learning=lerning; teach=tich; study=stadi; practice=praktis; read=rid
write=rayt; wrote=rout; written=ritn; draw=dro; drawing=droing; paint=peynt; play=pley; played=pleyd; player=pleyer
game=geym; games=geymlar; gaming=geyming; win=uin; won=uan; lose=luz; lost=lost; score=skor; level=level; levels=levellar
life=layf; live=liv; lives=livz; alive=alayv; dead=ded; death=des; kill=kil; killed=kild; fight=fayt; attack=atek
health=helth; hp=eych pi; mana=mana; damage=demij; speed=spid; fast=fast; slow=slou; quick=kuik; quickly=kuikli
easy=izi; hard=hard; simple=simpl; complex=kompleks; difficult=difikalt; important=important; useful=yusful
useless=yusles; good=gud; bad=bed; best=best; better=beter; worst=uorst; great=greyt; nice=nays; cool=kul; awesome=osm
amazing=ameyzing; perfect=perfekt; wrong=rong; right=rayt; correct=korekt; fine=fayn; okay=oukey; ok=oukey; yes=yes
no=nou; maybe=meybi; please=pliz; thanks=senks; thank=senk; sorry=sori; welcome=uelkam; bye=bay; goodbye=gudbay
hi=hay; hey=hey; wow=uau; oops=ups; boom=bum; cheers=chirz; enjoy=indjoy; fun=fan; funny=fani; happy=hepi; sad=sed
big=big; small=smol; large=larj; tiny=tayni; huge=hyuj; long=long; short=short; tall=tol; wide=uayd; narrow=nerou
full=ful; empty=empti; open=oupen; closed=klouzd; free=fri; busy=bizi; hot=hot; cold=kould; warm=uorm; cool=kul
high=hay; low=lou; top=top; bottom=botom; up=ap; down=daun; left=left; right=rayt; center=senter; middle=midl
front=frant; back=bek; side=sayd; inside=insayd; outside=autsayd; between=bituin; over=ouver; under=ander; above=abav
below=bilou; before=bifor; after=after; during=dyuring; until=antil; since=sins; while=uayl; because=bikoz
about=abaut; around=araund; through=sru; across=akros; against=agenst; without=uidaut; within=uidin; with=uit
and=end; or=or; not=not; but=bat; if=if; then=den; than=den; so=sou; very=veri; too=tu; also=olsou; just=jast
only=ounli; even=iven; still=stil; already=olredi; yet=yet; each=ich; every=evri; all=ol; any=eni; some=sam; many=meni
much=mach; more=mor; most=moust; less=les; least=list; few=fyu; other=ader; another=anader; same=seym; different=diferent
such=sach; both=bous; either=ider; neither=nider; one=uan; two=tu; three=sri; four=for; five=fayv; six=siks; seven=seven
eight=eyt; nine=nayn; ten=ten; zero=zirou; hundred=handred; thousand=sauzend; million=milyon; billion=bilyon
what=uot; when=uen; where=uer; why=uay; who=hu; whom=hum; whose=huz; which=uich; how=hau; whatever=uotever
here=hir; there=der; this=dis; that=det; these=diz; those=douz; its=its; they=dey; them=dem; their=der
we=ui; our=aur; you=yu; your=yor; he=hi; she=shi; his=hiz; her=her; my=may; mine=mayn; me=mi; myself=mayself
can=ken; could=kud; will=uil; would=uud; shall=shel; should=shud; might=mayt; must=mast; have=hev
has=hez; had=hed; having=heving; do=du; does=daz; did=did; done=dan; doing=duing; be=bi; been=bin; being=biing
is=iz; are=ar; was=uoz; were=uer; let=let; lets=lets; get=get; going=gouing; gonna=gona; wanna=uona
the=de; of=ov; to=tu; in=in; on=on; at=et; by=bay; for=for; from=from; into=intu; onto=ontu; off=of
out=aut; up=ap; as=ez; per=per; via=vaya; versus=versus; vs=versus; etc=et setera; eg=i ji; ie=ay i; aka=ey key ey
asap=ey es ey pi; faq=ef ey kyu; diy=di ay uay; fyi=ef uay ay; btw=bi ti dabilyu; imo=ay em o; lol=lol; omg=o em ji
brb=bi ar bi; idk=ay di key; tbd=ti bi di; todo=tu du; wip=dabilyu ay pi; eta=i ti ey; tl=ti el; dr=di ar
# ---------------- kundalik va umumiy
home=houm; house=haus; room=rum; door=dor; window=uindou; table=teybl; chair=cher; bed=bed; kitchen=kichen
office=ofis; school=skul; university=yunivrsiti; college=kolij; class=kles; classroom=klesrum; 
work=uerk; works=uerks; worked=uerkt; worker=uerker; working=uerking; job=job; boss=bos; team=tim; company=kampani
money=mani; cash=kesh; card=kard; coin=koyn; coins=koynlar; bitcoin=bitkoyn; ethereum=iserium; crypto=kripto
blockchain=blokcheyn; wallet=uolet; token=touken; nft=en ef ti; mining=mayning; miner=mayner; trading=treyding
trader=treyder; stock=stok; stocks=stoklar; forex=foreks; market=market; price=prays; chart=chart; candle=kendl
buy=bay; sell=sel; bought=bot; sold=sould; paid=peyd; cost=kost; cheap=chip; expensive=ikspensiv
food=fud; water=uoter; coffee=kofi; tea=ti; milk=milk; bread=bred; pizza=pitsa; burger=berger; sandwich=senduich
music=myuzik; song=song; songs=songlar; movie=muvi; movies=muvilar; film=film; photo=foutou; photos=foutoular
picture=pikcher; pictures=pikcherlar; image=imij; art=art; design=dizayn; style=stayl; fashion=feshn; beauty=byuti
sport=sport; sports=sportlar; football=futbol; basketball=basketbol; tennis=tenis; gym=jim; fitness=fitnes
travel=trevel; trip=trip; flight=flayt; airport=erport; ticket=tiket; taxi=taksi; bus=bas; train=treyn
car=kar; bike=bayk; road=roud; map=mep; maps=meplar; location=lokeyshn; place=pleys; places=pleyslar; world=uerld
earth=ers; sun=san; moon=mun; star=star; stars=starlar; space=speys; planet=planet; galaxy=galaksi; universe=yunivers
nature=neychr; tree=tri; flower=flauer; river=river; sea=si; ocean=oushn; mountain=mauntin; forest=forist
weather=veder; rain=reyn; snow=snou; wind=uind; storm=storm; sunny=sani; cloud=klaud; clouds=klaudlar
body=badi; head=hed; hand=hend; hands=hendlar; eye=ay; eyes=ayz; face=feys; heart=hart; brain=breyn; mind=mayn
family=femili; mother=mader; father=fader; brother=brader; sister=sister; baby=beybi; kid=kid; kids=kidlar
woman=umen; boy=boy; girl=gerl; guy=gay; guys=gayz; people=pipl; human=hyuman; humans=hyumanlar
life=layf; story=stori; news=nyuz; paper=peyper; book=buk; page=peyj; article=artikl; articles=artiklar
language=lengvij; languages=lengvijlar; english=inglish; uzbek=uzbek; russian=rashan; translate=trenzleyt
translation=trenzleyshn; speech=spich; voice=voys; sound=saund; audio=odiou; noise=noyz; silence=sayles
power=pauer; energy=enerji; force=fors; light=layt; fire=fayer; ice=ays; air=er; gas=ges; oil=oyl; electric=ilektrik
electricity=ilektrisiti; solar=soular; wind=uind; nuclear=nyukliyar; battery=betari; engine=enjin; motor=mouter
machine=mashin; machines=mashinlar; tool=tul; tools=tullar; toolbox=tul boks; kit=kit; gadget=gejet; device=divays
devices=divaysiz; gear=gir; wheel=uil; button=batn; switch=svich; lever=lever; screw=skru; wire=uayer; cable=keybl
safe=seyf; safety=seyfti; secure=sikyur; security=sikyuriti; risk=risk; danger=deynjer; dangerous=deynjeras
trust=trast; fake=feyk; true=tru; false=fols; fact=fekt; facts=fektlar; truth=trus; lie=lay; myth=mis
idea=aydiya; ideas=aydiyalar; plan=plen; goal=goul; goals=goullar; dream=drim; vision=vizhn; mission=mishn
success=saksess; failure=feylyur; fail=feyl; failed=feyld; pass=pas; passed=past; win=uin; loss=los; gain=geyn
change=cheynj; changes=cheynjlar; changed=cheynjd; improve=impruv; improved=impruvd; fix=fiks; fixed=fiksd
break=breyk; broken=brouken; repair=ripeyr; clean=klin; cleaner=kliner; dirty=derti; clear=klir; messy=mesi
simple=simpl; basic=beysik; advanced=advansd; expert=ekspert; beginner=biginer; pro=prou; master=master
smart=smart; clever=klever; genius=jinyas; crazy=kreyzi; magic=mejik; secret=sikrit; hidden=hidn; mystery=misteri
"""
