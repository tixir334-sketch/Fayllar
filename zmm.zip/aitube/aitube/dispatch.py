"""Update larni foydalanuvchi bo'yicha alohida navbatlarda ishlovchi dispatcher.

• Polling sikli hech qachon kutib qolmaydi: update navbatga tushadi va darrov keyingisi o'qiladi.
• Bir foydalanuvchining update lari TARTIB bilan, boshqalarnikidan mustaqil bajariladi (biri qotsa, qolganlari ishlayveradi).
• Bir foydalanuvchining ketma-ket bosishlari orasida kamida THROTTLE_SEC (standart 0.4 s) kutiladi.
• Bir xil tugma bir xil xabarda navbatda turgan bo'lsa, takrori tashlab yuboriladi (tugmani bosib turish serverni yuklamaydi).
• Navbat to'lib ketsa, eng eski tugma bosishlari tashlanadi; matnli xabarlar saqlanadi.
"""
from __future__ import annotations

import collections
import heapq
import queue
import threading
import time

from .util import log, tb_short

MAX_QUEUE = 40                 # bitta foydalanuvchi navbati
MAX_TOTAL = 60_000             # hamma navbatlardagi jami update: undan oshsa tugma bosishlari tashlanadi (xotira himoyasi)
DEFAULT_WORKERS = 24


class _Lane:
    __slots__ = ("key", "q", "pending_cb", "last_run", "scheduled")

    def __init__(self, key):
        self.key = key
        self.q: collections.deque = collections.deque()
        self.pending_cb: set = set()
        self.last_run = 0.0
        self.scheduled = False


class Dispatcher:
    """Aktor modeli: foydalanuvchi = "navbat" (lane). Navbatlar doimiy ishchilar pulida bajariladi:
    100 000 faol foydalanuvchi ham 100 000 oqim emas, ~DEFAULT_WORKERS oqim demak. Bir foydalanuvchining update lari
    hamisha ketma-ket; kutish (0.4 s) ishchini band qilmaydi — navbat kechiktirilgan ro'yxatga tushadi."""

    def __init__(self, throttle_fn=lambda: 0.4, on_error=None, workers: int = DEFAULT_WORKERS):
        self.throttle_fn = throttle_fn
        self.on_error = on_error
        self.nworkers = max(2, workers)
        self.lanes: dict = {}
        self.last: dict = {}                       # foydalanuvchi -> oxirgi bajarilgan vaqt (navbat o'chsa ham 0.4 s saqlanadi)
        self.lock = threading.Lock()
        self.ready: queue.SimpleQueue = queue.SimpleQueue()
        self.delayed: list = []                    # heap: (vaqt, soni, lane)
        self._seq = 0
        self.dcv = threading.Condition()
        self.total = 0
        self.dropped = 0
        self.done = 0
        self.errors = 0
        self._started = False

    # ------------------------------------------------------------------ ishga tushirish
    def _start(self):
        if self._started:
            return
        self._started = True
        for i in range(self.nworkers):
            threading.Thread(target=self._worker, daemon=True, name=f"disp-{i}").start()
        threading.Thread(target=self._timer, daemon=True, name="disp-timer").start()

    # ------------------------------------------------------------------ qo'shish
    def submit(self, key, fn, dedup=None) -> bool:
        """fn() ni `key` navbatiga qo'yadi. dedup: shu qiymat navbatda bo'lsa qo'shilmaydi (False)."""
        with self.lock:
            self._start()
            lane = self.lanes.get(key)
            if lane is None:
                lane = self.lanes[key] = _Lane(key)
                lane.last_run = self.last.get(key, 0.0)
            if dedup is not None and dedup in lane.pending_cb:
                self.dropped += 1
                return False
            if dedup is not None and self.total >= MAX_TOTAL:         # haddan tashqari yuk: tugma bosishlari tashlanadi
                self.dropped += 1
                return False
            if len(lane.q) >= MAX_QUEUE:
                for i, item in enumerate(lane.q):                      # eng eski tugma bosishini tashlaymiz
                    if item[1] is not None:
                        lane.pending_cb.discard(item[1])
                        del lane.q[i]
                        self.total -= 1
                        self.dropped += 1
                        break
                else:
                    self.dropped += 1
                    return False
            lane.q.append((fn, dedup))
            self.total += 1
            if dedup is not None:
                lane.pending_cb.add(dedup)
            if not lane.scheduled:
                lane.scheduled = True
                self.ready.put(lane)
        return True

    # ------------------------------------------------------------------ ichki
    def _timer(self):
        while True:
            with self.dcv:
                while not self.delayed:
                    self.dcv.wait()
                due = self.delayed[0][0]
                now = time.monotonic()
                if due > now:
                    self.dcv.wait(timeout=due - now)
                    continue
                _, _, lane = heapq.heappop(self.delayed)
            self.ready.put(lane)

    def _later(self, lane, due):
        with self.dcv:
            self._seq += 1
            heapq.heappush(self.delayed, (due, self._seq, lane))
            self.dcv.notify()

    def _worker(self):
        while True:
            lane = self.ready.get()
            gap = float(self.throttle_fn() or 0)
            due = lane.last_run + gap
            if due > time.monotonic():
                self._later(lane, due)             # ishchi band bo'lmaydi: vaqti kelganda qaytadi
                continue
            with self.lock:
                if not lane.q:
                    lane.scheduled = False
                    if self.lanes.get(lane.key) is lane:
                        del self.lanes[lane.key]
                    continue
                fn, dedup = lane.q.popleft()
                self.total -= 1
                if dedup is not None:
                    lane.pending_cb.discard(dedup)
            try:
                fn()
                self.done += 1
            except Exception as e:  # noqa: BLE001
                self.errors += 1
                log.error("Update xatosi (%s): %s\n%s", lane.key, e, tb_short(1500))
                if self.on_error:
                    try:
                        self.on_error(lane.key, e)
                    except Exception:  # noqa: BLE001
                        pass
            finally:
                lane.last_run = time.monotonic()
                with self.lock:
                    self.last[lane.key] = lane.last_run
                    if len(self.last) > 200_000:
                        cut = lane.last_run - 30
                        for k in [k for k, t in self.last.items() if t < cut]:
                            del self.last[k]
                    if lane.q:
                        self.ready.put(lane)       # keyingisi (kechiktirish yuqorida hisoblanadi)
                    else:
                        lane.scheduled = False
                        if self.lanes.get(lane.key) is lane:
                            del self.lanes[lane.key]   # bo'sh navbat xotirada turmaydi
