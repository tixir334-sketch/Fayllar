"""Stream TIZIMI: stream.py (asosiy mexanizm) ni bitta katta, o'zini nazorat qiluvchi tizimga aylantiradi.

  Telemetry   — efirning jonli ko'rsatkichlari: uzatish (bitrate, tezlik, tashlangan kadrlar — ffmpeg `-progress`),
                tayyorlash tezligi, zaxira, kodlovchi (GPU/CPU), CPU/RAM/disk; hodisalar jurnali.
  PROFILES    — tayyor sifat profillari (tejamkor / standart / sifatli / maksimal): bir bosishda hamma sozlama.
  build_output— bir vaqtda BIR NECHTA manzilga uzatish (YouTube + qo'shimcha RTMP) — ffmpeg `tee`; qo'shimchasi uzilsa
                asosiy efir to'xtamaydi.
  Watchdog    — nazoratchi: uzatish tezligi pastligi, qotib qolgan tayyorlov, kam disk/RAM, GPU xatosi; xabar beradi.
  Planner     — rejalashtirilgan boshlanish (STREAM_AT = HH:MM yoki YYYY-MM-DD HH:MM).
Hammasi ixtiyoriy va xavfsiz: nazorat xato bersa ham efirga ta'sir qilmaydi.
"""
from __future__ import annotations

import collections
import os
import re
import shutil
import threading
import time
from datetime import datetime, timedelta

from .hwenc import HW
from .util import esc, fmt_dur, human_size, local_now, log

# ---------------------------------------------------------------------------- profillar
PROFILES = {
    "tejamkor": {"STREAM_RES": "480", "STREAM_FPS": "25", "STREAM_BITRATE": "1500", "STREAM_CRF": "22",
                 "STREAM_PRESET": "veryfast"},
    "standart": {"STREAM_RES": "720", "STREAM_FPS": "30", "STREAM_BITRATE": "0", "STREAM_CRF": "21"},
    "sifatli": {"STREAM_RES": "1080", "STREAM_FPS": "30", "STREAM_BITRATE": "0", "STREAM_CRF": "20"},
    "maksimal": {"STREAM_RES": "1080", "STREAM_FPS": "60", "STREAM_BITRATE": "9000", "STREAM_CRF": "19"},
    "telefon": {"STREAM_RES": "720", "STREAM_FPS": "30", "STREAM_BITRATE": "0", "STREAM_CRF": "21", "STREAM_PRESET": "ultrafast"},
}
PROFILE_INFO = {
    "tejamkor": "480p · 25 fps · 1500 kbit/s — kuchsiz qurilma yoki sekin internet",
    "standart": "720p · 30 fps · avto bitrate — ko'pchilik uchun",
    "sifatli": "1080p · 30 fps · avto bitrate — GPU yoki kuchli CPU tavsiya etiladi",
    "maksimal": "1080p · 60 fps · 9000 kbit/s — GPU va tez internet kerak",
    "telefon": "720p · 30 fps · avto bitrate — telefonda (Termux) tezlik va sifat muvozanati; MediaCodec bo'lsa GPU da kodlanadi",
}


def apply_profile(cfg, name: str) -> str | None:
    """Profilni qo'llaydi (.env ga yozadi). Xato matnini yoki None qaytaradi."""
    name = (name or "").strip().lower()
    if name == "custom":
        cfg.set("STREAM_PROFILE", "custom")
        return None
    prof = PROFILES.get(name)
    if not prof:
        return "profil: " + ", ".join(PROFILES) + " yoki custom"
    for k, v in prof.items():
        cfg.set(k, v)
    cfg.set("STREAM_PROFILE", name)
    return None


# ---------------------------------------------------------------------------- bir nechta manzil
_RTMP = re.compile(r"^rtmps?://[^\s|\[\]]+$", re.I)


def parse_extra(value: str) -> list:
    """STREAM_EXTRA_RTMP: vergul/probel/qator bilan ajratilgan rtmp(s):// manzillar (yaroqsizlari tashlanadi)."""
    out = []
    for x in re.split(r"[,\s]+", value or ""):
        x = x.strip()
        if x and _RTMP.match(x) and x not in out:
            out.append(x)
    return out[:6]


def mask_url(url: str) -> str:
    """Efir kalitini yashiradi: rtmp://host/app/KALIT -> rtmp://host/app/KAL…"""
    m = re.match(r"^(rtmps?://[^/]+/.*?/)([^/]+)$", url or "")
    if not m:
        return (url or "")[:40]
    k = m.group(2)
    return m.group(1) + (k[:3] + "…" if len(k) > 4 else "***")


def build_output(url: str, extras: list | None = None, test: str = "", fmt: str = "flv") -> list:
    """Pusher (ffmpeg) chiqish argumentlari.
    test: fayl (sinov) · extras yo'q: bitta flv · extras bor: tee (asosiy manzil uzilsa pusher to'xtaydi va qayta
    ishga tushadi; qo'shimcha manzil uzilsa 'onfail=ignore' — qolganlari ishlayveradi)."""
    if test:
        return ["-bsf:a", "aac_adtstoasc", "-f", "mpegts", test]
    if not extras:
        return ["-bsf:a", "aac_adtstoasc", "-flvflags", "no_duration_filesize", "-f", fmt, url]
    base = f"f={fmt}:flvflags=no_duration_filesize:bsfs/a=aac_adtstoasc"
    slaves = [f"[{base}]{url}"] + [f"[{base}:onfail=ignore]{x}" for x in extras]
    return ["-map", "0:v:0", "-map", "0:a:0", "-f", "tee", "|".join(slaves)]


# ---------------------------------------------------------------------------- telemetriya
def _num(v: str, default: float = 0.0) -> float:
    m = re.search(r"-?\d+(?:\.\d+)?", v or "")
    return float(m.group(0)) if m else default


class Telemetry:
    """Jonli ko'rsatkichlar va hodisalar jurnali (oqim-xavfsiz)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.push: dict = {}
        self.push_t = 0.0
        self.history = collections.deque(maxlen=120)       # (vaqt, tezlik, kbit/s)
        self.events = collections.deque(maxlen=80)         # (vaqt, daraja, matn)
        self._blk: dict = {}
        self.started = time.time()

    # -- hodisalar
    def event(self, level: str, text: str):
        with self.lock:
            self.events.append((time.time(), level, str(text)[:300]))
        (log.warning if level in ("w", "e") else log.info)("Stream: %s", text)

    def recent(self, n: int = 5) -> list:
        with self.lock:
            return list(self.events)[-n:]

    # -- ffmpeg `-progress` oqimi (key=value qatorlari; `progress=` bilan blok tugaydi)
    def feed_line(self, line: str):
        line = (line or "").strip()
        if "=" not in line:
            return
        k, v = line.split("=", 1)
        self._blk[k.strip()] = v.strip()
        if k.strip() == "progress":
            self._commit()

    def _commit(self):
        b, self._blk = self._blk, {}
        speed = _num(b.get("speed", ""), 0.0) if "x" in b.get("speed", "") else None
        kbps = _num(b.get("bitrate", ""), 0.0) if "kbits" in b.get("bitrate", "") else None
        now = time.time()
        with self.lock:
            self.push = {"speed": speed, "kbps": kbps, "frame": int(_num(b.get("frame", "0"))),
                         "fps": _num(b.get("fps", "0")), "drop": int(_num(b.get("drop_frames", "0"))),
                         "dup": int(_num(b.get("dup_frames", "0"))), "size": int(_num(b.get("total_size", "0"))),
                         "out_s": _num(b.get("out_time_us", b.get("out_time_ms", "0"))) / 1e6}
            self.push_t = now
            if speed is not None:
                self.history.append((now, speed, kbps or 0.0))

    def reset_push(self):
        with self.lock:
            self.push, self.push_t, self._blk = {}, 0.0, {}
            self.history.clear()

    def avg_kbps(self, secs: float = 30.0) -> float:
        now = time.time()
        with self.lock:
            xs = [k for t, s, k in self.history if now - t <= secs and k > 0]
        return sum(xs) / len(xs) if xs else 0.0

    def min_speed(self, secs: float = 25.0) -> float | None:
        now = time.time()
        with self.lock:
            xs = [s for t, s, k in self.history if now - t <= secs and s > 0]
        return min(xs) if len(xs) >= 3 else None

    def fresh(self, max_age: float = 15.0) -> bool:
        return bool(self.push) and time.time() - self.push_t <= max_age


def sys_sample(path) -> dict:
    """CPU yuklama, RAM va disk (mavjudlari; platformada yo'q bo'lsa tushirib qoldiriladi)."""
    d: dict = {"cpus": os.cpu_count() or 1}
    try:
        d["load"] = os.getloadavg()[0]
    except (OSError, AttributeError):
        pass
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            mi = {ln.split(":")[0]: int(ln.split(":")[1].split()[0]) * 1024 for ln in f if ":" in ln}
        d["mem_total"] = mi.get("MemTotal", 0)
        d["mem_free"] = mi.get("MemAvailable", mi.get("MemFree", 0))
    except (OSError, ValueError, IndexError):
        pass
    try:
        du = shutil.disk_usage(str(path))
        d["disk_free"], d["disk_total"] = du.free, du.total
    except (OSError, TypeError):
        pass
    try:
        with open("/proc/self/statm", encoding="utf-8") as f:
            d["rss"] = int(f.read().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    except (OSError, ValueError, IndexError, AttributeError):
        pass
    return d


# ---------------------------------------------------------------------------- nazoratchi
class Watchdog(threading.Thread):
    """Efir davomida har 5 soniyada tizimni tekshiradi. Faqat XABAR beradi va jurnalga yozadi (efirga aralashmaydi)."""

    def __init__(self, sysm: "StreamSystem", period: float = 5.0):
        super().__init__(daemon=True, name="stream-watchdog")
        self.sysm = sysm
        self.period = period
        self.stop_evt = threading.Event()
        self.last: dict = {}
        self.slow_n = 0
        self.prog = (0, time.time())
        self.hw_seen = time.time()

    def note(self, kind: str, text: str, every: float = 900.0, level: str = "w", say: bool = True):
        now = time.time()
        if now - self.last.get(kind, 0) < every:
            return False
        self.last[kind] = now
        self.sysm.tel.event(level, text)
        if say:
            try:
                self.sysm.stream.say(text)
            except Exception:  # noqa: BLE001
                pass
        return True

    def run(self):
        while not self.stop_evt.wait(self.period):
            try:
                self.check()
            except Exception as e:  # noqa: BLE001
                log.warning("Stream nazoratchisi xatosi: %s", e)

    def check(self):
        sm = self.sysm
        st = sm.stream
        if st.state not in ("starting", "live"):
            return
        cfg = st.cfg
        tel = sm.tel
        # 1) uzatish tezligi: -re bilan ~1.0x bo'lishi kerak; kam bo'lsa — internet bitrate ga yetmayapti
        if st.state == "live" and tel.fresh():
            sp = tel.min_speed(25.0)
            if sp is not None and sp < 0.92:
                self.slow_n += 1
            else:
                self.slow_n = 0
            if self.slow_n >= 3:
                self.note("push_slow", f"⚠️ <b>Efirga uzatish sekin</b> (×{sp:.2f}): internet tezligi bitrate "
                                       f"({st.params.get('kbps', 0)} kbit/s) ga yetmayapti. /stream → Sifat: bitrate yoki "
                                       "o'lchamni kamaytiring, yoki <code>/stream profil tejamkor</code>.", every=600)
        # 2) tayyorlov qotib qoldi: kadr hisobi uzoq vaqt o'zgarmadi (render bosqichida)
        job = st.job or {}
        if job.get("frames_total"):
            fr = int(job.get("frames", 0))
            if fr != self.prog[0]:
                self.prog = (fr, time.time())
            elif st._has_work() and len(st.ready) < st.params.get("buffer", 1) \
                    and time.time() - self.prog[1] > max(60.0, cfg.float("STREAM_STALL_SEC")):
                self.note("stall", f"🐢 <b>Tayyorlov qotib qolgan ko'rinadi:</b> {fmt_dur(time.time() - self.prog[1])} dan beri "
                                   "kadr chiqmayapti. Agar o'zgarmasa: /stream → ⏭ keyingi bo'lak yoki to'xtatib qayta boshlang.",
                          every=1200)
        else:
            self.prog = (0, time.time())
        # 3) disk va RAM
        s = sys_sample(st.work or ".")
        mn = max(100, cfg.int("STREAM_MIN_DISK_MB")) * 1024 * 1024
        if s.get("disk_free", mn + 1) < mn:
            self.note("disk", f"💽 <b>Diskda joy kam:</b> {human_size(s['disk_free'])} qoldi. Tayyor bo'laklar zaxirasi "
                              "diskda turadi — joy bo'shating yoki STREAM_BUFFER_CAP ni (masalan 8) qo'ying; yangi bo'laklar tayyorlash vaqtincha to'xtadi.", every=1200)
        if s.get("mem_total") and s.get("mem_free", 1 << 40) < 150 * 1024 * 1024:
            self.note("ram", f"🧠 <b>Xotira (RAM) kam:</b> bo'sh {human_size(s['mem_free'])}. STREAM_WORKERS/STREAM_PROCS ni "
                             "kamaytiring.", every=1200)
        # 4) GPU/CPU kodlash hodisalari (GPU xato bergan bo'lsa CPU ga o'tilgani haqida)
        for ts, text in list(HW.events):
            if ts > self.hw_seen:
                self.hw_seen = ts
                if "CPU" in text or "chegara" in text:
                    self.note("hw:" + str(int(ts)), "🎞 " + esc(text), every=0)


# ---------------------------------------------------------------------------- rejalashtirish
class Planner(threading.Thread):
    """STREAM_AT (HH:MM yoki YYYY-MM-DD HH:MM) vaqtida efirni avtomatik boshlaydi (qoralama va navbat tayyor bo'lsa)."""

    def __init__(self, sysm: "StreamSystem", period: float = 15.0):
        super().__init__(daemon=True, name="stream-planner")
        self.sysm = sysm
        self.period = period
        self.stop_evt = threading.Event()

    @staticmethod
    def parse(raw: str, now: datetime) -> datetime | None:
        raw = (raw or "").strip()
        if not raw:
            return None
        m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})", raw)
        try:
            if m:
                y, mo, d, h, mi = (int(x) for x in m.groups())
                return now.replace(year=y, month=mo, day=d, hour=h, minute=mi, second=0, microsecond=0)
            m = re.fullmatch(r"(\d{1,2}):(\d{2})", raw)
            if m:
                h, mi = int(m.group(1)), int(m.group(2))
                t = now.replace(hour=h, minute=mi, second=0, microsecond=0)
                return t + timedelta(days=1) if now - t > timedelta(minutes=10) else t
        except ValueError:
            return None
        return None

    def run(self):
        while not self.stop_evt.wait(self.period):
            try:
                self.tick()
            except Exception as e:  # noqa: BLE001
                log.warning("Stream rejalashtiruvchisi xatosi: %s", e)

    def tick(self):
        st = self.sysm.stream
        cfg = st.cfg
        raw = cfg.get("STREAM_AT")
        if not raw.strip():
            return
        now = local_now(cfg)
        t = self.parse(raw, now)
        if t is None:
            cfg.set("STREAM_AT", "")
            st.say("⚠️ STREAM_AT noto'g'ri formatda (kerak: <code>HH:MM</code> yoki <code>YYYY-MM-DD HH:MM</code>) — bekor qilindi.")
            return
        if now < t or now - t > timedelta(minutes=10) or st.state != "draft":
            return
        cfg.set("STREAM_AT", "")
        err = st.start()
        if err:
            st.say(f"⏰ Rejalashtirilgan efir boshlanmadi: {esc(err)}")
        else:
            st.say("⏰ Rejalashtirilgan vaqt keldi — efir tayyorlanmoqda.")
            self.sysm.tel.event("i", "rejalashtirilgan efir boshlandi")


# ---------------------------------------------------------------------------- umumiy fasad
class StreamSystem:
    def __init__(self, stream):
        self.stream = stream
        self.tel = Telemetry()
        self.watch: Watchdog | None = None
        self.planner: Planner | None = None

    # -- hayot sikli
    def start_planner(self):
        if self.planner is None or not self.planner.is_alive():
            self.planner = Planner(self)
            self.planner.start()

    def start(self):
        """Efir boshlanganda: nazoratchini yoqadi."""
        self.tel.reset_push()
        self.tel.event("i", "efir tizimi ishga tushdi · kodlash: " + HW.label())
        if self.stream.cfg.bool("STREAM_WATCHDOG"):
            if self.watch is None or not self.watch.is_alive():
                self.watch = Watchdog(self)
                self.watch.start()

    def stop(self):
        if self.watch is not None:
            self.watch.stop_evt.set()
            self.watch = None
        self.tel.event("i", "efir tizimi to'xtadi")

    def close(self):
        self.stop()
        if self.planner is not None:
            self.planner.stop_evt.set()

    # -- ko'rsatish
    def encoder_line(self) -> str:
        p = self.stream.params or {}
        name = HW.pick()
        kind = "GPU" if name != "cpu" else "CPU"
        extra = f" · sessiyalar {HW.sessions(name)}" if name != "cpu" else f" · preset {p.get('preset', '')}"
        return f"🎞 Kodlash: <b>{esc(HW.label(name))}</b> ({kind}){extra}"

    def panel_text(self) -> str:
        """Telegramdagi '📊 Tizim' paneli (HTML)."""
        st = self.stream
        p = st.params or st._params()
        tel = self.tel
        L = ["📊 <b>Stream tizimi</b>", self.encoder_line()]
        L.append(f"🎚 Sifat: {p['res']}p · {p['fps']} fps · {p['kbps']} kbit/s · CRF {st.cfg.int('STREAM_CRF') or 20}"
                 f" · profil: <b>{esc(st.cfg.get('STREAM_PROFILE') or 'custom')}</b>")
        L.append(f"🎬 Animatsiya: har {p['step']}-kadrda yangilanadi ({p['fps'] / p['step']:.0f} kadr/s)")
        if tel.fresh(30.0):
            pu = tel.push
            sp = f"{pu['speed']:.2f}×" if pu.get("speed") is not None else "—"
            L.append(f"📡 Uzatish: <b>{tel.avg_kbps():.0f}</b> kbit/s · tezlik {sp} · tashlangan {pu.get('drop', 0)} · "
                     f"uzatilgan {fmt_dur(pu.get('out_s', 0))}")
        else:
            L.append("📡 Uzatish: ma'lumot yo'q (efir ochilmagan)")
        with st.lock:
            nready, tot = len(st.ready), sum(t["dur"] for t in st.ready)
        L.append(f"📦 Zaxira: {nready}{('/' + str(p['cap'])) if p.get('cap') else ' (cheksiz)'} bo'lak · {fmt_dur(tot)}"
                 + (f" · tayyorlash <b>{st.speed:.1f}×</b>" if st.speed else (f" · taxmin {st.bench:.1f}×" if st.bench else "")))
        extras = parse_extra(st.cfg.get("STREAM_EXTRA_RTMP"))
        if extras:
            L.append(f"🔀 Qo'shimcha manzillar: {len(extras)} ta (" + ", ".join(esc(mask_url(x)) for x in extras[:3]) + ")")
        s = sys_sample(st.work or ".")
        bits = []
        if "load" in s:
            bits.append(f"CPU {s['load']:.1f}/{s['cpus']}")
        if "mem_free" in s:
            bits.append(f"RAM bo'sh {human_size(s['mem_free'])}")
        if "disk_free" in s:
            bits.append(f"disk bo'sh {human_size(s['disk_free'])}")
        if bits:
            L.append("🖥 " + " · ".join(bits))
        if st.restarts:
            L.append(f"🔁 Pusher qayta ishga tushgan: {st.restarts}")
        at = st.cfg.get("STREAM_AT").strip()
        if at:
            L.append(f"⏰ Rejalashtirilgan boshlanish: <b>{esc(at)}</b>")
        ev = tel.recent(4)
        if ev:
            L.append("")
            L.append("<b>Oxirgi hodisalar</b>")
            for ts, lv, tx in ev:
                L.append(f"{'⚠️' if lv in ('w', 'e') else '•'} {fmt_dur(time.time() - ts)} oldin: {esc(re.sub(r'<[^>]+>', '', tx))[:110]}")
        return "\n".join(L)
