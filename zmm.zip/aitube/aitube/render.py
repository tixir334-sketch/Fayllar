"""Pillow yordamida kadrlarni chizish: harakatlanuvchi fon, animatsiyali sarlavha/qaydlar/kod/sxema,
so'zma-so'z yuruvchi subtitr."""
from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

from .anim import AnimMixin
from .bgfx import BgMixin
from .cards import CardsMixin, explain_blocks
from .highlight import highlight_line

BG1, BG2 = (11, 15, 22), (24, 32, 48)
TEXT, MUTED = (230, 237, 243), (139, 148, 158)
PANEL, BORDER, LINEHL = (17, 22, 30), (48, 54, 61), (30, 38, 50)
SYN = {
    "kw": (255, 123, 114), "str": (165, 214, 255), "comment": (125, 133, 144), "num": (121, 192, 255),
    "func": (210, 168, 255), "builtin": (255, 166, 87), "type": (126, 231, 135),
    "op": (255, 166, 87), "text": (230, 237, 243),
}
ACCENTS = [(88, 166, 255), (63, 185, 80), (255, 166, 87), (210, 168, 255), (255, 123, 114), (56, 211, 205)]

_FONT_NAMES = {"sans": "DejaVuSans.ttf", "bold": "DejaVuSans-Bold.ttf",
               "mono": "DejaVuSansMono.ttf", "monob": "DejaVuSansMono-Bold.ttf"}
_SYSTEM_FALLBACK = {
    "sans": ["/system/fonts/Roboto-Regular.ttf", "/system/fonts/DroidSans.ttf"],
    "bold": ["/system/fonts/Roboto-Bold.ttf", "/system/fonts/DroidSans-Bold.ttf"],
    "mono": ["/system/fonts/DroidSansMono.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"],
    "monob": ["/system/fonts/DroidSansMono.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"],
}
_CACHE: dict = {}


def get_font(fonts_dir, kind: str, size: int):
    size = max(8, int(size))
    key = (str(fonts_dir), kind, size)
    if key in _CACHE:
        return _CACHE[key]
    cands = [Path(fonts_dir) / _FONT_NAMES[kind],
             Path("/usr/share/fonts/truetype/dejavu") / _FONT_NAMES[kind]]
    cands += [Path(p) for p in _SYSTEM_FALLBACK[kind]]
    font = None
    for c in cands:
        if c.exists():
            try:
                font = ImageFont.truetype(str(c), size)
                break
            except OSError:
                continue
    if font is None:
        try:
            font = ImageFont.load_default(size=size)
        except TypeError:
            font = ImageFont.load_default()
    _CACHE[key] = font
    return font


class SFont:
    """Haqiqiy (kattalashtirilgan) shrift; o'lchovlar mantiqiy (1280x720 asosli) birlikda qaytariladi."""
    __slots__ = ("f", "s")

    def __init__(self, f, s):
        self.f, self.s = f, s

    def getlength(self, text):
        return self.f.getlength(text) / self.s


class SDraw:
    """ImageDraw o'rami: barcha mantiqiy koordinata/o'lchamlar haqiqiy pikselga ko'paytiriladi.
    Shu tufayli maket bir marta (mantiqiy birlikda) yoziladi va har qanday ruxsatda (720p, 1080p) bir xil ko'rinadi."""

    def __init__(self, img, s):
        self.d = ImageDraw.Draw(img)
        self.s = s

    def _xy(self, xy):
        s = self.s
        if isinstance(xy, (list, tuple)) and xy and isinstance(xy[0], (list, tuple)):
            return [(a * s, b * s) for a, b in xy]
        return type(xy)(v * s for v in xy) if isinstance(xy, tuple) else [v * s for v in xy]

    def _w(self, w):
        return max(1, int(round(w * self.s)))

    @staticmethod
    def _f(font):
        return font.f if isinstance(font, SFont) else font

    def text(self, xy, text, font=None, fill=None, anchor=None, **kw):
        self.d.text(self._xy(tuple(xy)), text, font=self._f(font), fill=fill, anchor=anchor, **kw)

    def textlength(self, text, font=None):
        return self.d.textlength(text, font=self._f(font)) / self.s

    def rounded_rectangle(self, xy, radius=0, fill=None, outline=None, width=1):
        self.d.rounded_rectangle(self._xy(xy), radius=radius * self.s, fill=fill, outline=outline,
                                 width=self._w(width))

    def rectangle(self, xy, fill=None, outline=None, width=1):
        self.d.rectangle(self._xy(xy), fill=fill, outline=outline, width=self._w(width))

    def ellipse(self, xy, fill=None, outline=None, width=1):
        self.d.ellipse(self._xy(xy), fill=fill, outline=outline, width=self._w(width))

    def line(self, xy, fill=None, width=1):
        self.d.line(self._xy(xy), fill=fill, width=self._w(width))

    def polygon(self, xy, fill=None, outline=None):
        self.d.polygon(self._xy(xy), fill=fill, outline=outline)

    def arc(self, xy, start, end, fill=None, width=1):
        self.d.arc(self._xy(xy), start, end, fill=fill, width=self._w(width))

    def pieslice(self, xy, start, end, fill=None, outline=None, width=1):
        self.d.pieslice(self._xy(xy), start, end, fill=fill, outline=outline, width=self._w(width))


def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    if isinstance(a, (int, float)):
        return a + (b - a) * t
    return tuple(int(round(x + (y - x) * t)) for x, y in zip(a, b))


def ease_out(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def lighten(c, k=0.35):
    return tuple(int(x + (255 - x) * k) for x in c)


def scene_units(scene: dict) -> int:
    t = scene["type"]
    if t == "bullets":
        return max(1, len(scene.get("bullets", [])))
    if t == "flow":
        return max(1, len(scene.get("steps", [])))
    if t == "diagram":
        return max(1, len(scene.get("links", [])))
    if t == "compare":
        return max(1, len(scene.get("left", {}).get("items", [])), len(scene.get("right", {}).get("items", [])))
    if t == "code":
        return max(1, len((scene.get("code") or "").split("\n")))
    if t == "parts":
        return max(1, len(scene.get("items", [])))
    if t == "explain":
        return max(1, len(explain_blocks(scene)))
    return 0


class Content:
    """Sahna mazmuni qatlamlari: img (statik fon ustida), shadow (soyalar, L), solid (shaffof emas joylar, L)."""
    __slots__ = ("img", "shadow", "solid", "plate")

    def __init__(self, img, shadow, solid, plate=None):
        # plate: RGBA qatlam (shisha kartalar, yarim shaffof chiziqlar, yorug'lik) - harakatlanuvchi fon USTIGA
        # alfa bilan qo'yiladi, shuning uchun fon uning ostidan ko'rinib turadi
        self.img, self.shadow, self.solid, self.plate = img, shadow, solid, plate


def ease_out_back(t: float) -> float:
    t = max(0.0, min(1.0, t))
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def prog(age: float, t0: float, dur: float) -> float:
    """age vaqtda t0 dan boshlanib dur davom etadigan animatsiya bosqichi (0..1, yumshatilgan)."""
    return ease_out((age - t0) / dur) if dur > 0 else (1.0 if age >= t0 else 0.0)


# Mask: kontent fon (statik) dan farq qilgan joyda shaffof emas. Farq >= 8 daraja bo'lsa to'liq ko'rinadi.
_MASK_LUT = [min(255, v * 64) for v in range(256)]

# Har bir sahna turida kirish animatsiyasi tugaydigan vaqt (s); undan keyin mazmun o'zgarmaydi (kesh uchun)
ENTER_END = {"title": 2.4, "recap": 2.6, "bullets": 0.8, "flow": 0.8, "code": 0.8, "outro": 2.4,
             "diagram": 0.9, "compare": 0.9, "parts": 0.9, "explain": 0.9}
CONTINUOUS = {"title", "outro", "diagram", "parts", "explain"}      # doimiy harakatlanadigan elementli sahnalar (dreyf, pulsatsiya)


class Renderer(BgMixin, AnimMixin, CardsMixin):
    """Kadrlarni chizadi.

    Kadr = harakatlanuvchi fon (`bg_frame`) + sahna mazmuni (`content`, animatsiyali) + subtitr + progress.
    Sahna mazmuni statik fon ustiga chiziladi, so'ng `mask_for` bilan fondan ajratiladi va harakatlanuvchi
    fon ustiga qo'yiladi - shuning uchun mazmun keshlanadi, fon esa har kadrda arzon yangilanadi."""

    def __init__(self, cfg, accent_idx=0, episode_label="", channel="", style=None, seed=0, art=None, card=None):
        self.cfg = cfg
        self.fd = cfg.fonts_dir
        self.W, self.H = cfg.base_size          # mantiqiy o'lcham (maket shu birlikda)
        self.RW, self.RH = cfg.size             # haqiqiy video o'lchami (masalan 1920x1080)
        self.S = self.RW / float(self.W)
        self.portrait = self.H > self.W
        self._fonts: dict = {}
        self.accent = ACCENTS[accent_idx % len(ACCENTS)]
        self.accent2 = lighten(self.accent, 0.4)
        self.alt = ACCENTS[(accent_idx + 3) % len(ACCENTS)]
        self.third = ACCENTS[(accent_idx + 5) % len(ACCENTS)]
        self.label = episode_label
        self.channel = channel
        try:
            self.motion = cfg.int("VIDEO_MOTION")
        except Exception:
            self.motion = 1
        self.m = 40 if self.portrait else 56
        self.header_h = 70
        if self.portrait:
            self.cap_font = 40
            self.cap_bottom = self.H - 150
            self.cap_max_lines = 5
        else:
            self.cap_font = 34
            self.cap_bottom = self.H - 34
            self.cap_max_lines = 3
        self.cap_zone_h = 175 if not self.portrait else 340
        self.content_box = (self.m, self.header_h + 26, self.W - self.m, self.cap_bottom - self.cap_zone_h - 10)
        self.art = art
        self.card = card
        self.t_off = 0.0              # fon animatsiyasi vaqt siljishi (stream bo'laklari uzluksiz davom etsin)
        self.show_progress = True
        self._setup_style(style, seed)
        self.bg = self._make_bg()
        self._probe = SDraw(Image.new("RGB", (8, 8)), self.S)
        self._cap_cache: dict = {}
        self._ghost: dict = {}
        self._fit_cache: dict = {}
        self._lay_cache: dict = {}
        self._sh = Image.new("L", (self.RW, self.RH), 0)
        self._sd = Image.new("L", (self.RW, self.RH), 0)
        self._pl = None
        self._glow_cache: dict = {}
        self._init_motion()

    # ---------------------------------------------------------------- yordamchilar
    def font(self, kind, size):
        key = (kind, size)
        f = self._fonts.get(key)
        if f is None:
            f = self._fonts[key] = SFont(get_font(self.fd, kind, int(round(size * self.S))), self.S)
        return f

    def D(self, img):
        return SDraw(img, self.S)

    def bgpx(self, x, y):
        x = max(0, min(self.RW - 1, int(x * self.S)))
        y = max(0, min(self.RH - 1, int(y * self.S)))
        return self.bg.getpixel((x, y))[:3]

    def mask_for(self, c: "Content") -> Image.Image:
        """Mazmun qaysi joylarda fon ustiga tushishini belgilaydi: statik fondan farq qilgan joylar + qattiq kartalar."""
        r, g, b = ImageChops.difference(c.img, self.bg).split()
        m = ImageChops.lighter(ImageChops.lighter(r, g), b).point(_MASK_LUT)
        return ImageChops.lighter(m, c.solid)

    def blend(self, a: "Content", b: "Content", alpha: float) -> "Content":
        plate = None
        if a.plate is not None or b.plate is not None:
            z = Image.new("RGBA", (self.RW, self.RH), (0, 0, 0, 0))
            pa = a.plate if a.plate is not None else z
            pb = b.plate if b.plate is not None else z
            # alfa kanalini premultiplied holda aralashtirish: rang chetlari qorayib ketmasin
            plate = Image.blend(pa, pb, alpha)
        return Content(Image.blend(a.img, b.img, alpha), Image.blend(a.shadow, b.shadow, alpha),
                       Image.blend(a.solid, b.solid, alpha), plate)

    # ---------------------------------------------------------------- shisha (shaffof) qatlam
    def _plate(self):
        if self._pl is None:
            self._pl = Image.new("RGBA", (self.RW, self.RH), (0, 0, 0, 0))
        return self._pl

    def PD(self):
        """Shisha qatlamiga chizish uchun (mantiqiy koordinatali) chizgich."""
        return SDraw(self._plate(), self.S)

    def _glass(self, box, radius=18, fill=(14, 20, 30), alpha=0.62, outline=None, width=2, oalpha=0.9, shine=True):
        """Yarim shaffof 'shisha' karta: harakatlanuvchi fon uning ostidan ko'rinadi."""
        S = self.S
        x0, y0, x1, y1 = [int(round(v * S)) for v in box]
        if x1 <= x0 or y1 <= y0:
            return
        w, h = x1 - x0 + 1, y1 - y0 + 1
        lay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ld = ImageDraw.Draw(lay)
        r = radius * S
        ld.rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=tuple(fill) + (int(255 * alpha),))
        if shine:   # tepada nozik yorug'lik
            sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            ImageDraw.Draw(sh).rounded_rectangle([0, 0, w - 1, max(2, int(h * 0.42))], radius=r,
                                                 fill=(255, 255, 255, int(255 * 0.045 * min(1.0, alpha * 1.6))))
            m = Image.new("L", (w, h), 0)
            ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255)
            sh.putalpha(ImageChops.multiply(sh.getchannel("A"), m))
            lay = Image.alpha_composite(lay, sh)
            ld = ImageDraw.Draw(lay)
        if outline:
            ld.rounded_rectangle([0, 0, w - 1, h - 1], radius=r, outline=tuple(outline) + (int(255 * oalpha),),
                                 width=max(1, int(round(width * S))))
        self._paste_rgba(lay, x0, y0)

    def _paste_rgba(self, lay, x, y):
        """RGBA qatlamni shisha qatlamga alfa bilan qo'shadi (chegaradan chiqqani kesiladi)."""
        pl = self._plate()
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(pl.width, x + lay.width), min(pl.height, y + lay.height)
        if x1 <= x0 or y1 <= y0:
            return
        part = lay.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        base = pl.crop((x0, y0, x1, y1))
        pl.paste(Image.alpha_composite(base, part), (x0, y0))

    def _glow(self, cx, cy, r, color, strength=0.8):
        """Yumshoq yorug'lik dog'i (mantiqiy koordinata va radius)."""
        S = self.S
        rr = max(2, int(round(r * S)))
        key = (rr, tuple(color))
        sp = self._glow_cache.get(key)
        if sp is None:
            g = Image.radial_gradient("L").resize((rr * 2, rr * 2), Image.BILINEAR)
            a = g.point(lambda v: int(255 * max(0.0, 1 - v / 255.0) ** 2))
            sp = Image.new("RGBA", (rr * 2, rr * 2), tuple(color) + (0,))
            sp.putalpha(a)
            if len(self._glow_cache) > 80:
                self._glow_cache.clear()
            self._glow_cache[key] = sp
        if strength < 0.999:
            sp = sp.copy()
            sp.putalpha(sp.getchannel("A").point(lambda v, k=strength: int(v * k)))
        self._paste_rgba(sp, int(cx * S) - rr, int(cy * S) - rr)

    # ---------------------------------------------------------------- matn yordamchilari
    def wrap(self, text, font, max_w):
        p = self._probe
        lines = []
        for para in str(text).split("\n"):
            cur = ""
            for w in para.split(" "):
                if not w:
                    continue
                trial = (cur + " " + w) if cur else w
                if p.textlength(trial, font=font) <= max_w:
                    cur = trial
                    continue
                if cur:
                    lines.append(cur)
                    cur = ""
                while p.textlength(w, font=font) > max_w and len(w) > 1:
                    k = len(w)
                    while k > 1 and p.textlength(w[:k], font=font) > max_w:
                        k -= 1
                    lines.append(w[:k])
                    w = w[k:]
                cur = w
            lines.append(cur)
        return lines

    def fit(self, text, kind, max_w, max_h, start, minsize=16, spacing=1.3, max_lines=None):
        key = (text, kind, max_w, max_h, start, minsize, spacing, max_lines)
        hit = self._fit_cache.get(key)
        if hit:
            return hit
        size = start
        while True:
            f = self.font(kind, size)
            lines = self.wrap(text, f, max_w)
            lh = int(size * spacing)
            ok = len(lines) * lh <= max_h and (max_lines is None or len(lines) <= max_lines)
            if ok or size <= minsize:
                res = (f, lines, lh, size)
                break
            size -= 2
        if len(self._fit_cache) > 300:
            self._fit_cache.clear()
        self._fit_cache[key] = res
        return res

    def _words_in_line(self, line, font):
        """[(so'z, x_siljish, kenglik)] - qator ichidagi so'z o'rinlari."""
        p = self._probe
        toks = line.split(" ")
        out = []
        for j, tk in enumerate(toks):
            pre = " ".join(toks[:j]) + (" " if j else "")
            out.append((tk, p.textlength(pre, font=font), p.textlength(tk, font=font)))
        return out

    def _anim_words(self, d, x, y, lines, font, lh, fill, age, t0, stagger, dur, rise=24, shadow=False,
                    counter=0, center_w=None):
        """Matn qatorlarini so'zma-so'z (kechikish bilan) pastdan ko'tarilib va ravshanlashib chiqarib chizadi.
        center_w berilsa har qator shu kenglikda markazlanadi. Oxirgi so'z hisoblagichini qaytaradi."""
        i = counter
        p = self._probe
        for ln in lines:
            xs = x if center_w is None else x + (center_w - p.textlength(ln, font=font)) / 2
            for tk, xo, w in self._words_in_line(ln, font):
                e = prog(age, t0 + i * stagger, dur)
                i += 1
                if e <= 0:
                    continue
                dy = (1 - e) * rise
                col = lerp(self.bgpx(xs + xo, y + lh / 2), fill, e)
                if shadow and e > 0.2:
                    d.text((xs + xo + 2, y + dy + 3), tk, font=font, fill=lerp(self.bgpx(xs + xo, y), (0, 0, 0), e),
                           anchor="la")
                d.text((xs + xo, y + dy), tk, font=font, fill=col, anchor="la")
            y += lh
        return i

    @staticmethod
    def _paste_max(dst, src, x, y):
        """src (L) ni dst (L) ga maksimum bilan qo'yadi (chegaradan chiqqan qismi kesiladi)."""
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(dst.width, x + src.width), min(dst.height, y + src.height)
        if x1 <= x0 or y1 <= y0:
            return
        part = src.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        dst.paste(ImageChops.lighter(dst.crop((x0, y0, x1, y1)), part), (x0, y0))

    def _shadow(self, img, box, radius=18, blur=14, offset=8, alpha=130):
        """Soya alohida qatlamga yoziladi (harakatlanuvchi fon ustiga qora yarim shaffof qatlam sifatida tushadi)."""
        S = self.S
        x0, y0, x1, y1 = [int(round(v * S)) for v in box]
        blur_r = blur * S
        pad = int(blur_r * 2)
        w, h = x1 - x0 + 2 * pad, y1 - y0 + 2 * pad
        if w <= 0 or h <= 0 or alpha <= 0:
            return
        layer = Image.new("L", (w, h), 0)
        ImageDraw.Draw(layer).rounded_rectangle([pad, pad, pad + x1 - x0, pad + y1 - y0], radius=radius * S,
                                                fill=int(alpha))
        layer = layer.filter(ImageFilter.GaussianBlur(blur_r))
        self._paste_max(self._sh, layer, x0 - pad, y0 - pad + int(offset * S))

    def _card(self, img, box, radius=18, fill=PANEL, outline=BORDER, width=2, shadow=True, alpha=130, solid=1.0,
              glass=None, gfill=None, gout=None, galpha=0.66):
        """glass=None: oddiy qattiq karta. glass=k (0..1): yarim shaffof shisha karta (fon ostidan ko'rinadi),
        gfill/gout - karta va chegara rangi, k - paydo bo'lish darajasi."""
        if glass is not None:
            if glass > 0.02:
                self._glass(box, radius, fill=gfill or fill, alpha=galpha * glass, outline=gout or outline,
                            width=width, oalpha=0.95 * glass)
            return
        if shadow:
            self._shadow(img, box, radius, alpha=alpha)
        b = [int(v) for v in box]
        self.D(img).rounded_rectangle(b, radius=radius, fill=fill, outline=outline, width=width)
        if solid > 0:
            self.D(self._sd).rounded_rectangle(b, radius=radius, fill=int(255 * min(1.0, solid)))

    def _pill(self, d, x, y, text, font, fill=None, outline=None, color=TEXT, padx=18, h=40, e=1.0):
        """Kapsula yorliq. e<1 bo'lsa fon rangiga qarab so'nadi."""
        w = d.textlength(text, font=font)
        bgc = self.bgpx(x + w / 2, y + h / 2)
        fl = lerp(bgc, fill, e) if fill else None
        ol = lerp(bgc, outline, e) if outline else None
        d.rounded_rectangle([x, y, x + w + 2 * padx, y + h], radius=h // 2, fill=fl, outline=ol, width=2)
        d.text((x + padx + w / 2, y + h / 2), text, font=font, fill=lerp(bgc, color, e), anchor="mm")
        return w + 2 * padx

    # ---------------------------------------------------------------- umumiy qismlar
    def _header(self, img, d):
        m = self.m
        y = 16
        d.rounded_rectangle([m, y, m + 46, y + 46], radius=12, fill=self.accent)
        d.rounded_rectangle([m + 3, y + 3, m + 43, y + 24], radius=9, fill=lighten(self.accent, 0.22))
        d.text((m + 23, y + 24), "</>", font=self.font("monob", 20), fill=BG1, anchor="mm")
        d.text((m + 62, y + 23), self.channel, font=self.font("bold", 26), fill=TEXT, anchor="lm")
        if self.label:
            f2 = self.font("bold", 21)
            w = d.textlength(self.label, font=f2)
            x1 = self.W - m
            d.rounded_rectangle([x1 - w - 38, y + 3, x1, y + 43], radius=20,
                                fill=tuple(int(c * 0.22) for c in self.accent), outline=self.accent, width=2)
            d.text((x1 - w / 2 - 19, y + 23), self.label, font=f2, fill=self.accent2, anchor="mm")
        d.line([(m, self.header_h + 4), (self.W - m, self.header_h + 4)], fill=(36, 44, 58), width=1)

    @property
    def wave_rect(self):
        """Ovoz to'lqini (ffmpeg showwaves) joylashadigan joy: (x, y, w, h) yoki None (tik formatda joy yo'q)."""
        if self.portrait:
            return None
        w, h = 300, 46
        S = self.S
        return (int(round((self.W - w) / 2 * S)), int(round(17 * S)), int(round(w * S)), int(round(h * S)))

    def _progress(self, d, p):
        p = max(0.0, min(1.0, p))
        H, W = self.H, self.W
        d.rectangle([0, H - 6, W, H], fill=(24, 30, 40))
        x = W * p
        d.rectangle([0, H - 6, x, H], fill=self.accent)
        if x > 4:
            d.rectangle([max(0, x - 40), H - 6, x, H], fill=self.accent2)

    def _heading(self, d, text, y, age=99.0):
        """Sarlavha (so'zma-so'z paydo bo'ladi) va ostida o'sib chiqadigan aksent chiziq. Pastki y ni qaytaradi."""
        x0, _, x1, _ = self.content_box
        if not text:
            return y
        f, lines, lh, size = self.fit(text, "bold", x1 - x0, 110, 46 if not self.portrait else 48,
                                      minsize=26, spacing=1.2, max_lines=2)
        n = self._anim_words(d, x0, y, lines, f, lh, TEXT, age, 0.0, 0.07, 0.42, rise=20)
        y += lh * len(lines)
        e = prog(age, 0.1 + 0.07 * min(n, 6), 0.5)
        d.rounded_rectangle([x0, y + 4, x0 + max(2, 96 * e), y + 9], radius=3, fill=self.accent)
        if e > 0.95:
            d.rounded_rectangle([x0 + 104, y + 4, x0 + 124, y + 9], radius=3, fill=lighten(self.accent, 0.5))
        return y + 30

    def _ghost_text(self, img, text, size, right_pad=40, alpha=0.10, dx=0):
        """Orqa fondagi katta xira belgi (raqam yoki ▶)."""
        if not text or alpha <= 0.002:
            return
        S = self.S
        key = (text, size)
        if key not in self._ghost:
            f = get_font(self.fd, "bold", int(round(size * S)))
            w = int(f.getlength(text)) + int(20 * S)
            lay = Image.new("L", (w, int(size * S * 1.3)), 0)
            ImageDraw.Draw(lay).text((int(10 * S), 0), text, font=f, fill=255)
            self._ghost[key] = lay
        lay = self._ghost[key].point(lambda v, a=alpha: int(v * a))
        col = Image.new("RGB", lay.size, self.accent)
        x = int((self.W - self.m - right_pad + dx) * S - lay.width)
        y = int(S * (self.header_h + (self.cap_bottom - self.cap_zone_h - self.header_h) / 2) - lay.height / 2)
        img.paste(col, (x, y), lay)

    # ---------------------------------------------------------------- sahna turlari
    def _s_title(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        self._ghost_text(img, (sc.get("label") or "").split(" ")[-1], 340 if not self.portrait else 300,
                         alpha=0.10 * prog(age, 0.0, 1.0), dx=math.sin(age * 0.7) * 10)
        d = self.D(img)
        cy = (y0 + y1) / 2
        label = sc.get("label", "")
        title_font, lines, lh, size = self.fit(sc.get("title", ""), "bold",
                                               (x1 - x0) * (0.56 if self._art_on() else 1.0) - (0 if self.portrait else 120),
                                               (y1 - y0) * 0.62, 76 if not self.portrait else 70, minsize=34,
                                               spacing=1.18)
        block = len(lines) * lh
        sub = sc.get("subtitle", "")
        self._art_card(img, age)
        total = (66 if label else 0) + block + 30 + (62 if sub else 0)
        y = cy - total / 2
        if label:
            e = prog(age, 0.0, 0.45)
            self._pill(d, x0, y - (1 - e) * 18, label, self.font("bold", 24), fill=self.accent, color=BG1, padx=20,
                       h=42, e=e)
            y += 66
        n = self._anim_words(d, x0, y, lines, title_font, lh, TEXT, age, 0.2, 0.09, 0.5, rise=34, shadow=True)
        y += block + 12
        tu = 0.3 + 0.09 * min(n, 8)
        e = prog(age, tu, 0.55)
        d.rounded_rectangle([x0, y, x0 + max(2, 150 * e), y + 8], radius=4, fill=self.accent)
        e2 = prog(age, tu + 0.3, 0.4)
        if e2 > 0:
            d.rounded_rectangle([x0 + 160, y, x0 + 160 + 30 * e2, y + 8], radius=4, fill=lighten(self.accent, 0.5))
        if sub:
            f = self.font("sans", 30)
            es = prog(age, tu + 0.3, 0.6)
            for ln in self.wrap(sub, f, x1 - x0)[:2]:
                y += 44
                if es > 0:
                    d.text((x0, y + (1 - es) * 14), ln, font=f, fill=lerp(self.bgpx(x0, y), MUTED, es), anchor="la")

    def _art_on(self) -> bool:
        return self.card is not None and not self.portrait

    def _art_box(self):
        x0, y0, x1, y1 = self.content_box
        w = (x1 - x0) * 0.40
        h = min((y1 - y0) - 10, w * 0.78)
        cy = (y0 + y1) / 2
        return [x1 - w, cy - h / 2, x1, cy + h / 2]

    def _art_card(self, img, age):
        """Sarlavha sahnasida o'ng tomonda AI rasm kartasi (yumshoq paydo bo'ladi)."""
        if not self._art_on():
            return
        e = ease_out(prog(age, 0.15, 0.7))
        if e <= 0.01:
            return
        S = self.S
        bx0, by0, bx1, by1 = self._art_box()
        rx0, ry0, rx1, ry1 = int(bx0 * S), int(by0 * S), int(bx1 * S), int(by1 * S)
        art = ImageOps.fit(self.card.convert('RGB'), (rx1 - rx0, ry1 - ry0), Image.LANCZOS)
        under = img.crop((rx0, ry0, rx1, ry1))
        mixed = Image.blend(under, art, e)
        m = Image.new("L", mixed.size, 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, mixed.width - 1, mixed.height - 1], radius=int(26 * S), fill=255)
        img.paste(mixed, (rx0, ry0), m)
        self._sd.paste(m.point(lambda v: int(v * e)), (rx0, ry0))
        d = self.D(img)
        d.rounded_rectangle([bx0, by0, bx1, by1], radius=26, outline=lerp(self.bgpx(bx0, by0), self.accent, e), width=3)

    def _s_recap(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        self._pill(d, x0, y0, sc.get("label", ""), self.font("bold", 24), outline=self.accent, color=self.accent2,
                   padx=20, h=42, e=prog(age, 0.0, 0.4))
        y = y0 + 72
        tf, tl, tlh, _ = self.fit(sc.get("title", ""), "bold", x1 - x0, 150, 52, minsize=28, spacing=1.2, max_lines=3)
        self._anim_words(d, x0, y, tl, tf, tlh, TEXT, age, 0.2, 0.07, 0.45, rise=22)
        y += tlh * len(tl) + 18
        if y1 - y > 80:
            e = prog(age, 0.5, 0.6)
            bgc = self.bgpx((x0 + x1) / 2, (y + y1) / 2)
            if e > 0:
                self._card(img, [x0, y, x1, y1], radius=20, fill=lerp(bgc, PANEL, e), outline=lerp(bgc, BORDER, e),
                           alpha=int(130 * e), solid=e)
                d = self.D(img)
                d.rounded_rectangle([x0, y + 18, x0 + 8, y + 18 + (y1 - y - 36) * e], radius=4, fill=self.accent)
            bf, bl, blh, _ = self.fit(sc.get("text", ""), "sans", x1 - x0 - 80, y1 - y - 44, 32, minsize=18, spacing=1.4)
            ty = y + 24
            for i, ln in enumerate(bl):
                el = prog(age, 0.9 + i * 0.16, 0.45)
                if el > 0:
                    d.text((x0 + 40, ty + (1 - el) * 14), ln, font=bf, fill=lerp(PANEL, (206, 214, 222), el),
                           anchor="la")
                ty += blh

    def _item_layout(self, items, width_avail, avail_h, start, gap_k=0.5, pad_y=14, min_row=0, minsize=14):
        """Qatorlar uchun shrift o'lchamini tanlaydi: hamma qator `avail_h` ga albatta sig'adi
        (shrift, ichki bo'shliq va raqam doirasi balandligi birga kichrayadi).
        (font, wrapped, lh, rows, gap, size, total)"""
        key = (tuple(items), width_avail, avail_h, start, gap_k, pad_y, min_row, minsize)
        hit = self._lay_cache.get(key)
        if hit:
            return hit
        n = len(items)
        size = start
        while True:
            f = self.font("sans", size)
            wrapped = [self.wrap(t, f, width_avail) for t in items]
            lh = int(size * 1.3)
            mr = min(min_row, int(size * 1.9) + 12) if min_row else 0
            py = max(4, min(pad_y, int(size * 0.45)))
            rows = [max(len(w) * lh + 2 * py, mr) for w in wrapped]
            gap = max(4, int(size * gap_k)) if size >= 22 else max(3, int(size * gap_k * 0.6))
            total = sum(rows) + gap * (n - 1)
            if total <= avail_h or size <= minsize:
                res = (f, wrapped, lh, rows, gap, size, total)
                break
            size -= 2
        if len(self._lay_cache) > 100:
            self._lay_cache.clear()
        self._lay_cache[key] = res
        return res

    def _s_bullets(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        y = self._heading(d, sc.get("heading", ""), y0, age)
        items = sc.get("bullets", [])
        n = len(items)
        if not n:
            return
        r = 24
        avail = y1 - y
        start = 40 if not self.portrait else 42
        f, wrapped, lh, rows, gap, size, total = self._item_layout(
            items, x1 - x0 - (r * 2 + 70) - 24, avail, start, gap_k=0.42, pad_y=14, min_row=2 * r + 24)
        yy = y + max(0, (avail - total) / 2 * 0.45)
        r = max(12, min(r, int(min(rows) / 2) - 5))
        nf = self.font("bold", max(14, min(26, int(r * 1.08))))
        e = ease_out(anim)
        for i in range(min(shown, n)):
            h = rows[i]
            active = i == shown - 1
            dx = int((1 - e) * 60) if active else 0
            a = e if active else 1.0
            bx0, bx1 = x0 + dx, x1
            bgc = self.bgpx((bx0 + bx1) / 2, yy + h / 2)
            fill = lerp(bgc, (26, 36, 52) if active else (19, 26, 36), a)
            outline = lerp(bgc, self.accent if active else BORDER, a)
            self._card(img, [bx0, yy, bx1, yy + h], radius=18, fill=fill, outline=outline,
                       width=3 if active else 2, glass=a, gfill=(26, 38, 56) if active else (18, 26, 38),
                       gout=self.accent if active else BORDER)
            dd = self.D(img)
            cx, cy = bx0 + 28 + r, yy + h / 2
            if active:
                dd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=lerp(fill, self.accent, a))
                dd.text((cx, cy), str(i + 1), font=nf, fill=lerp(fill, BG1, a), anchor="mm")
            else:
                dd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(30, 40, 56), outline=self.accent, width=2)
                dd.text((cx, cy), str(i + 1), font=nf, fill=self.accent2, anchor="mm")
            col = lerp(fill, TEXT, a) if active else (176, 186, 198)
            ty = yy + (h - len(wrapped[i]) * lh) / 2
            for ln in wrapped[i]:
                dd.text((cx + r + 24, ty), ln, font=f, fill=col, anchor="la")
                ty += lh
            yy += h + gap
        self._skeleton(d, x0, x1, yy, rows, gap, shown, age)

    def _skeleton(self, d, x0, x1, yy, rows, gap, shown, age, x_off=0):
        """Hali chiqmagan bandlar o'rni: xira kontur (ekran bo'sh turmasin, nechta band borligi ko'rinsin)."""
        pulse = 0.5 + 0.5 * math.sin(age * 2.2)
        for i in range(max(0, shown), len(rows)):
            h = rows[i]
            bgc = self.bgpx((x0 + x1) / 2, yy + h / 2)
            d.rounded_rectangle([x0 + x_off, yy, x1, yy + h], radius=18,
                                outline=lerp(bgc, BORDER, 0.22 + 0.16 * pulse), width=2)
            yy += h + gap

    def _typed(self, d, x, y, line, lang, font, cw, nchars, maxc):
        """Kod qatorining dastlabki nchars belgisini bo'yab chizadi. Oxirgi x ni qaytaradi."""
        left = nchars
        for txt, kind in highlight_line(line, lang):
            if left <= 0:
                break
            part = txt[:left]
            d.text((x, y), part, font=font, fill=SYN.get(kind, TEXT), anchor="la")
            x += cw * len(part)
            left -= len(part)
        return x

    def _s_code(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        y = y0
        if sc.get("heading"):
            f, lines, lh, _ = self.fit(sc["heading"], "bold", x1 - x0, 50, 34, minsize=22, max_lines=1)
            self._anim_words(d, x0, y, lines[:1], f, lh, TEXT, age, 0.0, 0.07, 0.42, rise=16)
            y += 54
        lang = sc.get("language", "python")
        code_lines = (sc.get("code") or "").split("\n")
        n = len(code_lines)
        bar_h = 44
        pad = 22
        cx0, cy0 = x0 + pad, y + bar_h + 14
        cw_avail, ch_avail = (x1 - x0) - 2 * pad, (y1 - cy0) - 16
        size = 34
        while size > 12:
            f = self.font("mono", size)
            cw = f.getlength("M")
            gutter = cw * 3
            lh = int(size * 1.5)
            maxlen = max((len(c) for c in code_lines), default=1)
            if maxlen * cw + gutter <= cw_avail and n * lh <= ch_avail:
                break
            size -= 2
        f = self.font("mono", size)
        cw = f.getlength("M")
        gutter = cw * 3
        lh = int(size * 1.5)
        maxc = max(8, int((cw_avail - gutter) / cw))
        py1 = min(y1, int(cy0 + n * lh + 26))
        ew = prog(age, 0.05, 0.5)
        bgc = self.bgpx((x0 + x1) / 2, (y + py1) / 2)
        self._card(img, [x0, y, x1, py1], radius=18, fill=lerp(bgc, PANEL, ew),
                   outline=lerp(bgc, lerp(BORDER, self.accent, 0.35), ew), width=2, glass=ew, gfill=(12, 17, 25),
                   gout=lerp(BORDER, self.accent, 0.35), galpha=0.84)
        d = self.D(img)
        d.rounded_rectangle([x0, y, x1, y + bar_h], radius=18, fill=lerp(bgc, (24, 30, 40), ew))
        d.rectangle([x0 + 2, y + bar_h - 16, x1 - 2, y + bar_h], fill=lerp(bgc, (24, 30, 40), ew))
        for i, c in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
            d.ellipse([x0 + 20 + i * 28, y + 14, x0 + 36 + i * 28, y + 30], fill=lerp(bgc, c, ew))
        d.text(((x0 + x1) / 2, y + bar_h / 2), sc.get("filename", ""), font=self.font("mono", 20),
               fill=lerp(bgc, MUTED, ew), anchor="mm")
        for i in range(min(shown, n)):
            ly = cy0 + i * lh
            line = code_lines[i]
            if len(line) > maxc:
                line = line[: maxc - 1] + "…"
            active = i == shown - 1
            if active:
                d.rounded_rectangle([x0 + 8, ly - 3, x1 - 8, ly + lh - 5], radius=8, fill=LINEHL)
                d.rectangle([x0 + 8, ly - 3, x0 + 12, ly + lh - 5], fill=self.accent)
            d.text((cx0, ly), str(i + 1).rjust(2), font=f, fill=(112, 120, 132), anchor="la")
            k = len(line) if not active else int(round(len(line) * min(1.0, anim)))
            x = self._typed(d, cx0 + gutter, ly, line, lang, f, cw, k, maxc)
            blink = int(age * 2.4) % 2 == 0 or anim < 1.0
            if active and (anim < 1.0 or shown < n) and blink:
                d.rectangle([x + 2, ly + 3, x + 2 + cw * 0.6, ly + lh - 9], fill=self.accent)

    def _s_flow(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        y = self._heading(d, sc.get("heading", ""), y0, age)
        steps = sc.get("steps", [])
        n = len(steps)
        if not n:
            return
        r = 26
        avail = y1 - y
        start = 36 if not self.portrait else 38
        f, wrapped, lh, rows, gap, size, total = self._item_layout(
            steps, x1 - x0 - (r * 2 + 110), avail, start, gap_k=0.8, pad_y=10, min_row=2 * r + 16)
        yy = y + max(0, (avail - total) / 2 * 0.4)
        r = max(13, min(r, int(min(rows) / 2) - 4))
        nf = self.font("bold", max(14, min(28, int(r * 1.08))))
        centers = []
        for i in range(n):
            centers.append(yy + rows[i] / 2)
            yy += rows[i] + gap
        cxm = x0 + 34 + r
        e = ease_out(anim)
        shown = min(shown, n)
        for i in range(shown - 1):
            a = e if i == shown - 2 else 1.0
            ya, yb = centers[i] + r + 4, centers[i + 1] - r - 4
            yb = ya + (yb - ya) * a
            d.line([(cxm, ya), (cxm, yb)], fill=self.accent, width=4)
            if a > 0.9:
                d.polygon([(cxm - 8, yb - 10), (cxm + 8, yb - 10), (cxm, yb)], fill=self.accent)
        for i in range(shown):
            active = i == shown - 1
            a = e if active else 1.0
            c = centers[i]
            h = rows[i]
            dx = int((1 - e) * 56) if active else 0
            bgc = self.bgpx((x0 + x1) / 2, c)
            fill = lerp(bgc, (26, 36, 52) if active else (19, 26, 36), a)
            self._card(img, [x0 + 10 + r * 2 + 30 + dx, c - h / 2, x1, c + h / 2], radius=16, fill=fill,
                       outline=lerp(bgc, self.accent if active else BORDER, a), width=3 if active else 2,
                       glass=a, gfill=(26, 38, 56) if active else (18, 26, 38),
                       gout=self.accent if active else BORDER)
            dd = self.D(img)
            dd.ellipse([cxm - r, c - r, cxm + r, c + r], fill=lerp(bgc, self.accent if active else (30, 40, 56), a),
                       outline=self.accent, width=3)
            dd.text((cxm, c), str(i + 1), font=nf, fill=BG1 if active else self.accent2, anchor="mm")
            ty = c - len(wrapped[i]) * lh / 2
            for ln in wrapped[i]:
                dd.text((x0 + r * 2 + 60 + dx, ty), ln, font=f, fill=lerp(fill, TEXT, a) if active else (176, 186, 198),
                        anchor="la")
                ty += lh
        pulse = 0.5 + 0.5 * math.sin(age * 2.2)
        for i in range(max(0, shown), n):
            c, h = centers[i], rows[i]
            bgc = self.bgpx((x0 + x1) / 2, c)
            d.rounded_rectangle([x0 + 10 + r * 2 + 30, c - h / 2, x1, c + h / 2], radius=16,
                                outline=lerp(bgc, BORDER, 0.22 + 0.16 * pulse), width=2)
            d.ellipse([cxm - r, c - r, cxm + r, c + r], outline=lerp(bgc, BORDER, 0.3), width=2)

    def _s_outro(self, img, d, sc, shown, anim, age):
        x0, y0, x1, y1 = self.content_box
        self._ghost_text(img, "▶", 300 if not self.portrait else 260, alpha=0.08 * prog(age, 0.0, 1.0),
                         dx=math.sin(age * 0.8) * 10)
        d = self.D(img)
        cy = (y0 + y1) / 2
        tf, lines, lh, _ = self.fit(sc.get("title", ""), "bold", x1 - x0 - (0 if self.portrait else 110),
                                    (y1 - y0) * 0.5, 64, minsize=30, spacing=1.2)
        total = 66 + len(lines) * lh + 34 + 72
        y = cy - total / 2
        e = prog(age, 0.0, 0.45)
        self._pill(d, x0, y - (1 - e) * 18, sc.get("label", ""), self.font("bold", 26), fill=self.accent, color=BG1,
                   padx=22, h=46, e=e)
        y += 70
        n = self._anim_words(d, x0, y, lines, tf, lh, TEXT, age, 0.2, 0.09, 0.5, rise=34, shadow=True)
        y += len(lines) * lh + 34
        bf = self.font("bold", 28)
        cta = sc.get("cta", "")
        bw = d.textlength(cta, font=bf) + 110
        tc = 0.4 + 0.09 * min(n, 8)
        s = ease_out_back((age - tc) / 0.55)
        if s > 0.02:
            pulse = 0.5 + 0.5 * math.sin((age - tc) * 4.2) if age > tc + 0.55 else 0.0
            w2, h2 = bw * s, 64 * s
            ccx, ccy = x0 + bw / 2, y + 32
            bx0, by0, bx1, by1 = ccx - w2 / 2, ccy - h2 / 2, ccx + w2 / 2, ccy + h2 / 2
            if pulse > 0:      # kengayib so'nadigan halqa
                g = int(6 + 10 * pulse)
                d.rounded_rectangle([bx0 - g, by0 - g, bx1 + g, by1 + g], radius=int(h2 / 2) + g,
                                    outline=lerp(self.bgpx(ccx, ccy), (229, 57, 53), 0.55 * (1 - pulse) + 0.1), width=3)
            self._card(img, [bx0, by0, bx1, by1], radius=int(h2 / 2), fill=(229, 57, 53), outline=(255, 120, 110),
                       width=2, alpha=150)
            d = self.D(img)
            if s > 0.7:
                tx = bx0 + 30 * s
                bob = 2 * math.sin(age * 5) if age > tc + 0.55 else 0
                d.polygon([(tx, ccy - 12 + bob), (tx, ccy + 12 + bob), (tx + 20, ccy + bob)], fill=(255, 255, 255))
                d.text((bx0 + 66 * s + (w2 - 90 * s) / 2, ccy), cta, font=bf, fill=(255, 255, 255), anchor="mm")

    # ---------------------------------------------------------------- subtitr (so'zma-so'z)
    def _cap_layout(self, words):
        key = tuple(words)
        lay = self._cap_cache.get(key)
        if lay:
            return lay
        m = self.m
        max_w = self.W - 2 * m - 64
        text = " ".join(words)
        f, lines, lh, size = self.fit(text, "bold", max_w, self.cap_max_lines * 90, self.cap_font,
                                      minsize=20, spacing=1.34, max_lines=self.cap_max_lines)
        p = self._probe
        items, idx, maxw = [], 0, 0
        for li, ln in enumerate(lines):
            toks = ln.split(" ")
            lw = p.textlength(ln, font=f)
            maxw = max(maxw, lw)
            xs = (self.W - lw) / 2
            for j, tk in enumerate(toks):
                pre = " ".join(toks[:j]) + (" " if j else "")
                items.append((min(idx, len(words) - 1), xs + p.textlength(pre, font=f), li, tk,
                              p.textlength(tk, font=f)))
                idx += 1
        lay = {"font": f, "lh": lh, "items": items, "lines": len(lines), "w": maxw}
        if len(self._cap_cache) > 400:
            self._cap_cache.clear()
        self._cap_cache[key] = lay
        return lay

    def _caption(self, img, cap):
        """cap = {"words": [...], "n": ko'ringan so'zlar soni, "cur": hozirgi so'z indeksi yoki -1}"""
        if not cap or not cap.get("words") or cap.get("n", 0) <= 0:
            return
        lay = self._cap_layout(cap["words"])
        f, lh = lay["font"], lay["lh"]
        padx, pady = 28, 16
        box_w = min(self.W - 2 * self.m, int(lay["w"] + 2 * padx))
        box_h = lay["lines"] * lh + 2 * pady
        bx0 = (self.W - box_w) // 2
        y1 = self.cap_bottom
        y0 = y1 - box_h
        S = self.S
        rx0, ry0, rx1, ry1 = int(bx0 * S), int(y0 * S), int((bx0 + box_w) * S), int(y1 * S)
        region = img.crop((rx0, ry0, rx1, ry1)).convert("RGBA")
        ov = Image.new("RGBA", region.size, (0, 0, 0, 0))
        od = ImageDraw.Draw(ov)
        od.rounded_rectangle([0, 0, region.width - 1, region.height - 1], radius=22 * S, fill=(6, 9, 14, 190),
                             outline=(255, 255, 255, 36), width=max(1, int(round(S))))
        img.paste(Image.alpha_composite(region, ov).convert("RGB"), (rx0, ry0))
        d = self.D(img)
        n_show, cur = cap["n"], cap.get("cur", -1)
        for idx, x, li, tk, w in lay["items"]:
            if idx >= n_show:
                continue
            cy = y0 + pady + li * lh + lh / 2
            if idx == cur:
                d.rounded_rectangle([x - 8, cy - lh / 2 + 3, x + w + 8, cy + lh / 2 - 3], radius=12, fill=self.accent)
                d.text((x, cy), tk, font=f, fill=BG1, anchor="lm")
            else:
                d.text((x, cy), tk, font=f, fill=(246, 248, 250), anchor="lm")

    # ---------------------------------------------------------------- asosiy kirish
    def age_key(self, scene: dict, age: float) -> float:
        """Kesh uchun yoshni yaxlitlaydi: kirish animatsiyasi tugagach (va doimiy harakat bo'lmasa) o'zgarmas."""
        if scene["type"] in CONTINUOUS:
            return round(age, 3)
        return round(min(age, ENTER_END.get(scene["type"], 1.0)), 3)

    def content(self, scene: dict, shown: int = 0, anim: float = 1.0, age: float = 99.0) -> "Content":
        """Sarlavha va sahna mazmuni (statik fon ustida; subtitr va progresssiz).
        shown - ko'rinayotgan bo'lakchalar soni, anim - oxirgisining paydo bo'lish bosqichi (0..1),
        age - sahna boshlanganidan beri o'tgan soniyalar (kirish animatsiyalari uchun)."""
        img = self.bg.copy()
        self._sh = Image.new("L", (self.RW, self.RH), 0)
        self._sd = Image.new("L", (self.RW, self.RH), 0)
        self._pl = None
        d = self.D(img)
        self._header(img, d)
        fn = getattr(self, "_s_" + scene["type"], self._s_bullets)
        fn(img, self.D(img), scene, shown, anim, age)
        return Content(img, self._sh, self._sd, self._pl)

    def compose_base(self, t: float, c: "Content", mask: Image.Image) -> Image.Image:
        """Subtitrsiz kadr: harakatlanuvchi fon + soyalar + mazmun (bir necha kadr uchun qayta ishlatiladi)."""
        img = self.bg_frame(t + self.t_off)
        img.paste((0, 0, 0), (0, 0), c.shadow)
        if c.plate is not None:
            img = Image.alpha_composite(img.convert("RGBA"), c.plate).convert("RGB")
        img.paste(c.img, (0, 0), mask)
        return img

    def finish(self, img: Image.Image, cap, progress: float) -> Image.Image:
        """Asos kadrga subtitr (+progress) chizadi (img o'zgartiriladi)."""
        self._caption(img, cap)
        if self.show_progress:
            self._progress(self.D(img), progress)
        return img

    def compose(self, t: float, c: "Content", mask: Image.Image, cap, progress: float) -> Image.Image:
        """Yakuniy kadr: harakatlanuvchi fon (t soniya) + soyalar + mazmun + subtitr + progress."""
        return self.finish(self.compose_base(t, c, mask), cap, progress)

    def frame(self, scene: dict, shown: int, anim: float, cap, progress: float, t: float = 0.0,
              age: float = 99.0) -> Image.Image:
        c = self.content(scene, shown, anim, age)
        return self.compose(t, c, self.mask_for(c), cap, progress)

    def black(self) -> "Content":
        z = Image.new("L", (self.RW, self.RH), 0)
        return Content(Image.new("RGB", (self.RW, self.RH), (0, 0, 0)), z, z.copy())
