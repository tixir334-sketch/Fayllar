"""Fasl pleylistini o'z-o'zini tiklovchi sinxronlash.

Har safar: pleylist mavjudligi tekshiriladi; o'chib ketgan bo'lsa yangisi yaratiladi
va faslning barcha yuklangan videolari (tartib bilan) qayta qo'shiladi.
Pleylistda yo'q videolar (masalan, oldingi xato tufayli) ham to'ldiriladi.
"""
from __future__ import annotations

from .util import clip, log
from .youtube import YTError


def _gone(e: YTError) -> bool:
    return e.status == 404 or e.reason in ("playlistNotFound", "notFound")


def sync_season(yt, db, cfg, season_id) -> list:
    """Faslning pleylistini tekshiradi/tiklaydi. Foydalanuvchiga ko'rsatiladigan qatorlar ro'yxatini qaytaradi.
    Kvota/avtorizatsiya xatolari yuqoriga ko'tariladi (chaqiruvchi hal qiladi)."""
    season = db.season(season_id)
    notes = []
    eps = [e for e in db.season_episodes(season_id) if e["status"] == "uploaded" and e.get("yt_id")]
    if not eps:
        return notes
    pid = season.get("playlist_id") or ""
    present = None  # pleylistdagi video ID lari
    if pid:
        try:
            if yt.playlist_exists(pid):
                present = set(yt.playlist_video_ids(pid))
            else:
                notes.append("♻️ pleylist o'chirib yuborilgan ekan")
                pid = ""
        except YTError as e:
            if _gone(e):
                notes.append("♻️ pleylist o'chirib yuborilgan ekan")
                pid = ""
            elif e.quota or e.auth:
                raise
            else:
                log.warning("pleylistni tekshirib bo'lmadi: %s", e)
                present = set()
    created = False
    if not pid:
        pid = _create(yt, cfg, season)
        db.set_playlist(season_id, pid)
        present, created = set(), True
        notes.append("📚 yangi pleylist yaratildi")
    added = failed = 0
    for ep in eps:
        if ep["yt_id"] in present:
            continue
        try:
            yt.add_to_playlist(pid, ep["yt_id"])
            present.add(ep["yt_id"])
            added += 1
        except YTError as e:
            if _gone(e) and not created and added == 0:
                # tekshiruvdan keyin o'chirilgan: bir marta qayta yaratib, boshidan
                pid = _create(yt, cfg, season)
                db.set_playlist(season_id, pid)
                present, created = set(), True
                notes.append("♻️ pleylist qayta yaratildi")
                try:
                    yt.add_to_playlist(pid, ep["yt_id"])
                    present.add(ep["yt_id"])
                    added += 1
                except YTError as e2:
                    if e2.quota or e2.auth:
                        raise
                    failed += 1
                continue
            if e.quota or e.auth:
                raise
            failed += 1
            log.warning("pleylistga qo'shib bo'lmadi %s: %s", ep["yt_id"], e)
            if failed == 1:
                notes.append(f"⚠️ #{ep['gno']} qo'shilmadi: {clip(str(e), 90)}")
    if added:
        notes.append(f"📚 pleylistga {added} ta video qo'shildi")
    return notes


def _create(yt, cfg, season) -> str:
    return yt.ensure_playlist(f"{cfg.get('CHANNEL_NAME')} · {season['theme']}",
                              season.get("description", "") or "", cfg.get("YT_PRIVACY"))
