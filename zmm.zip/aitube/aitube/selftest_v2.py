"""Yangi imkoniyatlar sinovi (tarmoqsiz, GPU kerak emas): GPU/CPU kodlash menejeri, kalit aylanishi, parallel ovoz,
fps ga bog'liq animatsiya, stream tizimi, sozlamalar. selftest.main() chaqiradi.

GPU "soxta ffmpeg" (shim) bilan sinaladi: u `h264_nvenc` buyruqlarini haqiqiy libx264 ga o'giradi yoki xato beradi
(Cannot load libcuda / sessiya chegarasi) — shu tariqa GPU yo'li, sessiyalar va CPU ga avtomatik o'tish tekshiriladi.
"""
from __future__ import annotations

import contextlib
import math
import os
import queue
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import wave
from pathlib import Path

from .selftest import ok, section

SR = 44100

SHIM = r'''#!@PY@
import os, sys, subprocess
REAL = @REAL@
LOG = os.environ.get("FAKE_GPU_LOG", "")
MODE = os.environ.get("FAKE_GPU_MODE", "ok")
SLOTS = os.environ.get("FAKE_GPU_SLOTS", "")
args = sys.argv[1:]
if "h264_nvenc" not in args:
    os.execv(REAL, [REAL] + args)
probe = args[-3:] == ["-f", "null", "-"]
if MODE == "fail":
    sys.stderr.write("[h264_nvenc @ 0x55d0] Cannot load libcuda.so.1\n[h264_nvenc @ 0x55d0] Error initializing the encoder\n")
    sys.exit(1)
if MODE == "probe_only" and not probe:
    sys.stderr.write("[h264_nvenc @ 0x1] OpenEncodeSessionEx failed: out of memory (10)\n")
    sys.exit(1)
slot = None
if MODE.startswith("limit:"):
    for i in range(int(MODE.split(":")[1])):
        p = os.path.join(SLOTS, "slot%d" % i)
        try:
            os.close(os.open(p, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            slot = p
            break
        except FileExistsError:
            continue
    if slot is None:
        sys.stderr.write("[h264_nvenc @ 0x1] OpenEncodeSessionEx failed: out of memory (10)\n")
        sys.exit(1)
drop1 = {"-tune", "-rc", "-cq", "-spatial-aq", "-forced-idr", "-b_ref_mode", "-rc-lookahead", "-bf"}
out, i = [], 0
while i < len(args):
    a = args[i]
    if a == "h264_nvenc":
        out += ["libx264", "-crf", "30"]
    elif a == "-preset":
        out += ["-preset", "ultrafast"]
        i += 1
    elif a in drop1:
        i += 1
    elif a == "-b:v" and i + 1 < len(args) and args[i + 1] == "0":
        i += 1
    else:
        out.append(a)
    i += 1
if LOG:
    with open(LOG, "a") as f:
        f.write("NVENC " + " ".join(args) + "\n")
try:
    rc = subprocess.call([REAL] + out)
finally:
    if slot:
        try:
            os.unlink(slot)
        except OSError:
            pass
sys.exit(rc)
'''


@contextlib.contextmanager
def fake_gpu(td: Path, mode: str = "ok"):
    """PATH ning boshiga soxta ffmpeg qo'yadi (haqiqiy ffmpeg ustiga). mode: ok | fail | probe_only | limit:N."""
    from .hwenc import HW
    real = shutil.which("ffmpeg")
    d = td / f"shim_{mode.replace(':', '_')}"
    d.mkdir(parents=True, exist_ok=True)
    (d / "slots").mkdir(exist_ok=True)
    p = d / "ffmpeg"
    p.write_text(SHIM.replace("@PY@", sys.executable).replace("@REAL@", repr(real)), encoding="utf-8")
    p.chmod(0o755)
    log = d / "nvenc.log"
    old = {k: os.environ.get(k) for k in ("PATH", "FAKE_GPU_MODE", "FAKE_GPU_LOG", "FAKE_GPU_SLOTS", "ENCODER")}
    os.environ.update(PATH=f"{d}{os.pathsep}{old['PATH']}", FAKE_GPU_MODE=mode, FAKE_GPU_LOG=str(log),
                      FAKE_GPU_SLOTS=str(d / "slots"))
    HW.detect(force=True)
    try:
        yield log
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        HW.detect(force=True)


class FakeTTS:
    """Ovoz: matn uzunligiga mos sinus; har chaqiruv `delay` soniya 'tarmoq' kutadi (parallelligini o'lchash uchun)."""

    def __init__(self, k=0.25, delay=0.0):
        self.k, self.delay = k, delay
        self.calls = 0
        self.lock = threading.Lock()

    def synth_ex(self, text, out, allow_silent=None, spec=None, prepared=False, only=None):
        with self.lock:
            self.calls += 1
        if self.delay:
            time.sleep(self.delay)
        sm = [0] * int(SR * 0.1)
        for wd in text.split():
            n = int(SR * (0.03 * max(2, len(wd)) * self.k + 0.04))
            sm += [int(8000 * math.sin(2 * math.pi * 160 * i / SR)) for i in range(n)]
            sm += [0] * int(SR * (0.25 if wd[-1] in ".!?" else 0.02))
        with wave.open(str(out), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes(b"".join(struct.pack("<h", v) for v in sm))
        return "fake", []


def _scenes(cfg, n=3):
    from .compose import compose_scenes
    sc = [{"type": "bullets", "heading": f"Band {i}", "bullets": ["Birinchi", "Ikkinchi", "Uchinchi"],
           "narration": "Birinchi ikkinchi uchinchi nuqta."} for i in range(n)]
    script = {"title": "Sinov", "hook": "Salom, bu sinov.", "recap": "", "teaser": "Ko'rishamiz.", "scenes": sc}
    return compose_scenes(cfg, {"gno": 1, "season_id": 1}, script, None, None)


def _codec_of(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name",
                        "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    return r.stdout.strip()


# ============================================================================ 1) kodlash menejeri: parametrlar
def hw_args_tests():
    section("V2-1) GPU/CPU kodlash: parametrlar va sifat")
    from .hwenc import HW, NAMES, ORDER, auto_kbps
    for nm in ORDER:
        for kind in ("stream", "video"):
            tiers = HW._tiers(nm, kind, 30, 0, 20, 1080)
            ok(len(tiers) >= 2, f"{nm}/{kind}: kamida 2 ta variant (eng yaxshisidan oddiygacha)")
            ok(all(NAMES[nm] in t and "-crf" not in t for t in tiers), f"{nm}/{kind}: to'g'ri kodek va x264 `-crf` yo'q")
            ok(all(t[t.index("-g") + 1] == "60" for t in tiers), f"{nm}/{kind}: kalit kadr har 2 soniyada (fps*2)")
    q = HW._tiers("qsv", "stream", 30, 3000, 20, 720)[0]
    ok(q[q.index("-pix_fmt") + 1] == "nv12", "QSV: piksel formati nv12")
    n = HW._tiers("nvenc", "stream", 25, 3000, 20, 720)[0]
    ok("-cq" in n and "-maxrate" in n and "-bufsize" in n and "-bf" in n, "NVENC (stream): doimiy sifat (CQ) + bitrate chegarasi, B-kadrsiz")
    nv = HW._tiers("nvenc", "video", 30, 0, 23, 1080)[0]
    ok(nv[nv.index("-cq") + 1] == "21" and nv[nv.index("-b:v") + 1] == "0", "NVENC (video): CQ = CRF-2 (sifat saqlanadi), bitrate chegarasiz")
    cpu = HW._cpu_args("stream", 30, 5000, 20, "ultrafast", False)
    ok("libx264" in cpu and cpu[cpu.index("-crf") + 1] == "20" and "-maxrate" in cpu and "-x264-params" in cpu
       and cpu[cpu.index("-preset") + 1] == "ultrafast", "CPU (stream): libx264 + CRF + maxrate + yengil x264-params")
    ok("-tune" in HW._cpu_args("video", 30, 0, 23, None, True) and "-tune" not in HW._cpu_args("stream", 30, 0, 20, None, False),
       "CPU: statik tasvir uchun stillimage, harakatli stream uchun yo'q")
    ok(auto_kbps(480, 25) < auto_kbps(720, 30) < auto_kbps(1080, 30) < auto_kbps(1080, 60),
       f"avto bitrate o'lcham va fps ga qarab o'sadi ({auto_kbps(480, 25)}..{auto_kbps(1080, 60)})")
    ok(HW.venc("stream", 30, 3000, 20, "ultrafast", 720, force_cpu=True)[1] == "libx264", "force_cpu: har doim CPU")
    ok(HW.is_hw(["-c:v", "h264_nvenc"]) and not HW.is_hw(["-c:v", "libx264"]), "is_hw: kodlovchi turini aniqlaydi")
    # xato tasnifi
    ok(HW.report(["-c:v", "libx264"], False, "x") == "other" and HW.report("nvenc", True) == "ok", "report: CPU xatosi GPU hisobiga kirmaydi")
    HW._fails.clear()
    HW._off_until.clear()


# ============================================================================ 2) GPU yo'li (soxta ffmpeg bilan)
def hw_shim_tests(tmp: Path):
    section("V2-2) GPU kodlash yo'li: tanlash, sessiyalar, CPU ga avtomatik o'tish")
    from .config import Config
    from .hwenc import HW
    from .render import Renderer
    from .video import VideoBuilder, VideoError
    os.environ["AITUBE_DATA"] = str(tmp / "v2data")
    cfg = Config(root=tmp, env_file=tmp / "v2.env")
    cfg.overrides.update({"VIDEO_RES": "480", "VIDEO_FPS": "15", "VIDEO_MOTION": "1", "VIDEO_WAVE": "0", "MUSIC": "0"})
    HW.bind(cfg)
    # --- GPU yo'q (haqiqiy muhit)
    HW.detect(force=True)
    ok(HW.pick() in ("cpu", "nvenc", "qsv", "amf", "videotoolbox"), f"kodlovchi aniqlandi: {HW.label()}")
    # --- GPU ishlaydi (soxta)
    with fake_gpu(tmp, "ok") as log:
        ok(HW.pick() == "nvenc", "NVENC ishlasa avto-tanlash uni tanlaydi")
        st = HW.status()
        ok(st["probe"]["nvenc/stream"]["ok"] and st["probe"]["nvenc/video"]["ok"], "stream va video uchun sinov o'tdi")
        ok(HW.sessions("nvenc") >= 4, f"sessiyalar o'lchandi ({HW.sessions('nvenc')})")
        ok("NVIDIA NVENC" in HW.describe(html=False) and "✅" in HW.describe(html=False), "tavsif GPU ni ko'rsatadi")
        cfg.overrides["ENCODER"] = "cpu"
        ok(HW.pick() == "cpu", "ENCODER=cpu: GPU bo'lsa ham CPU")
        cfg.overrides["ENCODER"] = "qsv"
        ok(HW.pick() == "cpu", "ENCODER=qsv, lekin QSV yo'q: CPU ga tushadi")
        cfg.overrides["ENCODER"] = "auto"
        HW.detect(force=True)
        # --- video qurish GPU kodlovchi bilan
        scenes = _scenes(cfg, 2)
        vb = VideoBuilder(cfg, FakeTTS(0.25))
        rr = Renderer(cfg, accent_idx=0, episode_label="Q1", channel="Sinov")
        res = vb.build(scenes, tmp / "w_gpu", tmp / "gpu.mp4", rr)
        ok((tmp / "gpu.mp4").exists() and _codec_of(tmp / "gpu.mp4") == "h264", "GPU yo'li: video yaratildi (h264)")
        ok(res["encoder"] == "NVIDIA NVENC", f"natijada kodlovchi ko'rsatilgan ({res['encoder']})")
        txt = log.read_text() if log.exists() else ""
        ok("NVENC" in txt and "-cq" in txt and "-crf" not in txt.split("NVENC")[-1], "ffmpeg ga NVENC parametrlari (-cq) berildi, x264 `-crf` emas")
    # --- sessiya chegarasi o'lchanadi
    with fake_gpu(tmp, "limit:3"):
        ok(HW.sessions("nvenc") == 3, f"drayver chegarasi (3 sessiya) o'lchab topildi ({HW.sessions('nvenc')})")
        cnt = {"max": 0, "cur": 0}
        lk = threading.Lock()

        def worker():
            with HW.session("nvenc"):
                with lk:
                    cnt["cur"] += 1
                    cnt["max"] = max(cnt["max"], cnt["cur"])
                time.sleep(0.15)
                with lk:
                    cnt["cur"] -= 1

        ths = [threading.Thread(target=worker) for _ in range(9)]
        [t.start() for t in ths]
        [t.join() for t in ths]
        ok(cnt["max"] == 3, f"bir vaqtda ko'pi bilan 3 ta GPU sessiyasi ochildi ({cnt['max']})")
        with HW.session(["-c:v", "libx264"]):
            ok(True, "CPU uchun sessiya kutilmaydi")
    # --- GPU umuman ishlamasa
    with fake_gpu(tmp, "fail"):
        ok(HW.pick() == "cpu", "GPU xato bersa avtomatik CPU")
        ok("libcuda" in HW.describe(html=False), "sabab ko'rsatiladi (libcuda)")
        vb = VideoBuilder(cfg, FakeTTS(0.25))
        res = vb.build(_scenes(cfg, 1), tmp / "w_cpu", tmp / "cpu.mp4", Renderer(cfg, accent_idx=0, episode_label="Q1", channel="S"))
        ok((tmp / "cpu.mp4").exists() and res["encoder"].startswith("CPU"), f"CPU bilan video yaratildi ({res['encoder']})")
    # --- sinov o'tadi, haqiqiy kodlashda GPU yiqiladi: video CPU da qayta kodlanadi
    with fake_gpu(tmp, "probe_only"):
        ok(HW.pick() == "nvenc", "sinov o'tdi (GPU tanlandi)")
        vb = VideoBuilder(cfg, FakeTTS(0.25))
        res = vb.build(_scenes(cfg, 1), tmp / "w_fb", tmp / "fb.mp4", Renderer(cfg, accent_idx=0, episode_label="Q1", channel="S"))
        ok((tmp / "fb.mp4").exists() and _codec_of(tmp / "fb.mp4") == "h264" and res["encoder"].startswith("CPU"),
           f"GPU yiqildi -> video avtomatik CPU da qayta kodlandi ({res['encoder']})")
        res2 = vb.build(_scenes(cfg, 1), tmp / "w_fb2", tmp / "fb2.mp4", Renderer(cfg, accent_idx=0, episode_label="Q1", channel="S"))
        ok((tmp / "fb2.mp4").exists() and HW.pick() == "cpu" and HW.fallbacks >= 1,
           "ketma-ket ikkinchi xatodan keyin GPU vaqtincha o'chiriladi (10 daqiqa CPU)")
        ok("CPU ga o'tiladi" in " ".join(s for _, s in HW.events) or HW.fallbacks >= 1, "hodisa jurnalga yozildi")
    # --- stream bo'lagi: parallel qismlar GPU da; GPU yiqilsa butun bo'lak CPU da
    for mode, expect in (("ok", "nvenc"), ("probe_only", "cpu")):
        with fake_gpu(tmp, mode):
            from concurrent.futures import ThreadPoolExecutor
            cs = cfg
            cs.overrides.update({"VIDEO_RES": "480", "VIDEO_FPS": "15"})
            vb = VideoBuilder(cs, FakeTTS(0.25))
            scenes = _scenes(cs, 3)
            wd = tmp / f"sw_{mode}"
            pr = vb.prepare_stream(scenes, wd, portrait=False, tts_workers=4)
            rq: queue.Queue = queue.Queue()
            for _ in range(3):
                rq.put(Renderer(cs, accent_idx=1, episode_label="LIVE", channel="S"))
            codec = HW.venc("stream", 15, 1200, 20, "ultrafast", 480)
            fb = HW.venc("stream", 15, 1200, 20, "ultrafast", 480, force_cpu=True)
            out = tmp / f"stream_{mode}.mp4"
            with ThreadPoolExecutor(max_workers=4) as ex:
                vb.motion_step = 1
                try:
                    r = vb.render_stream(pr, scenes, wd, out, rq.get, rq.put, ex, 1.5, codec, 0.0, None, threads_each=1,
                                         remote=None, spec_base=None, fallback_args=fb)
                    good = True
                except VideoError as e:
                    good, r = False, {}
                    print("   render_stream:", str(e)[:200])
            ok(good and out.exists() and _codec_of(out) == "h264", f"stream bo'lagi ({mode}) yaratildi")
            ok(pr.get("encoder") == expect, f"stream bo'lagi {expect} bilan kodlandi (mode={mode}: {pr.get('encoder')})")
            if good:
                d = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(out)],
                                   capture_output=True, text=True).stdout.strip()
                ok(abs(float(d) - pr["total_f"] / pr["fps"]) < 0.5, f"bo'lak davomiyligi ovozga mos ({float(d):.2f}s)")
    HW._fails.clear()
    HW._off_until.clear()
    HW.cfg = None


# ============================================================================ 3) kalit aylanishi va parallel LLM
def llm_rotation_tests():
    section("V2-3) LLM: kalitlar navbat bilan, kutishsiz almashtirish, parallel so'rovlar")
    from . import llm as L
    from .config import Config
    td = Path(tempfile.mkdtemp())
    try:
        cfg = Config(root=td, env_file=td / ".env")
        cfg.overrides.update({"GEMINI_API_KEYS": "k1,k2,k3", "GEMINI_MODELS": "m1,m2", "LLM_ORDER": "gemini"})
        lm = L.LLM(cfg)
        calls = []
        orig = L.GeminiProvider.call

        def fake(self, key, model, system, prompt, json_mode, temperature, max_tokens):
            calls.append((key, model))
            time.sleep(0.05)
            return "ok-" + key

        L.GeminiProvider.call = fake
        try:
            r = [lm.complete("s", "p")[0] for _ in range(6)]
            ok(r == ["ok-k1", "ok-k2", "ok-k3", "ok-k1", "ok-k2", "ok-k3"], f"kalitlar navbat bilan almashadi ({r})")
            calls.clear()
            t = time.time()
            res = list(lm.complete_many([("s", f"p{i}") for i in range(9)]))
            dt = time.time() - t
            ok(len(res) == 9 and all(x[3] is None for x in res), "complete_many: 9 so'rov hammasi bajarildi")
            ok(dt < 0.35, f"parallel: 9 so'rov {dt:.2f}s da (ketma-ket 0.45s+)")
            ok({c[0] for c in calls} == {"k1", "k2", "k3"}, "parallel so'rovlar hamma kalitlarga taqsimlandi")
            order = []
            for i, txt, label, err in lm.complete_many([("s", "a", {"max_tokens": 10}), ("s", "b")]):
                order.append(i)
            ok(sorted(order) == [0, 1], "natija har biri tugashi bilan keladi (indeks bilan)")

            def flaky(self, key, model, system, prompt, json_mode, temperature, max_tokens):
                if key in ("k1", "k2"):
                    raise L.ProviderError("HTTP 503: down", 503)
                return "good-" + key

            L.GeminiProvider.call = flaky
            lm._rr.clear()
            t = time.time()
            txt, label = lm.complete("s", "p")
            ok(txt == "good-k3" and time.time() - t < 0.3, f"5xx: uyqusiz darhol keyingi kalitga o'tildi ({time.time() - t:.3f}s)")

            def limited(self, key, model, system, prompt, json_mode, temperature, max_tokens):
                if key == "k1":
                    raise L.ProviderError("HTTP 429: quota", 429, 0)
                return "fine-" + key

            L.GeminiProvider.call = limited
            lm._rr.clear()
            lm.cooldown.clear()
            txt, _ = lm.complete("s", "p")
            ok(txt == "fine-k2" and ("gemini", "k1") in lm.cooldown, "429: kalit dam oladi, keyingisi ishlaydi")
            txt, _ = lm.complete("s", "p")
            txt2, _ = lm.complete("s", "p")
            ok("fine-k1" not in (txt, txt2), "dam olayotgan kalit qayta ishlatilmaydi")

            def dead(self, key, model, system, prompt, json_mode, temperature, max_tokens):
                raise L.ProviderError("HTTP 500: x", 500)

            L.GeminiProvider.call = dead
            lm.cooldown.clear()
            t = time.time()
            try:
                lm.complete("s", "p")
                ok(False, "hammasi yiqilsa LLMError kutilgan")
            except L.LLMError:
                ok(time.time() - t < 2.0, f"hammasi yiqilsa tez LLMError ({time.time() - t:.2f}s, uzun uyqu yo'q)")
            ok(sum(lm.key_use.values()) >= 12, "kalit ishlatilishi sanaladi (key_use)")
        finally:
            L.GeminiProvider.call = orig
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ============================================================================ 4) parallel ovoz va fps ga bog'liq animatsiya
def tts_and_anim_tests(tmp: Path):
    section("V2-4) Video: ovoz PARALLEL, animatsiya fps ga bog'liq")
    from .config import Config
    from .video import VideoBuilder, motion_cad
    os.environ["AITUBE_DATA"] = str(tmp / "v2data")
    cfg = Config(root=tmp, env_file=tmp / "v2.env")
    scenes = _scenes(cfg, 8)
    n = len(scenes)
    tts = FakeTTS(0.25, delay=0.3)
    vb = VideoBuilder(cfg, tts)
    t0 = time.time()
    a = vb.make_audio(scenes, tmp / "wa", lambda i, k, info: None, workers=0)
    dt = time.time() - t0
    ok(tts.calls >= 4 and dt < 0.3 * tts.calls * 0.6, f"ovoz parallel: {tts.calls} chaqiruv {dt:.2f}s da (ketma-ket {0.3 * tts.calls:.1f}s+)")
    tts2 = FakeTTS(0.25, delay=0.2)
    t0 = time.time()
    VideoBuilder(cfg, tts2).make_audio(scenes, tmp / "wb", lambda i, k, info: None, workers=1)
    ok(time.time() - t0 >= 0.2 * tts2.calls * 0.9, "workers=1 ketma-ket rejim saqlangan")
    # --- asinxron TTS sikli: ko'p chaqiruv bir vaqtda, bitta sikl/oqimda
    import asyncio
    from .tts import AsyncLoop
    import threading as _th

    async def nap(i):
        await asyncio.sleep(0.25)
        return i, _th.current_thread().name

    t0 = time.time()
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=24) as ex:
        outs = list(ex.map(lambda i: AsyncLoop.run(nap(i)), range(24)))
    dt = time.time() - t0
    ok(dt < 1.2 and {n for _, n in outs} == {"tts-async"}, f"24 ta asinxron chaqiruv BITTA siklda parallel ({dt:.2f}s; ketma-ket 6s)")
    # kechiktirilgan renderer: build() ovozdan KEYIN chaqiradi
    from .render import Renderer
    cfg.overrides.update({"VIDEO_RES": "480", "VIDEO_FPS": "15", "VIDEO_WAVE": "0", "MUSIC": "0"})
    order = []

    class T2(FakeTTS):
        def synth_ex(self, *a, **k):
            order.append("tts")
            return super().synth_ex(*a, **k)

    def mk():
        order.append("renderer")
        return Renderer(cfg, accent_idx=0, episode_label="Q", channel="S")

    VideoBuilder(cfg, T2(0.25)).build(_scenes(cfg, 2), tmp / "wl", tmp / "lazy.mp4", mk)
    ok(order and order[-1] != "tts" and "renderer" in order and order.index("renderer") > max(i for i, x in enumerate(order) if x == "tts"),
       "renderer ovoz tayyor bo'lgach yaratiladi (rasm/boshqa ishlar bilan parallel)")
    # animatsiya kadr tezligi fps ga bog'liq (harakat tezligi emas — u soniyalarda)
    ok(motion_cad(30, 2) == 1 and motion_cad(60, 2) == 1, "silliq rejim: har kadr (fps ga teng)")
    ok(motion_cad(30, 1) == 2 and motion_cad(60, 1) == 2 and motion_cad(25, 1) == 2, "oddiy rejim: fps/2 (har fps da bir xil nisbat)")
    ok(motion_cad(30, 0) == 0 and motion_cad(30, 0, True) == 2, "statik: yo'q; uzluksiz sahna: fps/2")
    ok(motion_cad(60, 1, False, 20) == 3 and motion_cad(30, 1, False, 30) == 1 and motion_cad(30, 2, False, 100) == 1,
       "VIDEO_ANIM_FPS qo'lda: kadr tezligi berilgan qiymatga yaqin (fps dan oshmaydi)")
    for f in (20, 25, 30, 60):
        cad = motion_cad(f, 1)
        ok(abs(f / cad - f / 2) < 0.51, f"{f} fps: animatsiya {f / cad:.1f} kadr/s")


# ============================================================================ 5) stream tizimi
def streamsys_tests(tmp: Path):
    section("V2-5) Stream tizimi: telemetriya, profillar, qo'shimcha manzillar, nazoratchi, rejalashtirish")
    from datetime import datetime, timedelta, timezone
    from .config import Config
    from .streamsys import (PROFILES, Planner, StreamSystem, Telemetry, Watchdog, apply_profile, build_output, mask_url,
                            parse_extra, sys_sample)
    os.environ["AITUBE_DATA"] = str(tmp / "v2data")
    cfg = Config(root=tmp, env_file=tmp / "v2s.env")
    # --- manzillar
    ex = parse_extra("rtmp://a.example/live/k1, rtmps://b.example/app/k2\nhttp://bad  rtmp://a.example/live/k1")
    ok(ex == ["rtmp://a.example/live/k1", "rtmps://b.example/app/k2"], f"qo'shimcha manzillar: yaroqlilari, takrorsiz ({ex})")
    ok(mask_url("rtmp://a.example/live/SECRETKEY") == "rtmp://a.example/live/SEC…", "manzil kaliti yashiriladi")
    single = build_output("rtmp://a/b/c")
    ok(single[-2:] == ["flv", "rtmp://a/b/c"] and "aac_adtstoasc" in single, "bitta manzil: oddiy flv")
    tee = build_output("rtmp://y/live2/key", ["rtmp://x/app/k"])
    ok(tee[tee.index("-f") + 1] == "tee" and "onfail=ignore" in tee[-1] and tee[-1].count("|") == 1
       and tee[-1].split("|")[0].find("onfail") < 0, "tee: asosiy manzil uzilsa to'xtaydi, qo'shimchasi 'onfail=ignore'")
    ok(build_output("x", [], "/tmp/f.ts")[-2:] == ["mpegts", "/tmp/f.ts"], "sinov fayli rejimi saqlangan")
    # tee haqiqatan ikkita nusxa yozadi (fayllarga)
    a, b = tmp / "tee_a.ts", tmp / "tee_b.ts"
    spec = f"[f=mpegts]{a}|[f=mpegts:onfail=ignore]{b}"
    rc = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=160x120:r=10:d=1", "-f", "lavfi",
                         "-i", "sine=d=1", "-map", "0:v", "-map", "1:a", "-c:v", "mpeg4", "-c:a", "aac", "-f", "tee", spec],
                        capture_output=True).returncode
    ok(rc == 0 and a.stat().st_size > 500 and b.stat().st_size > 500, "tee bir vaqtda ikki manzilga yozadi")
    # --- telemetriya: ffmpeg -progress bloklari
    tel = Telemetry()
    for ln in ("frame=120", "fps=30.0", "bitrate=4521.3kbits/s", "total_size=9876543", "out_time_us=4000000", "drop_frames=2",
               "dup_frames=0", "speed=1.01x", "progress=continue"):
        tel.feed_line(ln)
    ok(tel.push.get("kbps") == 4521.3 and tel.push["speed"] == 1.01 and tel.push["drop"] == 2 and tel.push["frame"] == 120
       and abs(tel.push["out_s"] - 4.0) < 1e-6, f"pusher ko'rsatkichlari o'qildi ({tel.push})")
    ok(tel.fresh() and tel.avg_kbps() > 4000, "uzatish bitrate o'rtachasi hisoblandi")
    for ln in ("bitrate=N/A", "speed=N/A", "progress=continue"):
        tel.feed_line(ln)
    ok(tel.push["speed"] is None and tel.push["kbps"] is None, "N/A qiymatlar xatosiz o'qiladi")
    for sp in (0.8, 0.8, 0.8):
        for ln in ("bitrate=1000kbits/s", f"speed={sp}x", "progress=continue"):
            tel.feed_line(ln)
    ok(tel.min_speed(60) is not None and tel.min_speed(60) <= 0.8, "eng past tezlik oynada topiladi")
    tel.event("w", "sinov")
    ok(tel.recent(1)[0][1:] == ("w", "sinov"), "hodisalar jurnali")
    s = sys_sample(tmp)
    ok("cpus" in s and s.get("disk_free", 1) > 0, f"tizim ko'rsatkichlari (CPU/disk/RAM): {sorted(s)}")
    # --- profillar
    ok(set(PROFILES) == {"tejamkor", "standart", "sifatli", "maksimal", "telefon"}, "5 ta tayyor profil (telefon profili bilan)")
    from .stream import valid_fps
    ok(all(valid_fps(p["STREAM_FPS"]) == int(p["STREAM_FPS"]) for p in PROFILES.values()), "profil FPS lari yaroqli (44100 ga bo'linadi)")
    ok(apply_profile(cfg, "sifatli") is None and cfg.int("STREAM_RES") == 1080 and cfg.get("STREAM_PROFILE") == "sifatli", "profil qo'llanadi")
    ok(apply_profile(cfg, "yoq") is not None, "noma'lum profil rad etiladi")
    ok(apply_profile(cfg, "custom") is None and cfg.get("STREAM_PROFILE") == "custom", "custom profil")
    # --- rejalashtirish
    tz = timezone(timedelta(hours=5))
    now = datetime(2026, 11, 3, 20, 0, tzinfo=tz)
    p = Planner.parse
    ok(p("21:30", now) == now.replace(hour=21, minute=30), "HH:MM: bugun")
    ok(p("19:00", now) == now.replace(hour=19, minute=0) + timedelta(days=1), "HH:MM o'tib ketgan (>10 daq): ertaga")
    ok(p("19:55", now) == now.replace(hour=19, minute=55), "HH:MM 10 daqiqa ichida o'tgan: hozir ishga tushadi")
    ok(p("2026-12-01 08:15", now) == now.replace(year=2026, month=12, day=1, hour=8, minute=15), "to'liq sana va vaqt")
    ok(p("99:99", now) is None and p("abc", now) is None and p("", now) is None, "noto'g'ri format None")

    # --- nazoratchi (soxta stream bilan)
    class FakeStream:
        def __init__(self):
            self.cfg, self.said = cfg, []
            self.state, self.job, self.ready = "live", {}, []
            self.params = {"kbps": 5000, "buffer": 3, "res": 720, "fps": 30, "step": 1}
            self.work = tmp
            self.restarts, self.speed, self.bench = 0, 0.0, 0.0
            self.lock = threading.RLock()

        def say(self, t, markup=None):
            self.said.append(t)

        def _has_work(self):
            return True

    fs = FakeStream()
    sm = StreamSystem(fs)
    wd = Watchdog(sm, period=0.01)
    for _ in range(8):
        for ln in ("bitrate=900kbits/s", "speed=0.7x", "progress=continue"):
            sm.tel.feed_line(ln)
        wd.check()
    ok(any("sekin" in t for t in fs.said), "nazoratchi: uzatish sekinligini xabar qildi")
    n = len(fs.said)
    for _ in range(5):
        wd.check()
    ok(len(fs.said) == n, "xabar takrorlanmaydi (cheklangan)")
    cfg.overrides["STREAM_STALL_SEC"] = "60"
    fs.job = {"frames_total": 1000, "frames": 10}
    wd.check()
    wd.prog = (10, time.time() - 400)
    wd.check()
    ok(any("qotib" in t for t in fs.said), "nazoratchi: qotib qolgan tayyorlovni topdi")
    cfg.overrides["STREAM_MIN_DISK_MB"] = "99999999"
    wd.check()
    ok(any("Diskda joy kam" in t for t in fs.said), "nazoratchi: kam disk haqida xabar")
    cfg.overrides.pop("STREAM_MIN_DISK_MB", None)
    fs.state = "draft"
    n = len(fs.said)
    wd.check()
    ok(len(fs.said) == n, "efir bo'lmasa nazoratchi jim")
    txt = sm.encoder_line()
    ok("Kodlash" in txt, "kodlash qatori: " + txt)
    sm.close()


# ============================================================================ 6) sozlamalar va AI rasm o'chirilganligi
def config_tests(tmp: Path):
    section("V2-6) Sozlamalar tekshiruvi, AI rasm o'chirilgan, ko'p foydalanuvchi rejimi yo'q")
    from .bot import validate_setting as v
    from .config import DEFAULTS, SAFE_KEYS
    ok(v("STREAM_BITRATE", "0") is None and v("STREAM_BITRATE", "200") is not None and v("STREAM_BITRATE", "9000") is None,
       "STREAM_BITRATE: 0 (avto) yoki 300..25000")
    ok(v("ENCODER", "nvenc") is None and v("ENCODER", "x") is not None, "ENCODER qiymatlari")
    ok(v("STREAM_PROFILE", "sifatli") is None and v("STREAM_PROFILE", "x") is not None, "STREAM_PROFILE qiymatlari")
    ok(v("STREAM_AT", "21:30") is None and v("STREAM_AT", "99:99") is not None and v("STREAM_AT", "") is None, "STREAM_AT formati")
    ok(v("STREAM_EXTRA_RTMP", "rtmp://a/b/c") is None and v("STREAM_EXTRA_RTMP", "http://x") is not None, "STREAM_EXTRA_RTMP")
    ok(v("STREAM_BG_FPS", "0") is None and v("STREAM_BG_FPS", "30") is None and v("STREAM_BG_FPS", "2") is not None, "STREAM_BG_FPS: 0=avto")
    ok(v("STREAM_CRF", "20") is None and v("STREAM_CRF", "5") is not None, "STREAM_CRF 10..36")
    ok(DEFAULTS["STREAM_AUTO"] == "0" and DEFAULTS["STREAM_BITRATE"] == "0" and DEFAULTS["STREAM_BG_FPS"] == "0" and DEFAULTS["ENCODER"] == "auto",
       "standartlar: sifat avtomatik tushirilmaydi, bitrate avto, animatsiya fps ga teng, GPU avto")
    ok(all(k in DEFAULTS for k in SAFE_KEYS), "SAFE_KEYS hammasi DEFAULTS da bor")
    ok("AI_IMAGES" not in SAFE_KEYS and DEFAULTS["AI_IMAGES"] == "0", "AI rasm sozlamasi menyuda yo'q, standart 0")
    for mod in ("accounts", "hub", "userbot", "botusers", "selftest_users"):
        ok(not (Path(__file__).parent / f"{mod}.py").exists(), f"ko'p foydalanuvchi moduli olib tashlangan: {mod}.py")
    from .config import Config
    c = Config(root=tmp, env_file=tmp / "x.env")
    ok(not hasattr(c, "parent"), "Config da 'parent' (ko'p foydalanuvchi) yo'q")
    src = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")
    ok("AccountStore" not in src and "UserHub" not in src and "Gate" not in src, "app.py da hisoblar/hub/gate yo'q")




# ============================================================================ 7) stream fayl bo'laklari (GPU / CPU zaxira)
def stream_chunk_gpu_tests(tmp: Path):
    section("V2-7) Stream fayl bo'laklari: GPU da kodlash va GPU yiqilsa CPU ga o'tish")
    from concurrent.futures import ThreadPoolExecutor
    from .app import App
    from .config import Config
    from .hwenc import HW
    os.environ["AITUBE_DATA"] = str(tmp / "v2data_s")
    cfg = Config(root=Path(__file__).resolve().parent.parent, env_file=tmp / "s.env")
    cfg.overrides.update({"STREAM_RES": "480", "STREAM_FPS": "15", "STREAM_PART_SEC": "5", "ENCODER": "auto"})
    app = App(cfg)
    src = tmp / "clip.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=320x240:r=15:d=11", "-f", "lavfi",
                    "-i", "sine=d=11", "-c:v", "libx264", "-c:a", "aac", "-shortest", str(src)], check=True)
    try:
        for mode, expect in (("ok", "nvenc"), ("probe_only", "cpu"), ("fail", "cpu")):
            with fake_gpu(tmp, mode) as log:
                stm = app.stream
                stm._reset_runtime()
                stm.params = stm._params()
                stm.work = tmp / f"swc_{mode}"
                stm.work.mkdir(parents=True, exist_ok=True)
                stm.ready_dir = stm.work / "ready"
                stm.ready_dir.mkdir()
                stm.pool = ThreadPoolExecutor(max_workers=4)
                stm.threads_each = 1
                stm.chunks = [{"item": {"id": "x1", "title": "Klip", "path": str(src)}, "i": 0, "n": 1, "len": 11.0, "ss": 0.0}]
                try:
                    tk = stm._make_chunk()
                finally:
                    stm.pool.shutdown(wait=True)
                ok(Path(tk["path"]).exists() and _codec_of(tk["path"]) == "h264", f"fayl bo'lagi ({mode}) yaratildi")
                ok(abs(tk["dur"] - 11.0) < 0.7, f"davomiylik mos ({tk['dur']:.2f}s)")
                txt = log.read_text() if log.exists() else ""
                if expect == "nvenc":
                    ok("NVENC" in txt and "-cq" in txt and "-crf" not in txt.split("NVENC")[-1],
                       "fayl bo'lagi qismlari NVENC (-cq) bilan kodlandi, x264 -crf yo'q")
                    ok(txt.count("NVENC ") >= 3, f"parallel qismlar GPU da ({txt.count('NVENC ')} ta jarayon)")
                elif mode == "probe_only":
                    ev = " ".join(e[2] for e in stm.sys.tel.recent(10))
                    ok("CPU da qayta" in ev, "GPU yiqildi -> butun bo'lak CPU da qayta kodlandi (telemetriyada qayd etilgan)")
                else:
                    ok("NVENC" not in txt, "GPU umuman yo'q: CPU ishlatildi")
                ok(not list(stm.work.glob("c*")), "vaqtinchalik qismlar tozalandi")
        # --- pusher chiqishi: bitta manzil / tee / sinov fayli
        a = tmp / "push_a.ts"
        cfg.overrides["STREAM_TEST"] = ""
        stm = app.stream
        stm.s["rtmp"], stm.s["key"] = "rtmp://x/live", "k"
        cfg.overrides["STREAM_EXTRA_RTMP"] = "rtmp://e1.example/app/k1"
        out = stm._out_target()
        ok(out[out.index("-f") + 1] == "tee" and "e1.example" in out[-1], "pusher: qo'shimcha manzil bo'lsa tee")
        cfg.overrides["STREAM_EXTRA_RTMP"] = ""
        out = stm._out_target()
        ok(out[-2:] == ["flv", "rtmp://x/live/k"], "pusher: qo'shimcha manzil yo'q bo'lsa oddiy flv")
        cfg.overrides["STREAM_TEST"] = str(a)
        ok(stm._out_target()[-2:] == ["mpegts", str(a)], "pusher: sinov fayli rejimi")
    finally:
        HW.cfg = None
        try:
            app.close()
        except Exception:  # noqa: BLE001
            pass


# ============================================================================ 8) telefon (Android MediaCodec / MediaTek Helio + Mali)
MC_SHIM = r"""#!@PY@
import os, sys, subprocess, time
REAL = @REAL@
MODE = os.environ.get("FAKE_MC_MODE", "ok")
a = sys.argv[1:]
if "-encoders" in a:
    out = subprocess.run([REAL] + a, capture_output=True, text=True).stdout
    sys.stdout.write(out.rstrip("\n") + "\n V....D h264_mediacodec     H.264 Android MediaCodec encoder (codec h264)\n")
    sys.exit(0)
if "h264_mediacodec" not in a:
    os.execv(REAL, [REAL] + a)
if MODE == "fail":
    sys.stderr.write("[h264_mediacodec @ 0x1] Failed to create MediaCodec encoder\n")
    sys.exit(1)
if MODE == "hang":
    time.sleep(60)
    sys.exit(1)
if MODE == "no_name" and "-codec_name" in a:
    sys.stderr.write("[h264_mediacodec @ 0x1] createCodecByName failed\n")
    sys.exit(1)
out, i = [], 0
while i < len(a):
    x = a[i]
    if x == "h264_mediacodec":
        out += ["libx264", "-preset", "ultrafast", "-crf", "28"]
    elif x in ("-ndk_codec", "-bitrate_mode", "-codec_name"):
        i += 1
    else:
        out.append(x)
    i += 1
if MODE == "bad_color":
    j = out.index("-frames:v")
    out[j:j] = ["-vf", "negate"]
sys.exit(subprocess.call([REAL] + out))
"""


@contextlib.contextmanager
def fake_mediacodec(td: Path, mode: str = "ok", device: dict | None = None):
    """Telefon (Termux) muhitini taqlid qiladi: ffmpeg ro'yxatida h264_mediacodec bor; mode: ok | no_name | bad_color | fail | hang."""
    from .hwenc import HW
    real = shutil.which("ffmpeg")
    d = td / f"mcshim_{mode}"
    d.mkdir(parents=True, exist_ok=True)
    p = d / "ffmpeg"
    p.write_text(MC_SHIM.replace("@PY@", sys.executable).replace("@REAL@", repr(real)), encoding="utf-8")
    p.chmod(0o755)
    old = {k: os.environ.get(k) for k in ("PATH", "FAKE_MC_MODE")}
    old_dev, old_to = HW._dev, HW.MC_TIMEOUT
    os.environ.update(PATH=f"{d}{os.pathsep}{old['PATH']}", FAKE_MC_MODE=mode)
    HW._dev = device if device is not None else {}
    HW.MC_TIMEOUT = 3 if mode == "hang" else 25
    HW.detect(force=True)
    try:
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        HW._dev, HW.MC_TIMEOUT = old_dev, old_to
        HW.detect(force=True)


def hw_mediacodec_tests(tmp: Path):
    section("V2-8) Telefon GPU (Android MediaCodec, MediaTek Helio G100 Ultra / Mali-G57): sinov, tekshiruv, zaxira")
    from .config import Config
    from .hwenc import HW, MC_BOOST, is_android
    cfg = Config(root=tmp, env_file=tmp / "mc.env")
    HW.bind(cfg)
    mtk = {"soc": "MT6835", "manu": "Mediatek", "platform": "mt6835", "hw": "mt6835", "model": "Redmi Note 15", "sdk": "35",
           "release": "15", "android": "1"}
    HW._dev = mtk
    ok(HW._mc_names() == ["c2.mtk.avc.encoder", "OMX.MTK.VIDEO.ENCODER.AVC"], "MediaTek: apparat kodlovchi nomlari (c2.mtk...)")
    HW._dev = {"soc": "SM8650", "manu": "Qualcomm", "platform": "pineapple"}
    ok(HW._mc_names()[0] == "c2.qti.avc.encoder", "Qualcomm: c2.qti.avc.encoder")
    HW._dev = {"platform": "exynos2400", "manu": "Samsung"}
    ok(HW._mc_names()[0] == "c2.exynos.h264.encoder", "Exynos: c2.exynos.h264.encoder")
    HW._dev = {}
    ok(HW._mc_names() == [], "chip noma'lum: nom berilmaydi (Android o'zi tanlaydi)")
    ok(MC_BOOST > 1 and is_android() in (True, False), "telefon avto-bitrate oshirilishi belgilangan")
    HW._dev = mtk
    st = HW._tiers("mediacodec", "stream", 30, 5500, 20, 1080)
    ok(len(st) == 8 and "-codec_name" in st[0] and st[0][st[0].index("-bitrate_mode") + 1] == "cbr", "stream: nomli CBR variant birinchi (8 variant)")
    ok(all("-crf" not in t and t[t.index("-pix_fmt") + 1] == "nv12" and t[t.index("-g") + 1] == "60" for t in st), "hamma variant nv12, kalit kadr 2 s, x264 `-crf` yo'q")
    ok(HW._tiers("mediacodec", "video", 30, 0, 23, 1080)[0][HW._tiers("mediacodec", "video", 30, 0, 23, 1080)[0].index("-bitrate_mode") + 1] == "vbr",
       "video: VBR")
    ok(HW._tiers("mediacodec", "stream", 30, 5500, 20, 1080)[-1] == ["-c:v", "h264_mediacodec", "-b:v", "5500k", "-pix_fmt", "nv12", "-g", "60"],
       "eng oddiy variant: faqat bitrate")
    with fake_mediacodec(tmp, "ok", mtk):
        r = HW._probe[("mediacodec", "stream")]
        ok(r["ok"] and r["tier"] == 0 and HW.pick() == "mediacodec", "telefon kodlovchisi ishlasa avto-tanlanadi (1-variant)")
        ok(1 <= HW.sessions("mediacodec") <= 6, f"sessiyalar o'lchandi ({HW.sessions('mediacodec')})")
        ok("📱" in HW.describe(html=False) and "Redmi Note 15" in HW.describe(html=False), "tavsifda telefon modeli va chipi")
        a = HW.venc("stream", 30, 5500, 20, "ultrafast", 1080)
        ok(a[a.index("-c:v") + 1] == "h264_mediacodec" and "-codec_name" in a, "venc: MediaCodec parametrlari")
    with fake_mediacodec(tmp, "no_name", mtk):
        r = HW._probe[("mediacodec", "stream")]
        ok(r["ok"] and r["tier"] == 4, f"chip nomi ochilmasa nomsiz variantga o'tadi (variant {r['tier']})")
    with fake_mediacodec(tmp, "bad_color", mtk):
        r = HW._probe[("mediacodec", "stream")]
        ok(not r["ok"] and "PSNR" in r["msg"] and HW.pick() == "cpu", f"buzuq chiqish PSNR bilan rad etildi -> CPU ({r['msg'][:50]})")
    with fake_mediacodec(tmp, "fail", mtk):
        ok(not HW._probe[("mediacodec", "stream")]["ok"] and HW.pick() == "cpu", "MediaCodec ochilmasa -> CPU")
    t0 = time.time()
    with fake_mediacodec(tmp, "hang", mtk):
        ok(HW._probe[("mediacodec", "stream")]["msg"].startswith("javob bermadi") and HW.pick() == "cpu" and time.time() - t0 < 30,
           "osilib qolsa tez to'xtatiladi (qolgan variantlar urinilmaydi) -> CPU")
        ok("Android 15" in HW.describe(html=False), "Android 15+ uchun tushuntirish ko'rsatiladi")
    HW._dev = None
    HW.cfg = None


# ============================================================================ 9) stream siyosati: cheksiz zaxira, taymautsiz ochilish, so'ralmaydi
def stream_policy_tests(tmp: Path):
    section("V2-9) Stream: zaxira CHEKSIZ, efir taymaut bilan ochilmaydi, «Efir tugasinmi?» so'ralmaydi")
    from .app import App
    from .config import DEFAULTS, Config
    from .hwenc import HW
    os.environ["AITUBE_DATA"] = str(tmp / "v2data_p")
    cfg = Config(root=Path(__file__).resolve().parent.parent, env_file=tmp / "p.env")
    app = App(cfg)
    try:
        stm = app.stream
        stm.work = tmp / "pw"
        stm.work.mkdir(parents=True, exist_ok=True)
        ok(DEFAULTS["STREAM_PREROLL_WAIT"] == "0" and DEFAULTS["STREAM_BUFFER_CAP"] == "0" and DEFAULTS["STREAM_ASK_END"] == "0",
           "standart: taymaut yo'q, zaxira cheksiz, so'ralmaydi")
        p = stm._params()
        ok(p["wait"] == 0.0 and p["cap"] == 0, "parametrlar: wait=0 (cheksiz kutish), cap=0 (cheksiz zaxira)")
        cfg.overrides["STREAM_PREROLL_WAIT"] = "20"
        ok(stm._params()["wait"] == 60.0, "taymaut berilsa kamida 60 soniya")
        cfg.overrides["STREAM_PREROLL_WAIT"] = "0"
        stm.ready = [{"dur": 600.0, "path": "x"} for _ in range(60)]          # 10 soat tayyor kontent
        cfg.overrides["STREAM_MIN_DISK_MB"] = "200"
        ok(stm._room() is True, "60 ta bo'lak (10 soat) zaxirada bo'lsa ham yangi bo'lak tayyorlanaveradi (cheklov yo'q)")
        cfg.overrides["STREAM_BUFFER"] = "15"                                       # eski .env qiymati endi chegara EMAS
        stm.params = stm._params()
        ok(stm._room() is True, "STREAM_BUFFER (eski 15) zaxirani chegaralamaydi")
        cfg.overrides["STREAM_BUFFER_CAP"] = "5"
        stm.params = stm._params()
        ok(stm._room() is False, "STREAM_BUFFER_CAP=5 qo'yilsa chegara ishlaydi")
        cfg.overrides["STREAM_BUFFER_CAP"] = "0"
        stm.params = stm._params()
        cfg.overrides["STREAM_MIN_DISK_MB"] = "99999999"                           # disk 'to'lgan' deb hisoblansin
        ok(stm._room() is False, "disk bo'sh joyi himoya chegarasidan kam: yangi bo'lak to'xtatiladi")
        stm.ready = []
        ok(stm._room() is True, "zaxira bo'sh bo'lsa disk himoyasidan qat'i nazar kamida bittasi tayyorlanadi")
        txt = stm.sys.panel_text()
        ok("cheksiz" in txt, "panelda zaxira 'cheksiz' deb ko'rsatiladi")
    finally:
        HW.cfg = None
        try:
            app.close()
        except Exception:  # noqa: BLE001
            pass


# ============================================================================ 10) 3D ikonkalar, kartalar, jonli fon, prompt, parallel video
def visual_tests(tmp: Path):
    section("V2-10) 3D ikonkalar, tushuntirish kartalari, jonli «olam» foni, o'qitish prompti")
    from PIL import ImageChops
    from . import icons3d as I
    from .anim import KIND_COL, infer_kind
    from .config import Config
    from .render import Renderer, scene_units
    from . import bgfx, teach, writer
    os.environ["AITUBE_DATA"] = str(tmp / "v2data_v")
    ks = I.kinds()
    ok(len(ks) >= 70, f"3D ikonkalar kutubxonasi katta ({len(ks)} ta)")
    bad = []
    for k in ks:
        try:
            im = I.I3.render(k, 96, KIND_COL.get(k, (110, 170, 255)), t=0.7, phase=0.3)
            if im.size != (96, 96) or im.getchannel("A").getbbox() is None:
                bad.append(k)
        except Exception as e:  # noqa: BLE001
            bad.append(f"{k}:{e}")
    ok(not bad, f"hamma ikonka xatosiz chiziladi {bad[:3]}")
    a = I.I3.render("cpu", 128, (255, 123, 190), t=0.2)
    b = I.I3.render("cpu", 128, (255, 123, 190), t=1.1)
    ok(ImageChops.difference(a.convert("RGB"), b.convert("RGB")).getbbox() is not None, "ikonka vaqt bo'yicha tebranadi va yaltiraydi (kadrlar farq qiladi)")
    sh = I.I3.sprite("server", 128, (63, 185, 80)).shadow
    ok(sh.getchannel("A").getbbox() is not None, "yumshoq soya bor")
    # barcha nomlar tanilishi: yangi aliaslar
    ok(infer_kind("videokarta", "") == "gpu" and infer_kind(None, "Operativ xotira") == "ram" and infer_kind("", "Ona plata") == "motherboard",
       "ikonka nomi/yorliqdan aniqlanadi (videokarta -> gpu, operativ xotira -> ram)")
    cfg = Config(root=tmp, env_file=tmp / "v.env")
    cfg.overrides.update({"VIDEO_RES": "480"})
    parts = {"type": "parts", "heading": "Qismlar", "items": [{"icon": "cpu", "name": "Protsessor", "role": "Hisoblaydi"},
                                                              {"icon": "gpu", "name": "Videokarta", "role": "Rasm chizadi"},
                                                              {"icon": "ram", "name": "Xotira", "role": "Tez xotira"}]}
    expl = {"type": "explain", "heading": "CPU", "term": "Protsessor", "icon": "cpu",
            "definition": "Protsessor — kompyuterning markaziy hisoblash qurilmasi.", "analogy": "Bosh oshpaz kabi.", "points": ["Tezlik muhim", "Yadrolar"]}
    ok(scene_units(parts) == 3 and scene_units(expl) == 4, f"birliklar: parts=3, explain=4 ({scene_units(parts)}, {scene_units(expl)})")
    for port in (False, True):
        c2 = Config(root=tmp, env_file=tmp / "v2.env")
        c2.overrides.update({"VIDEO_RES": "480", "VIDEO_FORMAT": "shorts" if port else "landscape"})
        r = Renderer(c2, accent_idx=1, episode_label="Q", channel="K", style="world", seed=2)
        for nm, sc, n in (("parts", parts, 3), ("explain", expl, 4)):
            try:
                img = r.frame(sc, n, 1.0, None, 0.5, t=2.0)
                ok(img.size == r.size if hasattr(r, "size") else True, f"{nm} ({'vertikal' if port else 'gorizontal'}) chizildi")
            except Exception as e:  # noqa: BLE001
                ok(False, f"{nm} chizilmadi: {e}")
    c3 = Config(root=tmp, env_file=tmp / "v3.env")
    c3.overrides.update({"VIDEO_RES": "480"})
    r = Renderer(c3, accent_idx=0, episode_label="Q", channel="K", style="world", seed=3)
    f1 = r.frame(expl, 4, 1.0, None, 0.2, t=1.0).convert("RGB")
    f2 = r.frame(expl, 4, 1.0, None, 0.2, t=5.0).convert("RGB")
    ok(ImageChops.difference(f1, f2).getbbox() is not None, "«olam» foni va 3D ikonkalar vaqt bo'yicha harakatlanadi (video kabi jonli)")
    ok("world" in bgfx.STYLES and sum(bgfx.style_for(n) == "world" for n in range(1, 31)) >= 18, "epizodlarning ko'pchiligi «olam» fonida")
    # prompt: o'qitish doktrinasi va sahna turlari
    ok("ZERO-TO-HERO" in teach.TEACH_RULES and "parts" in teach.SCENE_SPEC and "explain" in teach.SCENE_SPEC and "cpu" in teach.ICON_LIST,
       "AI prompti: 0 dan o'rgatish doktrinasi, yangi sahna turlari va ikonka lug'ati bor")
    sysm = writer.WRITE_SYSTEM.format(channel="X", niche="IT", lang_name="Uzbek", teach_rules=teach.TEACH_RULES)
    ok("GPU" in sysm and "SSD" in sysm and "mini-recap" in sysm, "prompt: kompyuter yig'ish (CPU, GPU, RAM, SSD) ni batafsil tushuntirish talabi")
    scs = writer.normalize_scenes([{"type": "parts", "heading": "Q", "items": [{"icon": "cpu", "name": "A", "role": "x"}, {"icon": "gpu", "name": "B", "role": "y"}], "narration": "matn " * 20},
                                   {"type": "explain", "heading": "E", "term": "RAM", "definition": "RAM — tezkor xotira, dasturlar shu yerda turadi.", "narration": "matn " * 20},
                                   {"type": "explain", "heading": "Yo'q", "definition": "qisqa", "narration": "x"}])
    ok([x["type"] for x in scs] == ["parts", "explain"], "writer: yaroqli parts/explain qabul qilinadi, yaroqsizi tashlanadi")


def video_parallel_tests(tmp: Path):
    section("V2-11) Video parallel qismlarda chiziladi (sessiyalar) va ketma-ket yo'l bilan bir xil natija beradi")
    from .compose import compose_scenes
    from .config import Config
    from .render import Renderer
    from .video import VideoBuilder
    os.environ["AITUBE_DATA"] = str(tmp / "v2data_pv")
    cfg = Config(root=Path(__file__).resolve().parent.parent, env_file=tmp / "pv.env")
    cfg.overrides.update({"VIDEO_RES": "480", "VIDEO_FPS": "15", "VIDEO_WAVE": "0", "MUSIC": "0", "VIDEO_PROCS": "2", "VIDEO_PART_SEC": "8"})
    sc = [{"type": "bullets", "heading": "A", "bullets": ["bir", "ikki", "uch"], "narration": "Bir ikki uch to'rt besh olti yetti sakkiz to'qqiz o'n. " * 20}]
    script = {"title": "S", "hook": "Salom, bu sinov matni.", "recap": "", "teaser": "Ko'rishamiz.", "scenes": sc}
    rargs = dict(accent_idx=0, episode_label="Q1", channel="S", style="aurora", seed=1)
    res = {}
    old_cpu = os.cpu_count
    called = {"par": 0}
    orig = VideoBuilder._render_parallel

    def spy(self, *a, **k):
        called["par"] += 1
        return orig(self, *a, **k)

    VideoBuilder._render_parallel = spy
    try:
        for mode in ("1", "0"):
            cfg.overrides["VIDEO_PARALLEL"] = mode
            os.cpu_count = lambda: 4              # ko'p yadroli qurilma
            scenes = compose_scenes(cfg, {"gno": 1, "season_id": 1}, script, None, None)
            vb = VideoBuilder(cfg, FakeTTS(0.25))
            out = tmp / f"pv_{mode}.mp4"
            r = vb.build(scenes, tmp / f"pvw_{mode}", out, lambda: Renderer(cfg, **rargs), None, rargs=rargs)
            res[mode] = (r, out)
    finally:
        VideoBuilder._render_parallel = orig
        os.cpu_count = old_cpu
    ok(called["par"] == 1, "VIDEO_PARALLEL=1: parallel yo'l ishlatildi; =0: ketma-ket yo'l")
    (r1, o1), (r0, o0) = res["1"], res["0"]
    ok(r1["frames"] == r0["frames"] and abs(r1["duration"] - r0["duration"]) < 0.01, f"kadrlar soni va davomiylik bir xil ({r1['frames']})")
    def nb(path):
        return subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=nb_frames", "-of", "csv=p=0", str(path)],
                              capture_output=True, text=True).stdout.strip()
    ok(nb(o1) == nb(o0) == str(r1["frames"]), f"ffprobe: haqiqiy kadrlar soni mos ({nb(o1)})")
    ok(_codec_of(o1) == "h264", "parallel natija h264")


# ============================================================================ kirish nuqtasi
def run_all():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        for fn, args in ((hw_args_tests, ()), (llm_rotation_tests, ()), (config_tests, (tmp,)), (streamsys_tests, (tmp,)),
                         (tts_and_anim_tests, (tmp,)), (hw_shim_tests, (tmp,)), (hw_mediacodec_tests, (tmp,)),
                         (stream_chunk_gpu_tests, (tmp,)), (stream_policy_tests, (tmp,)),
                         (visual_tests, (tmp,)), (video_parallel_tests, (tmp,))):
            try:
                fn(*args)
            except Exception:  # noqa: BLE001
                import traceback
                traceback.print_exc()
                ok(False, f"{fn.__name__} kutilmagan istisno bilan to'xtadi")


if __name__ == "__main__":
    run_all()
