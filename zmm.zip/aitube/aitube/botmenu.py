"""Ixcham ko'p bosqichli inline menyu: asosiy menyu 8 ta bo'lim, har bo'lim o'z tugmalari bilan.
Hamma buyruq (/slash) avvalgidek ishlaydi; tugmalar shularni chaqiradi. Tez sozlamalar `q:KEY:VAL` orqali."""
from __future__ import annotations

from .config import SAFE_KEYS
from .scheduler import next_slot
from .util import esc
import time

# (bo'lim -> (sarlavha, [[(matn, callback), ...], ...]))
SECTIONS = {
    "prod": ("🎬 <b>Ishlab chiqarish</b>\nVideo yasash, yuklash va xatolikdan tiklash.", [
        [("🎬 Keyingisini yasash", "m:make"), ("⬆️ Yuklash", "m:upload")],
        [("⏰ Rejalashtirilgan chiqarish", "m:schedule")],
        [("🔁 Qayta urinish", "m:retry"), ("🎞 Videolar", "m:videos")],
        [("⏸ To'xtatish", "m:pause"), ("▶️ Davom ettirish", "m:resume")],
    ]),
    "plan": ("🗓 <b>Reja va mazmun</b>\nNavbat, fasllar va epizodlar.", [
        [("📋 Navbat", "m:queue"), ("🗓 Reja", "m:plan"), ("📺 Epizodlar", "m:episodes")],
        [("🗂 Fasllar", "m:seasons"), ("🆕 Yangi fasl", "m:newseason")],
        [("⏰ Rejalashtirilgan", "m:schedule"), ("🕒 Vaqtlar", "m:times")],
        [("🗑 Unutish", "m:forget")],
    ]),
    "vid": ("🎞 <b>Videolar va fayllar</b>\nBoshqarish, qayta yaratilganlar va tozalash.", [
        [("🎞 Videolar", "m:videos"), ("📁 Qayta yaratilgan", "m:regen")],
        [("🧹 Tozalash", "m:clean"), ("♻️ Avto-tozalash", "m:autoclean")],
        [("💾 Zaxira (baza)", "m:backup"), ("📚 Pleylist", "m:playlist")],
    ]),
    "ai": ("🤖 <b>AI, ovoz va talaffuz</b>\nModellar, kalitlar, diktor ovozi va ingliz so'zlar aytilishi.", [
        [("🤖 Modellar", "m:models"), ("🔑 Kalitlar", "m:keys")],
        [("🧪 AI sinov", "m:llm"), ("🔐 Kalit sinov", "m:testkeys")],
        [("🎙 Ovoz", "m:voice"), ("🔊 Ovoz sinov", "m:tts")],
        [("🔤 So'zlar lug'ati", "m:sozlar"), ("🔤 Talaffuz (/pron)", "m:pron")],
    ]),
    "sec": ("🛡 <b>Himoya</b>\nBegona foydalanuvchilar avtomatik bloklanadi.", [
        [("🛡 Himoya holati", "m:security"), ("⛔ Bloklanganlar", "m:blocked")],
    ]),
    "sys": ("🧰 <b>Tizim</b>\nTekshiruv, hisobot va ulanishlar.", [
        [("🩺 Salomatlik", "m:health"), ("📜 Loglar", "m:logs")],
        [("📈 Statistika", "m:stats"), ("💬 Izohlar", "m:comments")],
        [("🔐 YouTube ulash", "m:auth"), ("♻️ Qayta ishga tushirish", "m:restart")],
    ]),
}

BACK = [("⬅️ Menyu", "mn:main")]


def _onoff(cfg, key):
    return "✅" if cfg.bool(key) else "⬜"


class MenuMixin:
    # ------------------------------------------------------------------ asosiy va bo'limlar
    def main_text(self):
        a = self.app
        cfg, db = a.cfg, a.db
        c = db.counts()
        nxt = next_slot(cfg)
        state = "⏸ to'xtatilgan" if cfg.bool("PAUSED") else "▶️ faol"
        halt = db.kv_get("halt_reason")
        lines = [f"🤖 <b>{esc(cfg.get('CHANNEL_NAME'))}</b> — boshqaruv",
                 f"{state} · 🔄 {esc(a.jobs.describe())}"]
        if halt:
            lines.append(f"⛔ {esc(halt)}")
        lines.append(f"🎬 yuklangan {c.get('uploaded', 0)} · tayyor {c.get('ready', 0)} · rejada {c.get('planned', 0)}"
                     + (f" · ❌ {c['failed']}" if c.get("failed") else ""))
        lines.append(f"⏭ keyingi yuklash: {nxt.strftime('%m-%d %H:%M') if nxt else '-'} · "
                     f"🎞 {cfg.get('VIDEO_RES')}p/{cfg.get('VIDEO_FPS')}fps")
        return "\n".join(lines)

    def main_rows(self):
        return [
            [("📊 Holat", "m:status"), ("🎬 Ishlab chiqarish", "mn:prod")],
            [("🗓 Reja", "mn:plan"), ("🎞 Videolar", "mn:vid")],
            [("🤖 AI va ovoz", "mn:ai"), ("⚙️ Sozlamalar", "mn:set")],
            [("🛡 Himoya", "mn:sec"), ("🧰 Tizim", "mn:sys")],
            [("📡 Jonli translatsiya", "m:stream"), ("📤 Post joylash", "m:post")],
            [("👥 Foydalanuvchilar", "m:users")],
        ]

    def mn_callback(self, val, chat):
        sec = val.split(":")[0]
        if sec == "main":
            return self._screen(chat, self.main_text(), self.main_rows())
        if sec == "set":
            return self.settings_screen(chat)
        if sec in SECTIONS:
            title, rows = SECTIONS[sec]
            return self._screen(chat, title, [list(r) for r in rows] + [BACK])
        return self._screen(chat, self.main_text(), self.main_rows())

    # ------------------------------------------------------------------ tez sozlamalar
    def settings_screen(self, chat):
        cfg = self.app.cfg

        def mark(key, val):
            return "●" if cfg.get(key).strip().lower() == val else "○"

        lines = [
            "⚙️ <b>Sozlamalar</b> (bosib o'zgartiring)",
            f"🖥 Sifat: <b>{cfg.get('VIDEO_RES')}p</b> · 🎞 <b>{cfg.get('VIDEO_FPS')} fps</b> · "
            f"📐 {esc(cfg.get('VIDEO_FORMAT'))}",
            f"⬆️ Avto-yuklash {_onoff(cfg, 'AUTO_UPLOAD')} · 👍 Tasdiq rejimi {_onoff(cfg, 'APPROVAL_MODE')} · "
            f"🎼 Musiqa {_onoff(cfg, 'MUSIC')} · 🌊 To'lqin {_onoff(cfg, 'VIDEO_WAVE')}",
            f"🕒 Yuklash vaqti: {esc(cfg.get('UPLOAD_TIMES'))} · 🔒 {esc(cfg.get('YT_PRIVACY'))}",
            "\nBoshqa kalitlar: /config va /set KEY VALUE",
        ]

        def tog(label, key):
            nv = "0" if cfg.bool(key) else "1"
            return (f"{_onoff(cfg, key)} {label}", f"q:{key}:{nv}")

        rows = [
            [(f"{mark('VIDEO_RES', '1080')} 1080p", "q:VIDEO_RES:1080"), (f"{mark('VIDEO_RES', '720')} 720p", "q:VIDEO_RES:720"),
             (f"{mark('VIDEO_FPS', '30')} 30fps", "q:VIDEO_FPS:30"), (f"{mark('VIDEO_FPS', '25')} 25fps", "q:VIDEO_FPS:25")],
            [(f"{mark('VIDEO_FORMAT', 'landscape')} Keng", "q:VIDEO_FORMAT:landscape"),
             (f"{mark('VIDEO_FORMAT', 'shorts')} Shorts", "q:VIDEO_FORMAT:shorts")],
            [tog("Avto-yuklash", "AUTO_UPLOAD"), tog("Tasdiq rejimi", "APPROVAL_MODE")],
            [tog("Musiqa", "MUSIC"), tog("Ovoz to'lqini", "VIDEO_WAVE")],
            [("🔒 public", "q:YT_PRIVACY:public"), ("🔒 unlisted", "q:YT_PRIVACY:unlisted"), ("🔒 private", "q:YT_PRIVACY:private")],
            [("📃 Hamma sozlamalar", "m:config")],
            BACK,
        ]
        return self._screen(chat, "\n".join(lines), rows)

    def q_callback(self, val, chat):
        key, _, v = val.partition(":")
        out = self.c_set(f"{key} {v}", chat)
        if out and not out.startswith("✅"):
            self.tg.send(out, chat=chat)
        return self.settings_screen(chat)
