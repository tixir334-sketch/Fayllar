"""Rejalashtirilgan chiqarishni boshqarish: ro'yxat, vaqtni o'zgartirish, almashtirish, surish,
hozir chiqarish, bekor qilish. Hammasi tugmalar (`sc:`) yoki buyruqlar orqali."""
from __future__ import annotations

from datetime import timedelta

from . import schedule as sc
from .util import clip, esc

HELP_SC = (
    "<b>Rejalashtirish buyruqlari</b>\n"
    "/schedule - ro'yxat va tugmalar\n"
    "/reschedule 5 18:30 - vaqt (18:30 · ertaga 12:00 · 2026-10-20 18:30 · +2h · +1d)\n"
    "/publish 5 - hoziroq ochiq qilish\n"
    "/unschedule 5 - rejani bekor qilish\n"
    "/swap 5 6 - ikki videoning vaqtini almashtirish\n"
    "/shift +1d - hamma rejalashtirilganlarni surish\n"
    "/reslot - hammasini eng yaqin bo'sh vaqtlarga tartiblash"
)


class SchedMixin:
    # ------------------------------------------------------------------ ro'yxat
    def c_schedule(self, arg, chat):
        a = self.app
        cfg, db = a.cfg, a.db
        if arg.strip().lower() in ("help", "yordam"):
            return HELP_SC
        items = db.scheduled()
        manual = [e for e in db.uploaded(200) if e.get("pub_state") == "manual"]
        planned = db.with_planned_time()
        ready = [e for e in a.pipeline.ready_episodes() if e.get("pub_state") != "planned"]
        mode = sc.active(cfg)
        lines = [f"⏰ <b>Rejalashtirilgan chiqarish</b> · {'✅ yoqiq' if mode else '⬜ o`chiq'}",
                 f"Vaqtlar: <code>{esc(cfg.get('UPLOAD_TIMES'))}</code> (UTC+{esc(cfg.get('TZ_OFFSET'))}) · "
                 f"oldindan: {len(items)}/{cfg.int('SCHEDULE_AHEAD')}"]
        if cfg.bool("YT_SCHEDULE") and cfg.get("YT_PRIVACY") != "public":
            lines.append("⚠️ Rejalashtirish faqat YT_PRIVACY=public bilan ishlaydi.")
        kb = []
        if items:
            lines += ["", "<b>YouTube'da kutayotganlar</b>"]
            for e in items:
                lines.append(sc.summary_line(cfg, e))
                kb.append([(f"⏰ #{e['gno']} {clip(e['title'], 22)} · {sc.fmt_local(cfg, e['publish_at'])}",
                            f"sc:ep:{e['gno']}")])
        if planned:
            lines += ["", "<b>Yuklanmagan, vaqti belgilangan</b>"]
            for e in planned:
                lines.append(sc.summary_line(cfg, e))
                kb.append([(f"📌 #{e['gno']} {clip(e['title'], 24)}", f"sc:ep:{e['gno']}")])
        if ready:
            proj = sc.slots_from(cfg, sc.now_utc() + sc.LEAD, len(items) + len(ready))[len(items):]
            lines += ["", "<b>Tayyor, yuklanmagan</b> (taxminiy vaqt)"]
            for e, d in zip(ready, proj):
                lines.append(f"🟢 #{e['gno']} {esc(clip(e['title'], 34))} · {sc.fmt_local(cfg, d)}")
                kb.append([(f"🟢 #{e['gno']} {clip(e['title'], 24)}", f"sc:ep:{e['gno']}")])
        if manual:
            lines += ["", "<b>Yopiq (vaqtsiz)</b>"]
            for e in manual:
                lines.append(sc.summary_line(cfg, e))
                kb.append([(f"🔒 #{e['gno']} {clip(e['title'], 24)}", f"sc:ep:{e['gno']}")])
        if not (items or planned or ready or manual):
            lines += ["", "Hozircha rejalashtirilgan video yo'q. Video tayyor bo'lishi bilan avtomatik qo'yiladi."]
        kb.append([("🔄 Yangilash", "sc:list"), (f"Rejim: {'✅' if mode else '⬜'}", "sc:mode")])
        kb.append([("➖ Oldindan", "sc:ahead:-1"), (f"{cfg.int('SCHEDULE_AHEAD')} ta", "sc:list"), ("➕ Oldindan", "sc:ahead:1")])
        kb.append([("↕️ Tartiblash", "sc:reslot"), ("⏩ +1 kun", "sc:shift:1d"), ("⏪ -1 kun", "sc:shift:-1d")])
        kb.append([("🕒 Vaqtlar", "m:times"), ("⬆️ Hozir yuklash", "m:upload"), ("⬅️ Menyu", "mn:main")])
        self._screen(chat, "\n".join(lines), kb)

    # ------------------------------------------------------------------ bitta video
    def _sc_ep(self, gno, chat):
        a = self.app
        cfg = a.cfg
        e = a.db.ep_by_gno(gno)
        if not e:
            return self.c_schedule("", chat)
        st = e.get("pub_state")
        d = sc.from_iso(e.get("publish_at"))
        lines = [f"🎬 <b>#{gno} {esc(clip(e['title'], 80))}</b>"]
        kb = []
        if e["status"] == "uploaded":
            if st == "scheduled" and d:
                lines += [f"⏰ Chiqish: <b>{sc.fmt_local(cfg, d)}</b> · {sc.eta(d)}", f"🔗 {e['yt_url']} (hozircha yopiq)"]
                kb.append([("⏰ Vaqtni o'zgartirish", f"sc:ask:{gno}"), ("⏩ Hozir ochish", f"sc:now:{gno}")])
                kb.append([("⬆️ Oldinga", f"sc:up:{gno}"), ("⬇️ Orqaga", f"sc:down:{gno}")])
                kb.append([("+1 soat", f"sc:add:{gno}:1h"), ("+1 kun", f"sc:add:{gno}:1d"),
                           ("-1 kun", f"sc:add:{gno}:-1d")])
                kb.append([("⛔ Rejani bekor qilish", f"sc:cancel:{gno}")])
            elif st == "manual":
                lines += ["🔒 Yopiq, vaqtsiz.", f"🔗 {e['yt_url']}"]
                kb.append([("⏰ Bo'sh vaqtga qo'yish", f"sc:auto:{gno}"), ("⏩ Hozir ochish", f"sc:now:{gno}")])
                kb.append([("📅 Vaqt belgilash", f"sc:ask:{gno}")])
            else:
                lines += ["✅ Video ochiq.", f"🔗 {e['yt_url']}"]
        elif e["status"] == "ready":
            if st == "planned" and d:
                lines.append(f"📌 Belgilangan chiqish: <b>{sc.fmt_local(cfg, d)}</b> ({sc.eta(d)})")
                kb.append([("📅 O'zgartirish", f"sc:ask:{gno}"), ("🧽 Belgini olib tashlash", f"sc:cancel:{gno}")])
            else:
                lines.append("🟢 Tayyor. Vaqt avtomatik tanlanadi.")
                kb.append([("📅 Vaqt belgilash", f"sc:ask:{gno}")])
            kb.append([("⬆️ Hozir yuklash", f"vd:up:{gno}")])
        else:
            lines.append(f"Holat: {esc(e['status'])}")
            kb.append([("📅 Chiqish vaqtini oldindan belgilash", f"sc:ask:{gno}")])
        kb.append([("🎞 Video sahifasi", f"vd:ep:{gno}:0"), ("⬅️ Reja", "sc:list")])
        self._screen(chat, "\n".join(lines), kb)

    # ------------------------------------------------------------------ amallar
    def _sc_run(self, name, fn, chat, after=None):
        a = self.app

        def job():
            try:
                ok, msg = fn()
            except Exception as ex:  # noqa: BLE001
                ok, msg = False, f"{type(ex).__name__}: {ex}"
            self.tg.send(("✅ " if ok else "⚠️ ") + esc(msg), chat=chat)
            if after:
                after()
        if not a.jobs.submit_light(name, job):
            self.tg.send("ℹ️ Shu amal hozir bajarilmoqda.", chat=chat)

    def _need_yt(self, e, chat):
        if e["status"] == "uploaded" and not self.app.yt.authorized():
            self.tg.send("🔑 YouTube ulanmagan: /auth", chat=chat)
            return False
        return True

    def sc_callback(self, val, chat):
        a = self.app
        p = val.split(":")
        act = p[0]
        g = int(p[1]) if len(p) > 1 and p[1].lstrip("-").isdigit() else None
        e = a.db.ep_by_gno(g) if g is not None and act not in ("ahead", "shift") else None
        self.pending = None
        if act == "list":
            return self.c_schedule("", chat)
        if act == "mode":
            a.cfg.set("YT_SCHEDULE", "0" if a.cfg.bool("YT_SCHEDULE") else "1")
            return self.c_schedule("", chat)
        if act == "ahead":
            n = max(1, min(14, a.cfg.int("SCHEDULE_AHEAD") + int(p[1])))
            a.cfg.set("SCHEDULE_AHEAD", str(n))
            return self.c_schedule("", chat)
        if act == "reslot":
            return self._sc_run("sc-reslot", lambda: self._fmt_multi(sc.reslot(a)), chat,
                                lambda: self.c_schedule("", chat))
        if act == "shift":
            delta = self._delta(p[1])
            return self._sc_run("sc-shift", lambda: self._fmt_multi(sc.shift_all(a, delta)), chat,
                                lambda: self.c_schedule("", chat))
        if act == "ep":
            return self._sc_ep(g, chat)
        if not e:
            return self.tg.send("ℹ️ Epizod topilmadi.", chat=chat)
        if act == "ask":
            cur = sc.fmt_local(a.cfg, e.get("publish_at")) if e.get("publish_at") else "yo'q"
            self.pending = ("resched", g)
            return self._screen(chat, f"⏰ <b>#{g}</b> uchun yangi chiqish vaqtini yozing\n"
                                      f"Hozirgi: {cur}\n\nMasalan: <code>18:30</code> · <code>ertaga 12:00</code> · "
                                      f"<code>2026-10-20 18:30</code> · <code>+2h</code> · <code>+1d</code>",
                                [[("✖️ Bekor qilish", f"sc:ep:{g}")]])
        if not self._need_yt(e, chat):
            return None
        after = lambda: self._sc_ep(g, chat)  # noqa: E731
        if act == "now":
            return self._sc_run(f"sc-now-{g}", lambda: sc.publish_now(a, a.db.ep_by_gno(g)), chat, after)
        if act == "cancel":
            return self._sc_run(f"sc-cancel-{g}", lambda: sc.unschedule(a, a.db.ep_by_gno(g)), chat, after)
        if act == "auto":
            return self._sc_run(f"sc-auto-{g}", lambda: sc.schedule_manual(a, a.db.ep_by_gno(g)), chat, after)
        if act == "add":
            delta = self._delta(p[2])

            def f():
                ee = a.db.ep_by_gno(g)
                base = sc.from_iso(ee.get("publish_at")) or sc.now_utc()
                return sc.set_time(a, ee, base + delta)
            return self._sc_run(f"sc-add-{g}", f, chat, after)
        if act in ("up", "down"):
            return self._sc_run(f"sc-mv-{g}", lambda: sc.move_step(a, a.db.ep_by_gno(g), -1 if act == "up" else 1),
                                chat, after)
        return None

    @staticmethod
    def _delta(s):
        s = s.strip().lower()
        sign = -1 if s.startswith("-") else 1
        s = s.lstrip("+-")
        try:
            n = int(s[:-1])
        except ValueError:
            return timedelta(0)
        u = s[-1:]
        return sign * (timedelta(minutes=n) if u == "m" else timedelta(hours=n) if u == "h" else timedelta(days=n))

    @staticmethod
    def _fmt_multi(res):
        done, fail = res
        msg = f"{done} ta video yangilandi"
        if fail:
            msg += "\n" + "\n".join(fail[:6])
        return (not fail or done > 0), msg

    # ------------------------------------------------------------------ matn kiritish
    def sc_pending(self, gno, text, chat):
        a = self.app
        e = a.db.ep_by_gno(gno)
        if not e:
            self.tg.send("ℹ️ Epizod topilmadi.", chat=chat)
            return
        base = sc.from_iso(e.get("publish_at"))
        dt, err = sc.parse_when(a.cfg, text, base)
        if err:
            self.pending = ("resched", gno)
            self.tg.send(f"⚠️ {esc(err)}\nQayta yozing yoki /schedule.", chat=chat)
            return
        self._sc_run(f"sc-set-{gno}", lambda: sc.set_time(a, a.db.ep_by_gno(gno), dt), chat,
                     lambda: self._sc_ep(gno, chat))

    # ------------------------------------------------------------------ buyruqlar
    def _gno_arg(self, s):
        s = s.strip().lstrip("#")
        return int(s) if s.isdigit() else None

    def c_reschedule(self, arg, chat):
        parts = arg.split(None, 1)
        g = self._gno_arg(parts[0]) if parts else None
        if g is None or len(parts) < 2:
            return "Foydalanish: /reschedule 5 18:30 (yoki ertaga 12:00 · 2026-10-20 18:30 · +2h · +1d)"
        if not self.app.db.ep_by_gno(g):
            return "Bunday epizod yo'q."
        self.sc_pending(g, parts[1], chat)
        return None

    def c_publish(self, arg, chat):
        g = self._gno_arg(arg)
        e = self.app.db.ep_by_gno(g) if g is not None else None
        if not e:
            return "Foydalanish: /publish 5 - rejalashtirilgan videoni hozir ochiq qiladi"
        self._sc_run(f"sc-now-{g}", lambda: sc.publish_now(self.app, self.app.db.ep_by_gno(g)), chat)
        return None

    def c_unschedule(self, arg, chat):
        g = self._gno_arg(arg)
        e = self.app.db.ep_by_gno(g) if g is not None else None
        if not e:
            return "Foydalanish: /unschedule 5 - rejani bekor qiladi (video yopiq qoladi)"
        self._sc_run(f"sc-cancel-{g}", lambda: sc.unschedule(self.app, self.app.db.ep_by_gno(g)), chat)
        return None

    def c_swap(self, arg, chat):
        p = arg.split()
        if len(p) != 2 or not all(x.lstrip("#").isdigit() for x in p):
            return "Foydalanish: /swap 5 6"
        a = self.app
        e1, e2 = a.db.ep_by_gno(int(p[0].lstrip("#"))), a.db.ep_by_gno(int(p[1].lstrip("#")))
        if not e1 or not e2:
            return "Epizod topilmadi."
        self._sc_run("sc-swap", lambda: sc.swap(a, e1, e2), chat)
        return None

    def c_shift(self, arg, chat):
        d = self._delta(arg) if arg.strip() else timedelta(0)
        if not d:
            return "Foydalanish: /shift +1d (yoki -2h, +30m) - hamma rejalashtirilganlar siljiydi"
        self._sc_run("sc-shift", lambda: self._fmt_multi(sc.shift_all(self.app, d)), chat)
        return None

    def c_reslot(self, arg, chat):
        self._sc_run("sc-reslot", lambda: self._fmt_multi(sc.reslot(self.app)), chat)
        return None
