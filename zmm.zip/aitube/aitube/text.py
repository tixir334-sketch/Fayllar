"""Til matnlari va matn tozalash funksiyalari."""
from __future__ import annotations

import re

L = {
    "uz": {
        "lang_name": "o'zbek tili (lotin yozuvida)",
        "part": "Qism",
        "recap_label": "Oldingi qismda",
        "next_label": "Keyingi qism",
        "cta": ("Video yoqqan bo'lsa, like bosing va kanalga obuna bo'ling, "
                "keyingi qismni o'tkazib yubormaysiz. Keyingi qismda ko'rishamiz!"),
        "cta_short": "Obuna bo'ling",
        "ai_note": "Bu video sun'iy intellekt yordamida yaratilgan (ssenariy, ovoz va montaj).",
        "prev_link": "Oldingi qism",
        "next_link": "Keyingi qism",
        "chapters": "Bo'limlar",
        "intro_chapter": "Kirish",
        "outro_chapter": "Keyingi qism haqida",
        "recap_chapter": "Oldingi qism xulosasi",
        "season": "Fasl",
        "watch_next": "Keyingi qismni ko'ring",
    },
    "en": {
        "lang_name": "English",
        "part": "Part",
        "recap_label": "Previously",
        "next_label": "Next part",
        "cta": ("If you liked this video, hit like and subscribe so you don't miss the next part. "
                "See you in the next one!"),
        "cta_short": "Subscribe",
        "ai_note": "This video was created with AI assistance (script, voice and editing).",
        "prev_link": "Previous part",
        "next_link": "Next part",
        "chapters": "Chapters",
        "intro_chapter": "Intro",
        "outro_chapter": "What's next",
        "recap_chapter": "Previously",
        "season": "Season",
        "watch_next": "Watch the next part",
    },
}


def tr(lang: str) -> dict:
    return L.get((lang or "uz").lower()[:2], L["uz"])


_URL = re.compile(r"https?://\S+")
_MD = re.compile(r"[*_#>`~|]+")
_EMOJI = re.compile("[\U00010000-\U0010ffff☀-➿️‍]")
_WS = re.compile(r"\s+")


def clean_narration(t: str) -> str:
    """Ovozlashtirish uchun matnni tozalaydi (markdown, emoji, havola)."""
    t = str(t or "")
    t = _URL.sub("", t)
    t = _EMOJI.sub("", t)
    t = t.replace("->", " dan ").replace("=>", " ").replace("&", " va ")
    t = _MD.sub("", t)
    t = t.replace("’", "'").replace("‘", "'").replace("ʼ", "'")
    t = _WS.sub(" ", t).strip()
    if t and t[-1] not in ".!?…":
        t += "."
    return t


def clean_line(t: str, limit: int = 0) -> str:
    t = _EMOJI.sub("", str(t or ""))
    t = _MD.sub("", t) if "`" in t or "*" in t else t
    t = _WS.sub(" ", t).strip()
    if limit and len(t) > limit:
        t = t[: limit - 1].rstrip() + "…"
    return t


def split_sentences(text: str) -> list:
    parts = re.split(r"(?<=[.!?…])\s+", text.strip())
    return [p.strip() for p in parts if p.strip()]


def split_captions(text: str, max_chars: int) -> list:
    """Ovozli matnni ekrandagi subtitr bo'laklariga ajratadi."""
    out = []
    for s in split_sentences(text):
        if len(s) <= max_chars:
            out.append(s)
            continue
        # vergul bo'yicha, keyin so'zlar bo'yicha bo'lish
        pieces = re.split(r"(?<=[,;:])\s+", s)
        cur = ""
        for p in pieces:
            for w in p.split(" "):
                if not cur:
                    cur = w
                elif len(cur) + 1 + len(w) <= max_chars:
                    cur += " " + w
                else:
                    out.append(cur)
                    cur = w
            if cur and len(cur) > max_chars * 0.6 and p.endswith((",", ";", ":")):
                out.append(cur)
                cur = ""
        if cur:
            out.append(cur)
    return [o for o in out if o.strip()] or [text.strip()]


def tts_prepare(text: str) -> str:
    """TTS yaxshi o'qishi uchun tozalash va talaffuz filtri (.pdf -> "pi di ef" va h.k.)."""
    from .speak import speak_text
    t = speak_text(clean_narration(text))
    t = t.replace("…", "...")
    t = re.sub(r"\s*[\(\)\[\]{}]\s*", ", ", t)
    t = re.sub(r"\s*[/\\]\s*", " ", t)
    t = re.sub(r",\s*,", ",", t)
    t = re.sub(r"\s+", " ", t).strip(" ,")
    if t and t[-1] not in ".!?":
        t += "."
    return t
