"""Lug'at boshqaruvi (tugmalar): qidirish (ingliz/o'zbek), qo'lda qo'shish, txt yuklash/eksport, tahrirlash, o'chirish."""
from __future__ import annotations

import tempfile
from pathlib import Path

from . import lexicon as lx
from . import pronounce, speak
from .util import clip, esc

PAGE = 8
SRC_ICON = {"user": "👤", "auto": "🤖", "base": "📘"}


class DictMixin:
    # ------------------------------------------------------------------ asosiy ekran
    def c_sozlar(self, arg, chat):
        """/sozlar [so'z] - menyu yoki tezkor qidiruv."""
        arg = arg.strip()
        if arg:
            return self._dc_results(arg, 0, chat)
        self._dc_main(chat)

    def _dc_main(self, chat):
        a = self.app
        st = lx.stats(a.db)
        text = ("🔤 <b>So'zlar lug'ati</b> (ingliz so'zlarning o'zbekcha aytilishi)\n"
                f"📘 O'rnatilgan: {st['base']} · 🤖 AI aniqlagan: {st['auto']} · 👤 Sizniki: {st['user']}\n\n"
                "• 🔍 Qidirish: ingliz so'z (<code>shape</code>) yoki aytilish (<code>sheyp</code>) bo'yicha\n"
                "• ➕ Qo'shish: <code>shape = sheyp</code> (bir nechta qatorni birdan ham yuborish mumkin)\n"
                "• 📥 TXT: faylni shu chatga yuboring (har qatorda <code>so'z = aytilish</code>)\n"
                "Sizniki hamma narsadan ustun turadi.")
        rows = [
            [("🔍 Qidirish", "dc:search"), ("➕ Qo'shish", "dc:add")],
            [("📥 TXT yuklash", "dc:txt"), ("📤 Eksport (sizniki)", "dc:exp:user")],
            [("🗂 Sizning so'zlaringiz", "dc:list:0"), ("📦 Hammasi (txt)", "dc:exp:all")],
            [("🧪 Eshitmasdan sinash", "dc:test"), ("⬅️ Menyu", "mn:main")],
        ]
        self._screen(chat, text, rows)

    # ------------------------------------------------------------------ qidiruv
    def _dc_results(self, q, page, chat, prefix=""):
        a = self.app
        res = lx.search(a.db, q)
        if not res:
            first = [("➕ Qo'shish", f"dc:addw:{q}")] if pronounce._KEY.match(q) else []
            self._screen(chat, f"🔍 «{esc(q)}» bo'yicha hech narsa topilmadi.\n\nQo'shish: <code>{esc(q)} = aytilishi</code>",
                         [first + [("🔍 Qayta", "dc:search")], [("⬅️ Lug'at", "dc:main")]])
            return None
        pages = max(1, (len(res) + PAGE - 1) // PAGE)
        page = max(0, min(page, pages - 1))
        chunk = res[page * PAGE:(page + 1) * PAGE]
        lines = [f"🔍 «{esc(q)}» · {len(res)} ta · sahifa {page + 1}/{pages}", "👤 sizniki · 🤖 AI · 📘 o'rnatilgan", ""]
        rows = []
        for k, v, src in chunk:
            lines.append(f"{SRC_ICON[src]} <code>{esc(k)}</code> → {esc(v)}")
            rows.append([(f"✏️ {clip(k, 18)}", f"dc:ed:{k[:30]}"),
                         ("🔊", f"dc:say:{k[:30]}")] + ([("🗑", f"dc:del:{k[:30]}")] if src != "base" else []))
        nav = []
        if page > 0:
            nav.append(("◀️", f"dc:q:{page - 1}"))
        if page < pages - 1:
            nav.append(("▶️", f"dc:q:{page + 1}"))
        if nav:
            rows.append(nav)
        rows.append([("🔍 Yangi qidiruv", "dc:search"), ("⬅️ Lug'at", "dc:main")])
        self._dc_last_q = q
        self._screen(chat, "\n".join(lines), rows)
        return None

    # ------------------------------------------------------------------ ro'yxat (sizniki)
    def _dc_list(self, page, chat):
        a = self.app
        user = sorted((a.db.kv_json(pronounce.KV_USER, {}) or {}).items())
        if not user:
            return self._screen(chat, "👤 Sizning lug'atingiz hozircha bo'sh.\nQo'shish uchun ➕ yoki txt yuboring.",
                                [[("➕ Qo'shish", "dc:add"), ("📥 TXT", "dc:txt")], [("⬅️ Lug'at", "dc:main")]])
        pages = max(1, (len(user) + PAGE - 1) // PAGE)
        page = max(0, min(page, pages - 1))
        chunk = user[page * PAGE:(page + 1) * PAGE]
        lines = [f"👤 <b>Sizning so'zlaringiz</b> · {len(user)} ta · sahifa {page + 1}/{pages}", ""]
        rows = []
        for k, v in chunk:
            lines.append(f"<code>{esc(k)}</code> → {esc(v)}")
            rows.append([(f"✏️ {clip(k, 18)}", f"dc:ed:{k[:30]}"), ("🔊", f"dc:say:{k[:30]}"), ("🗑", f"dc:del:{k[:30]}")])
        nav = []
        if page > 0:
            nav.append(("◀️", f"dc:list:{page - 1}"))
        if page < pages - 1:
            nav.append(("▶️", f"dc:list:{page + 1}"))
        if nav:
            rows.append(nav)
        rows.append([("⬅️ Lug'at", "dc:main")])
        self._screen(chat, "\n".join(lines), rows)

    # ------------------------------------------------------------------ callback
    def dc_callback(self, val, chat):
        a = self.app
        act, _, arg = val.partition(":")
        self.pending = None
        if act == "main":
            return self._dc_main(chat)
        if act == "search":
            return self._dc_ask(chat, "dc_search", None,
                                "🔍 Qidirish: ingliz so'z yoki o'zbekcha aytilishni yozing\n(masalan <code>shape</code> yoki <code>sheyp</code>)")
        if act == "add":
            return self._dc_ask(chat, "dc_add", None,
                                "➕ Yangi so'z(lar): <code>so'z = aytilish</code>\nBir nechta qator yuborsangiz hammasi qo'shiladi.\n"
                                "Masalan:\n<code>shape = sheyp\nlike = layk</code>")
        if act == "addw":
            return self._dc_ask(chat, "dc_addw", arg, f"➕ «{esc(arg)}» qanday aytilsin? Aytilishini yozing (masalan <code>sheyp</code>).")
        if act == "txt":
            return self._screen(chat, "📥 <b>TXT yuklash</b>\nFaylni shu chatga hujjat sifatida yuboring (.txt/.csv).\n"
                                      "Har qatorda: <code>so'z = aytilish</code> (ajratgich: = : - -> tab). # bilan boshlangan qator — izoh.\n"
                                      "Bor so'zlar yangilanadi, yangilari qo'shiladi.",
                                [[("📤 Namuna (sizniki)", "dc:exp:user")], [("⬅️ Lug'at", "dc:main")]])
        if act == "list":
            return self._dc_list(int(arg) if arg.isdigit() else 0, chat)
        if act == "q":
            return self._dc_results(getattr(self, "_dc_last_q", ""), int(arg) if arg.isdigit() else 0, chat)
        if act == "test":
            return self._dc_ask(chat, "dc_test", None, "🧪 Matn yozing — ovoz uni qanday o'qishini ko'rsataman.")
        if act == "exp":
            return self._dc_export(arg or "user", chat)
        if act == "say":
            low = arg.lower()
            self.tg.send(f"🔊 <code>{esc(arg)}</code> → <code>{esc(speak.speak_text(arg))}</code>", chat=chat)
            return None
        if act == "ed":
            cur = speak.lookup_en(arg.lower()) or "-"
            return self._dc_ask(chat, "dc_edit", arg.lower(),
                                f"✏️ <code>{esc(arg)}</code> hozir: <b>{esc(cur)}</b>\nYangi aytilishini yozing.")
        if act == "del":
            ok = lx.remove_user(a.db, arg)
            self.tg.send(("🗑 O'chirildi: " if ok else "ℹ️ Sizning/AI lug'atingizda yo'q (o'rnatilganni o'chirib bo'lmaydi, "
                                                      "o'zingizniki bilan almashtiring): ") + f"<code>{esc(arg)}</code>", chat=chat)
            return self._dc_main(chat)
        return None

    def _dc_ask(self, chat, kind, data, text):
        self.pending = (kind, data)
        self._screen(chat, text + "\n\nHozir shu chatga yozib yuboring.", [[("✖️ Bekor qilish", "dc:main")]])

    # ------------------------------------------------------------------ matn kiritish
    def dc_pending(self, kind, data, text, chat):
        a = self.app
        text = text.strip()
        self._cb_msg = None
        if kind == "dc_search":
            return self._dc_results(text, 0, chat)
        if kind == "dc_test":
            self.tg.send(f"🗣 Ovoz shunday o'qiydi:\n<code>{esc(speak.speak_text(text[:600]))}</code>", chat=chat)
            return self._dc_main(chat)
        if kind == "dc_addw":
            text = f"{data} = {text}"
        if kind == "dc_edit":
            text = f"{data} = {text}"
        good, bad = lx.parse_lexicon(text)
        if not good:
            self.pending = (kind, data)
            reason = bad[0][2] if bad else "format: so'z = aytilish"
            self.tg.send(f"⚠️ Qabul qilinmadi: {esc(reason)}\nQayta yozing yoki /sozlar.", chat=chat)
            return None
        st = lx.merge_user(a.db, good)
        lines = [f"✅ Qo'shildi: {st['added']} · yangilandi: {st['updated']} · o'zgarishsiz: {st['same']}"]
        if st["full"]:
            lines.append(f"⚠️ Lug'at to'ldi ({lx.MAX_USER}): {st['full']} ta qo'shilmadi")
        for k in list(good)[:3]:
            lines.append(f"🔊 <code>{esc(k)}</code> → <code>{esc(speak.speak_text(k))}</code>")
        if bad:
            lines.append(f"⚠️ {len(bad)} qator o'tkazib yuborildi")
        self.tg.send("\n".join(lines), chat=chat)
        return self._dc_main(chat)

    # ------------------------------------------------------------------ fayl
    def dc_import_file(self, msg):
        """Telegramdan kelgan .txt/.csv lug'at faylini qabul qiladi."""
        a = self.app
        chat = msg["chat"]["id"]
        doc = msg["document"]
        if doc.get("file_size", 0) > 3 * 1024 * 1024:
            self.tg.send("ℹ️ Fayl juda katta (3 MB gacha).", chat=chat)
            return
        dest = Path(tempfile.mkdtemp(prefix="dict_", dir=str(a.cfg.dirs["work"]))) / "in.txt"
        try:
            self.tg.download_file(doc["file_id"], dest)
            text = lx.decode_bytes(dest.read_bytes())
        except Exception as e:  # noqa: BLE001
            self.tg.send(f"❌ Fayl o'qilmadi: {esc(clip(self.tg._clean(e), 200))}", chat=chat)
            return
        finally:
            try:
                dest.unlink()
                dest.parent.rmdir()
            except OSError:
                pass
        good, bad = lx.parse_lexicon(text)
        if not good:
            self.tg.send("⚠️ Faylda yaroqli qator topilmadi. Format: <code>so'z = aytilish</code>", chat=chat)
            return
        st = lx.merge_user(a.db, good)
        lines = [f"📥 <b>{esc(doc.get('file_name', 'fayl'))}</b>: {len(good)} ta yaroqli qator",
                 f"✅ Qo'shildi: {st['added']} · yangilandi: {st['updated']} · o'zgarishsiz: {st['same']}"]
        if st["full"]:
            lines.append(f"⚠️ Lug'at to'ldi ({lx.MAX_USER}): {st['full']} ta qo'shilmadi")
        if bad:
            lines.append(f"⚠️ {len(bad)} qator o'tkazildi:")
            lines += [f"  {no}: <code>{esc(clip(s, 30))}</code> — {esc(why)}" for no, s, why in bad[:8]]
            if len(bad) > 8:
                lines.append(f"  … yana {len(bad) - 8} ta")
        self.tg.send("\n".join(lines), chat=chat,
                     markup={"inline_keyboard": [[{"text": "🔤 Lug'at", "callback_data": "dc:main"}]]})

    def _dc_export(self, which, chat):
        a = self.app
        text = lx.export_text(a.db, which)
        name = "sozlar_hammasi.txt" if which == "all" else "sozlar_sizniki.txt"
        p = Path(tempfile.mkdtemp(prefix="dict_", dir=str(a.cfg.dirs["work"]))) / name
        p.write_text(text, encoding="utf-8")

        def job():
            try:
                self.tg.send_file("document", str(p), f"🔤 {name}: {text.count(chr(10)) - 2} qator", chat=chat)
            finally:
                try:
                    p.unlink()
                    p.parent.rmdir()
                except OSError:
                    pass
        if not a.jobs.submit_light("dict-export", job):
            self.tg.send("ℹ️ Eksport bajarilmoqda.", chat=chat)
