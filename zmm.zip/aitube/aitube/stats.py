"""Statistika: ko'rishlar, yoqtirishlar, izohlar, kunlik hisobot."""
from __future__ import annotations

from .util import clip, esc, fmt_dur, iso_now, local_now, log
from .youtube import YTError


class Stats:
    def __init__(self, cfg, db, yt, notifier):
        self.cfg, self.db, self.yt, self.n = cfg, db, yt, notifier

    def refresh(self) -> dict:
        ups = [e for e in self.db.uploaded(500) if e.get("yt_id")]
        if not ups or not self.yt.authorized():
            return {}
        try:
            data = self.yt.stats([e["yt_id"] for e in ups])
        except YTError as e:
            log.warning("Statistika olinmadi: %s", e)
            if e.auth:
                self.n.say("🔑 Statistika uchun YouTube avtorizatsiyasi yaroqsiz - /auth")
            return {}
        for e in ups:
            s = data.get(e["yt_id"])
            if s:
                self.db.ep_update(e["id"], views=s["views"], likes=s["likes"], comments=s["comments"])
        self.db.kv_set("stats_last", str(int(__import__("time").time())))
        self.hide_stats(ups)
        return data

    def hide_stats(self, ups=None) -> int:
        """HIDE_STATS yoqiq bo'lsa: ochiq statistikasi ko'rinib qolgan videolarda uni yana yopadi."""
        if not self.cfg.bool("HIDE_STATS") or not self.yt.authorized():
            return 0
        ups = ups if ups is not None else [e for e in self.db.uploaded(500) if e.get("yt_id")]
        try:
            ch = self.yt.hide_stats([e["yt_id"] for e in ups])
        except YTError as e:
            log.warning("Statistikani yopib bo'lmadi: %s", e)
            return 0
        if ch:
            nums = {e["yt_id"]: e["gno"] for e in ups}
            self.n.say("🙈 Ochiq statistika sahifasi qayta yopildi (layk soni bundan YOPILMAYDI): " + ", ".join(f"#{nums.get(i, '?')}" for i in ch))
        return len(ch)

    def totals(self):
        ups = self.db.uploaded(500)
        return {"n": len(ups), "views": sum(e["views"] or 0 for e in ups),
                "likes": sum(e["likes"] or 0 for e in ups), "comments": sum(e["comments"] or 0 for e in ups)}

    def check_comments(self, notify=True) -> int:
        """Oxirgi yuklangan videolardagi yangi izohlarni adminga yuboradi."""
        if not self.yt.authorized():
            return 0
        ups = self.db.uploaded(5)
        new = 0
        for e in ups:
            if not e.get("yt_id") or not (e["comments"] or 0):
                continue
            try:
                items = self.yt.comments(e["yt_id"], 20)
            except YTError as ex:
                log.warning("Izohlar olinmadi: %s", ex)
                continue
            fresh = [c for c in items if not self.db.comment_seen(c["id"])]
            first_run = not self.db.kv_get(f"comments_init:{e['id']}")
            for c in fresh:
                self.db.comment_mark(c["id"])
            self.db.kv_set(f"comments_init:{e['id']}", "1")
            if first_run or not fresh:
                continue
            new += len(fresh)
            if notify:
                lines = [f"💬 <b>#{e['gno']} · {esc(clip(e['title'], 40))}</b> — {len(fresh)} ta yangi izoh"]
                for c in fresh[:8]:
                    lines.append(f"• <b>{esc(clip(c['author'], 24))}</b>: {esc(clip(c['text'], 220))}")
                self.n.say("\n".join(lines))
        return new

    def digest(self) -> str:
        db, cfg = self.db, self.cfg
        t = self.totals()
        prev_views = int(db.kv_get("digest_views", "0") or 0)
        delta = t["views"] - prev_views
        db.kv_set("digest_views", str(t["views"]))
        c = db.counts()
        ups = db.uploaded(200)
        lines = [f"📰 <b>Kunlik hisobot</b> · {local_now(cfg).strftime('%Y-%m-%d')}",
                 f"📺 Yuklangan epizodlar: {t['n']} · 👁 {t['views']} ({'+' if delta >= 0 else ''}{delta} oxirgi hisobotdan) · "
                 f"👍 {t['likes']} · 💬 {t['comments']}",
                 f"🎬 Holat: tayyor {c.get('ready', 0)} · rejada {c.get('planned', 0)} · xato {c.get('failed', 0)} · "
                 f"o'tkazilgan {c.get('skipped', 0)}"]
        if ups:
            top = sorted(ups, key=lambda e: e["views"] or 0, reverse=True)[:3]
            lines.append("🏆 Eng ko'p ko'rilgan:\n" + "\n".join(
                f"  {i}. #{e['gno']} {esc(clip(e['title'], 45))} — {e['views'] or 0} 👁" for i, e in enumerate(top, 1)))
            last = ups[0]
            lines.append(f"🆕 Oxirgi: #{last['gno']} {esc(clip(last['title'], 50))} {last['yt_url'] or ''}")
        halt = db.kv_get("halt_reason")
        if halt:
            lines.append(f"⛔ To'xtatilgan: {esc(halt)}")
        nxt = db.by_status("ready", "planned", limit=1)
        if nxt:
            lines.append(f"⏭ Keyingi: #{nxt[0]['gno']} {esc(clip(nxt[0]['title'], 50))} [{nxt[0]['status']}]")
        return "\n".join(lines)
