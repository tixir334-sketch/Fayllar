"""AI uchun o'qitish doktrinasi va sahna turlari spetsifikatsiyasi (writer.py va streamgen.py umumiy ishlatadi).

Maqsad: tomoshabin mavzuni 0 dan o'rganadi — hech qanday atama oldindan tushuntirilmasdan ishlatilmaydi; har bir tushuncha
«nima → nega → qanday → hayotiy misol → raqamli misol → odatiy xato» zanjiri bilan, 3D kartalar va animatsiyalar bilan o'rgatiladi.
"""
from __future__ import annotations

ICON_LIST = ("user, users, server, db, browser, laptop, phone, cloud, file, folder, lock, key, ai, bot, gear, code, terminal, "
             "globe, router, wifi, bolt (cache), queue, lb, docker, git, mail, shield, disk, clock, chat, bug, firewall, "
             "cpu, gpu, ram, ssd, hdd, motherboard, psu, fan, tower (pc case), monitor, keyboard, mouse, battery, usb, camera, "
             "mic, speaker, headphones, printer, book, bulb (idea), rocket, magnifier (search), chart, calendar, coin, trophy, "
             "star, heart, puzzle, link, sphere, pyramid, check, cross, box")

TEACH_RULES = """
TEACHING DOCTRINE (follow strictly - this is what makes the channel valuable):
1. ZERO-TO-HERO: assume the viewer has NEVER heard any term used in this episode. Never use a technical word before it has been
   explained in plain language in an EARLIER scene of this same episode; if a word is needed earlier, add a 6-10 word explanation
   in-line at its first mention. Nothing may stay unexplained or "obvious".
2. For EVERY new concept follow this chain: WHAT it is (one plain sentence) -> WHY it exists / what problem it solves -> HOW it works,
   step by step -> a REAL-LIFE ANALOGY (kitchen, post office, library, road traffic, school, shop...) -> a concrete EXAMPLE with real
   numbers -> the typical MISTAKE beginners make and how to avoid it.
3. Expand every abbreviation at first use (e.g. "CPU, ya'ni Central Processing Unit - kompyuterning markaziy protsessori") and
   explain every unit the first time it appears (GHz, GB, core, thread, bit, byte, Mbit/s, watt...).
4. Never skip a step because it seems obvious. For every part of a system say: what it is, what it does, WHY it is needed, what
   happens if it is missing or too weak, and how it works together with the other parts.
5. HARDWARE / BUILD topics (for example assembling a PC): explain each component in detail and in the order a beginner builds it:
   CPU (does the calculations; cores, threads, GHz; why the PC cannot work without it), GPU (draws images/video, thousands of small
   parallel workers; when a separate GPU is needed and when integrated graphics is enough), RAM (short-term working memory; why
   more RAM means more programs at once), SSD/HDD (long-term storage; speed difference), motherboard (connects everything; sockets and
   compatibility), PSU (power; how to choose watts), cooling, case - plus compatibility rules and typical budget trade-offs.
6. Teach with VISUALS, not only text: "parts" scenes for sets of components (3D cards), "explain" scenes for each key term
   (definition + analogy + why it matters), "diagram" scenes for anything that moves or communicates, "flow" for procedures,
   "compare" for A-versus-B, "code" for code. At least 40% of the scenes must be "explain", "parts" or "diagram". Choose the most
   fitting 3D icon for every item (never the same icon twice in one scene).
7. The narration of each scene walks through EXACTLY what is on screen, item by item, in the same order in which the items appear.
   For "parts": one short paragraph per item (what it is + why it is needed). For "explain": first the definition, then the analogy
   ("Xuddi ... dek"), then the points. Say the names of the items aloud so the viewer can match voice and picture.
8. Warm, patient tone, short simple sentences, second person ("siz"), everyday words instead of jargon. After every 3rd-4th scene add
   a one-sentence mini-recap ("Demak, ...") so nothing is lost.
9. Accuracy first: no invented statistics; when you give a number say it is an example ("masalan").
"""

SCENE_SPEC = """Scene types (use a rich mix; each scene is one JSON object):
- "explain" (a 3D CONCEPT CARD - use one for every important new term):
  {"type":"explain","heading":"Protsessor nima?","term":"Protsessor (CPU)","icon":"cpu",
   "definition":"<= 120 chars: what it is, in plain words","analogy":"<= 110 chars: real-life comparison, e.g. 'Xuddi oshxonadagi bosh oshpaz kabi...'",
   "points":["<= 48 chars why it matters","(max 2 points)"],"narration":"..."}
- "parts" (a grid of 2-6 3D CARDS, one per component/option; revealed one by one):
  {"type":"parts","heading":"Kompyuter qismlari","items":[{"icon":"cpu","name":"Protsessor (CPU)","role":"<= 56 chars: what it does / why needed"},
   {"icon":"ram","name":"Operativ xotira","role":"..."}],"narration":"... one paragraph per item, in order ..."}
- "diagram": an ANIMATED picture of how parts talk to each other (messages travel along arrows between 3D icons):
  {"type":"diagram","heading":"...","nodes":[{"id":"u","kind":"user","label":"Foydalanuvchi"},{"id":"s","kind":"server","label":"Server"},
   {"id":"d","kind":"db","label":"Baza"}],"links":[{"from":"u","to":"s","label":"HTTP so'rov"},{"from":"s","to":"d","label":"SQL","kind":"data"},
   {"from":"d","to":"s","label":"natija","kind":"response"},{"from":"s","to":"u","label":"JSON javob","kind":"response"}],"narration":"..."}
  2-7 nodes (label <= 16 chars), 2-8 links in the order the narration tells them (label <= 18 chars). Link kind: request (default),
  response, data, error, event. Optional "packet": "msg" | "file" | "dot". The narration walks through the links one by one.
- "flow": {"type":"flow","heading":"...","steps":["3-6 steps, <= 40 chars"],"narration":"..."}
- "compare": {"type":"compare","heading":"...","left":{"title":"A","items":["<= 40 chars"]},"right":{"title":"B","items":["..."]},"narration":"..."}
- "bullets": {"type":"bullets","heading":"...","bullets":["max 5 short points, <= 56 chars"],"narration":"..."}
- "code": {"type":"code","heading":"...","filename":"app.py","language":"python","code":"...","narration":"..."}
Icon / node kinds (all rendered as shiny 3D objects with shadows): """ + ICON_LIST + """.
Use "diagram" whenever components communicate (client/server, HTTP, API, database, network, DNS, queues, AI request/response, git,
deployment, auth). Use "parts" whenever you list the components of something. Use "explain" for every key term the viewer has not met."""
