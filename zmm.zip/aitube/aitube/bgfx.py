"""Harakatlanuvchi fon uslublari (har epizodda boshqa): aurora, perspektiv to'r, tarmoq, kod yomg'iri,
to'lqinlar, olti burchaklar, yulduzlar uchishi, yorug' nurlar.
Statik qism `Renderer.bg` ga chiziladi (mazmun niqobi shu bilan solishtiriladi), harakatlanuvchi qism
`bg_frame(t)` da har kadrda arzon yangilanadi (past aniqlikdagi yorug'lik + oz sonli aniq chiziqlar)."""
from __future__ import annotations

import math
import random

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

STYLES = ("aurora", "grid", "network", "rain", "waves", "hex", "warp", "beams", "world")
PALS = {
    "aurora": ((11, 15, 22), (24, 32, 48)),
    "grid": ((12, 10, 26), (34, 16, 56)),
    "network": ((7, 15, 24), (12, 38, 54)),
    "rain": ((5, 13, 11), (10, 32, 26)),
    "waves": ((7, 13, 30), (13, 40, 74)),
    "hex": ((15, 11, 22), (42, 22, 46)),
    "warp": ((5, 7, 17), (14, 15, 42)),
    "beams": ((13, 13, 18), (37, 30, 46)),
    "world": ((7, 11, 26), (20, 28, 60)),
}
WORLD_ICONS = ("cpu", "gpu", "ram", "gear", "cloud", "db", "bolt", "shield", "code", "globe", "server", "ssd", "bulb", "rocket",
               "chip", "fan", "link", "star", "monitor", "key")
_GLYPHS = "01{}[]()<>/=+-*;:#$&|~^%@λ∑πΩ"


def _mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def _scale(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def style_for(n: int) -> str:
    """Epizod raqamiga qarab uslub. Asosan 'world' (3D ikonkalar suzib yuradigan, videodek jonli olam); har uchinchi epizod boshqa uslub."""
    n = int(n)
    if n % 3 != 0:
        return "world"
    others = [s for s in STYLES if s != "world"]
    return others[(n * 3 + 1) % len(others)]


class BgMixin:
    # ------------------------------------------------------------ sozlash
    def _setup_style(self, style, seed):
        if isinstance(style, int):
            style = STYLES[style % len(STYLES)]
        if style not in STYLES:
            style = "aurora"
        self.style = style
        self.bg1, self.bg2 = PALS[style]
        self.bg_seed = int(seed or 0)

    def _make_bg(self):
        W, H, S = self.RW, self.RH, self.S
        grad = Image.linear_gradient("L").resize((W, H))
        if self.style in ("grid", "waves"):
            grad = grad.transpose(Image.FLIP_TOP_BOTTOM) if self.style == "grid" else grad
        img = Image.composite(Image.new("RGB", (W, H), self.bg2), Image.new("RGB", (W, H), self.bg1), grad)
        d = ImageDraw.Draw(img)
        st = self.style
        if st in ("aurora", "network", "beams"):
            dc = _mix(self.bg1, (60, 74, 98), 0.45)
            step, off, rr = max(2, int(round(40 * S))), int(round(28 * S)), max(1.0, S)
            for x in range(off, W, step):
                for y in range(off, H, step):
                    d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=dc)
        elif st == "grid":
            hz = int(H * 0.50)
            lc = _scale(self.accent, 0.20)
            d.line([(0, hz), (W, hz)], fill=_scale(self.accent, 0.38), width=max(1, int(S * 2)))
            vx = W / 2
            for k in range(-14, 15):
                x_bot = vx + k * W * 0.115
                d.line([(vx + k * 4 * S, hz), (x_bot, H)], fill=lc, width=max(1, int(S)))
        elif st == "hex":
            R = 46 * S
            hc = _mix(self.bg1, self.accent, 0.13)
            dx, dy = R * 1.5, R * math.sqrt(3) / 2
            col = 0
            x = -R
            while x < W + R:
                y0 = -dy + (dy if col % 2 else 0)
                y = y0
                while y < H + R:
                    pts = [(x + R * math.cos(math.pi / 3 * i), y + R * math.sin(math.pi / 3 * i)) for i in range(6)]
                    d.line(pts + [pts[0]], fill=hc, width=max(1, int(S)))
                    y += dy * 2
                x += dx
                col += 1
        elif st == "warp":
            rnd = random.Random(7 + self.bg_seed)
            for _ in range(160):
                x, y = rnd.randrange(W), rnd.randrange(H)
                c = _mix(self.bg1, (170, 190, 230), rnd.uniform(0.15, 0.5))
                r = max(0.5, S * rnd.choice((0.6, 0.8, 1.0)))
                d.ellipse([x - r, y - r, x + r, y + r], fill=c)
        if getattr(self, "art", None) is not None:      # AI rasm: xira, biroz xiralashtirilgan fon
            a = ImageOps.fit(self.art.convert("RGB"), (W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(max(1, 3 * S)))
            a = a.point(lambda v: int(v * 0.36))
            img = Image.blend(img, ImageChops.screen(img, a), 0.9)
        # burchak yorug'ligi
        sw, sh = max(8, W // 4), max(8, H // 4)
        glow = Image.new("RGB", (sw, sh), (0, 0, 0))
        gx = (0.5, 1.2) if st != "grid" else (0.2, 0.9)
        ImageDraw.Draw(glow).ellipse([sw * gx[0], -sh * 0.45, sw * gx[1], sh * 0.5],
                                     fill=tuple(int(c * 0.14) for c in self.accent))
        glow = glow.filter(ImageFilter.GaussianBlur(sw * 0.12)).resize((W, H), Image.BILINEAR)
        img = ImageChops.add(img, glow)
        vg = Image.radial_gradient("L").resize((W, H))
        vg = vg.point(lambda v: 255 - int(max(0, v - 120) * 0.55))
        return ImageChops.multiply(img, Image.merge("RGB", (vg, vg, vg)))

    # ------------------------------------------------------------ harakat ma'lumotlari
    def _init_motion(self):
        rnd = random.Random(1234 + self.bg_seed * 17)
        W, H, S = self.RW, self.RH, self.S
        st = self.style
        self.gsize = (max(32, int(self.W) // 8), max(32, int(self.H) // 8))
        self.blobs = [
            (0.80, 0.12, 0.10, 0.10, 17.0, 0.0, 0.36, _scale(self.accent, 0.26)),
            (0.10, 0.88, 0.09, 0.08, 23.0, 2.1, 0.30, _scale(self.alt, 0.22)),
            (0.48, 0.55, 0.16, 0.12, 29.0, 4.0, 0.22, _scale(self.third, 0.10)),
        ]
        self.bokeh = [(rnd.random(), rnd.random(), rnd.uniform(0.012, 0.035), rnd.uniform(0.01, 0.03),
                       rnd.uniform(0, 6.28), _scale(self.accent2, rnd.uniform(0.10, 0.20))) for _ in range(7)]
        n_parts = 30 if not self.portrait else 22
        self.parts = [dict(x=rnd.uniform(0, W), y=rnd.uniform(0, H + 20 * S), vy=rnd.uniform(10, 34) * S,
                           r=rnd.choice((1, 1, 2, 2, 3)) * S, ph=rnd.uniform(0, 6.28), amp=rnd.uniform(6, 22) * S,
                           fx=rnd.uniform(0.2, 0.6)) for _ in range(n_parts)]
        if st == "network":
            n = 16 if not self.portrait else 12
            self.nodes = [dict(x=rnd.random(), y=rnd.random(), ax=rnd.uniform(0.02, 0.07), ay=rnd.uniform(0.02, 0.07),
                               px=rnd.uniform(0, 6.28), py=rnd.uniform(0, 6.28), fx=rnd.uniform(0.08, 0.22),
                               fy=rnd.uniform(0.08, 0.22)) for _ in range(n)]
        elif st == "rain":
            ncol = 26 if not self.portrait else 14
            self.cols = [dict(x=(i + rnd.uniform(0.1, 0.9)) / ncol, v=rnd.uniform(0.05, 0.16), ph=rnd.uniform(0, 1),
                              n=rnd.randint(6, 13), seq=[rnd.choice(_GLYPHS) for _ in range(16)]) for i in range(ncol)]
        elif st == "warp":
            self.stars = [dict(a=rnd.uniform(0, 6.283), r=rnd.uniform(0.03, 1.0), v=rnd.uniform(0.04, 0.10))
                          for _ in range(110 if not self.portrait else 80)]
        elif st == "hex":
            R = 46 * S
            self.hex_R = R
            self.hex_lit = [dict(cx=rnd.randrange(0, 40), cy=rnd.randrange(0, 40), ph=rnd.uniform(0, 6.28),
                                 f=rnd.uniform(0.25, 0.7)) for _ in range(12)]
        elif st == "waves":
            self.waves = [dict(base=0.62 + 0.09 * i, amp=0.035 + 0.01 * (i % 2), k=rnd.uniform(1.4, 2.6),
                               sp=rnd.uniform(0.18, 0.4) * (1 if i % 2 else -1), ph=rnd.uniform(0, 6.28),
                               col=_mix(self.accent, self.alt, i / 3.0)) for i in range(4)]
        elif st == "beams":
            self.beams = [dict(x=rnd.uniform(0.1, 0.9), w=rnd.uniform(0.04, 0.10), ang=rnd.uniform(0.35, 0.6),
                               per=rnd.uniform(14, 26), ph=rnd.uniform(0, 6.28), a=rnd.uniform(0.7, 1.0))
                          for _ in range(4)]
        elif st == "world":
            kinds = list(WORLD_ICONS)
            rnd.shuffle(kinds)
            n_ic = 9 if not self.portrait else 7
            self.world_icons = []
            for i in range(n_ic):
                depth = 0.25 + 0.75 * (i / max(1, n_ic - 1))                 # 0.25 uzoq .. 1.0 yaqin
                self.world_icons.append(dict(kind=kinds[i % len(kinds)], depth=depth, x=rnd.random(), y=rnd.uniform(0.10, 0.82),
                                             vx=rnd.uniform(0.004, 0.011) * (0.4 + depth), fy=rnd.uniform(0.25, 0.6),
                                             amp=rnd.uniform(0.012, 0.035), ph=rnd.uniform(0, 6.28),
                                             col=_mix(self.accent, rnd.choice((self.alt, self.third, self.accent2)), rnd.uniform(0.2, 0.8))))
            self.world_cache = {}
            self.world_pulses = [dict(i=rnd.randint(-7, 7), sp=rnd.uniform(0.10, 0.22), ph=rnd.random()) for _ in range(7)]

    # ------------------------------------------------------------ kadr
    def _drift(self, t):
        """Asosiy va qo'shimcha rang orasida sekin siljish (har epizod ichida fon asta o'zgaradi)."""
        return 0.5 + 0.5 * math.sin(t / 22.0 + self.bg_seed)

    def _glow_layer(self, draw_fn, blur=0.045):
        gw, gh = self.gsize
        g = Image.new("RGB", (gw, gh), (0, 0, 0))
        draw_fn(ImageDraw.Draw(g), gw, gh)
        return g.filter(ImageFilter.GaussianBlur(gw * blur)).resize((self.RW, self.RH), Image.BILINEAR)

    def bg_frame(self, t: float) -> Image.Image:
        """t - soniya. Harakatsiz rejimda (VIDEO_MOTION=0) statik fon."""
        if self.motion <= 0:
            return self.bg.copy()
        return getattr(self, "_bgf_" + self.style)(t)

    def _particles(self, img, t, count=None):
        W, H, S = self.RW, self.RH, self.S
        d = ImageDraw.Draw(img)
        for p in self.parts[:count]:
            y = (p["y"] - p["vy"] * t) % (H + 20 * S) - 10 * S
            x = p["x"] + p["amp"] * math.sin(t * p["fx"] + p["ph"])
            b = 0.40 + 0.35 * math.sin(t * 1.6 + p["ph"])
            col = _mix(_mix(self.bg1, (60, 74, 98), 0.5), self.accent2, b * 0.75)
            r = p["r"]
            d.ellipse([x - r, y - r, x + r, y + r], fill=col)

    def _bgf_aurora(self, t):
        tau = 2 * math.pi
        dr = self._drift(t)

        def fn(gd, gw, gh):
            for i, (cx, cy, ax, ay, per, ph, rad, col) in enumerate(self.blobs):
                if i == 0:
                    col = _mix(col, _scale(self.alt, 0.26), dr * 0.5)
                x = (cx + ax * math.sin(tau * t / per + ph)) * gw
                y = (cy + ay * math.cos(tau * t / (per * 1.3) + ph)) * gh
                r = rad * gw
                gd.ellipse([x - r, y - r, x + r, y + r], fill=col)
            for bx, by, br, vy, ph, col in self.bokeh:
                x = (bx + 0.03 * math.sin(t * 0.3 + ph)) * gw
                y = ((by - vy * t / 6.0) % 1.2 - 0.1) * gh
                r = br * gw * (1 + 0.15 * math.sin(t * 0.8 + ph))
                gd.ellipse([x - r, y - r, x + r, y + r], fill=col)
        img = ImageChops.add(self.bg, self._glow_layer(fn))
        self._particles(img, t)
        return img

    def _bgf_grid(self, t):
        W, H, S = self.RW, self.RH, self.S
        hz = H * 0.50

        def fn(gd, gw, gh):
            x = (0.5 + 0.18 * math.sin(t / 9.0)) * gw
            gd.ellipse([x - gw * 0.32, gh * 0.50 - gh * 0.16, x + gw * 0.32, gh * 0.50 + gh * 0.16],
                       fill=_scale(_mix(self.accent, self.alt, self._drift(t)), 0.30))
            gd.ellipse([gw * 0.78 - gw * 0.18, gh * 0.18 - gw * 0.18, gw * 0.78 + gw * 0.18, gh * 0.18 + gw * 0.18],
                       fill=_scale(self.third, 0.10))
        img = ImageChops.add(self.bg, self._glow_layer(fn))
        d = ImageDraw.Draw(img)
        ph = (t * 0.35) % 1.0
        for k in range(12):
            u = (k + ph) / 12.0
            y = hz + (H - hz) * (u ** 2.2)
            c = _scale(_mix(self.accent, self.alt, u), 0.20 + 0.62 * u)
            d.line([(0, y), (W, y)], fill=c, width=max(1, int(S * (1 + 1.6 * u))))
        self._particles(img, t, 14)
        return img

    def _world_sprite(self, ic, px, t):
        """Suzuvchi 3D ikonka sprite'i (soya, yaltirash bilan). Sekundiga ~6 marta yangilanadi (arzon), uzoqdagilari xiralashtirilgan."""
        from .icons3d import I3
        key = (ic["kind"], px, int(t * 6) % 600)
        spr = self.world_cache.get(key)
        if spr is None:
            if len(self.world_cache) > 220:
                self.world_cache.clear()
            spr = I3.render(ic["kind"], px, ic["col"], t, ic["ph"], wob=0.8, glint=0.55 if ic["depth"] > 0.6 else 0.25)
            if ic["depth"] < 0.6:                                         # chuqurlik: uzoq narsalar xira va kichik
                spr = spr.filter(ImageFilter.GaussianBlur(max(1, px * (0.6 - ic["depth"]) * 0.05)))
            a = int(255 * (0.22 + 0.45 * ic["depth"]))
            spr.putalpha(spr.getchannel("A").point(lambda v: v * a // 255))
            self.world_cache[key] = spr
        return spr

    def _bgf_world(self, t):
        """Videodek jonli 'yangi olam': harakatlanuvchi nur-nurlar, perspektiv pol (ma'lumot impulslari bilan),
        uzoq-yaqin suzib yuruvchi 3D ikonkalar (parallaks) va zarrachalar."""
        W, H, S = self.RW, self.RH, self.S
        hz = H * 0.56

        def fn(gd, gw, gh):
            x = (0.5 + 0.20 * math.sin(t / 11.0 + self.bg_seed)) * gw
            gd.ellipse([x - gw * 0.30, gh * 0.30 - gh * 0.20, x + gw * 0.30, gh * 0.30 + gh * 0.20],
                       fill=_scale(_mix(self.accent, self.alt, self._drift(t)), 0.30))
            for k in range(3):                                           # quyosh nurlari (yumshoq, sekin aylanadi)
                a0 = 0.62 + 0.20 * k + 0.12 * math.sin(t / 7.0 + k * 1.7)
                x0 = gw * (0.20 + 0.30 * k + 0.06 * math.sin(t / 9.0 + k))
                gd.polygon([(x0, 0), (x0 + gw * 0.09, 0), (x0 + gw * 0.09 + gh * 0.9 * math.cos(a0), gh),
                            (x0 + gh * 0.9 * math.cos(a0) - gw * 0.02, gh)], fill=_scale(self.accent2, 0.16))
            gd.ellipse([gw * 0.82 - gw * 0.16, gh * 0.20 - gw * 0.16, gw * 0.82 + gw * 0.16, gh * 0.20 + gw * 0.16],
                       fill=_scale(self.third, 0.10))
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.06))
        d = ImageDraw.Draw(img)
        # perspektiv pol
        ph = (t * 0.30) % 1.0
        for k in range(10):
            u = (k + ph) / 10.0
            y = hz + (H - hz) * (u ** 2.1)
            c = _scale(_mix(self.accent, self.alt, u), 0.16 + 0.55 * u)
            d.line([(0, y), (W, y)], fill=c, width=max(1, int(S * (1 + 1.4 * u))))
        vx = W * (0.5 + 0.03 * math.sin(t / 8.0))
        for i in range(-8, 9):
            xb = vx + i * W * 0.13
            c = _scale(_mix(self.alt, self.accent, 0.5), 0.34)
            d.line([(vx + i * W * 0.012, hz), (xb, H)], fill=c, width=max(1, int(S * 1.2)))
        for p in self.world_pulses:                                        # ma'lumot impulslari chiziqlar bo'ylab yuguradi
            u = ((t * p["sp"] + p["ph"]) % 1.0) ** 1.8
            x = vx + p["i"] * W * 0.012 + (p["i"] * W * 0.13 - p["i"] * W * 0.012) * u
            y = hz + (H - hz) * u
            r = (2 + 5 * u) * S
            d.ellipse([x - r, y - r, x + r, y + r], fill=_scale(_mix(self.accent2, (255, 255, 255), 0.4), 0.55 + 0.4 * u))
        # 3D ikonkalar (uzoqdan yaqinga)
        for ic in sorted(self.world_icons, key=lambda z: z["depth"]):
            px = int((64 + 124 * ic["depth"]) * S)
            x = ((ic["x"] + ic["vx"] * t) % 1.25 - 0.12) * W
            y = (ic["y"] + ic["amp"] * math.sin(t * ic["fy"] + ic["ph"])) * H
            spr = self._world_sprite(ic, px, t)
            img.paste(spr, (int(x - px / 2), int(y - px / 2)), spr)
        self._particles(img, t, 16)
        return img

    def _bgf_network(self, t):
        W, H, S = self.RW, self.RH, self.S
        pts = []
        for n in self.nodes:
            x = (n["x"] + n["ax"] * math.sin(t * n["fx"] * 6.283 / 6 + n["px"])) * W
            y = (n["y"] + n["ay"] * math.cos(t * n["fy"] * 6.283 / 6 + n["py"])) * H
            pts.append((x, y))

        def fn(gd, gw, gh):
            for i, (x, y) in enumerate(pts):
                if i % 3 == 0:
                    r = gw * 0.06
                    gx, gy = x / W * gw, y / H * gh
                    gd.ellipse([gx - r, gy - r, gx + r, gy + r], fill=_scale(self.accent, 0.20))
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.05))
        d = ImageDraw.Draw(img)
        lim = W * 0.30
        base = _mix(self.bg1, self.accent, 0.80)
        edges = []
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                dist = math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1])
                if dist < lim:
                    edges.append((i, j, dist))
                    c = _mix(self.bg1, base, 1 - dist / lim)
                    d.line([pts[i], pts[j]], fill=_scale(c, 0.95), width=max(1, int(S)))
        for x, y in pts:
            r = 3.2 * S
            d.ellipse([x - r, y - r, x + r, y + r], fill=_mix(self.bg1, self.accent2, 0.55))
        # chiziq bo'ylab yuguruvchi impulslar
        for k in range(min(5, len(edges))):
            i, j, _ = edges[(k * 7) % len(edges)]
            u = (t * 0.22 + k * 0.37) % 1.0
            x = pts[i][0] + (pts[j][0] - pts[i][0]) * u
            y = pts[i][1] + (pts[j][1] - pts[i][1]) * u
            r = 3.6 * S
            d.ellipse([x - r, y - r, x + r, y + r], fill=_mix(self.bg1, self.accent2, 0.95))
        return img

    def _bgf_rain(self, t):
        W, H, S = self.RW, self.RH, self.S

        def fn(gd, gw, gh):
            gd.ellipse([gw * 0.55, -gh * 0.4, gw * 1.15, gh * 0.45], fill=_scale(self.accent, 0.12))
        img = ImageChops.add(self.bg, self._glow_layer(fn))
        d = ImageDraw.Draw(img)
        fs = 20
        f = self.font("mono", fs)
        step = fs * 1.15
        for c in self.cols:
            x = c["x"] * self.W
            head = ((t * c["v"] + c["ph"]) % 1.35) * (self.H + c["n"] * step) - c["n"] * step
            for k in range(c["n"]):
                y = head - k * step
                if y < -step or y > self.H:
                    continue
                a = (1 - k / c["n"]) ** 1.7
                col = _mix(self.bg1, self.accent2 if k == 0 else self.accent, 0.16 + 0.50 * a)
                ch = c["seq"][(k + int(t * (2 + c["v"] * 10))) % len(c["seq"])]
                d.text((x * S, y * S), ch, font=f.f if hasattr(f, "f") else f, fill=col, anchor="la")
        self._particles(img, t, 8)
        return img

    def _bgf_waves(self, t):
        gw, gh = self.gsize

        def fn(gd, gw, gh):
            for w in self.waves:
                pts = [(0, gh)]
                for i in range(41):
                    u = i / 40.0
                    y = (w["base"] + w["amp"] * math.sin(u * w["k"] * 6.283 + t * w["sp"] + w["ph"])
                         + 0.012 * math.sin(u * 9 + t * 0.7)) * gh
                    pts.append((u * gw, y))
                pts.append((gw, gh))
                gd.polygon(pts, fill=_scale(w["col"], 0.30))
            gd.ellipse([gw * 0.6, -gh * 0.5, gw * 1.2, gh * 0.4], fill=_scale(self.accent, 0.14))
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.006))
        self._particles(img, t, 16)
        return img

    def _bgf_hex(self, t):
        W, H, S = self.RW, self.RH, self.S
        R = self.hex_R
        dx, dy = R * 1.5, R * math.sqrt(3) / 2

        def fn(gd, gw, gh):
            x = ((t * 0.045) % 1.4 - 0.2) * gw
            gd.ellipse([x - gw * 0.22, gh * 0.5 - gh * 0.45, x + gw * 0.22, gh * 0.5 + gh * 0.45],
                       fill=_scale(_mix(self.accent, self.alt, self._drift(t)), 0.16))
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.06))
        d = ImageDraw.Draw(img)
        for h in self.hex_lit:
            col_i, row_i = h["cx"] % int(W / dx + 2), h["cy"] % int(H / (dy * 2) + 2)
            x = -R + col_i * dx
            y = -dy + (dy if col_i % 2 else 0) + row_i * dy * 2
            a = 0.5 + 0.5 * math.sin(t * h["f"] * 3 + h["ph"])
            if a < 0.25:
                continue
            pts = [(x + R * math.cos(math.pi / 3 * i), y + R * math.sin(math.pi / 3 * i)) for i in range(6)]
            d.polygon(pts, fill=_mix(self.bg1, self.accent, 0.10 + 0.20 * a),
                      outline=_mix(self.bg1, self.accent2, 0.30 + 0.30 * a))
        self._particles(img, t, 10)
        return img

    def _bgf_warp(self, t):
        W, H, S = self.RW, self.RH, self.S

        def fn(gd, gw, gh):
            gd.ellipse([gw * 0.5 - gw * 0.35, gh * 0.5 - gh * 0.35, gw * 0.5 + gw * 0.35, gh * 0.5 + gh * 0.35],
                       fill=_scale(_mix(self.accent, self.alt, self._drift(t)), 0.10))
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.10))
        d = ImageDraw.Draw(img)
        cx, cy = W / 2, H / 2
        diag = math.hypot(W, H) / 2
        for s in self.stars:
            z = (s["r"] - t * s["v"]) % 1.0 + 0.02
            r0 = (s["r"] * 0.0 + (1.0 / (z * 6.0))) * 0.06 * diag
            r1 = r0 * (1.0 + 0.55 * min(1.0, 0.25 / z))
            if r0 > diag * 1.1:
                continue
            ca, sa = math.cos(s["a"]), math.sin(s["a"])
            b = min(1.0, 0.25 + 0.75 * (1 - z))
            col = _mix(self.bg1, (190, 205, 240), b * 0.8)
            d.line([(cx + ca * r0, cy + sa * r0), (cx + ca * r1, cy + sa * r1)], fill=col,
                   width=max(1, int(S * (1 + 1.5 * (1 - z)))))
        return img

    def _bgf_beams(self, t):
        def fn(gd, gw, gh):
            for b in self.beams:
                sw = math.sin(t * 6.283 / b["per"] + b["ph"])
                x = (b["x"] + 0.12 * sw) * gw
                ang = b["ang"] + 0.08 * math.cos(t * 6.283 / (b["per"] * 1.4) + b["ph"])
                w = b["w"] * gw
                dxy = math.tan(ang) * gh
                col = _scale(_mix(self.accent, self.alt, self._drift(t + b["ph"])), 0.30 * b["a"] * (0.7 + 0.3 * sw))
                gd.polygon([(x - w, 0), (x + w, 0), (x + w + dxy, gh), (x - w + dxy, gh)], fill=col)
        img = ImageChops.add(self.bg, self._glow_layer(fn, 0.035))
        self._particles(img, t, 18)
        return img
