"""LLM modellari va API kalitlarini boshqarish (sof funksiyalar; bot shularni chaqiradi).

Kalitlar hech qachon to'liq ko'rsatilmaydi: faqat maska (AIza…xyz).
"""
from __future__ import annotations

PROV = {
    "gemini": ("GEMINI_API_KEYS", "GEMINI_MODELS"),
    "groq": ("GROQ_API_KEYS", "GROQ_MODELS"),
    "openrouter": ("OPENROUTER_API_KEYS", "OPENROUTER_MODELS"),
    "pollinations": (None, "POLLINATIONS_MODELS"),
}
ALIAS = {"google": "gemini", "g": "gemini", "gr": "groq", "or": "openrouter", "router": "openrouter",
         "poll": "pollinations", "p": "pollinations"}


def norm(name: str):
    n = (name or "").strip().lower()
    n = ALIAS.get(n, n)
    return n if n in PROV else None


def mask(k: str) -> str:
    return k[:4] + "…" + k[-3:] if len(k) > 10 else "***"


# ---------------------------------------------------------------- kalitlar
def keys(cfg, prov):
    kk = PROV[prov][0]
    return cfg.list(kk) if kk else []


def _save_keys(cfg, prov, lst):
    cfg.set(PROV[prov][0], ",".join(lst))


def valid_key(k: str) -> bool:
    return 12 <= len(k) <= 300 and not any(c.isspace() or c == "," for c in k)


def add_key(cfg, prov, key):
    if not PROV[prov][0]:
        return False, f"{prov} uchun kalit kerak emas."
    key = key.strip()
    if not valid_key(key):
        return False, "Kalit shaklan noto'g'ri (bo'sh joy/vergulsiz, 12+ belgi bo'lishi kerak)."
    lst = keys(cfg, prov)
    if key in lst:
        return False, "Bu kalit allaqachon qo'shilgan."
    lst.append(key)
    _save_keys(cfg, prov, lst)
    return True, f"{prov}: kalit qo'shildi → #{len(lst)} ({mask(key)})"


def del_key(cfg, prov, idx):
    lst = keys(cfg, prov)
    if not (1 <= idx <= len(lst)):
        return False, f"Bunday raqam yo'q (1–{len(lst) or 0})."
    k = lst.pop(idx - 1)
    _save_keys(cfg, prov, lst)
    return True, f"{prov}: #{idx} ({mask(k)}) o'chirildi. Qolgan: {len(lst)} ta."


def edit_key(cfg, prov, idx, new):
    lst = keys(cfg, prov)
    new = new.strip()
    if not (1 <= idx <= len(lst)):
        return False, f"Bunday raqam yo'q (1–{len(lst) or 0})."
    if not valid_key(new):
        return False, "Yangi kalit shaklan noto'g'ri."
    if new in lst and lst.index(new) != idx - 1:
        return False, "Bu kalit ro'yxatda boshqa raqam ostida bor."
    old = lst[idx - 1]
    lst[idx - 1] = new
    _save_keys(cfg, prov, lst)
    return True, f"{prov}: #{idx} almashtirildi ({mask(old)} → {mask(new)})"


# ---------------------------------------------------------------- modellar
def models(cfg, prov):
    return cfg.list(PROV[prov][1])


def _save_models(cfg, prov, lst):
    cfg.set(PROV[prov][1], ",".join(lst))


def valid_model(m: str) -> bool:
    return 2 <= len(m) <= 120 and not any(c.isspace() or c == "," for c in m)


def add_model(cfg, prov, model, first=False):
    model = model.strip()
    if not valid_model(model):
        return False, "Model nomi noto'g'ri."
    lst = models(cfg, prov)
    if model in lst:
        return False, "Bu model allaqachon ro'yxatda."
    lst = [model] + lst if first else lst + [model]
    _save_models(cfg, prov, lst)
    return True, f"{prov}: model qo'shildi → <code>{model}</code>"


def resolve_model(cfg, prov, ref):
    lst = models(cfg, prov)
    if ref.isdigit() and 1 <= int(ref) <= len(lst):
        return lst[int(ref) - 1]
    return ref if ref in lst else None


def del_model(cfg, prov, ref):
    m = resolve_model(cfg, prov, ref)
    if not m:
        return False, "Model topilmadi (raqam yoki to'liq nom)."
    lst = [x for x in models(cfg, prov) if x != m]
    if not lst and prov != "pollinations":
        return False, "Oxirgi modelni o'chirib bo'lmaydi (avval yangisini qo'shing)."
    _save_models(cfg, prov, lst)
    return True, f"{prov}: <code>{m}</code> o'chirildi."


def use_model(cfg, prov, ref):
    """Modelni ro'yxat boshiga chiqaradi (= birinchi navbatda ishlatiladi)."""
    m = resolve_model(cfg, prov, ref)
    if not m:
        return False, "Model topilmadi (raqam yoki to'liq nom)."
    lst = [m] + [x for x in models(cfg, prov) if x != m]
    _save_models(cfg, prov, lst)
    return True, f"{prov}: asosiy model → <code>{m}</code>"


def edit_model(cfg, prov, ref, new):
    m = resolve_model(cfg, prov, ref)
    if not m:
        return False, "Model topilmadi."
    if not valid_model(new):
        return False, "Yangi nom noto'g'ri."
    lst = [new if x == m else x for x in models(cfg, prov)]
    _save_models(cfg, prov, list(dict.fromkeys(lst)))
    return True, f"{prov}: <code>{m}</code> → <code>{new}</code>"


def set_models(cfg, prov, names):
    lst = [x for x in dict.fromkeys(n.strip() for n in names) if valid_model(x)]
    if not lst:
        return False, "Ro'yxat bo'sh."
    _save_models(cfg, prov, lst)
    return True, f"{prov}: {len(lst)} ta model o'rnatildi."


# ---------------------------------------------------------------- tartib
def set_order(cfg, names):
    lst = []
    for n in names:
        p = norm(n)
        if not p:
            return False, f"Noma'lum provayder: {n}. Mavjud: {', '.join(PROV)}"
        if p not in lst:
            lst.append(p)
    if not lst:
        return False, "Ro'yxat bo'sh."
    cfg.set("LLM_ORDER", ",".join(lst))
    return True, "Tartib: " + " → ".join(lst)
