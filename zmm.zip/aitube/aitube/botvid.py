"""Videolar ro'yxati va "Qayta yaratilganlar" ni tugmalar orqali to'liq boshqarish."""
from __future__ import annotations

from pathlib import Path

from . import cleaner
from .util import clip, esc, fmt_dur, human_size

PAGE = 8
ICON = {"uploaded": "✅", "ready": "🟢", "planned": "🕓", "scripted": "⚙️", "rendered": "⚙️",
        "failed": "❌", "skipped": "⏭"}
STATUS = {"uploaded": "YouTube'ga yuklangan", "ready": "tayyor (yuklashni kutmoqda)", "planned": "rejada",
          "scripted": "ssenariy yozilgan, video tugamagan", "rendered": "video yasalgan", "failed": "xato",
          "skipped": "o'tkazib yuborilgan"}


def _has_file(e) -> bool:
    return bool(e.get("video_path")) and Path(e["video_path"]).exists()


class VideoMixin:
    # ------------------------------------------------------------- ro'yxat
    def c_videos(self, arg, chat):
        self._vd_list(int(arg) if arg.strip().isdigit() else 0, chat)

    def _vd_list(self, page, chat):
        a = self.app
        eps = a.db.all_episodes()
        seen, rows_ep = set(), []
        for e in eps:                       # bir gno ning faqat oxirgi yozuvi
            if e["gno"] not in seen:
                seen.add(e["gno"])
                rows_ep.append(e)
        pages = max(1, (len(rows_ep) + PAGE - 1) // PAGE)
        page = max(0, min(page, pages - 1))
        chunk = rows_ep[page * PAGE:(page + 1) * PAGE]
        n_reg = len(a.db.regen_list())
        lines = [f"🎞 <b>Videolar</b> · {len(rows_ep)} ta · sahifa {page + 1}/{pages}",
                 "✅ yuklangan · 🟢 tayyor · 🕓 rejada · ❌ xato · ⏭ o'tkazilgan · 💾 fayl bor", ""]
        kb = []
        for e in chunk:
            tag = ICON.get(e["status"], "•") + ("💾" if _has_file(e) else "")
            kb.append([(f"{tag} #{e['gno']} {clip(e['title'], 28)}", f"vd:ep:{e['gno']}:{page}")])
        nav = []
        if page > 0:
            nav.append(("◀️", f"vd:list:{page - 1}"))
        if page < pages - 1:
            nav.append(("▶️", f"vd:list:{page + 1}"))
        if nav:
            kb.append(nav)
        kb.append([(f"📁 Qayta yaratilganlar ({n_reg})", "vd:rg:0"), ("🧹 Tozalash", "vd:clean")])
        kb.append([(f"Avto-tozalash: {'✅ yoqiq' if a.cfg.bool('AUTO_CLEAN') else '⬜ o`chiq'}", "vd:ac"),
                   ("⬅️ Menyu", "m:menu")])
        self._screen(chat, "\n".join(lines), kb)

    # ------------------------------------------------------------- bitta epizod
    def _vd_ep(self, gno, page, chat):
        a = self.app
        e = a.db.ep_by_gno(gno)
        if not e:
            return self._vd_list(page, chat)
        has = _has_file(e)
        n_ver = len(a.db.regen_list(gno))
        lines = [f"{ICON.get(e['status'], '•')} <b>#{gno} {esc(clip(e['title'], 80))}</b>",
                 f"Holat: {STATUS.get(e['status'], e['status'])}",
                 f"Tur: {esc(e['kind'] or '-')} · fasl {e['season_id']}-qism {e['num']}"]
        if has:
            lines.append(f"💾 Fayl: {fmt_dur(e['duration'] or 0)} · {human_size(e['size_bytes'] or 0)}")
        else:
            lines.append("💾 Lokal fayl yo'q (tozalangan yoki hali yasalmagan)")
        if e["status"] == "uploaded":
            lines.append(f"🔗 {e['yt_url']} · 👁 {e['views'] or 0}")
        if e.get("error"):
            lines.append(f"⚠️ {esc(clip(e['error'], 160))}")
        kb = []
        if has:
            kb.append([("▶️ Videoni yuborish", f"vd:send:{gno}"), ("🖼 Muqova", f"vd:thumb:{gno}")])
        if e["status"] == "ready":
            kb.append([("⬆️ YouTube'ga yuklash", f"vd:up:{gno}")])
        if e["status"] == "uploaded":
            kb.append([("♻️ Unutib qayta yasash", f"vd:fr:{gno}"), ("🧽 Unutish", f"vd:fg:{gno}")])
        elif e["status"] == "skipped":
            kb.append([("↩️ Qaytarish", f"vd:unskip:{gno}"), ("🔄 Qayta yasash", f"vd:retry:{gno}")])
        else:
            kb.append([("🔄 Qayta yasash (saqlanadi)", f"vd:retry:{gno}"), ("⏭ O'tkazish", f"vd:skip:{gno}")])
        row = []
        if has:
            row.append(("🗑 Faylni o'chirish", f"vd:del:{gno}:{page}"))
        if n_ver:
            row.append((f"📁 Versiyalar ({n_ver})", f"vd:rgg:{gno}"))
        if row:
            kb.append(row)
        kb.append([("⬅️ Ro'yxat", f"vd:list:{page}")])
        self._screen(chat, "\n".join(lines), kb)

    # ------------------------------------------------------------- qayta yaratilganlar
    def c_regen(self, arg, chat):
        self._vd_regen(0, None, chat)

    def _vd_regen(self, page, gno, chat):
        a = self.app
        items = a.db.regen_list(gno)
        pages = max(1, (len(items) + PAGE - 1) // PAGE)
        page = max(0, min(page, pages - 1))
        lines = [f"📁 <b>Qayta yaratilganlar</b>" + (f" · #{gno}" if gno else "") + f" · {len(items)} ta",
                 "Bu yerdagi videolarga avto-tozalash tegmaydi.", ""]
        kb = []
        for r in items[page * PAGE:(page + 1) * PAGE]:
            ok = "💾" if r["video_path"] and Path(r["video_path"]).exists() else "⚠️"
            kb.append([(f"{ok} #{r['gno']} v{r['id']} · {fmt_dur(r['duration'] or 0)} · {(r['created'] or '')[5:16]}",
                        f"vd:rge:{r['id']}")])
        if not items:
            lines.append("(hali yo'q — «🔄 Qayta yasash» yoki /retry N bilan yasalganlar shu yerga tushadi)")
        nav = []
        if page > 0:
            nav.append(("◀️", f"vd:rg:{page - 1}"))
        if page < pages - 1:
            nav.append(("▶️", f"vd:rg:{page + 1}"))
        if nav:
            kb.append(nav)
        kb.append([("⬅️ Videolar", "vd:list:0")])
        self._screen(chat, "\n".join(lines), kb)

    def _vd_regen_item(self, rid, chat):
        r = self.app.db.regen_get(rid)
        if not r:
            return self._vd_regen(0, None, chat)
        ok = r["video_path"] and Path(r["video_path"]).exists()
        txt = (f"📁 <b>#{r['gno']} · versiya {r['id']}</b>\n{esc(clip(r['title'], 80))}\n"
               f"⏱ {fmt_dur(r['duration'] or 0)} · {human_size(r['size_bytes'] or 0)} · {(r['created'] or '')[:16]}\n"
               + ("" if ok else "⚠️ Fayl topilmadi\n")
               + "«Asosiy qilish»: shu video epizodning yuklanadigan videosi bo'ladi (tavsif joriy ssenariydan olinadi).")
        kb = [[("▶️ Yuborish", f"vd:rgs:{rid}"), ("✅ Asosiy qilish", f"vd:rgu:{rid}")],
              [("🗑 O'chirish", f"vd:rgd:{rid}"), ("⬅️ Orqaga", "vd:rg:0")]]
        self._screen(chat, txt, kb)

    # ------------------------------------------------------------- callback
    def vd_callback(self, val, chat):
        a = self.app
        p = val.split(":")
        act = p[0]
        n = int(p[1]) if len(p) > 1 and p[1].lstrip("-").isdigit() else 0
        n2 = int(p[2]) if len(p) > 2 and p[2].isdigit() else 0
        if act == "list":
            return self._vd_list(n, chat)
        if act == "ep":
            return self._vd_ep(n, n2, chat)
        if act == "rg":
            return self._vd_regen(n, None, chat)
        if act == "rgg":
            return self._vd_regen(0, n, chat)
        if act == "rge":
            return self._vd_regen_item(n, chat)
        if act == "ac":
            a.cfg.set("AUTO_CLEAN", "0" if a.cfg.bool("AUTO_CLEAN") else "1")
            return self._vd_list(0, chat)
        if act == "clean":
            return self.c_clean("", chat)
        if act == "send":
            out = self.c_video(str(n), chat)
            return self.tg.send(out, chat=chat) if out else None
        if act == "thumb":
            e = a.db.ep_by_gno(n)
            if e and e.get("thumb_path") and Path(e["thumb_path"]).exists():
                a.jobs.submit_light(f"thumb-{n}", lambda: a.n.file("photo", e["thumb_path"], f"Muqova · #{n}"))
            else:
                self.tg.send("ℹ️ Muqova fayli yo'q.", chat=chat)
            return None
        if act == "up":
            e = a.db.ep_by_gno(n)
            if e and a.jobs.submit(f"upload-{e['id']}", a.pipeline.upload_episode, e):
                self.tg.send(f"✅ #{n} yuklash navbatga qo'yildi.", chat=chat)
            else:
                self.tg.send("ℹ️ Navbatda yoki epizod topilmadi.", chat=chat)
            return None
        if act == "retry":
            out = self.c_retry(str(n), chat)
            return self.tg.send(out, chat=chat) if out else None
        if act in ("skip", "unskip", "fg"):
            e = a.db.ep_by_gno(n)
            if not e:
                return None
            ep_act = {"skip": "skip", "unskip": "unskip", "fg": "forget"}[act]
            out = self._ep_callback(ep_act, n, chat)
            if out:
                self.tg.send(out, chat=chat)
            return None
        if act == "fr":     # yuklanganni unutib, qayta yasash va saqlash
            e = a.db.ep_by_gno(n)
            if e:
                a.db.kv_set(f"keep_regen:{e['id']}", "1")
                out = self._forget(n, chat, False)
                if out:
                    self.tg.send(out, chat=chat)
            return None
        if act == "del":
            return self._screen(chat, f"🗑 #{n} videosining lokal faylini o'chirasizmi?\n"
                                      "(YouTube'dagi video va rejadagi ma'lumot qolaveradi)",
                                [[("✅ Ha, o'chirish", f"vd:delok:{n}:{n2}"), ("✖️ Yo'q", f"vd:ep:{n}:{n2}")]])
        if act == "delok":
            e = a.db.ep_by_gno(n)
            if e:
                ch = {}
                for k in ("video_path", "thumb_path", "srt_path"):
                    if e.get(k):
                        try:
                            Path(e[k]).unlink()
                        except OSError:
                            pass
                        ch[k] = None
                if ch:
                    a.db.ep_update(e["id"], **ch)
                    if e["status"] in ("ready", "rendered"):
                        a.db.ep_update(e["id"], status="planned", script_json=None, summary=None)
            return self._vd_ep(n, n2, chat)
        if act == "rgs":
            r = a.db.regen_get(n)
            if r and r["video_path"] and Path(r["video_path"]).exists():
                a.jobs.submit_light(f"rgsend-{n}", lambda: a.n.file(
                    "video", r["video_path"], f"▶️ #{r['gno']} · versiya {r['id']} {esc(clip(r['title'], 60))}"))
            else:
                self.tg.send("⚠️ Fayl topilmadi.", chat=chat)
            return None
        if act == "rgu":
            err = cleaner.promote_regenerated(a.cfg, a.db, n)
            r = a.db.regen_get(n)
            self.tg.send(("⚠️ Bo'lmadi: " + esc(err)) if err else
                         f"✅ #{r['gno']} uchun versiya {n} asosiy qilindi (holat: tayyor). Yuklash: /upload",
                         chat=chat)
            return None
        if act == "rgd":
            return self._screen(chat, f"🗑 Versiya {n} butunlay o'chiriladi. Tasdiqlaysizmi?",
                                [[("✅ Ha", f"vd:rgdok:{n}"), ("✖️ Yo'q", f"vd:rge:{n}")]])
        if act == "rgdok":
            cleaner.delete_regenerated(a.db, n)
            return self._vd_regen(0, None, chat)
        return None

    # ------------------------------------------------------------- tozalash va /retry
    def c_autoclean(self, arg, chat):
        a = self.app
        v = arg.strip().lower()
        if v in ("on", "1", "ha", "yoq"):
            a.cfg.set("AUTO_CLEAN", "1")
        elif v in ("off", "0", "yoq", "yo'q"):
            a.cfg.set("AUTO_CLEAN", "0")
        return (f"🧹 Avto-tozalash: <b>{'yoqiq' if a.cfg.bool('AUTO_CLEAN') else 'o`chiq'}</b>\n"
                "Oxirgi yaratilgan video (va yuklashni kutayotganlar) qoladi, qolganlari butunlay o'chadi. "
                "«Qayta yaratilganlar» ga tegilmaydi.\n/autoclean on|off")

    # ------------------------------------------------------------- talaffuz lug'ati
    def c_pron(self, arg, chat):
        """/pron | /pron so'z talaffuz | /pron del so'z | /pron test matn"""
        from . import pronounce, speak
        a = self.app
        arg = arg.strip()
        user = dict(a.db.kv_json(pronounce.KV_USER, {}) or {})
        auto = dict(a.db.kv_json(pronounce.KV_AUTO, {}) or {})
        if not arg:
            lines = [f"• <code>{esc(k)}</code> → {esc(v)}" for k, v in list(user.items())[-40:]]
            return ("🔤 <b>Ingliz so'zlar talaffuzi</b>\n"
                    f"O'rnatilgan lug'at: {len(speak.EN)} so'z · AI aniqlagan: {len(auto)} · sizniki: {len(user)}\n\n"
                    + ("<b>Sizning so'zlaringiz:</b>\n" + "\n".join(lines) + "\n\n" if lines else "")
                    + "Qo'shish: <code>/pron shape sheyp</code>\n"
                    "O'chirish: <code>/pron del shape</code>\n"
                    "Eshitmasdan tekshirish: <code>/pron test Pandas da shape ni ko'ring</code>")
        head, _, rest = arg.partition(" ")
        head_l = head.lower()
        rest = rest.strip()
        if head_l == "test":
            if not rest:
                return "Matn yozing: /pron test df.shape ni chiqaring"
            return f"🗣 Ovoz shunday o'qiydi:\n<code>{esc(speak.speak_text(rest[:600]))}</code>"
        if head_l in ("del", "rm", "o'chir"):
            key = rest.lower()
            if key in user:
                user.pop(key)
                a.db.kv_set_json(pronounce.KV_USER, user)
                pronounce.activate(a.db)
                return f"🗑 «{esc(key)}» o'chirildi."
            if key in auto:
                auto.pop(key)
                a.db.kv_set_json(pronounce.KV_AUTO, auto)
                pronounce.activate(a.db)
                return f"🗑 «{esc(key)}» (AI aniqlagan) o'chirildi."
            return "Bunday so'z lug'atda yo'q."
        val = rest.lower()
        if not rest or not pronounce._KEY.match(head) or not pronounce._VAL.match(val):
            return ("ℹ️ Format: <code>/pron so'z talaffuz</code>\nMasalan: <code>/pron shape sheyp</code> "
                    "(talaffuz faqat a-z harf, bo'sh joy, apostrof va defis).")
        if len(user) >= 2000:
            return "Lug'at to'lib ketdi (2000)."
        user[head_l] = val
        a.db.kv_set_json(pronounce.KV_USER, user)
        pronounce.activate(a.db)
        return f"✅ «{esc(head)}» endi «{esc(val)}» deb o'qiladi.\n{esc(speak.speak_text(head))}"

    def c_clean(self, arg, chat):
        a = self.app

        def run():
            return cleaner.clean(a.cfg, a.db, force=True)

        from .util import disk_free_mb
        return self._mutate("clean", run, chat,
                            lambda r: f"🧹 Tozalandi: {r['files']} fayl, {r['bytes'] / 1048576:.1f} MB bo'shadi. "
                                      f"Bo'sh joy: {disk_free_mb(a.cfg.data)} MB.", resume=False)

    def c_retry(self, arg, chat):
        a = self.app
        if arg.strip().isdigit():
            e = a.db.ep_by_gno(int(arg))
            if not e:
                return "Epizod topilmadi."
            if e["status"] == "uploaded":
                self._confirm(chat, f"#{e['gno']} YouTube'ga yuklangan. Uni unutib, noldan qayta yasaymi? "
                                    "(yangi video «Qayta yaratilganlar» ga ham saqlanadi)",
                              f"vd:fr:{e['gno']}", "♻️ Ha, qayta yasash")
                return None
            self.ask_remake(e, chat, keep=True)
            return None
        n = a.pipeline.retry_failed()
        a.jobs.submit("make", a.pipeline.produce_next)
        return (f"🔁 {n} ta epizod qayta urinishga qo'yildi, ishlab chiqarish davom etadi.\n"
                "Aniq epizodni qayta yasash: /retry 5")
