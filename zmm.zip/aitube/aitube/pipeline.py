"""Asosiy zanjir: reja -> ssenariy -> ovoz -> video -> muqova -> (tasdiq) -> YouTube -> statistika."""
from __future__ import annotations

import shutil
import threading
import time
from pathlib import Path

from . import bgfx, cleaner, planner, pronounce, schedule as sched, writer
from .compose import (build_description, compose_scenes, episode_label, next_line, next_marker,
                      yt_title)
from .llm import LLM, LLMError
from .render import Renderer
from .tg import Board, Notifier, Telegram
from .thumb import make_thumbnail
from .tts import TTS, TTSError
from .util import (clip, esc, export_to_downloads, telegram_copy, fmt_dur, human_size, iso_now, json_dumps, log, tb_short)
from .video import VideoBuilder, VideoError, chapters
from .youtube import YouTube, YTError

MAX_TRIES = 3
# epizod .json fayliga yozilmaydigan (katta/ichki) sahna kalitlari
_HEAVY_KEYS = {"audio", "wav", "words", "wtimes", "chunks", "rf", "hl_off", "unit_rel", "unit_anim"}


class PipelineError(Exception):
    pass


class _UploadSession:
    """YouTube resumable yuklash manzili bazada saqlanadi: dastur o'chib yonsa yoki internet uzilsa,
    yuklash noldan emas, to'xtagan joyidan davom etadi."""

    def __init__(self, db, ep_id):
        self.db, self.key = db, f"upload_session:{ep_id}"

    def get(self):
        return self.db.kv_get(self.key) or None

    def set(self, loc):
        self.db.kv_set(self.key, loc)

    def clear(self):
        self.db.kv_del(self.key)


class Pipeline:
    def __init__(self, cfg, db, llm: LLM, tts: TTS, yt: YouTube, tg: Telegram, notifier: Notifier):
        self.cfg, self.db, self.llm, self.tts, self.yt, self.tg, self.n = cfg, db, llm, tts, yt, tg, notifier
        self.work_lock = threading.RLock()
        self.say = notifier.say
        try:
            pronounce.activate(db)
        except Exception:
            pass

    # ------------------------------------------------------------------ yordamchi
    def _paths(self, gno):
        return (self.cfg.dirs["work"] / f"ep{gno:03d}", self.cfg.dirs["out"] / f"ep{gno:03d}.mp4",
                self.cfg.dirs["out"] / f"ep{gno:03d}.jpg")

    def halted(self):
        return self.db.kv_get("halt_reason")

    def next_planned(self):
        # 'scripted' = ssenariy yozilgan, lekin video tugamagan (dastur o'chgan/uzilgan): shundan davom etadi
        pl = self.db.by_status("scripted", "planned")
        return pl[0] if pl else None

    def ready_episodes(self):
        return self.db.by_status("ready")

    def chain_blocker(self, ep):
        """ep yuklanishidan oldin yuklanishi kerak bo'lgan epizod (bo'lsa)."""
        r = self.db.q("SELECT gno,title,status FROM episodes WHERE gno<? AND status IN "
                      "('planned','scripted','rendered','ready','failed') ORDER BY gno LIMIT 1", (ep["gno"],), one=True)
        return dict(r) if r else None

    # ------------------------------------------------------------------ ishlab chiqarish
    def produce_next(self, ep=None) -> dict | None:
        """Keyingi rejalashtirilgan epizodni to'liq tayyorlaydi. Tayyor epizodni (yoki None) qaytaradi."""
        with self.work_lock:
            if self.halted() and ep is None:
                self.say(f"⏸ Ishlab chiqarish to'xtatilgan: {esc(self.halted())}\n/retry yoki /skip bilan davom ettiring.")
                return None
            try:
                planner.ensure_plan(self.cfg, self.db, self.llm, self.say)
            except Exception as e:
                self.n.error("Reja tuzib bo'lmadi", f"{e}")
                return None
            ep = ep or self.next_planned()
            if not ep:
                self.say("ℹ️ Rejalashtirilgan epizod yo'q.")
                return None
            return self._produce(ep)

    def _produce(self, ep) -> dict | None:
        cfg, db = self.cfg, self.db
        gno = ep["gno"]
        t_start = time.time()
        board = Board(self.n, f"🎬 Epizod #{gno} tayyorlanmoqda")
        board.set("t", f"<b>{esc(ep['title'])}</b>\n<i>{esc(ep['kind'])} · {cfg.get('VIDEO_FORMAT')}</i>", force=True)
        workdir, out, thumb = self._paths(gno)
        try:
            # ---- 1) ssenariy
            t0 = time.time()
            cur0 = db.ep(ep["id"])
            if cur0["status"] == "scripted" and cur0.get("script") and cur0["script"].get("scenes"):
                script = cur0["script"]     # oldingi urinishdagi tayyor ssenariy: qayta yozilmaydi
                board.set("s", f"📝 Ssenariy oldin yozilgan, davom etilmoqda ({len(script['scenes'])} sahna)", force=True)
            else:
                board.set("s", "📝 Ssenariy yozilmoqda…", force=True)
                script = writer.write_episode(cfg, db, self.llm, cur0, self.say)
                script["title"] = ep["title"]   # oldingi qism va'da qilgan sarlavha o'zgarmaydi
                db.kv_del("admin_note")
                db.ep_update(ep["id"], script=script, summary=script["summary"], status="scripted",
                             llm=script["llm"])
                board.set("s", f"📝 Ssenariy tayyor: {len(script['scenes'])} sahna, {script['words']} so'z · "
                               f"{esc(script['llm'])} · {time.time() - t0:.0f}s", force=True)
            # ---- 2) sahnalar
            prev, nxt = db.prev_episode(gno), db.next_planned_after(gno)
            scenes = compose_scenes(cfg, db.ep(ep["id"]), script, prev, nxt)
            art: dict = {}                  # AI rasm yaratilmaydi (butunlay o'chirilgan): odatdagi chizilgan ko'rinish
            board.set("p", "🔤 Ingliz so'zlar talaffuzi aniqlanmoqda…")
            pronounce.build(cfg, db, self.llm, scenes)
            total_scenes = len(scenes)
            # ---- 3) video
            workdir.mkdir(parents=True, exist_ok=True)
            accent = (db.season(ep["season_id"]) or {}).get("id", 0)
            bgs = (cfg.get("BG_STYLE") or "auto").strip().lower()
            style = bgfx.style_for(gno) if bgs not in bgfx.STYLES else bgs

            rargs = dict(accent_idx=accent, episode_label=episode_label(cfg, gno), channel=cfg.get("CHANNEL_NAME"),
                         style=style, seed=gno)

            def make_renderer():
                return Renderer(cfg, **rargs)

            vb = VideoBuilder(cfg, self.tts)
            vb.anim_fps = cfg.int("VIDEO_ANIM_FPS")

            def prog(stage, a, b, info=""):
                if stage == "tts":
                    board.set("a", f"🎙 Ovoz: {a}/{b} sahna {esc(info)}")
                elif stage == "frames":
                    board.set("f", f"🖼 Kadrlar: {a}/{b} sahna")
                elif stage == "encode":
                    board.set("e", "🎞 Kadrlar chizilib, ffmpeg bilan kodlanmoqda…", force=True)

            res = vb.build(scenes, workdir, out, make_renderer, prog, rargs=rargs)
            board.set("e", f"🎞 Video tayyor: {fmt_dur(res['duration'])} · {human_size(res['size'])}"
                           + (f" · {esc(res['encoder'])}" if res.get("encoder") else ""), force=True)
            # ---- 4) muqova
            make_thumbnail(cfg, thumb, script["thumb_text"], gno, cfg.get("CHANNEL_NAME"), accent,
                           art=art.get("thumb") if art.get("thumb") is not None else art.get("bg"))
            tts_used = ", ".join(f"{k}×{v}" for k, v in res["tts_providers"].items())
            db.ep_update(ep["id"], video_path=str(out), thumb_path=str(thumb), srt_path=str(res["srt"]),
                         duration=res["duration"], size_bytes=res["size"], status="ready", tts=tts_used,
                         render_sec=time.time() - t_start, error=None)
            import json as _json
            (self.cfg.dirs["out"] / f"ep{gno:03d}.json").write_text(
                _json.dumps({"title": script["title"], "summary": script["summary"], "script": script,
                             "scenes": [{k: v for k, v in s.items() if k not in _HEAVY_KEYS} for s in scenes]},
                            ensure_ascii=False, indent=1, default=str), encoding="utf-8")
            board.set("z", f"✅ Tayyor · jami {time.time() - t_start:.0f}s", force=True)
            ready = db.ep(ep["id"])
            # tavsif uchun 'start' vaqtlari scenes ichida; saqlab qo'yamiz
            ready_meta = {"chapters": [(round(t, 1), n) for t, n in chapters(scenes)],
                          "scene_count": total_scenes, "frames": res["frames"], "music": res["music"],
                          "timings": {"tts": round(res["t_tts"], 1), "frames": round(res["t_frames"], 1),
                                      "encode": round(res["t_encode"], 1)}}
            plan = ready["plan"]
            plan["meta"] = ready_meta
            plan["scenes_starts"] = [round(s.get("start", 0), 2) for s in scenes]
            plan["scene_chapters"] = [s.get("chapter", "") for s in scenes]
            db.ep_update(ep["id"], plan=plan)
            self._report_ready(db.ep(ep["id"]), res, scenes)
            shutil.rmtree(workdir, ignore_errors=True)
            db.kv_set("last_created_gno", str(gno))   # avto-tozalash shu videoni eslab qoladi
            if db.kv_get(f"keep_regen:{ep['id']}"):
                db.kv_del(f"keep_regen:{ep['id']}")
                rid = cleaner.save_regenerated(cfg, db, db.ep(ep["id"]), "qo'lda qayta yasalgan")
                if rid:
                    self.say(f"📁 #{gno} «Qayta yaratilganlar» ga saqlandi (versiya #{rid}). Boshqarish: /regen",
                             markup={"inline_keyboard": [[{"text": "📁 Qayta yaratilganlar", "callback_data": "vd:rg:0"}]]})
            self._auto_clean()
            return db.ep(ep["id"])
        except Exception as e:
            return self._fail(ep, e, board)

    def _fail(self, ep, e, board=None):
        db = self.db
        cur = db.ep(ep["id"])
        tries = (cur["tries"] or 0) + 1
        detail = f"{type(e).__name__}: {e}"
        log.error("Epizod #%s xatosi: %s\n%s", ep["gno"], detail, tb_short(3000))
        if tries >= MAX_TRIES:
            db.ep_update(ep["id"], status="failed", tries=tries, error=detail[:800])
            db.kv_set("halt_reason", f"#{ep['gno']} epizod {MAX_TRIES} marta muvaffaqiyatsiz: {clip(detail, 160)}")
            msg = (f"⛔ <b>Epizod #{ep['gno']} {MAX_TRIES} urinishdan keyin ham tayyor bo'lmadi</b>\n"
                   f"<pre>{esc(clip(detail, 900))}</pre>\nIshlab chiqarish to'xtatildi. "
                   f"Muammoni hal qilib /retry yuboring yoki /skip {ep['gno']}.")
        else:
            db.ep_update(ep["id"], status="planned", tries=tries, error=detail[:800])
            msg = (f"⚠️ <b>Epizod #{ep['gno']} xatosi</b> (urinish {tries}/{MAX_TRIES})\n"
                   f"<pre>{esc(clip(detail, 900))}</pre>\nKeyingi jadvalda qayta uriniladi (yoki /make).")
        if board:
            board.set("z", "❌ Xato", force=True)
        self.say(msg)
        shutil.rmtree(self._paths(ep["gno"])[0], ignore_errors=True)
        return None

    def _report_ready(self, ep, res, scenes):
        cfg = self.cfg
        sc = ep["script"]
        meta = ep["plan"].get("meta", {})
        ch = chapters(scenes)
        txt = [
            f"🎬 <b>Epizod #{ep['gno']} tayyor</b>",
            f"<b>{esc(sc['title'])}</b>",
            f"🗂 Tur: {esc(ep['kind'])} · fasl qismi {ep['num']}",
            f"⏱ {fmt_dur(res['duration'])} · 📦 {human_size(res['size'])} · 🖼 {res['frames']} kadr · "
            f"🎼 musiqa: {'ha' if res['music'] else 'yo`q'}",
            f"🤖 LLM: {esc(ep['llm'])}",
            f"🎙 Ovoz: {esc(ep['tts'])}",
            f"⚙️ Vaqt: ovoz {res['t_tts']:.0f}s, kadr chizish+kodlash {res['t_frames'] + res['t_encode']:.0f}s "
            f"(jami {ep['render_sec']:.0f}s)",
            "",
            f"<b>Xulosa:</b> {esc(clip(ep['summary'], 500))}",
        ]
        if sc.get("recap"):
            txt.append(f"\n🔗 <b>Oldingi qismga bog'lanish:</b> {esc(clip(sc['recap'], 300))}")
        txt.append(f"🔜 <b>Keyingi qismga chorlov:</b> {esc(clip(sc['teaser'], 300))}")
        if ch:
            txt.append("\n📑 Bo'limlar: " + " · ".join(f"{fmt_dur(t)} {esc(clip(n, 24))}" for t, n in ch[:8]))
        if cfg.bool("APPROVAL_MODE"):
            txt.append("\n👇 Tasdiqlaysizmi?")
        self.say("\n".join(txt))
        markup = None
        if cfg.bool("APPROVAL_MODE"):
            markup = {"inline_keyboard": [[
                {"text": "✅ Yuklash", "callback_data": f"approve:{ep['id']}"},
                {"text": "🔄 Qayta yasash", "callback_data": f"regen:{ep['id']}"},
                {"text": "⏭ O'tkazib yuborish", "callback_data": f"skip:{ep['id']}"}]]}
        try:
            if ep["thumb_path"] and Path(ep["thumb_path"]).exists():
                self.n.file("photo", ep["thumb_path"], f"Muqova · #{ep['gno']}")
            tgp = telegram_copy(ep["video_path"]) if cfg.bool("SEND_VIDEO_TO_ADMIN") and ep["size_bytes"] else None
            if tgp:
                sent = self.n.file("video", str(tgp), f"▶️ #{ep['gno']} {esc(clip(sc['title'], 80))}", markup=markup)
                if not sent:
                    dst = export_to_downloads(ep["video_path"])
                    self.say(f"⚠️ Video Telegramga yuklanmadi (tarmoq sekin). "
                             + (f"Fayl telefon Yuklanmalar papkasiga nusxalandi: <code>{esc(dst.name)}</code>. " if dst else
                                f"Fayl: <code>{esc(ep['video_path'])}</code>. ")
                             + f"Qayta yuborish: /video {ep['gno']}", markup=markup)
            elif markup:
                self.say("Video Telegramga yuborilmadi (juda katta yoki o'chirilgan).", markup=markup)
        except Exception as e:  # yuborilmasa ham ish davom etadi
            log.warning("Hisobotni yuborishda xato: %s", e)

    # ------------------------------------------------------------------ yuklash
    def can_upload(self) -> str | None:
        if not self.yt.configured():
            return "YT_CLIENT_ID / YT_CLIENT_SECRET sozlanmagan"
        if not self.yt.authorized():
            return "YouTube avtorizatsiyadan o'tilmagan (/auth)"
        until = float(self.db.kv_get("upload_block_until", "0") or 0)
        if until > time.time():
            return f"yuklash {fmt_dur(until - time.time())} gacha to'xtatilgan (kvota)"
        return None

    def upload_episode(self, ep) -> dict | None:
        cfg, db = self.cfg, self.db
        with self.work_lock:
            ep = db.ep(ep["id"])
            if ep["status"] == "uploaded":
                return ep
            if ep["status"] != "ready":
                self.say(f"ℹ️ #{ep['gno']} hali tayyor emas (holati: {ep['status']}).")
                return None
            why = self.can_upload()
            if why:
                self.say(f"ℹ️ #{ep['gno']} yuklanmadi: {esc(why)}")
                return None
            blk = self.chain_blocker(ep)
            if blk:
                self.say(f"⛓ #{ep['gno']} dan oldin #{blk['gno']} «{esc(clip(blk['title'], 50))}» "
                         f"({blk['status']}) hal bo'lishi kerak - zanjir tartibi saqlanadi.")
                return None
            if not Path(ep["video_path"] or "").exists():
                self.say(f"❌ #{ep['gno']} video fayli topilmadi. /remake {ep['gno']}")
                return None
            sc = ep["script"]
            scenes = self._scenes_for_desc(ep)
            prev_up = db.prev_uploaded(ep["gno"])
            nxt = db.next_planned_after(ep["gno"])
            desc = build_description(cfg, ep, sc, scenes, prev_up["yt_url"] if prev_up else None,
                                     nxt["title"] if nxt else None, prev_up["title"] if prev_up else "")
            title = yt_title(cfg, ep, sc)
            board = Board(self.n, f"⬆️ YouTube ga yuklanmoqda · #{ep['gno']}")
            pub_dt = sched.pick_time(cfg, db, ep) if sched.active(cfg) else None
            pub_at = sched.to_iso(pub_dt) if pub_dt else None
            board.set("t", f"<b>{esc(title)}</b>\n🔒 {'private → ' + sched.fmt_local(cfg, pub_dt) if pub_dt else cfg.get('YT_PRIVACY')}"
                           f" · {human_size(ep['size_bytes'] or 0)}", force=True)
            last_pct = [-1]

            def prog(done, total):
                pct = int(done * 100 / max(1, total))
                if pct != last_pct[0]:
                    last_pct[0] = pct
                    board.set("p", f"📤 {pct}% ({human_size(done)} / {human_size(total)})")

            t0 = time.time()
            try:
                resp = self.yt.upload(ep["video_path"], title, desc, sc.get("tags", []), cfg.get("YT_PRIVACY"),
                                      cfg.get("YT_CATEGORY"), cfg.bool("YT_SYNTHETIC"), prog,
                                      session=_UploadSession(db, ep["id"]), publish_at=pub_at)
            except YTError as e:
                board.set("p", "❌ yuklash xatosi", force=True)
                if e.quota:
                    db.kv_set("upload_block_until", str(time.time() + 4 * 3600))
                    self.say(f"⏳ <b>YouTube kvotasi tugadi</b>: {esc(clip(str(e), 300))}\n4 soatdan keyin qayta uriniladi.")
                elif e.auth:
                    self.say("🔑 <b>YouTube avtorizatsiyasi yaroqsiz.</b> /auth buyrug'i bilan qayta kiring.\n"
                             f"<pre>{esc(clip(str(e), 300))}</pre>")
                else:
                    db.ep_update(ep["id"], error=str(e)[:500])
                    self.say(f"❌ <b>Yuklash xatosi #{ep['gno']}</b>\n<pre>{esc(clip(str(e), 800))}</pre>")
                return None
            vid = resp["id"]
            url = f"https://youtu.be/{vid}"
            final_priv = (resp.get("status") or {}).get("privacyStatus", cfg.get("YT_PRIVACY"))
            db.ep_update(ep["id"], yt_id=vid, yt_url=url, status="uploaded", uploaded=iso_now(), error=None,
                         publish_at=pub_at, pub_state="scheduled" if pub_at else "public")
            board.set("p", f"✅ Yuklandi · {time.time() - t0:.0f}s", force=True)
            extra = []
            # muqova
            try:
                self.yt.set_thumbnail(vid, ep["thumb_path"])
                extra.append("🖼 muqova o'rnatildi")
            except Exception as e:
                extra.append(f"⚠️ muqova o'rnatilmadi ({esc(clip(str(e), 120))})")
            # pleylist
            if cfg.bool("YT_PLAYLIST_PER_SEASON"):
                try:
                    from .playlist import sync_season
                    notes = sync_season(self.yt, db, cfg, ep["season_id"])
                    extra += notes or ["📚 pleylist tekshirildi"]
                except Exception as e:
                    extra.append(f"⚠️ pleylist: {esc(clip(str(e), 120))}")
            # oldingi videoning tavsifiga "keyingi qism" havolasini yozish
            if prev_up:
                try:
                    self.yt.set_description_line(prev_up["yt_id"], next_marker(cfg),
                                                 next_line(cfg, ep["title"], url))
                    extra.append(f"🔗 #{prev_up['gno']} tavsifiga keyingi qism havolasi yozildi")
                except Exception as e:
                    extra.append(f"⚠️ oldingi tavsif yangilanmadi: {esc(clip(str(e), 120))}")
            warn = ""
            if pub_at and final_priv == "private":
                warn = (f"\n\n⏰ <b>Chiqish vaqti: {sched.fmt_local(cfg, pub_dt)}</b> ({sched.eta(pub_dt)}). "
                        f"YouTube o'zi ochadi. Boshqarish: /schedule")
            elif final_priv != cfg.get("YT_PRIVACY"):
                warn = (f"\n\n⚠️ <b>Video «{final_priv}» holatida qoldi</b> (so'ralgan: {cfg.get('YT_PRIVACY')}). "
                        "Tekshirilmagan (unverified) Google Cloud loyihalari yuklagan videolar YouTube tomonidan "
                        "maxfiy qilib qo'yiladi. Yechim: loyihani API audit (compliance) dan o'tkazing yoki "
                        "videolarni YouTube Studio dan qo'lda ochiq qiling.")
            self.say(f"🚀 <b>Yuklandi! #{ep['gno']}</b>\n{esc(title)}\n🔗 {url}\n🔒 {final_priv + ' → ' + sched.fmt_local(cfg, pub_dt) if pub_at else final_priv}\n" + "\n".join(extra) + warn)
            self._auto_clean()
            return db.ep(ep["id"])

    def _scenes_for_desc(self, ep) -> list:
        plan = ep["plan"]
        starts, chs = plan.get("scenes_starts", []), plan.get("scene_chapters", [])
        return [{"start": s, "chapter": c} for s, c in zip(starts, chs)]

    def _auto_clean(self):
        try:
            if self.cfg.bool("AUTO_CLEAN"):
                cleaner.clean(self.cfg, self.db)
            else:
                self._cleanup_local()
        except Exception as e:  # noqa: BLE001  tozalash hech qachon ishni to'xtatmasin
            log.warning("Avto-tozalash xatosi: %s", e)

    def _cleanup_local(self):
        keep = max(1, self.cfg.int("KEEP_LOCAL_VIDEOS"))
        ups = self.db.uploaded(200)
        for e in ups[keep:]:
            for k in ("video_path", "thumb_path", "srt_path"):
                p = e.get(k)
                if p and Path(p).exists():
                    try:
                        Path(p).unlink()
                    except OSError:
                        pass
        cutoff = time.time() - 14 * 86400
        for f in self.cfg.dirs["cache"].glob("tts_*.wav"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except OSError:
                pass

    # ------------------------------------------------------------------ qo'l bilan boshqaruv
    def regenerate(self, ep_id, keep=False, new_script=True, new_voice=True):
        """Epizodni qayta yasaydi (tasdiqlanmagan yoki xato bo'lsa).
        keep=True: tayyor video "Qayta yaratilganlar" saqlamasiga ham qo'yiladi.
        new_script=False: eski ssenariy saqlanadi (yangi yozilmaydi).
        new_voice=True: ovoz hozirgi sozlamalar bilan noldan yaratiladi; False: keshdagi eski ovoz ishlatiladi
        (yangi ssenariy bilan ovoz doim yangidan yaratiladi)."""
        if keep:
            self.db.kv_set(f"keep_regen:{ep_id}", "1")
        with self.work_lock:
            ep = self.db.ep(ep_id)
            if not ep or ep["status"] == "uploaded":
                self.say("ℹ️ Bu epizodni qayta yasab bo'lmaydi (yuklangan yoki topilmadi).")
                return None
            for k in ("video_path", "thumb_path", "srt_path"):
                if ep.get(k) and Path(ep[k]).exists():
                    Path(ep[k]).unlink()
            has_script = bool(ep.get("script") and (ep["script"] or {}).get("scenes"))
            if new_script or not has_script:
                self.db.ep_update(ep_id, status="planned", tries=0, error=None, script_json=None,
                                  summary=None, video_path=None, thumb_path=None, srt_path=None)
                fresh = True
            else:
                self.db.ep_update(ep_id, status="scripted", tries=0, error=None,
                                  video_path=None, thumb_path=None, srt_path=None)
                fresh = bool(new_voice)
            self.db.kv_del("halt_reason")
            self.tts.fresh = fresh
            try:
                return self.produce_next(self.db.ep(ep_id))
            finally:
                self.tts.fresh = False

    def skip(self, ep_id):
        ep = self.db.ep(ep_id)
        if not ep or ep["status"] == "uploaded":
            return False
        self.db.ep_update(ep_id, status="skipped")
        if self.halted():
            self.db.kv_del("halt_reason")
        return True

    def retry_failed(self) -> int:
        n = 0
        for ep in self.db.by_status("failed"):
            self.db.ep_update(ep["id"], status="planned", tries=0, error=None)
            n += 1
        self.db.kv_del("halt_reason")
        return n

    # ------------------------------------------------------------------ jadval bo'yicha
    def run_slot(self) -> bool:
        """Jadvaldagi vaqt kelganda: tayyor epizodni yuklash, kerak bo'lsa avval yasash, buferni to'ldirish.
        True qaytarsa slot bajarilgan hisoblanadi."""
        cfg, db = self.cfg, self.db
        if cfg.bool("PAUSED"):
            return True
        self.say(f"⏰ <b>Jadval vaqti</b> · {cfg.get('UPLOAD_TIMES')} (UTC+{cfg.get('TZ_OFFSET')})")
        ready = self.ready_episodes()
        if not ready:
            made = self.produce_next()
            if not made:
                return False
            ready = [made]
        ep = ready[0]
        if cfg.bool("APPROVAL_MODE"):
            if not db.kv_get(f"approval_sent:{ep['id']}"):
                db.kv_set(f"approval_sent:{ep['id']}", "1")
                self.say(f"👆 #{ep['gno']} tasdiq kutmoqda (yuqoridagi video xabaridagi tugmalar yoki /upload).")
        elif cfg.bool("AUTO_UPLOAD"):
            why = self.can_upload()
            if why:
                self.say(f"ℹ️ Avto-yuklash o'tkazib yuborildi: {esc(why)}. Video tayyor, /upload bilan yuklang.")
            elif not self.upload_episode(ep):
                return False
        # bufer
        try:
            need = cfg.int("BUFFER_AHEAD")
            have = len(self.ready_episodes())
            if have < need and not self.halted():
                self.produce_next()
        except Exception as e:
            log.warning("Bufer to'ldirishda xato: %s", e)
        return True

    def upload_next_ready(self) -> bool:
        ready = self.ready_episodes()
        if not ready:
            self.say("ℹ️ Yuklash uchun tayyor epizod yo'q. /make bilan yasang.")
            return False
        return bool(self.upload_episode(ready[0]))
