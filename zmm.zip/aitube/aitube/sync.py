"""Ovoz va subtitrni sinxronlash: so'zlarning aniq vaqtlarini topish va subtitr bo'laklariga ajratish.

Har qanday ovoz provayderi (Edge, Google) bilan ishlashi uchun vaqtlar ovoz faylining o'zidan
(energiya chizig'i va pauzalar) aniqlanadi. Edge so'z chegaralarini bersa, ular ham ishlatiladi va
haqiqiy ovoz oralig'iga tekislanadi.
"""
from __future__ import annotations

import array
import re
import sys
import wave

HOP = 0.01           # energiya o'lchash qadami (s)
PAUSE_MIN = 0.14     # shundan uzun jimlik pauza hisoblanadi (s)


# --------------------------------------------------------------------- ovoz tahlili
def read_env(path, hop: float = HOP):
    """WAV dan energiya chizig'i (har `hop` soniyada o'rtacha |amplituda|). (env, sr, davomiylik)."""
    with wave.open(str(path), "rb") as w:
        sr, n, ch, sw = w.getframerate(), w.getnframes(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(n)
    if sw != 2:
        raise ValueError("faqat 16-bit WAV")
    a = array.array("h")
    a.frombytes(raw)
    if sys.byteorder == "big":
        a.byteswap()
    if ch > 1:
        a = a[::ch]
    win = max(1, int(sr * hop))
    env = []
    for i in range(0, len(a), win):
        seg = a[i:i + win:4]
        env.append(sum(map(abs, seg)) / max(1, len(seg)))
    return env, sr, len(a) / float(sr)


def _pct(vals, p):
    s = sorted(vals)
    return s[min(len(s) - 1, int(len(s) * p))] if s else 0.0


def speech_span(env, hop: float = HOP):
    """(boshlanish, tugash, pauzalar[(s, e)], chegara). Jimlikda ovoz yo'q bo'lsa (0, 0, [], thr)."""
    if not env:
        return 0.0, 0.0, [], 0.0
    peak = _pct(env, 0.98)
    floor = _pct(env, 0.10)
    thr = max(peak * 0.05, floor * 3.0, 15.0)
    act = [e > thr for e in env]
    first = last = None
    for i in range(len(act) - 2):
        if act[i] and act[i + 1] and act[i + 2]:
            first = i
            break
    for i in range(len(act) - 1, 1, -1):
        if act[i] and act[i - 1] and act[i - 2]:
            last = i
            break
    if first is None or last is None or last <= first:
        return 0.0, len(env) * hop, [], thr
    pauses, i = [], first
    while i <= last:
        if not act[i]:
            j = i
            while j <= last and not act[j]:
                j += 1
            if (j - i) * hop >= PAUSE_MIN:
                pauses.append((i * hop, j * hop))
            i = j
        else:
            i += 1
    return first * hop, (last + 1) * hop, pauses, thr


# --------------------------------------------------------------------- so'z vaqtlari
def _weight(word: dict) -> float:
    s = re.sub(r"[^\w']", "", word.get("s", ""), flags=re.U)
    if not s:
        return 0.25
    vowels = len(re.findall(r"[aeiouyAEIOU]+", s))
    return len(s) + 1.2 * vowels + 1.0


def _gap_kind(word: dict) -> str:
    s = word.get("s", "")
    if not s:
        return "none"
    if s[-1] in ".!?" or s.endswith("..."):
        return "strong"
    if s[-1] in ",;:":
        return "weak"
    return "none"


def _match_pauses(words, weights, pauses, t0, t1):
    """Pauzalarni so'zlar orasidagi bo'shliqlarga monoton joylashtiradi (dinamik dasturlash).
    Qaytaradi: {bo'shliq_indeksi: (pauza_boshi, pauza_oxiri)}."""
    n = len(words)
    if n < 2 or not pauses:
        return {}
    W = sum(weights)
    cum, c = [], 0.0
    for w in weights:
        c += w
        cum.append(c / W)
    gaps = list(range(n - 1))
    total_p = sum(e - s for s, e in pauses)
    t_sp = max(0.2, (t1 - t0) - total_p)
    fr, before = [], 0.0
    for s, e in pauses:
        fr.append(max(0.0, min(1.0, (s - t0 - before) / t_sp)))
        before += e - s
    kinds = [_gap_kind(words[k]) for k in gaps]
    SKIP = 0.6
    INF = 1e9

    def cost(i, k):
        d = pauses[i][1] - pauses[i][0]
        c = abs(fr[i] - cum[k]) * 6.0
        kd = kinds[k]
        if kd == "none":
            c += 0.35
        elif kd == "weak":
            c += 0.08 + (0.1 if d >= 0.4 else 0.0)
        elif d < 0.18:
            c += 0.05
        return c

    m = len(pauses)
    # dp[i][j]: i ta pauza ko'rildi, oxirgi ishlatilgan bo'shliq j-1 (j=0 - hech biri)
    dp = [[INF] * (n) for _ in range(m + 1)]
    bp = [[None] * n for _ in range(m + 1)]
    dp[0][0] = 0.0
    for i in range(m):
        for j in range(n):
            base = dp[i][j]
            if base >= INF:
                continue
            if base + SKIP < dp[i + 1][j]:
                dp[i + 1][j] = base + SKIP
                bp[i + 1][j] = (j, None)
            for k in range(j, n - 1):
                if abs(fr[i] - cum[k]) > 0.25:
                    if cum[k] > fr[i]:
                        break
                    continue
                v = base + cost(i, k)
                if v < dp[i + 1][k + 1]:
                    dp[i + 1][k + 1] = v
                    bp[i + 1][k + 1] = (j, k)
    j = min(range(n), key=lambda x: dp[m][x])
    out, i = {}, m
    while i > 0:
        pj, k = bp[i][j]
        if k is not None:
            out[k] = pauses[i - 1]
        j, i = pj, i - 1
    return out


def _snap(times, env, hop, anchors):
    """So'zlar orasidagi ichki chegaralarni eng yaqin energiya "tushishi" ga suradi."""
    n = len(times)
    for k in range(n - 1):
        if k in anchors:
            continue
        tb = times[k][1]
        d = min(times[k][1] - times[k][0], times[k + 1][1] - times[k + 1][0])
        rad = min(0.06, 0.3 * d)
        a, b = int((tb - rad) / hop), int((tb + rad) / hop)
        a, b = max(1, a), min(len(env) - 2, b)
        if b <= a:
            continue
        best = min(range(a, b + 1), key=lambda i: (env[i - 1] + 2 * env[i] + env[i + 1], abs(i * hop - tb)))
        nb = best * hop
        lo, hi = times[k][0] + 0.04, times[k + 1][1] - 0.04
        if lo < nb < hi:
            times[k] = (times[k][0], nb)
            times[k + 1] = (nb, times[k + 1][1])
    return times


def proportional(words, t0, t1):
    """Eng oddiy usul: so'z uzunligiga mutanosib taqsimlash."""
    ws = [_weight(w) for w in words]
    tot = sum(ws) or 1.0
    out, t = [], t0
    for w in ws:
        d = (t1 - t0) * w / tot
        out.append((t, t + d))
        t += d
    return out


def align_words(path, words, bounds=None) -> list:
    """Har bir so'zning (boshi, oxiri) vaqti, ovoz faylining boshiga nisbatan (soniya).
    bounds: Edge so'z chegaralari [(offset_s, dur_s, text)] yoki None."""
    n = len(words)
    if n == 0:
        return []
    env, sr, dur = read_env(path)
    t0, t1, pauses, _ = speech_span(env)
    if t1 - t0 < 0.1:
        t0, t1, pauses = 0.0, dur, []
    # 1) Edge chegaralari (aniq mos kelsa)
    if bounds:
        need = sum(max(1, len(w["s"].split())) if w["s"] else 0 for w in words)
        if len(bounds) == need and need > 0:
            res, bi = [], 0
            for w in words:
                k = len(w["s"].split()) if w["s"] else 0
                if k == 0:
                    res.append(None)
                    continue
                res.append((bounds[bi][0], bounds[bi + k - 1][0] + bounds[bi + k - 1][1]))
                bi += k
            known = [r for r in res if r]
            b0, b1 = known[0][0], known[-1][1]
            if b1 - b0 > 0.1 and abs((b1 - b0) - (t1 - t0)) < 0.25 * (t1 - t0) + 0.4:
                scale = (t1 - t0) / (b1 - b0)
                res = [None if r is None else (t0 + (r[0] - b0) * scale, t0 + (r[1] - b0) * scale) for r in res]
                return _fill_silent(res, t0, t1)
    # 2) Ovoz faylidan: pauzalar + mutanosib taqsimot + energiya tushishlariga yopishtirish
    weights = [_weight(w) for w in words]
    anchors = _match_pauses(words, weights, pauses, t0, t1)
    times = [None] * n
    seg_start, a = t0, 0
    for k in sorted(list(anchors.keys()) + [n - 1]):
        if k < a:
            continue
        seg_end = anchors[k][0] if k in anchors else t1
        ws = weights[a:k + 1]
        tot = sum(ws) or 1.0
        t = seg_start
        for idx, w in zip(range(a, k + 1), ws):
            d = max(0.03, (seg_end - seg_start) * w / tot)
            times[idx] = (t, min(t + d, seg_end))
            t += d
        if k in anchors:
            seg_start = anchors[k][1]
        a = k + 1
    times = _snap(times, env, HOP, set(anchors))
    return times


def _fill_silent(res, t0, t1):
    """Aytilmaydigan belgilar (None) uchun oldingi so'zning oxiridagi nol-uzunlikli oraliq."""
    out, last = [], t0
    for r in res:
        if r is None:
            out.append((last, last))
        else:
            out.append(r)
            last = r[1]
    return out


# --------------------------------------------------------------------- subtitr bo'laklari
def make_chunks(words, times, max_chars: int, min_dur: float = 0.9) -> list:
    """So'zlarni subtitr bo'laklariga ajratadi (gap tugashi, tinish belgisi, uzunlik bo'yicha).
    Qaytaradi: [{"i0", "i1", "start", "end"}] (i1 kiritilgan)."""
    n = len(words)
    chunks, cur, clen = [], [], 0

    def flush():
        nonlocal cur, clen
        if cur:
            chunks.append([cur[0], cur[-1]])
        cur, clen = [], 0

    for i, w in enumerate(words):
        wl = len(w["w"])
        add = wl + (1 if cur else 0)
        if cur and clen + add > max_chars:
            # sig'masa: eng oxirgi tinish belgisida (agar yetarlicha uzun bo'lsa) bo'lamiz, qoldig'i keyingisiga
            cut, acc = None, 0
            for pos, idx in enumerate(cur):
                acc += len(words[idx]["w"]) + (1 if pos else 0)
                if _gap_kind(words[idx]) != "none" and acc >= 0.4 * max_chars and pos < len(cur) - 1:
                    cut = pos
            if cut is not None:
                tail = cur[cut + 1:]
                chunks.append([cur[0], cur[cut]])
                cur = tail
                clen = sum(len(words[x]["w"]) for x in cur) + max(0, len(cur) - 1)
            else:
                flush()
            add = wl + (1 if cur else 0)
        cur.append(i)
        clen += add
        kind = _gap_kind(w)
        gap = (times[i + 1][0] - times[i][1]) if i + 1 < n else 9.0
        if kind == "strong" and clen >= 0.55 * max_chars:
            flush()
        elif kind == "weak" and clen >= 0.72 * max_chars:
            flush()
        elif gap >= 0.45 and clen >= 0.4 * max_chars:
            flush()
    flush()

    def clen_of(ch):
        return sum(len(words[i]["w"]) for i in range(ch[0], ch[1] + 1)) + (ch[1] - ch[0])

    def dur_of(ch):
        return times[ch[1]][1] - times[ch[0]][0]

    changed = True
    while changed and len(chunks) > 1:
        changed = False
        for k, ch in enumerate(chunks):
            if dur_of(ch) < min_dur or clen_of(ch) < 14:
                if k + 1 < len(chunks) and clen_of(ch) + 1 + clen_of(chunks[k + 1]) <= max_chars:
                    chunks[k:k + 2] = [[ch[0], chunks[k + 1][1]]]
                    changed = True
                    break
                if k > 0 and clen_of(chunks[k - 1]) + 1 + clen_of(ch) <= max_chars * 1.1:
                    chunks[k - 1:k + 1] = [[chunks[k - 1][0], ch[1]]]
                    changed = True
                    break
    return [{"i0": a, "i1": b, "start": times[a][0], "end": times[b][1]} for a, b in chunks]
