"""Qayta yasash savollari: "Senariy qayta yozilsinmi?" -> (yo'q bo'lsa) "Ovoz qayta yaratilsinmi?"."""
from __future__ import annotations

from .util import clip, esc


class RetryMixin:
    def _has_script(self, e) -> bool:
        s = e.get("script") or {}
        return bool(s.get("scenes"))

    def ask_remake(self, e, chat, keep=False):
        """Qayta yasashdan oldin savol. Eski ssenariy bo'lmasa savolsiz yangi ssenariy bilan boshlanadi."""
        k = 1 if keep else 0
        n = e["gno"]
        if not self._has_script(e):
            return self._rt_run(e, keep, True, True, chat)
        self._screen(chat, f"🔄 <b>#{n} {esc(clip(e['title'], 60))}</b> qayta yaratiladi.\n\n"
                           "📝 <b>Ssenariy bilan qayta yaratilsinmi?</b>\n"
                           "• ✅ Ha — ssenariy ham, ovoz ham noldan yoziladi\n"
                           "• ❌ Yo'q — eski ssenariydan davom etadi",
                     [[("✅ Ha, ssenariy bilan", f"rt:sy:{n}:{k}"), ("❌ Yo'q, eski ssenariy", f"rt:sn:{n}:{k}")],
                      [("✖️ Bekor", "m:menu")]])
        return None

    def rt_callback(self, val, chat):
        a = self.app
        p = val.split(":")
        act = p[0]
        n = int(p[1]) if len(p) > 1 and p[1].isdigit() else 0
        keep = len(p) > 2 and p[2] == "1"
        e = a.db.ep_by_gno(n)
        if not e:
            return self.tg.send("ℹ️ Epizod topilmadi.", chat=chat)
        if e["status"] == "uploaded":
            return self.tg.send(f"ℹ️ #{n} YouTube'ga yuklangan. Avval /forget {n} (yoki epizod sahifasida «Unutib qayta yasash»).",
                                chat=chat)
        if act == "sy":
            return self._rt_run(e, keep, True, True, chat)
        if act == "sn":
            if not self._has_script(e):
                return self._rt_run(e, keep, True, True, chat)
            k = 1 if keep else 0
            return self._screen(chat, f"🎙 <b>#{n}: ovoz qayta yaratilsinmi?</b>\n"
                                      "• ✅ Ha — ovoz 0 dan, hozirgi sozlamalar bilan yaratiladi\n"
                                      "• ❌ Yo'q — eski ovoz ishlatiladi (bo'lmasa yangisi yaratiladi)",
                                [[("✅ Ha, yangi ovoz", f"rt:vy:{n}:{k}"), ("❌ Yo'q, eski ovoz", f"rt:vn:{n}:{k}")],
                                 [("✖️ Bekor", "m:menu")]])
        if act == "vy":
            return self._rt_run(e, keep, False, True, chat)
        if act == "vn":
            return self._rt_run(e, keep, False, False, chat)
        return None

    def _rt_run(self, e, keep, new_script, new_voice, chat):
        a = self.app
        ok = a.jobs.submit(f"retry-{e['id']}", a.pipeline.regenerate, e["id"], keep, new_script, new_voice)
        what = ("yangi ssenariy + yangi ovoz" if new_script else
                "eski ssenariy + " + ("yangi ovoz" if new_voice else "eski ovoz"))
        msg = (f"🔄 #{e['gno']} qayta yasalmoqda ({what})." if ok else "ℹ️ Bu epizod allaqachon navbatda.")
        if ok and keep:
            msg += " Tayyor bo'lgach «Qayta yaratilganlar» ga saqlanadi."
        self._cb_msg = None
        self.tg.send(msg, chat=chat)
        return None
