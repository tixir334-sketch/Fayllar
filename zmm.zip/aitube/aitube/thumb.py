"""Muqova (thumbnail) yaratish: 1280x720 JPEG (<2MB)."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

from .highlight import highlight_line
from .render import ACCENTS, BG1, SYN, get_font

CODE_DECOR = [
    "def next_episode(n):", "    return n + 1", "", "while True:", "    build(ep)", "    publish(ep)",
    "$ sudo systemctl start", "git commit -m 'part'", "print('salom')",
]


def _with_art(img, art, layout, accent):
    """AI rasmni muqovaga qo'yadi: 0 - o'ng yarmida (chap tomonga so'nadi), 1 - butun fon (qorong'ilashtirilgan),
    2 - o'ng tomonda ramkali karta."""
    W, H = img.size
    horiz = Image.linear_gradient("L").rotate(90).resize((W, H))      # chapdan o'ngga 0 -> 255
    if layout == 0:
        a = ImageOps.fit(art.convert("RGB"), (W, H), Image.LANCZOS)
        m = horiz.point(lambda v: 0 if v < 70 else min(255, int((v - 70) * 1.5)))
        return Image.composite(a, img, m)
    if layout == 1:
        a = ImageOps.fit(art.convert("RGB"), (W, H), Image.LANCZOS).point(lambda v: int(v * 0.62))
        shade = horiz.transpose(Image.FLIP_LEFT_RIGHT).point(lambda v: int(v * 0.78))
        return Image.composite(Image.new("RGB", (W, H), BG1), a, shade)
    cw, ch = 520, 420
    a = ImageOps.fit(art.convert("RGB"), (cw, ch), Image.LANCZOS)
    m = Image.new("L", (cw, ch), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, cw - 1, ch - 1], radius=36, fill=255)
    x, y = W - cw - 60, (H - ch) // 2
    sh = Image.new("L", (W, H), 0)
    ImageDraw.Draw(sh).rounded_rectangle([x + 10, y + 16, x + cw + 10, y + ch + 16], radius=40, fill=170)
    img = Image.composite(Image.new("RGB", (W, H), (0, 0, 0)), img, sh.filter(ImageFilter.GaussianBlur(18)))
    img.paste(a, (x, y), m)
    ImageDraw.Draw(img).rounded_rectangle([x, y, x + cw, y + ch], radius=36, outline=accent, width=5)
    return img


def make_thumbnail(cfg, out: Path, title: str, number: int, channel: str, accent_idx=0, tagline="", art=None) -> Path:
    W, H = 1280, 720
    fd = cfg.fonts_dir
    accent = ACCENTS[accent_idx % len(ACCENTS)]
    grad = Image.linear_gradient("L").rotate(90).resize((W, H))
    dark = Image.new("RGB", (W, H), BG1)
    col = Image.new("RGB", (W, H), tuple(int(c * 0.45) for c in accent))
    img = Image.composite(dark, col, grad)
    layout = int(number) % 3
    if art is not None:
        img = _with_art(img, art, layout, accent)
    # kod bezagi (rasm bo'lmasa)
    d = ImageDraw.Draw(img)
    mono = get_font(fd, "mono", 30)
    y = 40
    deco = Image.new("RGB", (W, H), (0, 0, 0))
    dd = ImageDraw.Draw(deco)
    for i, ln in enumerate(CODE_DECOR * 3):
        x = 640 + (i % 3) * 30
        for txt, kind in highlight_line(ln, "python"):
            dd.text((x, y), txt, font=mono, fill=tuple(int(c * 0.35) for c in SYN.get(kind, (200, 200, 200))))
            x += mono.getlength(txt)
        y += 44
        if y > H:
            break
    if art is None:
        img = ImageChops.add(img, deco)
    d = ImageDraw.Draw(img)
    # qism raqami
    badge = f"QISM {number}" if cfg.get("LANGUAGE").startswith("uz") else f"PART {number}"
    bf = get_font(fd, "bold", 46)
    bw = d.textlength(badge, font=bf) + 60
    d.rounded_rectangle([60, 56, 60 + bw, 128], radius=36, fill=accent)
    d.text((60 + bw / 2, 92), badge, font=bf, fill=BG1, anchor="mm")
    # asosiy matn
    words = title.upper().split()
    size = 150
    lines = []
    probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    while size >= 56:
        f = get_font(fd, "bold", size)
        lines, cur = [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if probe.textlength(t, font=f) <= 760:
                cur = t
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        if len(lines) * size * 1.12 <= 400 and all(probe.textlength(x, font=f) <= 800 for x in lines):
            break
        size -= 6
    f = get_font(fd, "bold", size)
    ty = 170
    for ln in lines[:4]:
        d.text((64, ty + 4), ln, font=f, fill=(0, 0, 0))
        d.text((60, ty), ln, font=f, fill=(255, 255, 255))
        ty += int(size * 1.12)
    d.rounded_rectangle([60, ty + 14, 260, ty + 24], radius=5, fill=accent)
    cf = get_font(fd, "bold", 34)
    d.text((60, H - 64), channel, font=cf, fill=(230, 237, 243), anchor="lm")
    if tagline:
        tf = get_font(fd, "sans", 28)
        d.text((W - 60, H - 64), tagline, font=tf, fill=(200, 208, 217), anchor="rm")
    out = Path(out)
    for q in (90, 80, 70, 55):
        img.save(out, "JPEG", quality=q, optimize=True)
        if out.stat().st_size < 1_900_000:
            break
    return out
