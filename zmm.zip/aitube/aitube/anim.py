"""Animatsiyali sxema sahnalari: 'diagram' (tugunlar + ular orasida yuruvchi paketlar) va 'compare' (ikki ustun).

Tugunlar - shisha (shaffof) kartalar ichidagi vektor piktogrammalar (odam, server, baza, brauzer, bulut, AI ...).
Aloqalar bo'ylab xabar/fayl paketlari yuradi, manzil tuguni yonib turadi. Hammasi Pillow bilan chiziladi.
Skript (LLM) faqat tugun turi va aloqalarni beradi - chizish shu yerda.
"""
from __future__ import annotations

import math

# --------------------------------------------------------------------------- turlar
KIND_COL = {
    "user": (88, 166, 255), "users": (88, 166, 255), "server": (63, 185, 80), "db": (255, 166, 87),
    "browser": (210, 168, 255), "laptop": (210, 168, 255), "phone": (210, 168, 255), "cloud": (86, 211, 205),
    "file": (176, 196, 222), "lock": (255, 206, 86), "key": (255, 206, 86), "ai": (255, 123, 190),
    "bot": (255, 123, 190), "gear": (176, 196, 222), "code": (126, 231, 135), "globe": (86, 211, 205),
    "router": (86, 211, 205), "bolt": (255, 206, 86), "queue": (255, 166, 87), "lb": (63, 185, 80),
    "docker": (86, 160, 255), "git": (255, 123, 114), "terminal": (126, 231, 135), "mail": (255, 166, 87),
    "shield": (63, 185, 80), "disk": (176, 196, 222), "clock": (255, 206, 86), "chat": (88, 166, 255),
    "bug": (255, 123, 114), "firewall": (255, 123, 114), "box": (176, 196, 222), "wifi": (86, 211, 205),
    "check": (63, 185, 80), "cross": (255, 123, 114),
    # --- 3D ikonkalar kutubxonasi (icons3d.py): qurilmalar, o'quv va mavhum belgilar
    "cpu": (255, 123, 190), "gpu": (88, 166, 255), "ram": (126, 231, 135), "ssd": (86, 211, 205), "hdd": (176, 196, 222),
    "motherboard": (63, 185, 80), "psu": (255, 166, 87), "fan": (88, 166, 255), "tower": (110, 170, 255),
    "monitor": (110, 170, 255), "keyboard": (176, 196, 222), "mouse": (176, 196, 222), "battery": (90, 235, 130),
    "usb": (255, 123, 114), "camera": (110, 170, 255), "mic": (167, 139, 250), "speaker": (86, 211, 205),
    "headphones": (255, 206, 86), "printer": (176, 196, 222), "book": (88, 166, 255), "bulb": (255, 206, 86),
    "rocket": (255, 123, 114), "magnifier": (88, 166, 255), "chart": (63, 185, 80), "calendar": (255, 123, 114),
    "coin": (255, 206, 86), "trophy": (255, 206, 86), "star": (255, 206, 86), "heart": (240, 70, 100),
    "puzzle": (86, 211, 205), "link": (255, 166, 87), "sphere": (167, 139, 250), "pyramid": (167, 139, 250),
    "folder": (255, 206, 86),
}

ALIASES = {
    "person": "user", "human": "user", "client_user": "user", "odam": "user", "foydalanuvchi": "user",
    "mijoz": "user", "people": "users", "group": "users", "team": "users", "backend": "server",
    "host": "server", "machine": "server", "node": "server", "api": "gear", "service": "gear",
    "microservice": "gear", "database": "db", "sql": "db", "postgres": "db", "postgresql": "db",
    "mysql": "db", "sqlite": "db", "mongo": "db", "mongodb": "db", "storage": "db", "baza": "db",
    "redis": "bolt", "cache": "bolt", "client": "browser", "frontend": "browser", "web": "browser",
    "page": "browser", "site": "browser", "website": "browser", "pc": "laptop", "computer": "laptop",
    "desktop": "laptop", "mobile": "phone", "app": "phone", "internet": "globe", "network": "globe",
    "world": "globe", "cdn": "globe", "dns": "globe", "cpu": "ai", "chip": "ai", "model": "ai",
    "llm": "ai", "neural": "ai", "brain": "ai", "gpu": "ai", "robot": "bot", "script": "code",
    "program": "code", "function": "code", "source": "code", "container": "docker", "balancer": "lb",
    "loadbalancer": "lb", "proxy": "lb", "gateway": "lb", "message": "mail", "email": "mail",
    "envelope": "mail", "folder": "file", "document": "file", "text": "file", "csv": "file", "json": "file",
    "image": "file", "secure": "lock", "https": "lock", "ssl": "lock", "auth": "key", "token": "key",
    "password": "key", "shell": "terminal", "bash": "terminal", "cmd": "terminal", "console": "terminal",
    "cli": "terminal", "repo": "git", "github": "git", "branch": "git", "commit": "git",
    "kafka": "queue", "stream": "queue", "pipeline": "queue", "worker": "gear", "job": "gear",
    "hdd": "disk", "ssd": "disk", "time": "clock", "cron": "clock", "timer": "clock", "comment": "chat",
    "sms": "chat", "telegram": "chat", "error": "bug", "exception": "bug", "antivirus": "shield",
    "security": "shield", "ok": "check", "success": "check", "fail": "cross", "wireless": "wifi",
    "modem": "router", "switch": "router", "thunder": "bolt", "lightning": "bolt", "saas": "cloud",
    "aws": "cloud", "bulut": "cloud", "protsessor": "cpu", "processor": "cpu", "videokarta": "gpu", "graphics": "gpu",
    "xotira": "ram", "memory": "ram", "monitor": "monitor", "ekran": "monitor", "display": "monitor",
    "motherboard": "motherboard", "mainboard": "motherboard", "onaplata": "motherboard", "powersupply": "psu",
    "kuler": "fan", "cooler": "fan", "sovutish": "fan", "keys": "key", "idea": "bulb", "goya": "bulb",
    "search": "magnifier", "qidiruv": "magnifier", "diagram": "chart", "statistika": "chart", "kitob": "book",
    "success_star": "star", "usbflesh": "usb", "flesh": "usb", "fleshka": "usb", "mikrofon": "mic",
    "karnay": "speaker", "quloqchin": "headphones", "kamera": "camera", "klaviatura": "keyboard",
    "sichqoncha": "mouse", "batareya": "battery", "raketa": "rocket", "kubok": "trophy", "pul": "coin",
}

# kalit so'z (yorliqdan) -> tur. Skript turini bermasa yoki noma'lum bo'lsa shu bo'yicha taxmin qilinadi.
LABEL_HINTS = [
    ("protsessor", "cpu"), ("processor", "cpu"), ("cpu", "cpu"), ("videokarta", "gpu"), ("gpu", "gpu"),
    ("operativ", "ram"), (" ram", "ram"), ("xotira", "ram"), ("ssd", "ssd"), ("hdd", "hdd"),
    ("ona plata", "motherboard"), ("motherboard", "motherboard"), ("quvvat bloki", "psu"), ("kuler", "fan"),
    ("sovutish", "fan"), ("monitor", "monitor"), ("ekran", "monitor"), ("klaviatura", "keyboard"),
    ("sichqoncha", "mouse"), ("batareya", "battery"), ("kamera", "camera"), ("mikrofon", "mic"),
    ("karnay", "speaker"), ("quloqchin", "headphones"), ("printer", "printer"), ("kitob", "book"),
    ("g'oya", "bulb"), ("raketa", "rocket"), ("qidiruv", "magnifier"), ("statistika", "chart"),
    ("kalendar", "calendar"), ("kubok", "trophy"), ("papka", "folder"), ("usb", "usb"),
    ("foydalanuvchi", "user"), ("mijoz", "user"), ("user", "user"), ("odam", "user"), ("inson", "user"),
    ("brauzer", "browser"), ("browser", "browser"), ("frontend", "browser"), ("sayt", "browser"),
    ("telefon", "phone"), ("phone", "phone"), ("mobil", "phone"), ("noutbuk", "laptop"), ("kompyuter", "laptop"),
    ("laptop", "laptop"), ("baza", "db"), ("database", "db"), ("sql", "db"), ("redis", "bolt"), ("kesh", "bolt"),
    ("cache", "bolt"), ("server", "server"), ("backend", "server"), ("api", "gear"), ("servis", "gear"),
    ("bulut", "cloud"), ("cloud", "cloud"), ("internet", "globe"), ("tarmoq", "globe"), ("dns", "globe"),
    ("cdn", "globe"), ("router", "router"), ("fayl", "file"), ("file", "file"), ("hujjat", "file"),
    ("lock", "lock"), ("parol", "key"), ("kalit", "key"), ("token", "key"), ("shifr", "lock"),
    ("ai ", "ai"), ("model", "ai"), ("neyron", "ai"), ("llm", "ai"), ("gpt", "ai"), ("bot", "bot"),
    ("docker", "docker"), ("konteyner", "docker"), ("git", "git"), ("terminal", "terminal"),
    ("buyruq", "terminal"), ("kod", "code"), ("dastur", "code"), ("skript", "code"), ("navbat", "queue"),
    ("queue", "queue"), ("pochta", "mail"), ("email", "mail"), ("xabar", "mail"), ("xavfsiz", "shield"),
    ("himoya", "shield"), ("firewall", "firewall"), ("xato", "bug"), ("bug", "bug"), ("disk", "disk"),
    ("soat", "clock"), ("vaqt", "clock"), ("balans", "lb"),
]


def infer_kind(kind: str, label: str = "") -> str:
    k = str(kind or "").strip().lower().replace("-", "").replace("_", "").replace(" ", "")
    if k in KIND_COL:
        return k
    if k in ALIASES:
        return ALIASES[k]
    low = " " + str(label or "").lower() + " "
    for key, v in LABEL_HINTS:
        if key in low:
            return v
    return "box"


def lighten(c, k):
    return tuple(int(x + (255 - x) * k) for x in c)


def dim(c, k):
    return tuple(int(x * k) for x in c)


def mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(round(x + (y - x) * t)) for x, y in zip(a, b))


INK = (13, 19, 29)


def bezier(a, c, b, n=26):
    pts = []
    for i in range(n + 1):
        t = i / n
        x = (1 - t) ** 2 * a[0] + 2 * (1 - t) * t * c[0] + t * t * b[0]
        y = (1 - t) ** 2 * a[1] + 2 * (1 - t) * t * c[1] + t * t * b[1]
        pts.append((x, y))
    return pts


class Path:
    """Siniq chiziq bo'ylab uzunlik bo'yicha nuqta olish."""

    def __init__(self, pts):
        self.side = 0.0
        self.pts = pts
        self.cum = [0.0]
        for i in range(1, len(pts)):
            self.cum.append(self.cum[-1] + math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]))
        self.length = self.cum[-1] or 1.0

    def at(self, s):
        s = max(0.0, min(self.length, s))
        lo, hi = 0, len(self.cum) - 1
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if self.cum[mid] <= s:
                lo = mid
            else:
                hi = mid
        seg = (self.cum[hi] - self.cum[lo]) or 1.0
        f = (s - self.cum[lo]) / seg
        x = self.pts[lo][0] + (self.pts[hi][0] - self.pts[lo][0]) * f
        y = self.pts[lo][1] + (self.pts[hi][1] - self.pts[lo][1]) * f
        ang = math.atan2(self.pts[hi][1] - self.pts[lo][1], self.pts[hi][0] - self.pts[lo][0])
        return x, y, ang

    def sub(self, s0, s1):
        """s0..s1 oralig'idagi nuqtalar ro'yxati."""
        s0, s1 = max(0.0, s0), min(self.length, s1)
        if s1 <= s0:
            return []
        out = [self.at(s0)[:2]]
        for p, c in zip(self.pts, self.cum):
            if s0 < c < s1:
                out.append(p)
        out.append(self.at(s1)[:2])
        return out


def ease_io(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def ease_out(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def back(t):
    t = max(0.0, min(1.0, t))
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


LINK_COL = {"request": (88, 166, 255), "response": (63, 185, 80), "data": (255, 166, 87),
            "error": (255, 123, 114), "event": (210, 168, 255)}


class AnimMixin:
    """Renderer ga qo'shiladigan sxema/taqqoslash sahnalari."""

    # ------------------------------------------------------------------ piktogrammalar
    def _icon(self, d, kind, cx, cy, s, col, t=0.0):
        """Piktogramma. s - umumiy o'lcham (mantiqiy piksel), (cx,cy) - markaz."""
        h = s / 2.0
        c2 = lighten(col, 0.45)
        ink = INK
        lw = max(2.0, s * 0.045)
        f = getattr(self, "_icon_" + kind, None) or self._icon_box
        f(d, cx, cy, h, col, c2, ink, lw, t)

    def _icon_user(self, d, cx, cy, h, col, c2, ink, lw, t):
        cy += 0.08 * h
        d.ellipse([cx - 0.30 * h, cy - 0.80 * h, cx + 0.30 * h, cy - 0.20 * h], fill=col)
        d.pieslice([cx - 0.64 * h, cy + 0.0 * h, cx + 0.64 * h, cy + 1.24 * h], 180, 360, fill=col)

    def _icon_users(self, d, cx, cy, h, col, c2, ink, lw, t):
        for dx, k, cc in ((-0.42, 0.78, dim(col, 0.7)), (0.42, 0.78, dim(col, 0.7)), (0.0, 1.0, col)):
            x = cx + dx * h
            yy = cy + 0.1 * h
            d.ellipse([x - 0.24 * h * k, yy - 0.74 * h * k, x + 0.24 * h * k, yy - 0.26 * h * k], fill=cc)
            d.pieslice([x - 0.52 * h * k, yy - 0.2 * h * k, x + 0.52 * h * k, yy + 0.8 * h * k], 180, 360, fill=cc)

    def _icon_server(self, d, cx, cy, h, col, c2, ink, lw, t):
        for i in range(3):
            y = cy - 0.84 * h + i * 0.58 * h
            d.rounded_rectangle([cx - 0.84 * h, y, cx + 0.84 * h, y + 0.5 * h], radius=0.1 * h, fill=ink,
                                outline=col, width=lw)
            on = int(t * 3 + i * 1.3) % 3 != 0
            d.ellipse([cx - 0.62 * h, y + 0.19 * h, cx - 0.5 * h, y + 0.31 * h], fill=(86, 235, 120) if on else dim(col, 0.4))
            d.ellipse([cx - 0.40 * h, y + 0.19 * h, cx - 0.28 * h, y + 0.31 * h],
                      fill=(255, 190, 80) if int(t * 2 + i) % 2 else dim(col, 0.4))
            d.line([(cx + 0.05 * h, y + 0.25 * h), (cx + 0.62 * h, y + 0.25 * h)], fill=c2, width=lw)

    def _icon_db(self, d, cx, cy, h, col, c2, ink, lw, t):
        x0, x1 = cx - 0.66 * h, cx + 0.66 * h
        top, bot, e = cy - 0.76 * h, cy + 0.76 * h, 0.17 * h
        d.ellipse([x0, bot - 2 * e, x1, bot], fill=ink)
        d.rectangle([x0, top + e, x1, bot - e], fill=ink)
        d.arc([x0, bot - 2 * e, x1, bot], 0, 180, fill=col, width=lw)
        for yy in (cy - 0.2 * h, cy + 0.3 * h):
            d.arc([x0, yy - e, x1, yy + e], 0, 180, fill=dim(col, 0.8), width=lw)
        d.line([(x0, top + e), (x0, bot - e)], fill=col, width=lw)
        d.line([(x1, top + e), (x1, bot - e)], fill=col, width=lw)
        d.ellipse([x0, top, x1, top + 2 * e], fill=ink, outline=col, width=lw)
        pulse = 0.5 + 0.5 * math.sin(t * 3)
        d.ellipse([cx - 0.14 * h, top + 0.12 * h, cx + 0.14 * h, top + 0.24 * h], fill=mix(dim(col, 0.5), c2, pulse))

    def _icon_browser(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.88 * h, cy - 0.68 * h, cx + 0.88 * h, cy + 0.68 * h], radius=0.14 * h, fill=ink,
                            outline=col, width=lw)
        d.line([(cx - 0.88 * h, cy - 0.38 * h), (cx + 0.88 * h, cy - 0.38 * h)], fill=col, width=lw)
        for i, cc in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
            d.ellipse([cx - 0.76 * h + i * 0.2 * h, cy - 0.56 * h, cx - 0.64 * h + i * 0.2 * h, cy - 0.44 * h], fill=cc)
        d.rounded_rectangle([cx - 0.12 * h, cy - 0.57 * h, cx + 0.74 * h, cy - 0.43 * h], radius=0.07 * h, fill=dim(col, 0.45))
        d.rounded_rectangle([cx - 0.7 * h, cy - 0.2 * h, cx - 0.1 * h, cy + 0.5 * h], radius=0.06 * h, fill=dim(col, 0.55))
        for i in range(3):
            w = 0.62 - 0.12 * i
            d.rounded_rectangle([cx + 0.05 * h, cy - 0.15 * h + i * 0.22 * h, cx + (0.05 + w) * h,
                                 cy - 0.03 * h + i * 0.22 * h], radius=0.05 * h, fill=c2 if i == 0 else dim(col, 0.7))

    def _icon_laptop(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.68 * h, cy - 0.7 * h, cx + 0.68 * h, cy + 0.32 * h], radius=0.1 * h, fill=ink,
                            outline=col, width=lw)
        d.polygon([(cx - 0.94 * h, cy + 0.45 * h), (cx + 0.94 * h, cy + 0.45 * h), (cx + 0.78 * h, cy + 0.66 * h),
                   (cx - 0.78 * h, cy + 0.66 * h)], fill=col)
        for i in range(3):
            d.rounded_rectangle([cx - 0.5 * h, cy - 0.5 * h + i * 0.24 * h, cx + (0.1 + 0.3 * (i % 2)) * h,
                                 cy - 0.4 * h + i * 0.24 * h], radius=0.04 * h, fill=c2 if i == 1 else dim(col, 0.7))

    def _icon_phone(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.4 * h, cy - 0.84 * h, cx + 0.4 * h, cy + 0.84 * h], radius=0.15 * h, fill=ink,
                            outline=col, width=lw)
        d.rounded_rectangle([cx - 0.12 * h, cy - 0.72 * h, cx + 0.12 * h, cy - 0.66 * h], radius=0.03 * h, fill=col)
        d.ellipse([cx - 0.08 * h, cy + 0.62 * h, cx + 0.08 * h, cy + 0.78 * h], outline=col, width=lw)
        for i in range(3):
            d.rounded_rectangle([cx - 0.26 * h, cy - 0.5 * h + i * 0.34 * h, cx + (0.26 - 0.12 * (i % 2)) * h,
                                 cy - 0.34 * h + i * 0.34 * h], radius=0.05 * h, fill=c2 if i == 0 else dim(col, 0.6))

    def _icon_cloud(self, d, cx, cy, h, col, c2, ink, lw, t):
        cy += 0.05 * h
        for x, y, r in ((-0.42, 0.12, 0.40), (0.0, -0.2, 0.52), (0.46, 0.14, 0.36)):
            d.ellipse([cx + (x - r) * h, cy + (y - r) * h, cx + (x + r) * h, cy + (y + r) * h], fill=col)
        d.rounded_rectangle([cx - 0.84 * h, cy + 0.1 * h, cx + 0.82 * h, cy + 0.5 * h], radius=0.2 * h, fill=col)
        d.line([(cx - 0.3 * h, cy + 0.28 * h), (cx + 0.3 * h, cy + 0.28 * h)], fill=lighten(col, 0.6), width=lw)

    def _icon_file(self, d, cx, cy, h, col, c2, ink, lw, t):
        pts = [(cx - 0.56 * h, cy - 0.84 * h), (cx + 0.14 * h, cy - 0.84 * h), (cx + 0.56 * h, cy - 0.42 * h),
               (cx + 0.56 * h, cy + 0.84 * h), (cx - 0.56 * h, cy + 0.84 * h)]
        d.polygon(pts, fill=ink)
        d.line(pts + [pts[0]], fill=col, width=lw)
        d.polygon([(cx + 0.14 * h, cy - 0.84 * h), (cx + 0.14 * h, cy - 0.42 * h), (cx + 0.56 * h, cy - 0.42 * h)], fill=col)
        for i in range(4):
            d.line([(cx - 0.34 * h, cy - 0.15 * h + i * 0.24 * h), (cx + (0.34 - 0.18 * (i == 3)) * h, cy - 0.15 * h + i * 0.24 * h)],
                   fill=c2 if i == 0 else dim(col, 0.75), width=lw)

    def _icon_lock(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.arc([cx - 0.42 * h, cy - 0.86 * h, cx + 0.42 * h, cy + 0.24 * h], 180, 360, fill=c2, width=lw * 1.8)
        d.line([(cx - 0.42 * h, cy - 0.3 * h), (cx - 0.42 * h, cy + 0.05 * h)], fill=c2, width=lw * 1.8)
        d.line([(cx + 0.42 * h, cy - 0.3 * h), (cx + 0.42 * h, cy + 0.05 * h)], fill=c2, width=lw * 1.8)
        d.rounded_rectangle([cx - 0.66 * h, cy - 0.04 * h, cx + 0.66 * h, cy + 0.8 * h], radius=0.14 * h, fill=col)
        d.ellipse([cx - 0.11 * h, cy + 0.2 * h, cx + 0.11 * h, cy + 0.42 * h], fill=ink)
        d.rectangle([cx - 0.04 * h, cy + 0.34 * h, cx + 0.04 * h, cy + 0.6 * h], fill=ink)

    def _icon_key(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.ellipse([cx - 0.84 * h, cy - 0.4 * h, cx - 0.04 * h, cy + 0.4 * h], outline=col, width=lw * 2)
        d.ellipse([cx - 0.56 * h, cy - 0.12 * h, cx - 0.32 * h, cy + 0.12 * h], fill=col)
        d.line([(cx - 0.04 * h, cy), (cx + 0.86 * h, cy)], fill=col, width=lw * 2)
        for x in (0.5, 0.74):
            d.line([(cx + x * h, cy), (cx + x * h, cy + 0.32 * h)], fill=col, width=lw * 2)

    def _icon_ai(self, d, cx, cy, h, col, c2, ink, lw, t):
        for i in range(3):
            o = (-0.3 + 0.3 * i) * h
            d.line([(cx + o, cy - 0.78 * h), (cx + o, cy - 0.52 * h)], fill=col, width=lw)
            d.line([(cx + o, cy + 0.52 * h), (cx + o, cy + 0.78 * h)], fill=col, width=lw)
            d.line([(cx - 0.78 * h, cy + o), (cx - 0.52 * h, cy + o)], fill=col, width=lw)
            d.line([(cx + 0.52 * h, cy + o), (cx + 0.78 * h, cy + o)], fill=col, width=lw)
        d.rounded_rectangle([cx - 0.54 * h, cy - 0.54 * h, cx + 0.54 * h, cy + 0.54 * h], radius=0.16 * h, fill=ink,
                            outline=col, width=lw)
        d.text((cx, cy + 0.02 * h), "AI", font=self.font("bold", max(10, int(h * 0.62))), fill=c2, anchor="mm")
        k = 0.5 + 0.5 * math.sin(t * 4)
        r = (0.16 + 0.1 * k) * h
        sx, sy = cx + 0.62 * h, cy - 0.62 * h
        d.polygon([(sx, sy - r), (sx + r * 0.3, sy - r * 0.3), (sx + r, sy), (sx + r * 0.3, sy + r * 0.3), (sx, sy + r),
                   (sx - r * 0.3, sy + r * 0.3), (sx - r, sy), (sx - r * 0.3, sy - r * 0.3)], fill=(255, 235, 150))

    def _icon_bot(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.line([(cx, cy - 0.5 * h), (cx, cy - 0.8 * h)], fill=col, width=lw)
        d.ellipse([cx - 0.1 * h, cy - 0.92 * h, cx + 0.1 * h, cy - 0.72 * h],
                  fill=(255, 235, 150) if int(t * 2) % 2 else col)
        d.rounded_rectangle([cx - 0.7 * h, cy - 0.5 * h, cx + 0.7 * h, cy + 0.62 * h], radius=0.2 * h, fill=ink,
                            outline=col, width=lw)
        for sx in (-0.3, 0.3):
            d.ellipse([cx + (sx - 0.14) * h, cy - 0.22 * h, cx + (sx + 0.14) * h, cy + 0.06 * h], fill=c2)
        d.line([(cx - 0.3 * h, cy + 0.32 * h), (cx + 0.3 * h, cy + 0.32 * h)], fill=col, width=lw)
        d.rectangle([cx - 0.82 * h, cy - 0.1 * h, cx - 0.7 * h, cy + 0.3 * h], fill=col)
        d.rectangle([cx + 0.7 * h, cy - 0.1 * h, cx + 0.82 * h, cy + 0.3 * h], fill=col)

    def _icon_gear(self, d, cx, cy, h, col, c2, ink, lw, t):
        pts = []
        teeth = 8
        rot = t * 0.9
        for i in range(teeth * 4):
            a = rot + i * math.pi * 2 / (teeth * 4)
            r = (0.9 if (i % 4) in (0, 1) else 0.68) * h
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        d.polygon(pts, fill=col)
        d.ellipse([cx - 0.3 * h, cy - 0.3 * h, cx + 0.3 * h, cy + 0.3 * h], fill=ink)

    def _icon_code(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.86 * h, cy - 0.62 * h, cx + 0.86 * h, cy + 0.62 * h], radius=0.14 * h, fill=ink,
                            outline=col, width=lw)
        d.text((cx, cy + 0.02 * h), "</>", font=self.font("monob", max(10, int(h * 0.7))), fill=c2, anchor="mm")

    def _icon_terminal(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.88 * h, cy - 0.66 * h, cx + 0.88 * h, cy + 0.66 * h], radius=0.14 * h, fill=ink,
                            outline=col, width=lw)
        d.text((cx - 0.3 * h, cy), ">", font=self.font("monob", max(10, int(h * 0.8))), fill=c2, anchor="mm")
        if int(t * 2) % 2 == 0:
            d.rectangle([cx - 0.02 * h, cy + 0.14 * h, cx + 0.4 * h, cy + 0.26 * h], fill=col)

    def _icon_globe(self, d, cx, cy, h, col, c2, ink, lw, t):
        r = 0.82 * h
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ink, outline=col, width=lw)
        wmer = r * abs(math.cos(t * 0.8))
        d.ellipse([cx - wmer, cy - r, cx + wmer, cy + r], outline=dim(col, 0.85), width=lw)
        d.line([(cx - r, cy), (cx + r, cy)], fill=dim(col, 0.85), width=lw)
        for k in (-0.5, 0.5):
            hw = math.sqrt(max(0.0, 1 - k * k)) * r
            d.line([(cx - hw, cy + k * r), (cx + hw, cy + k * r)], fill=dim(col, 0.6), width=lw)

    def _icon_wifi(self, d, cx, cy, h, col, c2, ink, lw, t):
        k = int(t * 2.5) % 4
        for i, r in enumerate((0.45, 0.8, 1.15)):
            d.arc([cx - r * h, cy + 0.5 * h - r * h, cx + r * h, cy + 0.5 * h + r * h], 225, 315,
                  fill=c2 if i < k else dim(col, 0.5), width=lw * 1.6)
        d.ellipse([cx - 0.1 * h, cy + 0.4 * h, cx + 0.1 * h, cy + 0.6 * h], fill=col)

    def _icon_router(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.9 * h, cy + 0.0 * h, cx + 0.9 * h, cy + 0.56 * h], radius=0.12 * h, fill=ink,
                            outline=col, width=lw)
        for i in range(4):
            on = int(t * 3 + i) % 2 == 0
            d.ellipse([cx - 0.66 * h + i * 0.24 * h, cy + 0.2 * h, cx - 0.54 * h + i * 0.24 * h, cy + 0.32 * h],
                      fill=(86, 235, 120) if on else dim(col, 0.45))
        d.line([(cx - 0.6 * h, cy), (cx - 0.7 * h, cy - 0.62 * h)], fill=col, width=lw * 1.4)
        d.line([(cx + 0.6 * h, cy), (cx + 0.7 * h, cy - 0.62 * h)], fill=col, width=lw * 1.4)
        k = 0.5 + 0.5 * math.sin(t * 4)
        d.arc([cx - 0.36 * h, cy - 0.7 * h - 0.2 * h * k, cx + 0.36 * h, cy - 0.1 * h], 200, 340, fill=c2, width=lw)

    def _icon_bolt(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.polygon([(cx + 0.18 * h, cy - 0.9 * h), (cx - 0.55 * h, cy + 0.12 * h), (cx - 0.04 * h, cy + 0.12 * h),
                   (cx - 0.2 * h, cy + 0.9 * h), (cx + 0.56 * h, cy - 0.18 * h), (cx + 0.06 * h, cy - 0.18 * h)],
                  fill=mix(col, (255, 255, 255), 0.25 * (0.5 + 0.5 * math.sin(t * 5))))

    def _icon_queue(self, d, cx, cy, h, col, c2, ink, lw, t):
        k = (t * 1.2) % 1.0
        for i in range(4):
            x = cx - 0.9 * h + i * 0.46 * h
            lit = (int(k * 4) == i)
            d.rounded_rectangle([x, cy - 0.34 * h, x + 0.38 * h, cy + 0.34 * h], radius=0.08 * h,
                                fill=c2 if lit else ink, outline=col, width=lw)
        d.polygon([(cx + 0.96 * h, cy), (cx + 0.78 * h, cy - 0.18 * h), (cx + 0.78 * h, cy + 0.18 * h)], fill=col)

    def _icon_lb(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.ellipse([cx - 0.88 * h, cy - 0.18 * h, cx - 0.52 * h, cy + 0.18 * h], fill=col)
        for dy in (-0.62, 0.0, 0.62):
            d.line([(cx - 0.52 * h, cy), (cx + 0.38 * h, cy + dy * h)], fill=dim(col, 0.8), width=lw)
            d.rounded_rectangle([cx + 0.38 * h, cy + dy * h - 0.2 * h, cx + 0.88 * h, cy + dy * h + 0.2 * h],
                                radius=0.06 * h, fill=ink, outline=col, width=lw)

    def _icon_docker(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.88 * h, cy - 0.6 * h, cx + 0.88 * h, cy + 0.66 * h], radius=0.14 * h, fill=ink,
                            outline=col, width=lw)
        for r in range(2):
            for c in range(3):
                x = cx - 0.66 * h + c * 0.46 * h
                y = cy - 0.42 * h + r * 0.5 * h
                d.rounded_rectangle([x, y, x + 0.38 * h, y + 0.4 * h], radius=0.05 * h, fill=c2 if (r + c) % 2 == 0 else dim(col, 0.7))

    def _icon_git(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.line([(cx - 0.5 * h, cy - 0.5 * h), (cx - 0.5 * h, cy + 0.5 * h)], fill=col, width=lw * 1.5)
        d.line([(cx - 0.5 * h, cy + 0.2 * h), (cx + 0.5 * h, cy - 0.2 * h)], fill=col, width=lw * 1.5)
        for x, y in ((-0.5, -0.5), (-0.5, 0.5), (0.5, -0.2)):
            d.ellipse([cx + (x - 0.2) * h, cy + (y - 0.2) * h, cx + (x + 0.2) * h, cy + (y + 0.2) * h], fill=ink,
                      outline=c2, width=lw * 1.4)

    def _icon_mail(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.88 * h, cy - 0.58 * h, cx + 0.88 * h, cy + 0.58 * h], radius=0.1 * h, fill=ink,
                            outline=col, width=lw)
        d.line([(cx - 0.84 * h, cy - 0.5 * h), (cx, cy + 0.12 * h), (cx + 0.84 * h, cy - 0.5 * h)], fill=c2, width=lw)

    def _icon_shield(self, d, cx, cy, h, col, c2, ink, lw, t):
        pts = [(cx - 0.7 * h, cy - 0.7 * h), (cx, cy - 0.9 * h), (cx + 0.7 * h, cy - 0.7 * h), (cx + 0.66 * h, cy + 0.1 * h),
               (cx, cy + 0.92 * h), (cx - 0.66 * h, cy + 0.1 * h)]
        d.polygon(pts, fill=dim(col, 0.5))
        d.line(pts + [pts[0]], fill=col, width=lw * 1.3)
        d.line([(cx - 0.28 * h, cy + 0.02 * h), (cx - 0.05 * h, cy + 0.28 * h), (cx + 0.34 * h, cy - 0.24 * h)],
               fill=(255, 255, 255), width=lw * 1.6)

    def _icon_disk(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.84 * h, cy - 0.6 * h, cx + 0.84 * h, cy + 0.6 * h], radius=0.14 * h, fill=ink,
                            outline=col, width=lw)
        d.ellipse([cx - 0.4 * h, cy - 0.4 * h, cx + 0.4 * h, cy + 0.4 * h], outline=c2, width=lw)
        a = t * 3
        d.line([(cx, cy), (cx + 0.36 * h * math.cos(a), cy + 0.36 * h * math.sin(a))], fill=col, width=lw)
        d.ellipse([cx + 0.56 * h, cy + 0.36 * h, cx + 0.7 * h, cy + 0.5 * h], fill=(86, 235, 120))

    def _icon_clock(self, d, cx, cy, h, col, c2, ink, lw, t):
        r = 0.8 * h
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ink, outline=col, width=lw * 1.5)
        a = t * 1.5 - math.pi / 2
        d.line([(cx, cy), (cx + 0.6 * h * math.cos(a), cy + 0.6 * h * math.sin(a))], fill=c2, width=lw * 1.2)
        a2 = t * 0.125 - math.pi / 2
        d.line([(cx, cy), (cx + 0.4 * h * math.cos(a2), cy + 0.4 * h * math.sin(a2))], fill=col, width=lw * 1.5)
        d.ellipse([cx - 0.07 * h, cy - 0.07 * h, cx + 0.07 * h, cy + 0.07 * h], fill=col)

    def _icon_chat(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.84 * h, cy - 0.66 * h, cx + 0.84 * h, cy + 0.38 * h], radius=0.24 * h, fill=ink,
                            outline=col, width=lw)
        d.polygon([(cx - 0.4 * h, cy + 0.36 * h), (cx - 0.5 * h, cy + 0.8 * h), (cx - 0.04 * h, cy + 0.36 * h)], fill=col)
        k = int(t * 3) % 3
        for i in range(3):
            d.ellipse([cx - 0.4 * h + i * 0.4 * h - 0.09 * h, cy - 0.14 * h - 0.09 * h,
                       cx - 0.4 * h + i * 0.4 * h + 0.09 * h, cy - 0.14 * h + 0.09 * h], fill=c2 if i == k else dim(col, 0.7))

    def _icon_bug(self, d, cx, cy, h, col, c2, ink, lw, t):
        for sy in (-0.35, 0.05, 0.45):
            d.line([(cx - 0.4 * h, cy + sy * h), (cx - 0.86 * h, cy + (sy - 0.15) * h)], fill=col, width=lw)
            d.line([(cx + 0.4 * h, cy + sy * h), (cx + 0.86 * h, cy + (sy - 0.15) * h)], fill=col, width=lw)
        d.ellipse([cx - 0.44 * h, cy - 0.28 * h, cx + 0.44 * h, cy + 0.84 * h], fill=col)
        d.ellipse([cx - 0.28 * h, cy - 0.76 * h, cx + 0.28 * h, cy - 0.2 * h], fill=col)
        d.line([(cx, cy - 0.1 * h), (cx, cy + 0.8 * h)], fill=ink, width=lw)
        d.line([(cx - 0.12 * h, cy - 0.76 * h), (cx - 0.3 * h, cy - 0.92 * h)], fill=col, width=lw)
        d.line([(cx + 0.12 * h, cy - 0.76 * h), (cx + 0.3 * h, cy - 0.92 * h)], fill=col, width=lw)

    def _icon_firewall(self, d, cx, cy, h, col, c2, ink, lw, t):
        for r in range(4):
            y = cy - 0.8 * h + r * 0.42 * h
            off = 0.0 if r % 2 == 0 else 0.3
            for c in range(-1, 3):
                x0 = cx - 0.9 * h + (c * 0.6 + off) * h
                x1 = x0 + 0.54 * h
                x0c, x1c = max(x0, cx - 0.9 * h), min(x1, cx + 0.9 * h)
                if x1c - x0c > 0.06 * h:
                    d.rectangle([x0c, y, x1c, y + 0.36 * h], fill=mix(dim(col, 0.55), col, ((r + c) % 3) / 3))

    def _icon_check(self, d, cx, cy, h, col, c2, ink, lw, t):
        r = 0.82 * h
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=dim(col, 0.45), outline=col, width=lw * 1.5)
        d.line([(cx - 0.4 * h, cy + 0.02 * h), (cx - 0.1 * h, cy + 0.34 * h), (cx + 0.46 * h, cy - 0.32 * h)],
               fill=(255, 255, 255), width=lw * 2)

    def _icon_cross(self, d, cx, cy, h, col, c2, ink, lw, t):
        r = 0.82 * h
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=dim(col, 0.45), outline=col, width=lw * 1.5)
        d.line([(cx - 0.38 * h, cy - 0.38 * h), (cx + 0.38 * h, cy + 0.38 * h)], fill=(255, 255, 255), width=lw * 2)
        d.line([(cx - 0.38 * h, cy + 0.38 * h), (cx + 0.38 * h, cy - 0.38 * h)], fill=(255, 255, 255), width=lw * 2)

    def _icon_box(self, d, cx, cy, h, col, c2, ink, lw, t):
        d.rounded_rectangle([cx - 0.7 * h, cy - 0.7 * h, cx + 0.7 * h, cy + 0.7 * h], radius=0.18 * h, fill=ink,
                            outline=col, width=lw)
        d.rounded_rectangle([cx - 0.32 * h, cy - 0.32 * h, cx + 0.32 * h, cy + 0.32 * h], radius=0.08 * h, fill=dim(col, 0.7))

    # ------------------------------------------------------------------ paketlar
    def _packet(self, d, kind, x, y, col, t):
        """Aloqa bo'ylab yuruvchi paket: 'msg' (konvert), 'file' (varaq), 'dot' (yorug' nuqta)."""
        bob = math.sin(t * 9) * 1.2
        y += bob
        if kind == "file":
            d.polygon([(x - 9, y - 12), (x + 3, y - 12), (x + 9, y - 6), (x + 9, y + 12), (x - 9, y + 12)],
                      fill=lighten(col, 0.15))
            d.polygon([(x + 3, y - 12), (x + 3, y - 6), (x + 9, y - 6)], fill=lighten(col, 0.65))
            for i in range(3):
                d.line([(x - 5, y - 2 + i * 5), (x + 5, y - 2 + i * 5)], fill=INK, width=1.6)
        elif kind == "dot":
            d.ellipse([x - 8, y - 8, x + 8, y + 8], fill=lighten(col, 0.25), outline=(255, 255, 255), width=1.5)
            d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(255, 255, 255))
        else:
            d.rounded_rectangle([x - 14, y - 10, x + 14, y + 10], radius=3.5, fill=lighten(col, 0.12),
                                outline=(255, 255, 255), width=1.5)
            d.line([(x - 12.5, y - 8), (x, y + 2), (x + 12.5, y - 8)], fill=(255, 255, 255), width=1.8)

    # ------------------------------------------------------------------ joylashuv
    def _dg_layout(self, nodes, links, box):
        """Tugun markazlari va karta o'lchamini hisoblaydi: (pos, ps, cw, ch). ps - piktogramma maydoni,
        karta (cw x ch) piktogramma va yorliqni birga ushlaydi. Hammasi mantiqiy birlikda."""
        x0, y0, x1, y1 = box
        W, H = x1 - x0, y1 - y0
        n = len(nodes)
        idx = {nd["id"]: i for i, nd in enumerate(nodes)}
        nb = [set() for _ in nodes]
        for lk in links:
            a_, b_ = idx[lk["from"]], idx[lk["to"]]
            nb[a_].add(b_)
            nb[b_].add(a_)
        hub = None
        if n >= 4:
            best = max(range(n), key=lambda i: len(nb[i]))
            if len(nb[best]) >= n - 1 or (n >= 5 and len(nb[best]) >= n - 2):
                hub = best
        pos = [None] * n

        def card(ps):
            return ps * (1.45 if n <= 3 else 1.32), ps * 1.14

        if hub is not None:
            ps = max(48.0, min(100.0, H * 0.22, W * 0.12))
            cw, ch = card(ps)
            cx, cy = x0 + W / 2, y0 + H / 2
            pos[hub] = (cx, cy)
            others = [i for i in range(n) if i != hub]
            m = len(others)
            rx = max(W / 2 - cw * 0.62, cw * 1.1)
            ry = max(H / 2 - ch * 0.62, ch * 0.9)
            for k, i in enumerate(others):
                ang = -math.pi / 2 + (k + 0.5) * 2 * math.pi / m
                pos[i] = (cx + rx * math.cos(ang), cy + ry * math.sin(ang))
            return pos, ps, cw, ch
        if self.portrait:
            cols = 1 if n <= 5 else 2
        else:
            cols = n if n <= 4 else math.ceil(n / 2)
        rows = math.ceil(n / cols)
        cell_w, cell_h = W / cols, H / rows
        ps = max(46.0, min(116.0, (cell_h - 44) / 1.14, (cell_w - 70) / 1.45 if cols > 1 else 116.0))
        cw, ch = card(ps)
        for i in range(n):
            r, c = divmod(i, cols)
            cnt = cols if r < rows - 1 else n - cols * (rows - 1)
            # ilon izi: ketma-ket bog'langan tugunlar ikkinchi qatorda ham yonma-yon tursin
            order = c if r % 2 == 0 else (cnt - 1 - c)
            x = x0 + W / 2 + (order - (cnt - 1) / 2.0) * cell_w
            pos[i] = (x, y0 + cell_h * (r + 0.5))
        return pos, ps, cw, ch

    @staticmethod
    def _edge_dist(ux, uy, hw, hh):
        """Markazdan (ux,uy) yo'nalishda to'rtburchak chegarasigacha masofa."""
        tx = hw / abs(ux) if abs(ux) > 1e-6 else 1e9
        ty = hh / abs(uy) if abs(uy) > 1e-6 else 1e9
        return min(tx, ty)

    def _dg_geometry(self, nodes, links, pos, cw, ch, box):
        """Har bir aloqa uchun yo'l (to'g'ri yoki egri chiziq)."""
        idx = {nd["id"]: i for i, nd in enumerate(nodes)}
        cx = sum(p[0] for p in pos) / len(pos)
        cy = sum(p[1] for p in pos) / len(pos)
        pair_total, pair_idx = {}, {}
        for lk in links:
            key = tuple(sorted((idx[lk["from"]], idx[lk["to"]])))
            pair_total[key] = pair_total.get(key, 0) + 1
        paths = []
        for lk in links:
            a, b = idx[lk["from"]], idx[lk["to"]]
            key = tuple(sorted((a, b)))
            k = pair_idx.get(key, 0)
            pair_idx[key] = k + 1
            A, B = pos[a], pos[b]
            dx, dy = B[0] - A[0], B[1] - A[1]
            dist = math.hypot(dx, dy) or 1.0
            ux, uy = dx / dist, dy / dist
            nx, ny = -uy, ux
            off = 0.0
            if pair_total[key] > 1:       # qarama-qarshi aloqalar yonma-yon parallel yursin
                off = (k - (pair_total[key] - 1) / 2.0) * 34.0
                off = off if a < b else -off
            ea = self._edge_dist(ux, uy, cw / 2, ch / 2) + 8
            eb = self._edge_dist(ux, uy, cw / 2, ch / 2) + 14
            sA = (A[0] + ux * ea + nx * off, A[1] + uy * ea + ny * off)
            sB = (B[0] - ux * eb + nx * off, B[1] - uy * eb + ny * off)
            # oradagi tugunni kesib o'tsa - egri chiziq bilan aylanib o'tadi
            bow = 0.0
            for j, P in enumerate(pos):
                if j in (a, b):
                    continue
                t = ((P[0] - A[0]) * ux + (P[1] - A[1]) * uy)
                if 0 < t < dist:
                    perp = (P[0] - A[0]) * nx + (P[1] - A[1]) * ny
                    if abs(perp) < ch * 0.75:
                        side = -1.0 if perp >= 0 else 1.0
                        bow = max(abs(bow), (ch * 0.62 + 16 - abs(perp))) * side
            if bow:
                # egri chiziq maket (box) dan chiqib ketmasin
                mx_, my_ = (sA[0] + sB[0]) / 2, (sA[1] + sB[1]) / 2
                lim = min(abs(bow), max(20.0, ((box[3] - 26 - my_) if ny * bow > 0 else (my_ - box[1] - 6)) / max(0.2, abs(ny))
                                        if abs(ny) > 0.2 else abs(bow)))
                bow = math.copysign(lim, bow)
                ctrl = ((sA[0] + sB[0]) / 2 + nx * bow * 2, (sA[1] + sB[1]) / 2 + ny * bow * 2)
                pth = Path(bezier(sA, ctrl, sB))
            else:
                pth = Path([sA, ((sA[0] + sB[0]) / 2, (sA[1] + sB[1]) / 2), sB])
            pth.side = (1.0 if off > 0 else -1.0) if off else (1.0 if bow > 0 else -1.0 if bow < 0 else 0.0)
            paths.append(pth)
        return paths

    # ------------------------------------------------------------------ vaqt yordamchisi
    def _unit_t(self, sc, k):
        """k-aloqa/qator paydo bo'lgan vaqt (sahna boshidan, soniya)."""
        rel = sc.get("unit_rel")
        fps = sc.get("fps")
        if rel and fps and k < len(rel):
            return sc.get("lead_f", 0) / float(fps) + rel[k]
        return 0.9 + 1.9 * k

    # ------------------------------------------------------------------ sahna: diagram
    def _s_diagram(self, img, d, sc, shown, anim, age):
        from .render import TEXT, MUTED, BG1, lerp, prog
        x0, y0, x1, y1 = self.content_box
        y = y0
        if sc.get("heading"):
            f, lines, lh, _ = self.fit(sc["heading"], "bold", x1 - x0, 50, 36, minsize=22, max_lines=1)
            self._anim_words(d, x0, y, lines[:1], f, lh, TEXT, age, 0.0, 0.07, 0.42, rise=16)
            e = prog(age, 0.25, 0.5)
            d.rounded_rectangle([x0, y + lh + 2, x0 + max(2, 96 * e), y + lh + 7], radius=3, fill=self.accent)
            y += lh + 22
        nodes, links = sc.get("nodes") or [], sc.get("links") or []
        if len(nodes) < 2:
            return
        t = age
        box = (x0 + 8, y + 6, x1 - 8, y1 - 2)
        lbox = (box[0], box[1], box[2], box[3] - (50 if len(nodes) > 4 else 0))
        pos, ps, cw, ch = self._dg_layout(nodes, links, lbox)
        paths = self._dg_geometry(nodes, links, pos, cw, ch, box)
        idx = {nd["id"]: i for i, nd in enumerate(nodes)}
        pd = self.PD()
        d = self.D(img)
        shown = min(shown, len(links))
        touched_last, touched_old = set(), set()
        for k in range(shown):
            tgt = (idx[links[k]["from"]], idx[links[k]["to"]])
            (touched_last if k == shown - 1 else touched_old).update(tgt)
        # --- aloqalar (chiziq, strelka, yorliq) va paketlar
        TRAVEL, PAUSE = 1.5, 0.5
        pulses = {}
        for k in range(shown):
            lk, path = links[k], paths[k]
            kind = lk.get("kind") or "request"
            col = LINK_COL.get(kind, self.accent)
            ak = max(0.0, age - self._unit_t(sc, k))
            grow = ease_out(ak / 0.55)
            L = path.length
            tip = L * grow
            latest = k == shown - 1
            # asosiy chiziq (yarim shaffof) + harakatlanuvchi shtrixlar
            seg = path.sub(0, tip)
            if len(seg) >= 2:
                pd.line(seg, fill=col + (110 if latest else 70,), width=4 if latest else 3)
                dash, gap = 14.0, 12.0
                s = (-(age * 46.0)) % (dash + gap) - (dash + gap)
                while s < tip:
                    a0, a1 = max(0.0, s), min(tip, s + dash)
                    if a1 - a0 > 1.5:
                        dp = path.sub(a0, a1)
                        if len(dp) >= 2:
                            pd.line(dp, fill=lighten(col, 0.3) + (235 if latest else 150,), width=3.4 if latest else 2.6)
                    s += dash + gap
            if grow > 0.12:
                hx, hy, ang = path.at(max(0.0, tip - 1))
                sz = 11 if latest else 9
                d.polygon([(hx + math.cos(ang) * sz * 0.9, hy + math.sin(ang) * sz * 0.9),
                           (hx + math.cos(ang + 2.5) * sz, hy + math.sin(ang + 2.5) * sz),
                           (hx + math.cos(ang - 2.5) * sz, hy + math.sin(ang - 2.5) * sz)], fill=lighten(col, 0.2))
            # yorliq
            lab = lk.get("label", "")
            if lab and grow > 0.5:
                mx, my, mang = path.at(L * 0.5)
                nxv, nyv = -math.sin(mang), math.cos(mang)
                if path.side:                      # juft aloqalar: yorliq o'z chizig'ining tashqi tomonida
                    nxv, nyv = nxv * path.side, nyv * path.side
                elif nyv > 0:
                    nxv, nyv = -nxv, -nyv          # yakka aloqa: yorliq chiziqdan yuqorida
                vertical = abs(math.sin(mang)) > 0.75
                size = 21 if not self.portrait else 22
                fnt = self.font("bold", size)
                if vertical:
                    size = 18
                    fnt = self.font("bold", size)
                else:
                    while size > 13 and d.textlength(lab, font=fnt) + 24 > max(L - 4, 70):
                        size -= 1
                        fnt = self.font("bold", size)
                    while len(lab) > 6 and d.textlength(lab, font=fnt) + 24 > max(L - 4, 70):
                        lab = lab[:-2].rstrip() + "…"
                tw = d.textlength(lab, font=fnt)
                if vertical:
                    lx = mx + (1 if nxv >= 0 else -1) * (tw / 2 + 24)
                    ly = my
                else:
                    lx, ly = mx + nxv * (size * 0.9 + 8), my + nyv * (size * 0.9 + 8)
                ly = max(box[1] + size * 0.8, min(box[3] - size * 0.9, ly))
                lx = max(box[0] + tw / 2 + 12, min(box[2] - tw / 2 - 12, lx))
                ea = ease_out((grow - 0.5) / 0.5)
                self._glass([lx - tw / 2 - 11, ly - size * 0.75, lx + tw / 2 + 11, ly + size * 0.75], radius=size * 0.75,
                            fill=(10, 15, 24), alpha=0.72 * ea, outline=col, width=1.6, oalpha=0.9 * ea, shine=False)
                d = self.D(img)
                d.text((lx, ly), lab, font=fnt, fill=lerp(self.bgpx(lx, ly), TEXT, ea), anchor="mm")
            # paket(lar)
            if ak > 0.05:
                cyc = TRAVEL + PAUSE
                ph = ak % cyc
                if ph <= TRAVEL:
                    p = ease_io(ph / TRAVEL)
                    px, py, _ = path.at(L * p)
                    for j, (rr, st) in enumerate(((46, 0.55), (30, 0.30))):
                        qx, qy, _ = path.at(L * max(0.0, p - 0.035 * (j + 1)))
                        self._glow(qx, qy, rr * 0.55, col, st * 0.8)
                    self._glow(px, py, 40, col, 0.75)
                    self._packet(d, lk.get("packet") or sc.get("packet") or "msg", px, py, col, age)
                else:
                    q = (ph - TRAVEL) / PAUSE
                    tgt = idx[lk["to"]]
                    pulses[tgt] = max(pulses.get(tgt, 0.0), 1.0 - q)
        # --- tugunlar (shisha karta: piktogramma + yorliq)
        for i, nd in enumerate(nodes):
            cxn, cyn = pos[i]
            kind = nd["kind"]
            col = KIND_COL.get(kind, self.accent)
            en = back((age - 0.12 - 0.1 * i) / 0.5)
            if en <= 0.01:
                continue
            hi = 1.0 if i in touched_last else (0.78 if i in touched_old else 0.5)
            pul = pulses.get(i, 0.0)
            hw, hh = cw / 2 * en, ch / 2 * en
            self._glow(cxn, cyn, cw * 0.78, col, (0.10 + 0.22 * hi + 0.35 * pul) * min(1.0, en))
            self._glass([cxn - hw, cyn - hh, cxn + hw, cyn + hh], radius=ps * 0.2 * en, fill=(14, 21, 32),
                        alpha=0.58 + 0.1 * hi, outline=mix(dim(col, 0.5), col, hi), width=2.6 if hi > 0.9 else 2.0,
                        oalpha=min(1.0, 0.55 + 0.45 * hi))
            if pul > 0.02:   # yetib kelganda kengayuvchi halqa
                gx, gy = hw + 10 * (1 - pul) * en, hh + 10 * (1 - pul) * en
                pd.rounded_rectangle([cxn - gx, cyn - gy, cxn + gx, cyn + gy], radius=ps * 0.24 * en,
                                     outline=col + (int(210 * pul),), width=2.4)
            d = self.D(img)
            lab = nd.get("label", "")
            fs = 21 if not self.portrait else 22
            fnt = self.font("bold", fs)
            lines = [lab] if lab else []
            if lab and d.textlength(lab, font=fnt) > cw - 18:
                fs = 18
                fnt = self.font("bold", fs)
                lines = self.wrap(lab, fnt, cw - 16)[:2]
                if len(lines) == 1 and d.textlength(lab, font=fnt) > cw - 12:
                    fs = 15
                    fnt = self.font("bold", fs)
            lab_h = len(lines) * (fs + 5)
            isz = min(ps * 0.62 * en, (ch - lab_h - 14) * en)
            icy = cyn - ch / 2 * en + 7 * en + isz / 2 + (0 if lines else (ch - isz) / 2 * en - 7 * en)
            if not self.icon3d(kind, cxn, icy, isz * 1.12, col, age + i * 0.7, phase=i * 0.9, hi=hi):     # 3D ikonka (soya, yaltirash)
                self._icon(d, kind, cxn, icy, isz, mix(dim(col, 0.65), col, hi), age + i * 0.7)
            if lines and en > 0.5:
                a = ease_out((en - 0.5) / 0.5)
                ty = cyn + ch / 2 - 8 - lab_h + 2
                colt = mix(MUTED, TEXT, hi)
                for ln in lines:
                    d.text((cxn, ty), ln, font=fnt, fill=lerp(self.bgpx(cxn, ty), colt, a), anchor="ma")
                    ty += fs + 5

    # ------------------------------------------------------------------ sahna: compare
    def _s_compare(self, img, d, sc, shown, anim, age):
        from .render import TEXT, MUTED, BG1, lerp, prog
        x0, y0, x1, y1 = self.content_box
        y = y0
        if sc.get("heading"):
            f, lines, lh, _ = self.fit(sc["heading"], "bold", x1 - x0, 50, 36, minsize=22, max_lines=1)
            self._anim_words(d, x0, y, lines[:1], f, lh, TEXT, age, 0.0, 0.07, 0.42, rise=16)
            y += lh + 20
        L, R = sc.get("left") or {}, sc.get("right") or {}
        li, ri = list(L.get("items", [])), list(R.get("items", []))
        n = max(len(li), len(ri))
        if not n:
            return
        d = self.D(img)
        vs_w = 56
        gapx = 20
        colw = (x1 - x0 - vs_w - 2 * gapx) / 2
        lx0, lx1 = x0, x0 + colw
        rx0, rx1 = x1 - colw, x1
        cols = ((lx0, lx1, L, li, self.accent), (rx0, rx1, R, ri, self.alt))
        th = 56
        # sarlavha plitkalari
        e = prog(age, 0.1, 0.5)
        for ax0, ax1, side, items, col in cols:
            self._glass([ax0, y, ax1, y + th], radius=16, fill=dim(col, 0.28), alpha=0.8 * e, outline=col,
                        width=2.5, oalpha=e)
            d = self.D(img)
            tf = self.font("bold", 28)
            t = side.get("title", "")
            d.text(((ax0 + ax1) / 2, y + th / 2), t, font=tf, fill=lerp(self.bgpx((ax0 + ax1) / 2, y + th / 2), TEXT, e),
                   anchor="mm")
        # VS belgisi
        vx, vy = (x0 + x1) / 2, y + th / 2
        s = back((age - 0.25) / 0.5)
        if s > 0.02:
            r = 27 * s
            self._glow(vx, vy, 60 * s, (255, 206, 86), 0.4)
            d.ellipse([vx - r, vy - r, vx + r, vy + r], fill=(255, 206, 86))
            if s > 0.6:
                d.text((vx, vy), "VS", font=self.font("bold", 24), fill=BG1, anchor="mm")
        y += th + 18
        avail = y1 - y
        gap = 12
        row_h = min(96.0, (avail - gap * (n - 1)) / n)
        ee = ease_out(anim)
        for i in range(min(shown, n)):
            active = i == shown - 1
            a = ee if active else 1.0
            ry = y + i * (row_h + gap)
            for si, (ax0, ax1, side, items, col) in enumerate(cols):
                if i >= len(items):
                    continue
                dx = (1 - ee) * (-60 if si == 0 else 60) if active else 0
                bx0, bx1 = ax0 + dx, ax1 + dx
                self._card(img, [bx0, ry, bx1, ry + row_h], radius=16, fill=(18, 26, 38), glass=a,
                           gfill=dim(col, 0.22) if active else (18, 26, 38), gout=col if active else BORDER_C,
                           width=2.6 if active else 2)
                d = self.D(img)
                tf, tl, tlh, _ = self.fit(items[i], "sans", bx1 - bx0 - 82, row_h - 12, 28, minsize=15, spacing=1.2,
                                          max_lines=3)
                cy = ry + row_h / 2
                d.ellipse([bx0 + 16, cy - 15, bx0 + 46, cy + 15], fill=lerp(self.bgpx(bx0 + 30, cy), col, a))
                d.text((bx0 + 31, cy), "•", font=self.font("bold", 20), fill=lerp(col, BG1, a),
                       anchor="mm")
                ty = cy - len(tl) * tlh / 2
                for ln in tl:
                    d.text((bx0 + 60, ty), ln, font=tf, fill=lerp(self.bgpx(bx0 + 90, cy), TEXT if active else (190, 200, 212), a),
                           anchor="la")
                    ty += tlh


BORDER_C = (60, 70, 84)
