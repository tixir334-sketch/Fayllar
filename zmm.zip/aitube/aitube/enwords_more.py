"""Qo'shimcha: brendlar, fe'llar, sifatlar, ko'p uchraydigan texnik va kundalik so'zlar (ingliz aytilishi)."""

RAW = """
# ---------------- brendlar va kompaniyalar
google=gugl; youtube=yutub; gmail=jimeyl; android=endroyd; chrome=kroum; apple=epl; iphone=ayfoun; ipad=ay ped
macbook=mek buk; microsoft=maykrosoft; windows=uindous; office=ofis; excel=eksel; powerpoint=pauer poynt
outlook=autluk; teams=timz; skype=skayp; linkedin=linkdin; github=git hab; amazon=amazon; netflix=netfliks; spotify=spotifay
facebook=feysbuk; meta=meta; instagram=instagram; whatsapp=uots ep; messenger=mesenjer; tiktok=tik tok; twitter=tuiter
snapchat=snep chet; pinterest=pinterest; reddit=redit; twitch=tuich; steam=stim; epic=epik; nvidia=envidiya; amd=ey em di
intel=intel; qualcomm=kualkom; samsung=samsung; huawei=xuavey; xiaomi=shaomi; sony=souni; nokia=noukiya; tesla=tesla
uber=yuber; airbnb=er bi en bi; paypal=peypal; stripe=strayp; visa=viza; mastercard=master kard; binance=baynens
coinbase=koin beys; ibm=ay bi em; oracle=orakl; sap=es ey pi; adobe=adoub; autodesk=otodesk; atlassian=atlassian
cloudflare=klaud fler; digitalocean=dijital oshn; heroku=heroku; vercel=versel; netlify=netlay fay; render=render
anthropic=antropik; deepmind=dip maynd; huggingface=haging feys; kaggle=kegl; stackoverflow=stek overflou
wikipedia=vikipidiya; medium=midiyum; quora=kuora; telegram=telegram; viber=vayber; zoom=zum; slack=slek; discord=diskord
yandex=yandeks; mail=meyl; vk=vi key; ok=oukey; click=klik; payme=peym mi; uzum=uzum; olx=o el eks; uzcard=uz kard
humo=humo; paynet=peynet; ucell=yu sel; beeline=bi layn; mobiuz=mobi yuz; uztelecom=uz telekom
# ---------------- ko'p uchraydigan fe'l va shakllar (texnik nutqda)
add=ed; added=edid; append=apend; apply=aplay; applied=aplayd; assign=asayn; assigned=asaynd; attach=atech; avoid=avoyd
bind=bayd; bound=baund; blink=blink; boot=but; build=bild; built=bilt; bundle=bandl; call=kol; cancel=kensl
capture=kepcher; change=cheynj; check=chek; checked=chekt; choose=chuz; chose=chouz; clean=klin; click=klik; clicked=klikt
close=klouz; collect=kolekt; combine=kombayn; compare=kompeer; compile=kompayl; compiled=kompayld; compress=kompres
compute=kompyut; configure=konfigyur; configured=konfigyurd; connect=konekt; connected=konektid; convert=konvert
converted=konvertid; copy=kopi; copied=kopid; count=kaunt; crash=kresh; crashed=kresht; create=krieyt; created=krieytid
customize=kastomayz; cut=kat; declare=dikler; declared=diklerd; decode=dikoud; define=difayn; defined=difaynd
delay=dileyl; delete=dilit; deleted=dilitid; deliver=diliver; deny=dinay; depend=dipend; depends=dipendz; describe=diskrayb
design=dizayn; detect=ditekt; develop=divelop; disable=diseybl; disabled=diseybld; discard=diskard; display=displey
download=daunloud; drag=dreg; drop=drop; dump=damp; edit=edit; enable=eneybl; enabled=eneybld; encode=inkoud
enter=enter; enumerate=inyumereyt; escape=iskeyp; evaluate=ivalyueyt; execute=eksekyut; executed=eksekyutid
exit=egzit; expand=ikspend; explain=iksplein; explore=iksplor; expose=ikspouz; extract=ekstrekt; fail=feyl
fetch=fech; fill=fil; filter=filter; find=faynd; finish=finish; fire=fayer; fit=fit; fix=fiks; flatten=fletn
flip=flip; flush=flash; focus=foukus; fold=fould; follow=folou; force=fors; fork=fork; format=format; forward=forvard
generate=jenereyt; generated=jenereytid; grab=greb; grant=grant; handle=hendl; handled=hendld; hash=hesh; highlight=haylayt
hit=hit; hold=hould; host=houst; hover=hover; ignore=ignor; implement=implement; improve=impruv; include=inklud
included=inkludid; increase=inkris; initialize=inishalayz; inject=inject; inspect=inspekt; install=instol
integrate=integreyt; invoke=invouk; iterate=iterit; jump=jamp; keep=kip; kill=kil; launch=lonch; leave=liv
lint=lint; link=link; load=loud; loaded=loudid; lock=lok; log=log; login=login; loop=lup; make=meyk; manage=menij
mark=mark; match=mech; measure=mejer; merge=merj; merged=merjd; mount=maunt; move=muv; name=neym; navigate=nevigeyt
notify=noutifay; obtain=obteyn; open=oupen; optimize=optimayz; overwrite=ouver rayt; parse=pars; parsed=parsd
paste=peyst; pause=poz; perform=perform; pick=pik; pipe=payp; place=pleys; poll=poul; pop=pop; post=poust
prepare=pripeer; press=pres; prevent=privent; print=print; process=prosses; produce=prodyus; protect=protekt
provide=provayd; publish=pablish; pull=pul; push=push; query=kuiri; queue=kyu; quit=kuit; raise=reyz; read=rid
receive=risiv; record=rikord; redirect=ridayrekt; refactor=rifaktor; refresh=rifresh; register=rejister
reload=riloud; remove=rimuv; rename=rineym; render=render; rendering=rendering; repeat=ripit; replace=riplays
reply=riplay; report=ripor; request=rikvest; require=rikuayr; reset=riset; resize=risayz; resolve=rizolv
respond=rispond; restart=ristart; restore=ristor; retry=ritray; return=ritern; reverse=river; revert=rivert
review=rivyu; roll=roul; run=ran; runs=ranz; sanitize=sanitayz; save=seyv; scan=skan; schedule=skedyul; scroll=skroul
search=serch; select=silekt; send=send; sent=sent; serialize=sirializayz; serve=serv; set=set; setup=set ap
share=sher; shift=shift; show=shou; shutdown=shat daun; sign=sayn; skip=skip; sleep=slip; slice=slays; sort=sort
spawn=spon; split=split; start=start; stop=stop; store=stor; stream=strim; submit=sabmit; subscribe=sabskrayb
supply=saplay; support=sapport; swap=svop; switch=svich; sync=sink; synchronize=sinkronayz; take=teyk; test=test
toggle=togl; track=trek; train=treyn; transfer=transfer; transform=transform; translate=trenzleyt; trigger=triger
trim=trim; try=tray; turn=tern; type=tayp; undo=ando; unlock=anlok; unpack=anpek; unzip=an zip; update=apdeyt
upgrade=apgreyd; upload=aplod; use=yuz; validate=velideyt; verify=verifay; view=vyu; visit=vizit; wait=ueyt
wake=ueyk; warn=uorn; watch=uoch; wrap=rep; write=rayt; zip=zip; zoom=zum
# ---------------- sifat va otlar (texnik)
active=aktiv; inactive=inaktiv; available=aveylabl; unavailable=anaveylabl; valid=velid; invalid=invelid
public=pablik; private=prayvit; protected=protektid; internal=internal; external=eksternal; native=neytiv
custom=kastom; default=difolt; automatic=otomatik; manual=menyual; dynamic=daynamik; static=statik; stable=steybl
unstable=anstayabl; latest=leytist; legacy=legasi; modern=modern; deprecated=deprikeytid; experimental=eksperimental
optional=opshnl; required=rikuayrd; mandatory=mendatori; unique=yunik; duplicate=dyuplikit; empty=empti; full=ful
valid=velid; safe=seyf; unsafe=anseyf; fast=fast; faster=faster; slow=slou; slower=slouer; heavy=hevi; light=layt
lightweight=layt ueyt; powerful=pauerful; flexible=fleksibl; scalable=skeylabl; reliable=rilayabl; secure=sikyur
simple=simpl; clean=klin; readable=ridabl; maintainable=meyntaynabl; portable=portabl; modular=modyular
visible=vizibl; hidden=hidn; local=loukal; remote=rimout; global=gloubal; online=onlayn; offline=oflayn
virtual=verchual; physical=fizikal; digital=dijital; analog=analog; binary=baynari; decimal=desimal; hexadecimal=heksadesimal
octal=oktal; unicode=yunikoud; ascii=eski; utf=yu ti ef; emoji=imoji; bit=bit; bits=bitlar; byte=bayt; bytes=bayt
kilobyte=kilobayt; megabyte=megabayt; gigabyte=gigabayt; terabyte=terabayt; hex=heks; rgb=ar ji bi; hsl=eych es el
alpha=elfa; beta=beyta; gamma=gema; delta=delta; sigma=sigma; lambda=lemda; pi=pay; theta=sita; epsilon=epsilon
matrix=meytriks; vector=vektor; scalar=skeyler; tensor=tensor; array=arey; shape=sheyp; dimension=dimenshn
axis=eksis; axes=eksiz; row=rou; column=kolam; cell=sel; sheet=shit; workbook=uerkbuk; spreadsheet=spredshit
formula=formula; function=fankshn; macro=makrou; pivot=pivot; table=teybl; chart=chart; pie=pay; bar=bar
line=layn; scatter=sketer; histogram=histogram; heatmap=hit mep; boxplot=boks plot; legend=lejend; label=leybl
title=taytl; grid=grid; marker=marker; color=kolor; palette=palet; theme=sim; style=stayl; figure=figyur
subplot=sab plot; canvas=kenvas; layer=leyer; mask=mask; filter=filter; blur=bler; sharpen=sharpen; crop=krop
rotate=routeyt; scale=skeyl; flip=flip; resize=risayz; pixel=piksel; channel=chenel; alpha=elfa; contrast=kontrast
brightness=brayt nes; saturation=sechureyshn; histogram=histogram; threshold=treshhold; edge=ej; contour=kontur
# ---------------- pandas / numpy / sklearn atamalari
dataframe=deyta freym; dataframes=deyta freymlar; series=siriz; index=indeks; columns=kolamlar; dtype=di tayp
dtypes=di taypz; shape=sheyp; head=hed; tail=teyl; describe=diskrayb; info=info; values=velyuz; loc=lok; iloc=ay lok
groupby=grup bay; agg=agg; aggregate=agrigeyt; merge=merj; concat=konket; pivot=pivot; melt=melt; apply=aplay
map=mep; drop=drop; dropna=drop en ey; fillna=fil en ey; isna=ay es en ey; isnull=ay snal; notnull=not nal
astype=ez tayp; rename=rineym; sort_values=sort velyuz; value_counts=velyu kauntz; unique=yunik; nunique=en yunik
read_csv=rid si es vi; to_csv=tu si es vi; read_excel=rid eksel; to_excel=tu eksel; read_json=rid jeyson
to_json=tu jeyson; read_sql=rid es kyu el; to_sql=tu es kyu el; reset_index=riset indeks; set_index=set indeks
inplace=in pleys; axis=eksis; copy=kopi; nan=nen; mean=min; std=es ti di; corr=kor; cov=kov
cumsum=kyum sam; rolling=rouling; resample=risempl; shift=shift; diff=dif; pct=pi si ti; change=cheynj
numpy=nampay; ndarray=en di arey; arange=ey reynj; linspace=lin speys; zeros=zirouz; ones=uanz; eye=ay
reshape=ri sheyp; flatten=fletn; transpose=transpouz; dot=dot; matmul=mat mal; concatenate=konketeneyt
stack=stek; vstack=vi stek; hstack=eych stek; where=uer; argmax=arg maks; argmin=arg min; argsort=arg sort
sum=sam; prod=prod; cumprod=kyum prod; sqrt=skver rut; exp=eksp; log=log; cos=kous; tan=tan
random=rendom; rand=rend; randn=rend en; randint=rend int; choice=choys; seed=sid; shuffle=shafl
sklearn=eskilern; train_test_split=treyn test split; fit=fit; predict=pridikt; transform=transform
score=skor; accuracy=akyurasi; regression=rigreshn; classifier=klasifayer; cluster=klaster; kmeans=key minz
pipeline=paypleyn; scaler=skeyler; encoder=inkoder; onehot=uan hot; pca=pi si ey; svm=es vi em
tree=tri; forest=forist; boosting=bustin; xgboost=eks ji bust; lightgbm=layt ji bi em; knn=key en en
matplotlib=metplotlib; pyplot=pay plot; plt=pi el ti; plot=plot; show=shou; savefig=seyv fig; imshow=im shou
xlabel=eks leybl; ylabel=uay leybl; xlim=eks lim; ylim=uay lim; tight_layout=tayt leyaut; figsize=fig sayz
seaborn=sibon; sns=es en es; heatmap=hit mep; pairplot=per plot; countplot=kaunt plot; barplot=bar plot
# ---------------- tarmoq / bot / web amaliy
telebot=tele bot; aiogram=ey ay o gram; pyrogram=pay rogram; telethon=teletun; webhook=ueb huk; polling=poling
longpolling=long poling; bot=bot; botfather=bot fader; inline=inlayn; keyboard=kiborrd; markup=markap
callback=kolbek; handler=hendler; dispatcher=dispecher; router=router; state=steyt; states=steytlar; fsm=ef es em
middleware=midlver; filter=filter; command=komand; commands=komandlar; start=start; help=help; menu=menyu
admin=admin; broadcast=brodkest; sticker=stiker; inlinequery=inlayn kuiri; payload=peyload; update=apdeyt
token=touken; chatid=chet ay di; userid=yuzer ay di; json=jeyson; dict=dikt; list=list; async=eysink
await=aveyt; asyncio=eysink ay o; aiohttp=ey ay o eych ti ti pi; httpx=eych ti ti pi eks; requests=rikvests
session=seshn; timeout=taymaut; retry=ritray; headers=hederlar; cookies=kukilar; proxy=proksi; user_agent=yuzer eyjent
scraping=skreyping; scraper=skreyper; crawler=krouler; parser=parser; html=eych ti em el; xpath=eks pes
selector=silektor; css=si es es; dom=dom; element=element; elements=elementlar; tag=teg; attribute=atribyut
bs4=bi es for; lxml=el eks em el; soup=sup; find_all=faynd ol; get_text=get tekst; href=eych ref; src=es ar si
"""
