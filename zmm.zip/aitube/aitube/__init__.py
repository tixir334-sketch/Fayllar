"""AITube - Termux uchun to'liq avtomatik AI YouTube kanal tizimi."""
__version__ = "1.0.0"
