"""Translatsiya (stream) uchun uzluksiz davom etuvchi bo'laklar ssenariysi.

Har bo'lak (~5 daqiqa) oldingisining davomi: bir xil mavzu, bir xil ovoz, salomlashuvsiz, takrorsiz.
Bo'lak oxiridagi gap ataylab o'rtasida uziladi (`split_tail`), keyingi bo'lak shu gapning davomi bilan
boshlanadi — tomoshabin chegarani sezmaydi ("API deganda" | "kalit...")."""
from __future__ import annotations

import json
import math
import re

from .llm import LLM, LLMError
from .teach import SCENE_SPEC, TEACH_RULES
from .text import clean_line, clean_narration, tr
from .util import clip, log
from .writer import normalize_scenes

SYSTEM = """You are the live-stream scriptwriter of the YouTube channel "{channel}" about {niche}.
The stream never repeats itself and never stops: you write ONE continuous lecture in consecutive segments.
Output language: {lang_name}. Narration is plain spoken text for a TTS voice: short natural sentences, no markdown,
no emojis, no URLs, no code symbols read aloud. Accurate facts only. Safe and legal content.
CONTINUITY RULES (very important):
- A segment is NOT an episode: NO greeting, NO "welcome", NO "today we will", NO recap, NO outro, NO "see you" -
  unless the task says it is the FINAL segment. Just keep teaching, as if the previous segment never paused.
- If "must_start_with" is given, those words are spoken automatically right BEFORE your first scene narration;
  your first narration must continue grammatically and logically right after them (do NOT repeat them).
- Never repeat points listed in "covered"; go deeper or move to the next natural sub-topic of the main topic.
{teach_rules}
Return STRICT JSON only (no markdown fences)."""

PROMPT = """TASK: stream_segment
Stream title: {title}
Main topic: {topic}
Segment number: {seg_no}{final_note}
Target narration: about {words} words across about {scenes} scenes (each scene narration 70-150 words; at most 2 "code" scenes).

{scene_spec}
The narration of every scene must explain what is on screen.

Required JSON: {{"scenes":[...], "summary":"2-3 sentences: exactly what THIS segment covered (used to write the next one)",
 "covered":["3-6 very short phrases of the points covered"]{final_json}}}

KONTEKST (JSON):
{ctx}
"""

FINAL_NOTE = """
THIS IS THE FINAL SEGMENT: the stream ends right after it. Wrap up the topic in 1-2 scenes (short bullets summarising the
key points), thank the viewers and say goodbye warmly. Target: about {words} words."""
FINAL_JSON = ', "goodbye":"2-3 spoken sentences: thanks, the stream is over, see you next time"'


def split_tail(text: str, min_words: int = 9) -> tuple:
    """Oxirgi gapni so'z chegarasida ikkiga bo'ladi: (uziladigan matn, keyingi bo'lakka o'tadigan davomi).
    Gap qisqa bo'lsa bo'linmaydi: (text, "")."""
    text = (text or "").strip()
    if not text:
        return "", ""
    parts = re.split(r"(?<=[.!?…])\s+", text)
    last = parts[-1]
    words = last.split()
    if len(words) < min_words:
        return text, ""
    k = max(3, min(len(words) - 3, len(words) // 2))
    keep, carry = words[:k], words[k:]
    head = " ".join(parts[:-1])
    kept = " ".join(keep).rstrip(",;:-–— ")
    return (head + " " + kept).strip(), " ".join(carry).strip()


def _words_for(cfg, sec: float) -> int:
    return max(30, int(sec * 2.1))        # ~126 so'z/daqiqa (ovoz + sahna ushlab turish vaqti hisobga olingan)


def _write_one(cfg, llm: LLM, st: dict, final: bool = False, seconds: float | None = None, say=lambda m: None) -> dict:
    """st: {title, topic, seg_no, summaries[], covered[], carry}. Qaytaradi:
    {scenes, summary, covered, goodbye, carry_out, llm}. LLM ishlamasa LLMError."""
    lang = tr(cfg.get("LANGUAGE"))
    sec = seconds or (cfg.float("STREAM_FAREWELL_SEC") if final else cfg.float("STREAM_SEG_SEC"))
    words = _words_for(cfg, sec)
    n_sc = max(1 if final else 2, int(round(words / 65.0)))
    ctx = {"previous_summaries": [clip(s, 300) for s in (st.get("summaries") or [])[-4:]],
           "covered": (st.get("covered") or [])[-24:],
           "must_start_with": st.get("carry") or "",
           "last_narration_tail": clip(st.get("tail") or "", 240)}
    if st.get("focus"):
        ctx["this_part_focus"] = f"Part {st.get('part_no', 1)} of {st.get('part_of', 1)}: teach ONLY this: {st['focus']}"
    system = SYSTEM.format(channel=cfg.get("CHANNEL_NAME"), niche=cfg.get("CHANNEL_NICHE"), lang_name=lang["lang_name"],
                           teach_rules=TEACH_RULES)
    prompt = PROMPT.format(title=st.get("title") or "", topic=st.get("topic") or st.get("title") or "",
                           seg_no=st.get("seg_no", 0) + 1, words=words, scenes=n_sc,
                           final_note=FINAL_NOTE.format(words=words) if final else "", scene_spec=SCENE_SPEC,
                           final_json=FINAL_JSON if final else "",
                           ctx=json.dumps(ctx, ensure_ascii=False, indent=1))
    errs, obj, label, scenes = [], None, "", []
    for attempt in range(3):
        extra = ("\n\nOLDINGI JAVOBDA XATO: " + "; ".join(errs[:4]) + ". To'liq JSONni qaytadan yoz.") if errs else ""
        obj, label = llm.complete_json(system, prompt + extra, max_tokens=8192, race=st.get("race", cfg.int("STREAM_AI_RACE")))
        scenes = normalize_scenes(obj.get("scenes") if isinstance(obj, dict) else None)
        scenes = [s for s in scenes if len(s.get("narration", "").split()) >= 8]
        errs = []
        if len(scenes) < (1 if final else 2):
            errs.append("kamida %d ta sahna kerak, har birida 8+ so'zli narration" % (1 if final else 2))
        elif final and not str(obj.get("goodbye", "")).strip():
            errs.append("'goodbye' maydoni yo'q")
        if not errs:
            break
        log.warning("Stream bo'lagi ssenariysi xato (%d/3): %s", attempt + 1, errs)
    if errs:
        raise LLMError("Stream bo'lagi ssenariysi yaroqsiz: " + "; ".join(errs))
    out = {"scenes": scenes, "llm": label,
           "summary": clean_line(obj.get("summary", ""), 600) or clip(scenes[-1]["narration"], 300),
           "covered": [clean_line(x, 60) for x in (obj.get("covered") or [])][:8],
           "goodbye": clean_narration(obj.get("goodbye", "")) if final else "", "carry_out": ""}
    return out


OUTLINE = """TASK: stream_outline
Stream title: {title}
Main topic: {topic}
Split the next {k} consecutive parts of ONE continuous lecture (language: {lang_name}). Each part ~3 minutes.
Parts must follow each other logically, never overlap and never repeat "covered".
Return STRICT JSON only: {{"parts":[{{"focus":"1 short sentence: what ONLY this part teaches"}}]}} with exactly {k} items.
KONTEKST (JSON):
{ctx}
"""


def _outline(cfg, llm: LLM, st: dict, k: int) -> list:
    """Qisqa va tez so'rov: k ta qism rejasi (parallel yozish uchun). Xato bo'lsa [] (ketma-ket yozishga o'tiladi)."""
    lang = tr(cfg.get("LANGUAGE"))
    ctx = {"previous_summaries": [clip(x, 300) for x in (st.get("summaries") or [])[-3:]],
           "covered": (st.get("covered") or [])[-24:]}
    system = SYSTEM.format(channel=cfg.get("CHANNEL_NAME"), niche=cfg.get("CHANNEL_NICHE"), lang_name=lang["lang_name"],
                           teach_rules=TEACH_RULES)
    prompt = OUTLINE.format(title=st.get("title") or "", topic=st.get("topic") or st.get("title") or "", k=k,
                            lang_name=lang["lang_name"], ctx=json.dumps(ctx, ensure_ascii=False))
    try:
        obj, _ = llm.complete_json(system, prompt, max_tokens=min(3500, 250 + 110 * k), race=cfg.int("STREAM_AI_RACE"))
        parts = [clean_line(str(p.get("focus", "")), 200) for p in (obj.get("parts") or []) if isinstance(p, dict)]
        parts = [p for p in parts if p]
        return parts[:k] if len(parts) >= k else []
    except Exception as e:  # noqa: BLE001
        log.info("Reja olinmadi (%s) — qismlar ketma-ket yoziladi", str(e)[:120])
        return []


def write_segment(cfg, llm: LLM, st: dict, final: bool = False, seconds: float | None = None, say=lambda m: None) -> dict:
    """Uzun bo'lak (10 daqiqa) ~5 daqiqalik qismlarga bo'linadi. Avval qisqa reja olinadi, so'ng barcha qismlar BIR VAQTDA
    (parallel) yoziladi — AI javobi k marta tezroq. Reja olinmasa yoki biror qism muvaffaqiyatsiz bo'lsa ketma-ket yoziladi."""
    sec = seconds or (cfg.float("STREAM_FAREWELL_SEC") if final else cfg.float("STREAM_SEG_SEC"))
    if final or sec <= 200 or not cfg.bool("STREAM_SPLIT"):
        try:                                   # BITTA bo'lak = BITTA ssenariy: 5 ta AI poygalashadi, eng tezi olinadi
            return _write_one(cfg, llm, st, final, sec, say)
        except Exception as e:  # noqa: BLE001
            if final or sec <= 200:
                raise
            log.warning("Butun bo'lak bir so'rovda yozilmadi (%s) — qismlarga bo'lib yoziladi", str(e)[:150])
    k = max(2, min(6, int(math.ceil(sec / 180.0))))      # ~3 daqiqalik qismlar: har bir AI javobi qisqa va tez
    each = sec / k
    base = {**st, "summaries": list(st.get("summaries") or []), "covered": list(st.get("covered") or [])}
    focus = _outline(cfg, llm, base, k)
    parts: list = [None] * k
    if focus:
        from concurrent.futures import ThreadPoolExecutor

        def one(i):
            w = {**base, "focus": focus[i], "carry": base.get("carry", "") if i == 0 else "",
                 "tail": base.get("tail", "") if i == 0 else "", "part_no": i + 1, "part_of": k}
            return _write_one(cfg, llm, w, False, each, say)

        with ThreadPoolExecutor(max_workers=k) as ex:
            futs = [ex.submit(one, i) for i in range(k)]
            for i, f in enumerate(futs):
                try:
                    parts[i] = f.result()
                except Exception as e:  # noqa: BLE001
                    log.info("Parallel qism %d yozilmadi (%s) — ketma-ket yoziladi", i + 1, str(e)[:120])
    work = dict(base)
    for i in range(k):                      # yetishmagan qismlar ketma-ket to'ldiriladi
        if parts[i] is None:
            if i > 0 and parts[i - 1] is not None:
                work["summaries"] = work["summaries"] + [parts[i - 1]["summary"]]
                work["tail"] = parts[i - 1]["scenes"][-1].get("narration", "")
            work["carry"] = base.get("carry", "") if i == 0 else ""
            work["focus"] = focus[i] if focus else ""
            parts[i] = _write_one(cfg, llm, work, False, each, say)
    scenes, summ, cov = [], [], []
    for p in parts:
        scenes += p["scenes"]
        summ.append(p["summary"])
        cov += p["covered"]
    return {"scenes": scenes, "llm": parts[-1]["llm"], "summary": clip(" ".join(summ), 600), "covered": cov[:10],
            "goodbye": "", "carry_out": ""}


def write_batch(cfg, llm: LLM, st: dict, m: int, say=lambda x: None) -> list:
    """m ta bo'lakni BIR VAQTDA yozadi: avval butun reja (syllabus) bitta tez so'rovda, so'ng barcha ~3 daqiqalik qismlar
    parallel. Bo'laklar bir-biriga bog'liq emas (reja ularni ajratib turadi), shuning uchun hammasi birdan tayyor bo'ladi.
    Qaytaradi: [{scenes, summary, covered, llm}] (tartib bo'yicha)."""
    from concurrent.futures import ThreadPoolExecutor
    sec = cfg.float("STREAM_SEG_SEC")
    k = max(1, int(math.ceil(sec / 180.0))) if sec > 200 else 1
    each = sec / k
    total = m * k
    base = {**st, "summaries": list(st.get("summaries") or []), "covered": list(st.get("covered") or [])}
    focus = _outline(cfg, llm, base, total) if total > 1 else []
    if not focus:
        focus = [f"the next natural sub-topic, number {i + 1} of {total} (cover only it, in teaching order)" for i in range(total)]
    race = max(0, min(8, cfg.int("STREAM_AI_RACE")))      # har qism uchun 5 ta AI poygalashadi

    def one(i):
        w = {**base, "focus": focus[i], "carry": base.get("carry", "") if i == 0 else "",
             "tail": base.get("tail", "") if i == 0 else "", "part_no": i + 1, "part_of": total, "race": race}
        last = None
        for attempt in (1, 2):
            try:
                return _write_one(cfg, llm, w, False, each, say)
            except Exception as e:  # noqa: BLE001
                last = e
                log.info("Qism %d/%d yozilmadi (%d): %s", i + 1, total, attempt, str(e)[:120])
        raise last

    with ThreadPoolExecutor(max_workers=min(total, 4)) as ex:
        parts = list(ex.map(one, range(total)))
    out = []
    for si in range(m):
        ps = parts[si * k:(si + 1) * k]
        scenes = [s for p in ps for s in p["scenes"]]
        out.append({"scenes": scenes, "llm": ps[-1]["llm"], "goodbye": "", "carry_out": "",
                    "summary": clip(" ".join(p["summary"] for p in ps), 600),
                    "covered": [c for p in ps for c in p["covered"]][:10]})
    return out


def build_scenes(cfg, st: dict, seg: dict, first: bool, final: bool, midcut: bool) -> list:
    """Bo'lak sahnalarini yig'adi: [sarlavha (faqat birinchi)] + asosiy + [xayrlashuv (faqat oxirgi)].
    `carry` (oldingi bo'lak uzgan gap davomi) birinchi narration boshiga qo'shiladi."""
    lang = tr(cfg.get("LANGUAGE"))
    scenes = []
    if first:
        scenes.append({"type": "title", "title": st.get("title") or cfg.get("CHANNEL_NAME"),
                       "label": "LIVE", "subtitle": cfg.get("CHANNEL_NAME"),
                       "narration": st.get("hook") or f"{st.get('title') or ''}.", "chapter": ""})
    body = [dict(s) for s in seg["scenes"]]
    carry = (st.get("carry") or "").strip()
    if carry and body:
        body[0]["narration"] = (carry + " " + body[0]["narration"]).strip()
    for s in body:
        s["chapter"] = s.get("heading") or ""
    carry_out = ""
    if not final and midcut and body:
        body[-1]["narration"], carry_out = split_tail(body[-1]["narration"])
    scenes += body
    if final:
        scenes.append({"type": "outro", "label": lang["next_label"].upper(), "title": cfg.get("CHANNEL_NAME"),
                       "cta": lang["cta_short"].upper(), "narration": seg.get("goodbye") or "", "chapter": ""})
    seg["carry_out"] = carry_out
    return scenes


def fallback_goodbye(cfg, title: str) -> list:
    """LLM ishlamasa: oddiy xayrlashuv sahnasi (hech narsaga bog'liq emas)."""
    lang = tr(cfg.get("LANGUAGE"))
    text = {"uz": "Bugungi translatsiya shu bilan yakunlandi. E'tiboringiz uchun katta rahmat! Yangi videolarda yana ko'rishamiz.",
            "en": "This stream is now over. Thank you so much for watching! See you in the next videos."}.get(
        (cfg.get("LANGUAGE") or "uz").lower()[:2], "Thank you for watching!")
    return [{"type": "outro", "label": lang["next_label"].upper(), "title": title or cfg.get("CHANNEL_NAME"),
             "cta": lang["cta_short"].upper(), "narration": text, "chapter": ""}]
