"""Zanjirni boshqarish: epizodga qaytish, o'tkazilganni qaytarish, faslni qayta ishga tushirish.

Barcha funksiyalar `dry=True` bilan faqat nima o'zgarishini hisoblab beradi (tasdiqlash uchun).
Yuklangan (YouTube'dagi) videolarga hech qachon tegilmaydi, faqat `force` yoki `forget_uploaded` da
epizod yozuvi qayta yasash uchun bo'shatiladi (eski video YouTube'da qoladi, havolasi
`plan.old_uploads` da saqlanadi).
"""
from __future__ import annotations

from pathlib import Path

RESETTABLE = ("scripted", "rendered", "ready", "failed")


def reset_episode(db, e):
    """Epizodni 'planned' holatiga qaytaradi, fayllarini o'chiradi."""
    for k in ("video_path", "thumb_path", "srt_path"):
        p = e.get(k)
        if p:
            for q in (Path(p), Path(p).with_suffix(".json")):
                try:
                    q.unlink()
                except OSError:
                    pass
    plan = {k: v for k, v in (e.get("plan") or {}).items() if k in ("planner", "old_uploads")}
    if e.get("yt_id"):
        plan.setdefault("old_uploads", []).append({"id": e["yt_id"], "url": e.get("yt_url")})
    db.ep_update(e["id"], status="planned", tries=0, error=None, script_json=None, summary=None,
                 video_path=None, thumb_path=None, srt_path=None, duration=None, size_bytes=None,
                 yt_id=None, yt_url=None, uploaded=None, views=0, likes=0, comments=0, llm=None,
                 tts=None, render_sec=None, plan=plan)
    db.kv_del(f"approval_sent:{e['id']}")


def _later(db, gno, statuses=RESETTABLE):
    ph = ",".join("?" * len(statuses))
    return [db.ep(r["id"]) for r in db.q(
        f"SELECT id FROM episodes WHERE gno>? AND status IN ({ph}) ORDER BY gno", (gno, *statuses))]


def _apply(db, todo, dry):
    out = [(e["gno"], e["title"], e["status"]) for e in todo]
    if not dry:
        for e in todo:
            reset_episode(db, e)
        db.kv_del("halt_reason")
    return out


def rewind(db, gno, force=False, dry=False) -> dict:
    """gno-epizoddan boshlab ishlab chiqarishni qaytadan boshlaydi."""
    t = db.ep_by_gno(gno)
    if not t:
        return {"error": "topilmadi"}
    if t["status"] == "uploaded" and not force:
        return {"error": "uploaded", "ep": t}
    todo = [] if t["status"] == "planned" else [t]
    todo += _later(db, gno)
    return {"ep": t, "reset": _apply(db, todo, dry)}


def forget_uploaded(db, gno=None, dry=False) -> dict:
    """Yuklangan videoni 'unutadi': epizod yuklanmagan (planned) holatga qaytadi va noldan qayta yasaladi.

    gno=None - barcha yuklanganlar. Eski ssenariy, ovoz/LLM va video sozlamalari tashlanadi, qayta yasashda
    joriy sozlamalar ishlatiladi (sarlavha, mavzu va va'da saqlanadi). YouTube'dagi video o'chirilmaydi,
    havolasi `plan.old_uploads` da qoladi. Unutilgan epizoddan keyingi yuklanmagan epizodlar ham
    qayta yasaladi (ular zanjirda shu qismga bog'liq)."""
    if gno is None:
        ups = [e for e in db.uploaded(100000)]
        if not ups:
            return {"error": "yo'q", "reset": []}
        ups.sort(key=lambda e: e["gno"])
        first = ups[0]["gno"]
    else:
        t = db.ep_by_gno(gno)
        if not t:
            return {"error": "topilmadi", "reset": []}
        if t["status"] != "uploaded":
            return {"error": "not_uploaded", "ep": t, "reset": []}
        ups, first = [t], gno
    todo = ups + _later(db, first)
    return {"reset": _apply(db, todo, dry), "forgotten": [e["gno"] for e in ups]}


def unskip(db, gno, cascade=True, dry=False) -> dict:
    """O'tkazib yuborilgan epizodni zanjirga qaytaradi. cascade: undan keyingi yuklanmagan
    tayyor epizodlar ham qayta yasaladi (ular oldingi qism sifatida boshqa epizodni nazarda tutgan)."""
    t = db.ep_by_gno(gno)
    if not t:
        return {"error": "topilmadi"}
    if t["status"] != "skipped":
        return {"error": "not_skipped", "ep": t}
    todo = [t] + (_later(db, gno) if cascade else [])
    return {"ep": t, "reset": _apply(db, todo, dry)}


def season_restart(db, sid, dry=False) -> dict:
    """Fasldagi yuklanmagan barcha epizodlarni (o'tkazilganlarini ham) qaytadan boshlaydi."""
    eps = db.season_episodes(sid)
    if not eps:
        return {"error": "topilmadi"}
    todo = [e for e in eps if e["status"] not in ("uploaded", "planned")]
    last = max(e["gno"] for e in eps)
    todo += _later(db, last)
    uploaded = sum(1 for e in eps if e["status"] == "uploaded")
    return {"reset": _apply(db, todo, dry), "uploaded": uploaded, "total": len(eps)}


def season_skip(db, sid, dry=False) -> dict:
    eps = [e for e in db.season_episodes(sid) if e["status"] not in ("uploaded", "skipped")]
    out = [(e["gno"], e["title"], e["status"]) for e in eps]
    if not dry:
        for e in eps:
            reset_episode(db, e)
            db.ep_update(e["id"], status="skipped")
        db.kv_del("halt_reason")
    return {"skipped": out}


def season_unskip(db, sid, dry=False) -> dict:
    eps = [e for e in db.season_episodes(sid) if e["status"] == "skipped"]
    if not eps:
        return {"reset": []}
    first = min(e["gno"] for e in eps)
    todo = eps + _later(db, first)
    return {"reset": _apply(db, todo, dry)}


def seasons_overview(db) -> list:
    rows = []
    for s in db.seasons():
        eps = db.season_episodes(s["id"])
        c: dict = {}
        for e in eps:
            c[e["status"]] = c.get(e["status"], 0) + 1
        rows.append({"season": s, "total": len(eps), "counts": c,
                     "first": eps[0]["gno"] if eps else None, "last": eps[-1]["gno"] if eps else None})
    return rows


def edit_planned(db, gno, field, text) -> str | None:
    """Faqat 'planned' epizodning sarlavha/mavzu/va'dasini o'zgartiradi. Xato matnini yoki None."""
    e = db.ep_by_gno(gno)
    if not e:
        return "Epizod topilmadi."
    if e["status"] != "planned":
        return f"Faqat rejadagi (planned) epizodni tahrirlash mumkin; bu epizod: {e['status']}. Avval /back {gno}."
    if field not in ("title", "topic", "promise", "kind"):
        return "Maydon: title, topic, promise yoki kind."
    db.ep_update(e["id"], **{field: text.strip()})
    return None
