"""Lug'at (ingliz so'z -> o'zbekcha aytilishi) uchun sof mantiq: txt/matn tahlili, qidiruv, eksport.
Botdan mustaqil, shuning uchun to'liq sinab ko'riladi."""
from __future__ import annotations

import difflib
import re

from . import pronounce, speak

MAX_USER = 20000
_APOS = str.maketrans({"’": "'", "ʻ": "'", "ʼ": "'", "‘": "'", "`": "'", "´": "'"})
_SEPS = ("=>", "->", "→", "=", "\t", ";", " - ", " – ", " — ", ":", ",", "|")


def norm_val(v: str) -> str:
    v = (v or "").translate(_APOS).strip().lower()
    return re.sub(r"\s+", " ", v)


def split_line(line: str):
    """Qatordan (so'z, aytilish) yoki None. Ajratgich topilmasa: birinchi bo'sh joygacha so'z, qolgani aytilish."""
    line = line.strip().lstrip("﻿")
    if not line or line.startswith("#") or line.startswith("//"):
        return None
    for sep in _SEPS:
        if sep in line:
            k, _, v = line.partition(sep)
            k, v = k.strip().strip("\"'"), v.strip().strip("\"'")
            if k and v:
                return k, v
    parts = line.split(None, 1)
    if len(parts) == 2:
        return parts[0].strip("\"'"), parts[1].strip("\"'")
    return None


def parse_lexicon(text: str):
    """Matndan lug'at. Qaytaradi: (yaroqli {so'z: aytilish}, xatolar [(qator_raqami, qator, sabab)])."""
    good, bad = {}, []
    for no, raw in enumerate(text.splitlines(), 1):
        pair = split_line(raw)
        if pair is None:
            if raw.strip() and not raw.strip().startswith(("#", "//")):
                bad.append((no, raw.strip()[:40], "ajratgich yo'q (so'z=aytilish)"))
            continue
        k, v = pair
        v = norm_val(v)
        if not pronounce._KEY.match(k):
            bad.append((no, raw.strip()[:40], "so'z yaroqsiz (lotin harf/raqam, _ + # . - ruxsat)"))
        elif not pronounce._VAL.match(v):
            bad.append((no, raw.strip()[:40], "aytilishda faqat a-z, raqam, bo'sh joy, ' va - bo'lishi mumkin"))
        else:
            good[k.lower()] = v
    return good, bad


def decode_bytes(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "cp1251", "latin-1"):
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return data.decode("utf-8", "replace")


def merge_user(db, new: dict) -> dict:
    """Foydalanuvchi lug'atiga qo'shadi. Qaytaradi: {'added','updated','same','full'}."""
    user = dict(db.kv_json(pronounce.KV_USER, {}) or {})
    st = {"added": 0, "updated": 0, "same": 0, "full": 0}
    for k, v in new.items():
        if k in user:
            if user[k] == v:
                st["same"] += 1
            else:
                user[k] = v
                st["updated"] += 1
        elif len(user) >= MAX_USER:
            st["full"] += 1
        else:
            user[k] = v
            st["added"] += 1
    db.kv_set_json(pronounce.KV_USER, user)
    pronounce.activate(db)
    return st


def remove_user(db, key: str) -> bool:
    key = key.lower()
    removed = False
    for kv in (pronounce.KV_USER, pronounce.KV_AUTO):
        d = dict(db.kv_json(kv, {}) or {})
        if key in d:
            d.pop(key)
            db.kv_set_json(kv, d)
            removed = True
    if removed:
        pronounce.activate(db)
    return removed


def all_entries(db):
    """[(so'z, aytilish, manba)] manba: 'user' | 'auto' | 'base'. Ustuvorlik: user > auto > base."""
    user = dict(db.kv_json(pronounce.KV_USER, {}) or {})
    auto = dict(db.kv_json(pronounce.KV_AUTO, {}) or {})
    seen, out = set(), []
    for src, d in (("user", user), ("auto", auto), ("base", speak.EN)):
        for k, v in d.items():
            if k not in seen:
                seen.add(k)
                out.append((k, v, src))
    return out


def search(db, q: str, limit: int = 200):
    """Ingliz so'z yoki o'zbekcha aytilish bo'yicha qidiradi. Natija reytingi: aniq > boshidan > ichidan > o'xshash."""
    q = norm_val(q)
    if not q:
        return []
    ents = all_entries(db)
    scored = []
    for k, v, src in ents:
        kl = k.lower()
        score = None
        if kl == q:
            score = 0
        elif v == q:
            score = 1
        elif kl.startswith(q):
            score = 2
        elif v.startswith(q):
            score = 3
        elif q in kl:
            score = 4
        elif q in v:
            score = 5
        if score is not None:
            scored.append((score, 0 if src == "user" else 1 if src == "auto" else 2, len(kl), kl, v, src))
    scored.sort()
    res = [(kl, v, src) for _, _, _, kl, v, src in scored[:limit]]
    if not res and len(q) >= 3:
        keys = [k for k, _, _ in ents]
        close = difflib.get_close_matches(q, keys, n=8, cutoff=0.72)
        by = {k: (v, s) for k, v, s in ents}
        res = [(k, by[k][0], by[k][1]) for k in close]
        if not res:
            vals = {}
            for k, v, s in ents:
                vals.setdefault(v, (k, s))
            for v in difflib.get_close_matches(q, list(vals), n=6, cutoff=0.75):
                k, s = vals[v]
                res.append((k, v, s))
    return res


def export_text(db, which: str = "user") -> str:
    if which == "all":
        rows = sorted((k, v) for k, v, _ in all_entries(db))
    else:
        rows = sorted((dict(db.kv_json(pronounce.KV_USER, {}) or {})).items())
    head = ("# AITube lug'ati: so'z = o'zbekcha aytilishi\n"
            "# Fayl tahrirlanib, botga qayta yuborilsa, yangilari qo'shiladi/yangilanadi.\n")
    return head + "\n".join(f"{k} = {v}" for k, v in rows) + "\n"


def stats(db) -> dict:
    user = db.kv_json(pronounce.KV_USER, {}) or {}
    auto = db.kv_json(pronounce.KV_AUTO, {}) or {}
    return {"base": len(speak.EN), "auto": len(auto), "user": len(user)}
