"""Texnik so'zlar (dasturlash, tizimlar, tarmoq, AI, bulut) - o'zbekcha ovoz uchun ingliz aytilishi.
Format: so'z=aytilishi; ... (aytilishi - o'zbek lotin harflarida). Qoidalar: ey=/eɪ/, ay=/aɪ/, ou=/oʊ/, au=/aʊ/, i=/iː/, u=/uː/."""

RAW = """
# ---------------- tillar va platformalar
python=payton; py=pay; java=java; javascript=java skript; js=jey es; typescript=tayp skript; ts=ti es
golang=gou leng; go=gou; rust=rast; ruby=rubi; php=pi eych pi; perl=perl; swift=svift; kotlin=kotlin; scala=skala
dart=dart; flutter=flater; lua=lua; haskell=heskel; elixir=eliksir; erlang=erleng; clojure=klojur; julia=juliya
matlab=metleb; fortran=fortran; cobol=koubol; pascal=paskal; delphi=delfay; assembly=asembli; assembler=asembler
bash=besh; zsh=zi esh; powershell=pauer shel; shell=shel; sql=es kyu el; nosql=nou es kyu el; html=eych ti em el
css=si es es; sass=sas; scss=es si es es; less=les; json=jeyson; yaml=yeymel; xml=eks em el; toml=tomel
markdown=markdaun; latex=leytex; regex=reg eks; graphql=gref kyu el; grpc=ji ar pi si; wasm=vazm; webassembly=veb asembli
node=noud; nodejs=noud jey es; deno=dino; bun=ban; react=riekt; reactjs=riekt jey es; redux=ridaks; angular=engyular
vue=vyu; vuejs=vyu jey es; nuxt=nakst; svelte=svelt; next=nekst; nextjs=nekst jey es; gatsby=getsbi; jquery=jey kveri
bootstrap=butstrep; tailwind=teylvind; webpack=ueb pek; vite=vit; babel=beybl; eslint=i es layt; prettier=priti
npm=en pi em; npx=en pi eks; yarn=yarn; pnpm=pi en pi em; pip=pip; pipenv=pip env; poetry=pouitri; conda=konda
django=jango; flask=flesk; fastapi=fest ey pi ay; tornado=tornedo; celery=seleri; pytest=pay test; unittest=yunit test
numpy=nampay; scipy=say pay; pandas=pendas; matplotlib=metplotlib; seaborn=sibon; plotly=plotli; bokeh=bouke
sklearn=eskilern; scikit=sayket; keras=keras; tensorflow=tensor flou; pytorch=pay torch; torch=torch
opencv=oupen si vi; pillow=pilou; requests=rikvests; urllib=yu ar el lib; beautifulsoup=byutiful sup; bs4=bi es for
selenium=selinium; scrapy=skreypi; playwright=pleyrayt; puppeteer=papiter; asyncio=eysink ay o; aiohttp=ey ay o eych ti ti pi
sqlalchemy=es kyu el alkemi; sqlite=es kyu el layt; sqlite3=es kyu el layt uch; postgres=postgres; postgresql=postgres es kyu el
mysql=may es kyu el; mariadb=meriya di bi; mongodb=mongo di bi; mongo=mongo; redis=redis; cassandra=kesendra
elasticsearch=elastik serch; kibana=kibana; logstash=logstesh; kafka=kafka; rabbitmq=rebit em kyu; memcached=mem keshd
oracle=orakl; firebase=fayerbeys; supabase=supabeys; prisma=prizma; hibernate=haybernit; spring=spring; maven=meyven
gradle=greydl; junit=jey yunit; laravel=laravel; symfony=simfoni; rails=reylz; sinatra=sinatra; express=ekspres
nestjs=nest jey es; koa=kou; fastify=fest ifay; electron=elektron; cordova=kordova; ionic=ayonik; xamarin=zamarin
unity=yuniti; unreal=anril; godot=godo; blender=blender; opengl=oupen ji el; vulkan=valkan; directx=dayrekt eks
arduino=arduino; raspberry=razberi; esp32=i es pi o'ttiz ikki; stm32=es ti em o'ttiz ikki; micropython=maykro payton
# ---------------- vositalar
git=git; github=git hab; gitlab=git leb; bitbucket=bit baket; svn=es vi en; mercurial=merkyuriyal
vscode=vi es koud; vim=vim; neovim=nio vim; emacs=imaks; nano=neynou; sublime=sablaym; atom=etom; notepad=noutped
intellij=intel ji; pycharm=paycharm; webstorm=ueb storm; eclipse=iklips; netbeans=net binz; xcode=eks koud
jupyter=jupiter; colab=kolab; kaggle=kegl; anaconda=anakonda; docker=doker; dockerfile=doker fayl; compose=kompouz
kubernetes=kubernitis; k8s=keyts; helm=helm; terraform=terrafom; ansible=ansibl; puppet=papet; chef=shef
jenkins=jenkins; travis=trevis; circleci=serkl si ay; actions=ekshnz; nginx=enjin eks; apache=apechi; tomcat=tomket
caddy=kedi; haproxy=ey ay proksi; traefik=treyfik; envoy=envoy; istio=istio; prometheus=prometius; grafana=grafana
datadog=deyta dog; sentry=sentri; splunk=splank; nagios=negios; zabbix=zabiks; wireshark=uayer shark; nmap=en mep
metasploit=metasployt; burp=berp; kali=keyli; ubuntu=ubuntu; debian=debiyan; fedora=fidora; centos=sent os
redhat=red het; arch=arch; manjaro=menjaro; mint=mint; alpine=elpayn; suse=suze; linux=linuks; unix=yuniks
macos=mak o es; windows=uindous; android=endroyd; ios=ay o es; ipados=ay pad o es; chromeos=kroum o es
termux=termaks; wsl=dabilyu es el; vmware=vi em ver; virtualbox=vorchual boks; vagrant=veygrant; qemu=kyu emyu
postman=poustmen; swagger=svager; insomnia=insomniya; curl=kerl; wget=u get; httpie=eych ti ti pi ay
figma=figma; photoshop=foutoshop; illustrator=ilyustreyter; canva=kenva; sketch=skech; zeplin=zeplin
slack=slek; discord=diskord; telegram=telegram; zoom=zum; teams=timz; trello=trello; jira=jira; notion=nouishn
asana=asana; confluence=konfluens; obsidian=obsidiyan; evernote=evernout; airtable=er teybl; zapier=zepiyer
# ---------------- git va jamoaviy ish
commit=komit; commits=komitlar; branch=brench; branches=brenchlar; merge=merj; rebase=ribeys; clone=kloun
fork=fork; forked=forkt; pull=pul; push=push; pushed=pusht; fetch=fech; stash=stesh; checkout=chekaut
cherry=cheri; pick=pik; tag=teg; release=rilis; diff=dif; blame=bleym; revert=river t; reset=riset; head=hed
origin=orijin; upstream=apstrim; remote=rimout; staging=steyjing; staged=steyjd; unstaged=anstreyjd; untracked=antrekt
conflict=konflikt; conflicts=konfliktlar; resolve=rizolv; issue=ishyu; issues=ishyular; pr=pi ar; request=rikvest
review=rivyu; reviewer=rivyuer; approve=apruv; approved=apruvd; maintainer=meyntayner; contributor=kontribyuter
repository=ripozitori; repo=ripo; repos=riposlar; readme=rid mi; license=laysens; gitignore=git ignor; ignore=ignor
workflow=uerkflou; pipeline=paypleyn; pipelines=paypleynlar; build=bild; builds=bildlar; deploy=diploy; deployment=diploymnt
deployed=diployd; rollback=roulbek; hotfix=hotfiks; patch=pech; version=vershn; versions=vershnlar; semver=sem ver
changelog=cheynj log; milestone=maylstoun; sprint=sprint; backlog=beklog; agile=ejayl; scrum=skram; kanban=kanban
standup=stend ap; roadmap=roudmep; feature=fiche r; bug=bag; bugs=baglar; bugfix=bag fiks; debug=di bag; debugging=di bagging
debugger=di bager; breakpoint=breykpoynt; traceback=treys bek; stacktrace=stek treys; log=log; logs=loglar; logging=logging
logger=loger; print=print; printf=printf; console=konsoul; terminal=terminal; prompt=prompt; cli=si el ay; gui=ji yu ay
# ---------------- tuzilma va tushunchalar
algorithm=algoritm; algorithms=algoritmlar; function=fankshn; functions=fankshnlar; method=metod; methods=metodlar
class=kles; classes=klesslar; object=obyekt; objects=obyektlar; instance=instans; inheritance=inxeritans
interface=interfeys; abstract=ebstrakt; static=statik; public=pablik; private=prayvit; protected=protektid
constructor=konstraktor; destructor=distraktor; self=self; this=dis; super=syuper; override=overrayd; overload=ouverloud
polymorphism=polimorfizm; encapsulation=inkepsyuleyshn; abstraction=ebstrekshn; module=modyul; modules=modyullar
package=pekij; packages=pekijlar; library=layberi; libraries=layberilar; framework=freymvork; frameworks=freymvorklar
import=import; export=eksport; from=from; as=ez; return=ritern; returns=riternz; yield=yild; lambda=lemda
variable=veriybl; variables=veriyblar; constant=konstant; constants=konstantlar; const=konst; let=let; var=var
integer=integer; int=int; float=flout; double=dabl; string=string; strings=stringlar; str=str; char=char; boolean=bulyan
bool=bul; true=tru; false=fols; null=nal; none=non; undefined=andifaynd; nan=nen; infinity=infiniti; void=voyd
array=arey; arrays=areylar; list=list; lists=listlar; tuple=tyupl; set=set; sets=setlar; dict=dikt; dictionary=dikshneri
map=mep; maps=meplar; hash=hesh; hashmap=hesh mep; hashtable=hesh teybl; queue=kyu; stack=stek; heap=hip; tree=tri
graph=gref; node=noud; nodes=noudlar; edge=ej; edges=ejlar; vertex=verteks; linked=linkt; sorting=sorting
sort=sort; sorted=sortid; search=serch; binary=baynari; recursion=rikershn; recursive=rikersiv; iteration=iterey shn
iterate=iterit; iterator=iteretor; generator=jeneretor; loop=lup; loops=luplar; while=uayl; for=for; foreach=for iych
break=breyk; continue=kontinyu; pass=pas; if=if; else=els; elif=el if; switch=svich; case=keys; default=difolt
try=tray; except=iksept; catch=kech; finally=fayneli; throw=srou; raise=reyz; exception=iksepshn; exceptions=iksepshnlar
error=erer; errors=ererlar; warning=uorning; assert=asert; test=test; tests=testlar; testing=testing; unit=yunit
mock=mok; fixture=fiksche r; coverage=kaveridj; benchmark=benchmark; profiler=profayler; profiling=profayling
async=eysink; await=aveyt; sync=sink; thread=tred; threads=tredlar; threading=treding; process=prosses; processes=prosseslar
multiprocessing=malti prosessing; concurrency=konkarensi; parallel=parallel; lock=lok; mutex=myuteks; semaphore=semafor
deadlock=ded lok; race=reys; condition=kondishn; callback=kolbek; promise=promis; promises=promislar; future=fyucher
event=ivent; events=iventlar; listener=lisner; handler=hendler; hook=huk; hooks=huklar; trigger=triger; emit=emit
middleware=midlver; decorator=dekoreyter; decorators=dekoreyterlar; wrapper=reper; closure=klouzhr; scope=skoup
global=gloubal; local=loukal; namespace=neymspeys; context=kontekst; manager=meneyjer; session=seshn; cookie=kuki
cookies=kukilar; token=touken; tokens=toukenlar; key=ki; keys=kilar; value=velyu; values=velyular; pair=per
attribute=atribyut; attributes=atribyutlar; property=propirti; properties=propirtilar; field=fild; fields=fildlar
parameter=parameter; parameters=parameterlar; argument=argyument; arguments=argyumentlar; args=args; kwargs=kuargs
keyword=kiuord; positional=pozishnal; optional=opshnal; required=rikuayrd; default=difolt; type=tayp; types=taypz
typing=tayping; hint=hint; hints=hintlar; annotation=anoteyshn; generic=jenerik; generics=jenerikz; enum=inam
struct=strakt; union=yunyon; pointer=poynter; reference=referens; memory=memori; allocation=aloukeyshn; garbage=garbij
collector=kolektor; leak=lik; buffer=bafer; cache=kesh; cached=keshd; caching=keshing; lru=el ar yu; ttl=ti ti el
index=indeks; indexes=indekslar; indices=indisiz; slice=slays; slicing=slaysing; range=reynj; length=lengs; len=len
size=sayz; count=kaunt; sum=sam; min=min; max=maks; avg=evg; average=everij; mean=min; median=midian; mode=moud
round=raund; floor=flor; ceil=sil; abs=abs; sqrt=skver rut; pow=pau; mod=mod; random=rendom; seed=sid; shuffle=shafl
sample=semipl; choice=choys; uniform=yuniform; normal=normal; gaussian=gaussiyan; distribution=distribyushn
filter=filter; filters=filterlar; reduce=ridyus; zip=zip; enumerate=inyumereyt; reversed=rivers t; reverse=river s
append=apend; extend=ikstend; insert=insert; remove=rimuv; delete=dilit; pop=pop; clear=klir; copy=kopi; deepcopy=dip kopi
join=joyn; split=split; strip=strip; replace=riplays; find=faynd; lower=louer; upper=aper; format=format; formatting=formating
startswith=start uits; endswith=end uits; contains=konteyns; match=mech; pattern=patern; group=grup; compile=kompayl
read=rid; write=rayt; open=oupen; close=klouz; file=fayl; files=faylar; path=pes; paths=peslar; directory=dayrektori
folder=foulder; mkdir=em kay dir; rmdir=ar em dir; cd=si di; ls=el es; cat=ket; echo=ekou; touch=tach; chmod=ch mod; chown=ch oun
sudo=sudo; su=es yu; root=rut; admin=admin; user=yuzer; users=yuzerlar; username=yuzer neym; password=pasuord; login=login
logout=logaut; signup=sayn ap; signin=sayn in; register=rejister; auth=ot; authentication=otentikeyshn; authorization=otorayzeyshn
oauth=o ot; jwt=jey dabilyu ti; hashing=heshing; encryption=inkripshn; encrypt=inkript; decrypt=dikript; cipher=sayfer
salt=solt; bcrypt=bi kript; sha=shey; md5=em di besh; aes=ey i es; rsa=ar es ey; ssl=es es el; tls=ti el es; https=eych ti ti pi es
certificate=sertifikit; cert=sert; firewall=fayervol; proxy=proksi; vpn=vi pi en; tor=tor; malware=melver; virus=vayrus
trojan=troujan; ransomware=rensom ver; phishing=fishing; spam=spem; exploit=iksployt; vulnerability=valnerabiliti
payload=peyload; injection=injekshn; xss=eks es es; csrf=si es ar ef; ddos=di dos; dos=dos; botnet=bot net; hacker=heker
hackers=hekerlar; hacking=heking; pentest=pen test; cve=si vi i; zeroday=ziro dey; backdoor=bek dor; rootkit=rut kit
"""
