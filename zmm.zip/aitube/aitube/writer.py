"""Ssenarist: epizod skriptini yozadi. Oldingi qismga bog'laydi, keyingisiga chorlaydi."""
from __future__ import annotations

import ast
import json
import re

from .llm import LLM, LLMError
from .anim import infer_kind
from .teach import SCENE_SPEC, TEACH_RULES
from .planner import performance_hints
from .text import clean_line, clean_narration, tr
from .util import clip, log, significant

WRITE_SYSTEM = """You are the head writer of the serialized YouTube channel "{channel}" about {niche}.
You write ONE complete episode as structured JSON. Output language: {lang_name}.
Hard rules:
- The channel is a continuous series: this episode MUST build on the previous episode (callback in
  the first seconds) and MUST end by teasing exactly the next episode.
- Narration is plain spoken text for a text-to-speech voice: short natural sentences, no markdown,
  no emojis, no URLs, no code symbols read aloud; describe code in words.
- Real value only: accurate facts, no invented statistics, no filler, no clickbait lies.
- Code must be correct, complete and runnable as shown, prefer the standard library, max 14 lines,
  each line max 54 characters, no placeholders like "..." and no secrets.
- Never copy copyrighted text. Stay safe and legal.
{teach_rules}
Return STRICT JSON only (no markdown fences)."""

WRITE_PROMPT = """TASK: write_episode
Write episode #{gno} (part {num} of {season_len} in the season).
Target total narration: about {words} words across about {scenes} content scenes.

{scene_spec}
Each scene narration: 70-150 words ("explain" and "parts": 90-170 words). Narration must explain what is on screen, item by item.

Required top-level JSON fields:
{{"title": "... (<= 80 chars, the series number is added automatically)",
  "description": "2-3 plain-text paragraphs for YouTube (no < > characters)",
  "tags": ["8-12 tags"],
  "thumb_text": "2-4 impactful words for the thumbnail",
  "hook": "first spoken sentences (1-2) that grab attention",
  "recap": "{recap_rule}",
  "scenes": [ ... ],
  "summary": "4-6 sentences: exactly what this episode covered and built (used to write the next episode)",
  "key_points": ["3-6 key takeaways"],
  "teaser": "2-3 spoken sentences that tease the NEXT episode (title and idea given in context) and create curiosity; mention its topic explicitly"}}

KONTEKST (JSON):
{ctx}
"""


# ----------------------------------------------------------------------------- tekshiruv
def _check_code(code: str, lang: str) -> str | None:
    lang = (lang or "").lower()
    if lang in ("python", "py", "python3"):
        try:
            ast.parse(code)
        except SyntaxError as e:
            return f"Python sintaksis xatosi {e.lineno}-qatorda: {e.msg}"
    elif lang == "json":
        try:
            json.loads(code)
        except ValueError as e:
            return f"JSON xato: {e}"
    elif lang in ("javascript", "js", "typescript", "ts", "go", "c", "cpp", "java", "rust", "css", "sql"):
        stack, pairs = [], {")": "(", "]": "[", "}": "{"}
        in_str = None
        prev = ""
        for ch in code:
            if in_str:
                if ch == in_str and prev != "\\":
                    in_str = None
            elif ch in "\"'`":
                in_str = ch
            elif ch in "([{":
                stack.append(ch)
            elif ch in ")]}":
                if not stack or stack.pop() != pairs[ch]:
                    return "qavslar muvozanati buzilgan"
            prev = ch
        if stack:
            return "qavslar yopilmagan"
    return None


def _clean_code(code: str) -> str:
    code = str(code or "")
    code = re.sub(r"^```[a-zA-Z0-9]*\n?", "", code.strip())
    code = re.sub(r"\n?```$", "", code)
    code = code.expandtabs(4)
    lines = [ln.rstrip() for ln in code.split("\n")]
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return "\n".join(lines)


def normalize_diagram(s: dict):
    """LLM sxemasini tozalaydi: tugun id lari, turlari (yorliqdan taxmin), mavjud tugunlarga ulangan aloqalar."""
    from .anim import infer_kind
    nodes, ids = [], {}
    for i, n in enumerate(s.get("nodes") or []):
        if not isinstance(n, dict):
            continue
        label = clean_line(n.get("label", ""), 18)
        nid = str(n.get("id") or label or i).strip()[:24]
        if not nid or nid in ids or len(nodes) >= 8:
            continue
        ids[nid] = len(nodes)
        nodes.append({"id": nid, "kind": infer_kind(n.get("kind", ""), label), "label": label})
    links = []
    for lk in s.get("links") or []:
        if not isinstance(lk, dict) or len(links) >= 8:
            continue
        a, b = str(lk.get("from", "")).strip(), str(lk.get("to", "")).strip()
        if a not in ids or b not in ids or a == b:
            continue
        kind = str(lk.get("kind", "request")).lower()
        if kind not in ("request", "response", "data", "error", "event"):
            kind = "request"
        item = {"from": a, "to": b, "label": clean_line(lk.get("label", ""), 22), "kind": kind}
        if str(lk.get("packet", "")).lower() in ("msg", "file", "dot"):
            item["packet"] = str(lk["packet"]).lower()
        links.append(item)
    return nodes, links


def normalize_scenes(raw_scenes) -> list:
    out = []
    for s in raw_scenes or []:
        if not isinstance(s, dict):
            continue
        t = str(s.get("type", "bullets")).lower()
        if t not in ("bullets", "code", "flow", "diagram", "compare", "parts", "explain"):
            t = "bullets"
        sc = {"type": t, "heading": clean_line(s.get("heading", ""), 60),
              "narration": clean_narration(s.get("narration", ""))}
        if t == "code":
            sc["code"] = _clean_code(s.get("code", ""))
            sc["language"] = str(s.get("language", "python")).lower().strip() or "python"
            sc["filename"] = clean_line(s.get("filename", ""), 28) or ("main." + {
                "python": "py", "javascript": "js", "bash": "sh", "go": "go"}.get(sc["language"], "txt"))
        elif t == "flow":
            sc["steps"] = [clean_line(x, 44) for x in (s.get("steps") or []) if str(x).strip()][:6]
        elif t == "diagram":
            nodes, links = normalize_diagram(s)
            if len(nodes) < 2 or not links:
                continue                # yaroqsiz sxema tashlanadi (tekshiruv boshqa sahnalar yetarlimi ko'radi)
            sc["nodes"], sc["links"] = nodes, links
            if str(s.get("packet", "")).lower() in ("msg", "file", "dot"):
                sc["packet"] = str(s["packet"]).lower()
        elif t == "parts":
            items = []
            for it in (s.get("items") or [])[:6]:
                if not isinstance(it, dict) or not str(it.get("name", "")).strip():
                    continue
                items.append({"icon": infer_kind(it.get("icon"), it.get("name")), "name": clean_line(it.get("name", ""), 30),
                              "role": clean_line(it.get("role", ""), 72)})
            if len(items) < 2:
                continue
            sc["items"] = items
        elif t == "explain":
            sc["term"] = clean_line(s.get("term") or s.get("heading") or "", 32)
            sc["icon"] = infer_kind(s.get("icon"), sc["term"])
            sc["definition"] = clean_line(s.get("definition", ""), 150)
            sc["analogy"] = clean_line(s.get("analogy", ""), 140)
            sc["points"] = [clean_line(x, 58) for x in (s.get("points") or []) if str(x).strip()][:3]
            if len(sc["definition"]) < 12:
                continue
        elif t == "compare":
            def side(x):
                x = x if isinstance(x, dict) else {}
                return {"title": clean_line(x.get("title", ""), 24),
                        "items": [clean_line(i, 44) for i in (x.get("items") or []) if str(i).strip()][:4]}
            sc["left"], sc["right"] = side(s.get("left")), side(s.get("right"))
            if not sc["left"]["items"] or not sc["right"]["items"]:
                continue
        else:
            sc["bullets"] = [clean_line(x, 60) for x in (s.get("bullets") or []) if str(x).strip()][:5]
        out.append(sc)
    return out


def validate_script(obj, ctx) -> list:
    errs = []
    if not isinstance(obj, dict):
        return ["javob JSON ob'ekt emas"]
    for f in ("title", "description", "hook", "summary", "teaser"):
        if len(str(obj.get(f, "")).strip()) < 8:
            errs.append(f"'{f}' maydoni bo'sh yoki juda qisqa")
    scenes = normalize_scenes(obj.get("scenes"))
    min_scenes = 4
    if len(scenes) < min_scenes:
        errs.append(f"sahnalar kam: {len(scenes)} (kamida {min_scenes})")
    total_words = len(re.findall(r"\w+", " ".join(s["narration"] for s in scenes) + " " + str(obj.get("hook", ""))))
    if total_words < ctx["target_words"] * 0.55:
        errs.append(f"matn juda qisqa: {total_words} so'z (maqsad ~{ctx['target_words']})")
    for i, s in enumerate(scenes, 1):
        if len(s["narration"].split()) < 12:
            errs.append(f"{i}-sahna matni juda qisqa")
        if s["type"] == "code":
            code = s["code"]
            if not code.strip():
                errs.append(f"{i}-sahna: kod bo'sh")
                continue
            lines = code.split("\n")
            if len(lines) > 16:
                errs.append(f"{i}-sahna: kod {len(lines)} qator (maks 14)")
            if max(len(ln) for ln in lines) > 62:
                errs.append(f"{i}-sahna: kod qatori juda uzun (maks 54 belgi)")
            if "..." in code and s["language"] in ("python", "py"):
                errs.append(f"{i}-sahna: kodda '...' to'ldirgich bor")
            e = _check_code(code, s["language"])
            if e:
                errs.append(f"{i}-sahna kodi: {e}")
        elif s["type"] == "parts" and len(s["items"]) < 2:
            errs.append(f"{i}-sahna: 'parts' uchun kamida 2 karta kerak")
        elif s["type"] == "explain" and len(s["definition"]) < 12:
            errs.append(f"{i}-sahna: 'explain' uchun ta'rif (definition) kerak")
        elif s["type"] == "flow" and len(s["steps"]) < 3:
            errs.append(f"{i}-sahna: kamida 3 qadam kerak")
        elif s["type"] == "bullets" and len(s["bullets"]) < 2:
            errs.append(f"{i}-sahna: kamida 2 band kerak")
    kinds = [s["type"] for s in scenes]
    if ctx.get("episode", {}).get("kind") != "history" and kinds.count("diagram") < 1 and len(scenes) >= 6:
        errs.append("kamida 1 ta 'diagram' (animatsiyali sxema) sahnasi kerak: tugunlar va ular orasidagi aloqalar")
    prev, nxt = ctx.get("previous"), ctx.get("next")
    if prev:
        recap = str(obj.get("recap", "")).strip()
        if len(recap.split()) < 8:
            errs.append("'recap' (oldingi qism xulosasi) yo'q yoki qisqa")
        else:
            ref = significant(prev["title"] + " " + prev["summary"] + " " + " ".join(prev.get("key_points", [])))
            if not (significant(recap) & ref):
                errs.append("'recap' oldingi qism mazmuniga bog'lanmagan")
    if nxt:
        ref = significant(nxt["title"] + " " + nxt["topic"])
        if not (significant(str(obj.get("teaser", ""))) & ref):
            errs.append("'teaser' keyingi qism mavzusiga bog'lanmagan (uning nomi/mavzusini ayt)")
    return errs


def _drop_bad_code(obj, ctx):
    """Qayta urinishlardan keyin ham xato bo'lgan kod sahnalarini olib tashlaydi."""
    scenes = normalize_scenes(obj.get("scenes"))
    keep = []
    for s in scenes:
        if s["type"] == "code":
            code = s["code"]
            if (not code.strip() or _check_code(code, s["language"]) or len(code.split("\n")) > 16
                    or max(len(x) for x in code.split("\n")) > 62):
                log.warning("Xato kod sahnasi olib tashlandi: %s", s["heading"])
                continue
        keep.append(s)
    obj = dict(obj)
    obj["scenes"] = keep
    return obj


# ----------------------------------------------------------------------------- asosiy
def build_context(cfg, db, ep) -> dict:
    prev = db.prev_episode(ep["gno"])
    nxt = db.next_planned_after(ep["gno"])
    season = db.season(ep["season_id"]) or {}
    minutes = max(1, cfg.int("EPISODE_MINUTES"))
    words = int(minutes * 125)
    ctx = {
        "channel": cfg.get("CHANNEL_NAME"),
        "episode": {"gno": ep["gno"], "num_in_season": ep["num"], "kind": ep["kind"],
                    "title": ep["title"], "topic": ep["topic"], "promise": ep["promise"]},
        "season": {"theme": season.get("theme", ""), "description": season.get("description", "")},
        "target_words": words,
        "scene_count": max(4, min(12, round(words / 65))),
        "previous": None,
        "next": None,
    }
    if prev:
        sc = prev.get("script") or {}
        ctx["previous"] = {"title": prev["title"], "summary": prev.get("summary") or prev["promise"] or "",
                           "key_points": sc.get("key_points", []), "teaser_given": sc.get("teaser", "")}
    if nxt:
        ctx["next"] = {"title": nxt["title"], "topic": nxt["topic"], "promise": nxt["promise"]}
    note = db.kv_get("admin_note")
    if note:
        ctx["admin_note"] = note
    hints = performance_hints(db)
    if hints:
        ctx["performance_hints"] = hints
    return ctx


def write_episode(cfg, db, llm: LLM, ep, say=lambda m: None) -> dict:
    ctx = build_context(cfg, db, ep)
    lang = tr(cfg.get("LANGUAGE"))
    season_len = max(1, db.season_size(ep["season_id"]))
    recap_rule = ("1-2 spoken sentences recalling the previous episode (start with a phrase like '%s ...')"
                  % lang["recap_label"]) if ctx["previous"] else "empty string for the very first episode"
    system = WRITE_SYSTEM.format(channel=cfg.get("CHANNEL_NAME"), niche=cfg.get("CHANNEL_NICHE"),
                                 lang_name=lang["lang_name"], teach_rules=TEACH_RULES)
    prompt = WRITE_PROMPT.format(gno=ep["gno"], num=ep["num"], season_len=season_len, words=ctx["target_words"],
                                 scenes=ctx["scene_count"], recap_rule=recap_rule, scene_spec=SCENE_SPEC,
                                 ctx=json.dumps(ctx, ensure_ascii=False, indent=1))
    obj, label, errs = None, "", []
    for attempt in range(1, 4):
        extra = ""
        if errs:
            extra = ("\n\nOLDINGI JAVOBDAGI XATOLAR. Hammasini tuzatib, to'liq JSONni qaytadan yoz:\n- "
                     + "\n- ".join(errs[:10]))
        obj, label = llm.complete_json(system, prompt + extra, max_tokens=8192, race=cfg.int("VIDEO_AI_RACE"))
        errs = validate_script(obj, ctx)
        if not errs:
            break
        log.warning("Ssenariy xatolari (%d/3): %s", attempt, errs)
        say(f"⚠️ Ssenariy tekshiruvida {len(errs)} ta xato (urinish {attempt}/3), qayta yozilmoqda:\n"
            + "\n".join("• " + clip(e, 110) for e in errs[:5]))
    soft = "kamida 1 ta 'diagram'"
    if errs and all(e.startswith(soft) for e in errs):
        log.warning("Ssenariyda 'diagram' sahnasi yo'q (qayta urinishlardan keyin ham) - davom etiladi")
        errs = []
    if errs:
        obj = _drop_bad_code(obj, ctx)
        errs = [e for e in validate_script(obj, ctx) if not e.startswith(soft)]
        if errs:
            raise LLMError("Ssenariy 3 urinishdan keyin ham yaroqsiz: " + "; ".join(errs[:4]))
        say("ℹ️ Xato kod sahnalari olib tashlandi, qolgan ssenariy yaroqli.")

    tags = []
    for t in obj.get("tags") or []:
        t = clean_line(t, 30).lstrip("#")
        if t and t.lower() not in [x.lower() for x in tags]:
            tags.append(t)
    script = {
        "title": clean_line(obj["title"], 80),
        "description": re.sub(r"[<>]", "", str(obj["description"]).strip())[:2500],
        "tags": tags[:12],
        "thumb_text": clean_line(obj.get("thumb_text") or obj["title"], 36),
        "hook": clean_narration(obj["hook"]),
        "recap": clean_narration(obj.get("recap", "")) if ctx["previous"] else "",
        "scenes": normalize_scenes(obj["scenes"]),
        "summary": clean_line(obj["summary"], 900),
        "key_points": [clean_line(k, 140) for k in (obj.get("key_points") or [])][:6],
        "teaser": clean_narration(obj["teaser"]),
        "llm": label,
        "words": sum(len(s["narration"].split()) for s in normalize_scenes(obj["scenes"])),
    }
    return script
