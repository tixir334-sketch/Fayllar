"""Internet, ijtimoiy tarmoq, biznes, apparat va AI atamalari - ingliz aytilishi (o'zbek lotin harflarida)."""

RAW = """
# ---------------- ijtimoiy tarmoq va kontent
like=layk; likes=layklar; liked=laykt; dislike=dislayk; share=sher; shares=sherlar; shared=sherd; comment=koment
comments=komentlar; subscribe=sabskrayb; subscriber=sabskrayber; subscribers=sabskrayberlar; channel=chenel
channels=chenellar; video=vidiou; videos=vidioular; vlog=vlog; blog=blog; blogger=bloger; post=poust; posts=poustlar
story=stori; stories=storilar; reels=rilz; shorts=shorts; live=layv; stream=strim; streaming=striming; streamer=strimer
podcast=podkest; playlist=pleylist; thumbnail=sambneyl; trailer=treyler; teaser=tizer; episode=episoud; season=sizon
views=vyuz; view=vyu; viewer=vyuer; viewers=vyuerlar; follow=folou; follower=folouer; followers=folouerlar; following=folouing
unfollow=anfolou; friend=frend; friends=frendlar; message=mesij; messages=mesijlar; messenger=mesenjer; chat=chet
chats=chetlar; chatbot=chet bot; group=grup; groups=guruplar; story=stori; feed=fid; timeline=taymlayn; profile=proufayl
account=akkaunt; accounts=akkauntlar; page=peyj; pages=peyjlar; link=link; links=linklar; bio=bayo; tag=teg; hashtag=heshteg
trend=trend; trends=trendlar; trending=trending; viral=vayral; content=kontent; creator=krieyter; creators=krieyterlar
influencer=influenser; brand=brend; marketing=marketing; marketer=marketer; seo=es i o; smm=es em em; ads=edz; ad=ed
advertising=edvertayzing; campaign=kempeyn; target=target; targeting=targeting; audience=odiens; engagement=engeyjment
reach=rich; impressions=impreshnz; click=klik; clicks=kliklar; ctr=si ti ar; conversion=konvershn; funnel=fanl
lead=lid; leads=lidlar; crm=si ar em; email=imeyl; newsletter=nyuzletter; inbox=inboks; spam=spem; sms=es em es
notification=noutifikeyshn; notifications=noutifikeyshnlar; push=push; popup=pop ap; banner=bener; widget=vijet
emoji=imoji; emojis=imojilar; sticker=stiker; stickers=stikerlar; gif=jif; meme=mim; memes=mimlar; selfie=selfi
screenshot=skrin shot; screenshots=skrin shotlar; screen=skrin; screens=skrinlar; screencast=skrin kest; record=rikord
recording=rikording; upload=aplod; uploaded=aplodid; download=daunloud; downloaded=daunloudid; downloads=daunloudlar
uploads=aploudlar; stream=strim; ban=ben; block=blok; blocked=blokt; report=ripor; mute=myut; unmute=anmyut; pin=pin
pinned=pind; reply=riplay; replies=ripalylar; mention=menshn; mentions=menshnlar; dm=di em; inbox=inboks; online=onlayn
offline=oflayn; status=steytus; typing=tayping; seen=sin; delivered=dilivered; sent=sent; draft=draft; archive=arkayv
trash=tresh; bookmark=bukmark; favorites=feyvaritlar; favorite=feyvarit; save=seyv; saved=seyvd; search=serch
# ---------------- internet va veb
internet=internet; web=ueb; website=ueb sayt; websites=ueb saytlar; webpage=ueb peyj; site=sayt; sites=saytlar; browser=brauzer
browsers=brauzerlar; chrome=kroum; firefox=fayerfoks; safari=safari; edge=ej; opera=opera; brave=breyv; tab=teb; tabs=teblar
bookmark=bukmark; url=yu ar el; uri=yu ar ay; domain=domeyn; domains=domeynlar; hosting=hosting; host=houst; hostname=houst neym
dns=di en es; ip=ay pi; address=adres; port=port; ports=portlar; localhost=loukal houst; server=server; servers=serverlar
client=klayent; clients=klayentlar; request=rikvest; requests=rikvestlar; response=rispons; responses=rispnslar
header=heder; headers=hederlar; body=badi; status=steytus; code=koud; codes=koudlar; get=get; post=poust; put=put
delete=dilit; patch=pech; head=hed; options=opshnz; rest=rest; restful=restful; api=ey pi ay; apis=ey pi ay lar
endpoint=endpoynt; endpoints=endpoyntlar; route=rut; routes=rutlar; router=router; routing=ruting; url=yu ar el
query=kuiri; queries=kuirilar; param=param; params=paramlar; form=form; forms=formlar; input=input; inputs=inputlar
output=autput; outputs=autputlar; button=batn; buttons=batnlar; checkbox=chekboks; dropdown=drop daun; menu=menyu
navbar=nev bar; sidebar=sayd bar; footer=futer; layout=leyaut; grid=grid; flex=fleks; flexbox=fleks boks; responsive=rispansiv
mobile=moubil; desktop=desktop; tablet=teblit; template=templeyt; templates=templeytlar; theme=sim; themes=simlar
dark=dark; light=layt; mode=moud; style=stayl; styles=staylar; font=font; fonts=fontlar; color=kolor; colors=kolorlar
background=bekgraund; foreground=forgraund; border=border; margin=marjin; padding=peding; width=uidt; height=hayt
display=displey; position=pozishn; absolute=ebsolyut; relative=relativ; fixed=fiksd; sticky=stiki; hover=hover
animation=animeyshn; transition=transishn; transform=transform; opacity=opesiti; shadow=shedou; gradient=greydiyent
frontend=frant end; backend=bek end; fullstack=ful stek; stack=stek; devops=dev ops; sysadmin=sis admin; dev=dev; ops=ops
developer=divelopr; developers=divelaperlar; programmer=progremer; coder=koder; engineer=injiner; architect=arkitekt
designer=dizayner; tester=tester; qa=kyu ey; manager=meneyjer; lead=lid; senior=sinyor; junior=junior; middle=midl
intern=intern; freelancer=frilanser; freelance=frilans; remote=rimout; hybrid=haybrid; startup=startap; startups=startaplar
company=kompani; team=tim; teams=timlar; project=prodjekt; projects=prodjektlar; product=prodakt; products=prodaktlar
client=klayent; customer=kastomer; customers=kastomerlar; user=yuzer; users=yuzerlar; ux=yu eks; ui=yu ay
mvp=em vi pi; prototype=prototayp; demo=demo; beta=beyta; alpha=elfa; release=rilis; launch=lonch; update=apdeyt
updates=apdeytlar; upgrade=apgreyd; downgrade=daungreyd; install=instol; installed=instold; installation=instoleyshn
uninstall=aninstol; setup=set ap; config=konfig; configuration=konfigyureyshn; settings=setingz; setting=seting
options=opshnz; preferences=preferensiz; plugin=plagin; plugins=plaginlar; extension=ikstenshn; extensions=ikstenshnlar
addon=ed on; app=ep; apps=eplar; application=eplikeyshn; applications=eplikeyshnlar; software=softuer; hardware=hardver
firmware=fermuer; driver=drayver; drivers=drayverlar; patch=pech; bug=bag; feature=fichr; features=fichrlar
service=servis; services=servislar; microservice=maykrou servis; microservices=maykrou servislar; monolith=monolit
serverless=server les; lambda=lemda; function=fankshn; cloud=klaud; saas=sas; paas=pas; iaas=ayas; aws=ey dabilyu es
azure=ejer; gcp=ji si pi; ec2=i si tu; s3=es uch; bucket=baket; buckets=baketlar; cdn=si di en; edge=ej; region=rijn
zone=zoun; vps=vi pi es; vm=vi em; instance=instans; cluster=klaster; clusters=klasterlar; container=konteyner
containers=konteynerlar; image=imij; images=imijlar; registry=rejistri; volume=volyum; volumes=volyumlar
network=netuork; networks=netuorklar; networking=netuorking; subnet=sab net; gateway=geytuey; router=router; switch=svich
firewall=fayervol; bandwidth=bendvidt; latency=leytensi; ping=ping; traceroute=treys rut; packet=peket; packets=peketlar
protocol=protokol; protocols=protokollar; tcp=ti si pi; udp=yu di pi; http=eych ti ti pi; ftp=ef ti pi; smtp=es em ti pi
imap=ay em ey pi; pop3=pi o pi uch; ssh=es es eych; telnet=telnet; websocket=ueb soket; socket=soket; sockets=soketlar
wifi=vay fay; bluetooth=blu tus; lan=len; wan=uen; vlan=vi len; nat=net; dhcp=di eych si pi; mac=mek; ethernet=isernet
router=router; modem=moudem; hotspot=hot spot; roaming=rouming; broadband=brod bend; fiber=fayber; speedtest=spid test
# ---------------- apparat
hardware=hardver; computer=kompyuter; computers=kompyuterlar; pc=pi si; laptop=laptop; notebook=noutbuk; desktop=desktop
server=server; mainframe=meynfreym; workstation=uerk steyshn; processor=prosessor; cpu=si pi yu; gpu=ji pi yu; tpu=ti pi yu
core=kor; cores=korlar; thread=tred; clock=klok; ghz=gigagers; ram=ram; rom=rom; cache=kesh; memory=memori; storage=storidj
disk=disk; drive=drayv; ssd=es es di; hdd=eych di di; nvme=en vi em i; usb=yu es bi; hdmi=eych di em ay; vga=vi ji ey
motherboard=madarbord; chipset=chipset; bios=bayos; uefi=yu i fay; boot=but; bootloader=but loder; reboot=ribut; restart=ristart
shutdown=shat daun; sleep=slip; hibernate=haybernit; battery=betari; charger=charjer; power=pauer; adapter=adapter; cable=keybl
monitor=monitor; display=displey; screen=skrin; pixel=piksel; pixels=pikselar; resolution=rezolyushn; fps=ef pi es
hz=gers; refresh=rifresh; hdr=eych di ar; oled=o led; led=led; lcd=el si di; touch=tach; touchscreen=tach skrin
keyboard=kiborrd; mouse=maus; trackpad=trek ped; webcam=veb kem; camera=kamera; microphone=maykrofon; mic=mayk
speaker=spiker; speakers=spikerlar; headphones=hedfonz; earbuds=irbadz; airpods=er podz; headset=hedset; sensor=sensor
sensors=sensorlar; gps=ji pi es; nfc=en ef si; rfid=ar ef ay di; qr=kyu ar; barcode=bar koud; scanner=skaner; printer=printer
router=router; smartphone=smartfoun; smartwatch=smart uoch; wearable=uerabl; drone=droun; robot=roubot; robotics=roubotiks
iot=ay o ti; embedded=embeded; microcontroller=maykrokontrouler; chip=chip; chips=chiplar; circuit=serkit; transistor=tranzistor
voltage=voltij; current=karent; resistor=rezistor; capacitor=kapasitor; breadboard=bred bord; pin=pin; gpio=ji pi ay o
# ---------------- AI va ma'lumotlar
ai=ey ay; ml=em el; dl=di el; llm=el el em; nlp=en el pi; gpt=ji pi ti; chatgpt=chet ji pi ti; openai=oupen ey ay
gemini=jemini; claude=klod; llama=lama; mistral=mistral; deepseek=dip sik; copilot=koupailot; midjourney=mid jerni
dalle=deli; stable=steybl; diffusion=difyuzhn; transformer=transformer; transformers=transformerlar; bert=bert
neural=nyural; network=netuork; neuron=nyuron; layer=leyer; layers=leyerlar; weights=ueytlar; bias=bayas; activation=aktiveyshn
relu=rilu; sigmoid=sigmoyd; softmax=softmaks; loss=los; gradient=greydiyent; descent=disent; backpropagation=bek propageyshn
epoch=ipok; epochs=ipoklar; batch=bech; training=treyning; train=treyn; trained=treynd; validation=validey shn; testing=testing
inference=inferens; model=model; models=modellar; dataset=deyta set; datasets=deyta setlar; data=deyta; database=deyta beys
databases=deyta beyslar; db=di bi; dbms=di bi em es; rdbms=ar di bi em es; table=teybl; tables=teyblar; row=rou; rows=rouz
column=kolam; columns=kolamlar; record=rikord; records=rikordlar; field=fild; schema=skima; schemas=skimalar; index=indeks
primary=praymeri; foreign=forin; join=joyn; joins=joynlar; inner=iner; outer=auter; left=left; right=rayt; select=silekt
insert=insert; update=apdeyt; delete=dilit; create=krieyt; drop=drop; alter=olter; where=uer; having=heving; group=grup
order=order; limit=limit; offset=ofset; union=yunyon; distinct=distinkt; count=kaunt; transaction=transekshn; commit=komit
rollback=roul bek; acid=esid; nosql=nou es kyu el; query=kuiri; backup=bek ap; restore=ristor; migration=maygreyshn
migrations=maygreyshnlar; orm=o ar em; cursor=kerser; connection=konekshn; pool=pul; sharding=sharding; replication=replikeyshn
big=big; analytics=analitiks; analysis=analisis; analyst=analist; science=sayens; scientist=sayentist; engineer=injiner
visualization=vijualizeyshn; dashboard=deshbord; chart=chart; charts=chartlar; plot=plot; plots=plotlar; graph=gref
report=ripor; metrics=metriks; metric=metrik; kpi=key pi ay; accuracy=akyurasi; precision=prisizhn; recall=rikol
f1=ef van; score=skor; confusion=konfyuzhn; matrix=meytriks; vector=vektor; vectors=vektorlar; embedding=embeding
embeddings=embedinglar; token=touken; tokens=toukenlar; prompt=prompt; prompts=promptlar; context=kontekst; window=uindou
agent=eydjent; agents=eydjentlar; rag=rag; fine=fayn; tuning=tyuning; finetune=fayn tyun; parameters=parameterlar
benchmark=benchmark; dataset=deyta set; labeled=leybld; label=leybl; labels=leyblar; feature=fichr; engineering=injiniring
supervised=syupervayzd; unsupervised=anssupervayzd; reinforcement=riinforsment; clustering=klastering; regression=rigreshn
classification=klasifikeyshn; classifier=klasifayer; overfitting=ouver fiting; underfitting=ander fiting; pipeline=paypleyn
# ---------------- biznes
business=biznes; businesses=bizneslar; startup=startap; founder=faunder; ceo=si i o; cto=si ti o; cfo=si ef o; hr=eych ar
investor=investor; investors=investorlar; investment=investment; funding=fanding; revenue=revenyu; profit=profit
budget=baget; cost=kost; price=prays; pricing=praysing; plans=plenz; free=fri; premium=primiyum; pro=prou
basic=beysik; standard=standart; enterprise=enterpraiz; trial=trayal; subscription=sabskripshn; payment=peyment
payments=peymentlar; invoice=invoys; billing=biling; checkout=chekaut; cart=kart; order=order; orders=orderlar
shop=shop; store=stor; market=market; marketplace=marketpleys; sale=seyl; sales=seylz; discount=diskaunt; coupon=kupon
promo=promou; bonus=bonus; cashback=kesh bek; refund=rifand; delivery=diliveri; shipping=shiping; tracking=treking
support=sapport; helpdesk=help desk; ticket=tiket; tickets=tiketlar; feedback=fidbek; review=rivyu; rating=reyting
ratings=reytinglar; survey=server vey; poll=poul; vote=vout; contest=kontest; giveaway=giv eyvey; deadline=dedlayn
meeting=miting; meetings=mitinglar; call=kol; calls=kollar; conference=konferens; webinar=vebinar; workshop=uerkshop
bootcamp=but kemp; course=kors; courses=korslar; lesson=lesn; lessons=lesnlar; tutorial=tyutoriyal; tutorials=tyutoriyallar
guide=gayd; guides=gaydlar; tips=tipslar; tip=tip; tricks=trikslar; trick=trik; hack=hek; hacks=heklar; cheatsheet=chit shit
roadmap=roud mep; skill=skil; skills=skillar; career=kariyer; job=job; jobs=joblar; interview=intervyu; resume=rezyume
cv=si vi; portfolio=portfolio; salary=saleri; offer=ofer; hiring=hayring; hire=hayr; recruiter=rikruter; networking=netuorking
mentor=mentor; mentoring=mentoring; coach=kouch; coaching=kouching; community=kommyuniti; communities=kommyunitilar
open=oupen; source=sors; opensource=oupen sors; license=laysens; mit=em ay ti; gpl=ji pi el; apache=apechi
"""
