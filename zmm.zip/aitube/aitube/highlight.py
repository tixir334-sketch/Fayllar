"""Yengil sintaksis bo'yash (Pillow uchun): qatorni (matn, rang_kaliti) bo'laklariga ajratadi."""
from __future__ import annotations

import re

PY_KW = set("""False None True and as assert async await break class continue def del elif else except finally for
from global if import in is lambda nonlocal not or pass raise return try while with yield match case""".split())
PY_BUILTIN = set("print len range int str float list dict set tuple open input sum min max sorted enumerate zip map "
                 "filter isinstance type bool abs round any all self super".split())
JS_KW = set("""const let var function return if else for while do break continue new class extends import export from
default async await try catch finally throw switch case typeof instanceof this null undefined true false of in
interface type enum implements public private static readonly""".split())
SH_KW = set("if then else elif fi for while do done case esac function in echo export cd ls cat grep sed awk "
            "sudo apt pkg pip git curl wget chmod mkdir rm cp mv tar ssh".split())
GO_KW = set("""package import func return if else for range switch case default var const type struct interface map
chan go defer select break continue nil true false make len append fmt""".split())
C_KW = set("""int char float double void return if else for while do switch case break continue struct typedef enum
const static include define sizeof null true false class public private fn let mut impl use pub match""".split())
SQL_KW = set("select from where insert into values update set delete create table join left right inner on group by "
             "order limit having and or not null primary key integer text as distinct count".split())

LANG_KW = {
    "python": PY_KW, "py": PY_KW, "python3": PY_KW,
    "javascript": JS_KW, "js": JS_KW, "typescript": JS_KW, "ts": JS_KW,
    "bash": SH_KW, "sh": SH_KW, "shell": SH_KW, "zsh": SH_KW,
    "go": GO_KW, "golang": GO_KW,
    "c": C_KW, "cpp": C_KW, "java": C_KW, "rust": C_KW,
    "sql": SQL_KW,
}
HASH_COMMENT = {"python", "py", "python3", "bash", "sh", "shell", "zsh", "yaml", "yml", "toml", "ini"}
SLASH_COMMENT = {"javascript", "js", "typescript", "ts", "go", "golang", "c", "cpp", "java", "rust", "css"}

TOKEN = re.compile(r"""
    (?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?|`[^`]*`?)
  | (?P<num>\b\d+(?:\.\d+)?\b)
  | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<sp>\s+)
  | (?P<other>.)
""", re.X)


def highlight_line(line: str, lang: str) -> list:
    lang = (lang or "").lower()
    kws = LANG_KW.get(lang, set())
    out = []
    comment_at = -1
    if lang in HASH_COMMENT:
        m = re.search(r"(?<![\"'\w$])#", line)
        if m and not line.lstrip().startswith("#!"):
            comment_at = m.start()
        elif line.lstrip().startswith("#!"):
            return [(line, "comment")]
    elif lang in SLASH_COMMENT:
        i = line.find("//")
        comment_at = i
    elif lang == "sql":
        i = line.find("--")
        comment_at = i
    body, comment = (line, "") if comment_at < 0 else (line[:comment_at], line[comment_at:])
    pos = 0
    toks = list(TOKEN.finditer(body))
    for idx, m in enumerate(toks):
        kind, txt = m.lastgroup, m.group()
        if kind == "id":
            low = txt.lower() if lang == "sql" else txt
            nxt = body[m.end():m.end() + 1]
            if low in kws:
                out.append((txt, "kw"))
            elif lang in ("python", "py", "python3") and txt in PY_BUILTIN:
                out.append((txt, "builtin"))
            elif nxt == "(":
                out.append((txt, "func"))
            elif txt[:1].isupper() and len(txt) > 1 and lang not in ("bash", "sh", "shell"):
                out.append((txt, "type"))
            else:
                out.append((txt, "text"))
        elif kind == "str":
            out.append((txt, "str"))
        elif kind == "num":
            out.append((txt, "num"))
        elif kind == "sp":
            out.append((txt, "text"))
        else:
            out.append((txt, "op" if txt in "=+-*/<>!&|%^~:.,;()[]{}" else "text"))
    if comment:
        out.append((comment, "comment"))
    # ketma-ket bir xil turdagi bo'laklarni birlashtirish
    merged = []
    for t, k in out:
        if merged and merged[-1][1] == k:
            merged[-1] = (merged[-1][0] + t, k)
        else:
            merged.append((t, k))
    return merged or [("", "text")]
