"""Pseudo-3D ikonkalar: shaffof fonli sprite'lar (gradient yoritish, qirra yorug'ligi, yumshoq soya) va ularning animatsiyasi.

Hammasi Pillow bilan (numpy yo'q), 3x supersampling bilan chiziladi va bir marta keshlanadi. Har kadrda faqat arzon amallar:
sprite biroz TEBRANADI (burilish + nafas + sakrash) va tebranish bilan birga ustidan QUYOSH NURIDEK YALTIRASH yo'li
sirpanadi (ikonka shakli bilan niqoblangan). Yumshoq soya tebranmaydi — ikonka ostida joyida turadi.

Foydalanish:  I3.render(kind, px, color, t, phase=0.0, wob=1.0, glint=1.0) -> RGBA (px x px, soya bilan).
Yangi ikonka qo'shish: `@icon("nom")` bilan `def f(c, col)` yozing (birlik koordinata 0..1, x o'ngga, y pastga).
"""
from __future__ import annotations

import math

from PIL import Image, ImageChops, ImageDraw, ImageFilter

SS = 3
_G = Image.linear_gradient("L")            # tepadan pastga 0..255
_GH = _G.rotate(90)                         # chapdan o'ngga 0..255
_RAD = Image.radial_gradient("L")           # markazdan chetga 0..255
MET = (176, 190, 210)
INKB = (28, 36, 50)
GOLD = (255, 200, 80)
PCB = (34, 139, 94)


def L(c, k):
    """k>0 oqqa, k<0 qoraga tomon."""
    if k >= 0:
        return tuple(int(v + (255 - v) * k) for v in c)
    return tuple(int(v * (1 + k)) for v in c)


def mixc(a, b, t):
    return tuple(int(x + (y - x) * t) for x, y in zip(a, b))


DRAW: dict = {}


def icon(*names):
    def deco(fn):
        for n in names:
            DRAW[n] = fn
        return fn
    return deco


class Cv:
    """Supersampled kanvas va yoritilgan primitivlar. Koordinatalar — birlik (0..1)."""

    def __init__(self, px: int):
        self.px = px
        self.n = px * SS
        self.im = Image.new("RGBA", (self.n, self.n), (0, 0, 0, 0))

    # ------------------------------------------------------------ asos
    def _mask(self, fn):
        m = Image.new("L", (self.n, self.n), 0)
        fn(ImageDraw.Draw(m), self.n)
        return m

    def paint(self, m, top, bot=None, horiz=False, ridge=False, alpha=1.0):
        bb = m.getbbox()
        if not bb:
            return m
        w, h = bb[2] - bb[0], bb[3] - bb[1]
        if bot is None or top == bot:
            fill = Image.new("RGB", (w, h), top)
        else:
            g = (_GH if (horiz or ridge) else _G).resize((w, h), Image.BILINEAR)
            if ridge:    # silindr: chetlari qorong'i, o'rtasi yorug'
                g = g.point(lambda v: int(255 * min(1.0, abs(v - 100) / 150.0)))
            fill = Image.composite(Image.new("RGB", (w, h), bot), Image.new("RGB", (w, h), top), g)
        piece = fill.convert("RGBA")
        a = m.crop(bb)
        if alpha < 1.0:
            a = a.point(lambda v: int(v * alpha))
        piece.putalpha(a)
        self.im.alpha_composite(piece, (bb[0], bb[1]))
        return m

    def gloss(self, m, k=0.30, frac=0.5):
        """Shakl ustiga tepadan yumshoq oq yaltirash."""
        bb = m.getbbox()
        if not bb:
            return
        w, h = bb[2] - bb[0], max(2, int((bb[3] - bb[1]) * frac))
        g = _G.resize((w, h), Image.BILINEAR).point(lambda v: int(255 * k * (1 - v / 255.0) ** 1.6))
        lay = Image.new("RGBA", (w, h), (255, 255, 255, 0))
        lay.putalpha(ImageChops.multiply(g, m.crop((bb[0], bb[1], bb[2], bb[1] + h))))
        self.im.alpha_composite(lay, (bb[0], bb[1]))

    def U(self, pts):
        return [(x * self.n, y * self.n) for x, y in pts]

    # ------------------------------------------------------------ primitivlar
    def poly(self, pts, col, sh=0.0, gr=0.16, horiz=False, gl=0.0):
        m = self._mask(lambda d, n: d.polygon(self.U(pts), fill=255))
        self.paint(m, L(col, sh + gr), L(col, sh - gr), horiz)
        if gl:
            self.gloss(m, gl)
        return m

    def rrect(self, x0, y0, x1, y1, r, col, sh=0.0, gr=0.16, gl=0.22, horiz=False):
        n = self.n
        m = self._mask(lambda d, _n: d.rounded_rectangle([x0 * n, y0 * n, x1 * n, y1 * n], radius=r * n, fill=255))
        self.paint(m, L(col, sh + gr), L(col, sh - gr), horiz)
        if gl:
            self.gloss(m, gl)
        return m

    def ell(self, x0, y0, x1, y1, col, sh=0.0, gr=0.16, gl=0.0, horiz=False):
        n = self.n
        m = self._mask(lambda d, _n: d.ellipse([x0 * n, y0 * n, x1 * n, y1 * n], fill=255))
        self.paint(m, L(col, sh + gr), L(col, sh - gr), horiz)
        if gl:
            self.gloss(m, gl)
        return m

    def ball(self, cx, cy, r, col, spec=0.85):
        """Sfera: markaziy yorug'lik + chetlari qorong'i + yaltiroq nuqta."""
        n = self.n
        m = self._mask(lambda d, _n: d.ellipse([(cx - r) * n, (cy - r) * n, (cx + r) * n, (cy + r) * n], fill=255))
        bb = m.getbbox()
        if not bb:
            return m
        w, h = bb[2] - bb[0], bb[3] - bb[1]
        rad = _RAD.resize((w, h), Image.BILINEAR)
        shifted = Image.new("L", (w, h), 255)
        shifted.paste(rad, (-int(w * 0.14), -int(h * 0.18)))          # yorug'lik markazi yuqori-chapga siljigan
        fill = Image.composite(Image.new("RGB", (w, h), L(col, -0.42)), Image.new("RGB", (w, h), L(col, 0.34)),
                               shifted.point(lambda v: min(255, int(v * 1.12))))
        piece = fill.convert("RGBA")
        piece.putalpha(m.crop(bb))
        self.im.alpha_composite(piece, (bb[0], bb[1]))
        if spec:
            sp = self._mask(lambda d, _n: d.ellipse([(cx - r * 0.52) * n, (cy - r * 0.62) * n,
                                                      (cx - r * 0.12) * n, (cy - r * 0.30) * n], fill=int(255 * spec)))
            sp = sp.filter(ImageFilter.GaussianBlur(max(1, int(r * n * 0.07))))
            lay = Image.new("RGBA", (self.n, self.n), (255, 255, 255, 0))
            lay.putalpha(ImageChops.multiply(sp, m))
            self.im.alpha_composite(lay)
        return m

    def box3(self, x, y, w, h, dx, dy, col, sh=0.0, gl=0.22, r=0.0):
        """Kub/to'g'ri to'rtburchak (oblique proyeksiya): old yuz + yuqori (yorug') + o'ng (qorong'i)."""
        top = [(x, y), (x + dx, y - dy), (x + w + dx, y - dy), (x + w, y)]
        right = [(x + w, y), (x + w + dx, y - dy), (x + w + dx, y + h - dy), (x + w, y + h)]
        self.poly(right, col, sh - 0.30, 0.10)
        self.poly(top, col, sh + 0.30, 0.06)
        if r > 0:
            front = self.rrect(x, y, x + w, y + h, r, col, sh, 0.14, gl)
        else:
            front = self.poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], col, sh, 0.14, gl=gl)
        # qirra yorug'ligi (old-yuqori)
        n = self.n
        ln = self._mask(lambda d, _n: d.line([(x * n, y * n), ((x + w) * n, y * n)], fill=200, width=max(1, int(n * 0.008))))
        lay = Image.new("RGBA", (n, n), (255, 255, 255, 0))
        lay.putalpha(ln)
        self.im.alpha_composite(lay)
        return front

    def cyl(self, cx, y0, y1, rx, ry, col, lid=True):
        """Vertikal silindr: yon tomoni (ridge gradient) + yuqori qopqoq ellips."""
        n = self.n
        body = self._mask(lambda d, _n: (d.rectangle([(cx - rx) * n, y0 * n, (cx + rx) * n, (y1 - 0.0) * n], fill=255),
                                         d.ellipse([(cx - rx) * n, (y1 - ry) * n, (cx + rx) * n, (y1 + ry) * n], fill=255)))
        top_cover = self._mask(lambda d, _n: d.ellipse([(cx - rx) * n, (y0 - ry) * n, (cx + rx) * n, (y0 + ry) * n], fill=255))
        body = ImageChops.lighter(body, top_cover)
        self.paint(body, L(col, 0.28), L(col, -0.38), ridge=True)
        if lid:
            self.paint(top_cover, L(col, 0.55), L(col, 0.18))
            inner = self._mask(lambda d, _n: d.ellipse([(cx - rx * 0.72) * n, (y0 - ry * 0.72) * n,
                                                         (cx + rx * 0.72) * n, (y0 + ry * 0.72) * n], fill=255))
            self.paint(inner, L(col, 0.34), L(col, 0.5), alpha=0.7)
        return body

    def line(self, pts, col, w, cap=True, alpha=1.0):
        n = self.n
        m = self._mask(lambda d, _n: d.line([(x * n, y * n) for x, y in pts], fill=255, width=max(1, int(w * n)), joint="curve"))
        if cap:
            r = w * n / 2

            def dots(d, _n):
                for x, y in (pts[0], pts[-1]):
                    d.ellipse([x * n - r, y * n - r, x * n + r, y * n + r], fill=255)
            m = ImageChops.lighter(m, self._mask(dots))
        self.paint(m, L(col, 0.18), L(col, -0.2), alpha=alpha)
        return m

    def dot(self, cx, cy, r, col, glow=True):
        """LED nuqta (yorug'lanuvchi)."""
        n = self.n
        if glow:
            g = self._mask(lambda d, _n: d.ellipse([(cx - r * 2.4) * n, (cy - r * 2.4) * n, (cx + r * 2.4) * n, (cy + r * 2.4) * n], fill=90))
            g = g.filter(ImageFilter.GaussianBlur(r * n * 1.1))
            lay = Image.new("RGBA", (n, n), col + (0,))
            lay.putalpha(g)
            self.im.alpha_composite(lay)
        self.ball(cx, cy, r, col, spec=0.7)

    def stroke(self, pts, col, w, alpha=1.0):
        """Tekis (gradientsiz) chiziq: belgilar, panjaralar uchun."""
        n = self.n
        m = self._mask(lambda d, _n: d.line([(x * n, y * n) for x, y in pts], fill=int(255 * alpha), width=max(1, int(w * n)), joint="curve"))
        lay = Image.new("RGBA", (n, n), tuple(col) + (0,))
        lay.putalpha(m)
        self.im.alpha_composite(lay)

    def poly_flat(self, pts, col, alpha=1.0):
        m = self._mask(lambda d, _n: d.polygon(self.U(pts), fill=int(255 * alpha)))
        lay = Image.new("RGBA", (self.n, self.n), tuple(col) + (0,))
        lay.putalpha(m)
        self.im.alpha_composite(lay)

    # ------------------------------------------------------------ yakuniy ishlov
    def finish(self):
        """Qirra (bevel) yorug'ligi/soyasi + kichraytirish. (body RGBA, alpha L)"""
        a = self.im.getchannel("A")
        k = max(2, SS * 2)
        hl = ImageChops.subtract(a, ImageChops.offset(a, k, k)).point(lambda v: min(255, v * 2))
        sh = ImageChops.subtract(a, ImageChops.offset(a, -k, -k)).point(lambda v: min(255, v * 2))
        lay = Image.new("RGBA", self.im.size, (255, 255, 255, 0))
        lay.putalpha(ImageChops.multiply(hl, a).point(lambda v: int(v * 0.42)))
        self.im.alpha_composite(lay)
        lay2 = Image.new("RGBA", self.im.size, (0, 0, 0, 0))
        lay2.putalpha(ImageChops.multiply(sh, a).point(lambda v: int(v * 0.30)))
        self.im.alpha_composite(lay2)
        body = self.im.resize((self.px, self.px), Image.LANCZOS)
        return body, body.getchannel("A")


# =============================================================================================== ikonkalar
@icon("server")
def _server(c, col):
    for i in range(3):
        y = 0.20 + i * 0.25
        c.box3(0.12, y, 0.62, 0.20, 0.13, 0.07, col if i != 1 else L(col, -0.08), r=0.025)
        c.dot(0.21, y + 0.10, 0.028, (90, 235, 130) if i != 2 else (255, 190, 80))
        c.dot(0.29, y + 0.10, 0.022, (255, 190, 80) if i == 0 else (90, 150, 255))
        for k in range(4):
            c.stroke([(0.40 + k * 0.07, y + 0.05), (0.40 + k * 0.07, y + 0.15)], L(col, -0.5), 0.012, 0.8)


@icon("db", "disk_stack")
def _db(c, col):
    for i in (2, 1, 0):
        y0 = 0.22 + i * 0.22
        c.cyl(0.46, y0, y0 + 0.19, 0.32, 0.085, col if i != 1 else L(col, -0.1), lid=(i == 0))
    c.dot(0.62, 0.50, 0.02, (90, 235, 130))
    c.dot(0.62, 0.72, 0.02, (255, 190, 80))


@icon("cpu", "ai", "chip")
def _cpu(c, col):
    for k in range(6):                                                 # oyoqchalar
        t = 0.30 + k * 0.08
        for pts in (((t, 0.14), (t, 0.24)), ((t, 0.76), (t, 0.86)), ((0.14, t), (0.24, t)), ((0.76, t), (0.86, t))):
            c.line(list(pts), GOLD, 0.028, cap=False)
    c.box3(0.22, 0.26, 0.52, 0.52, 0.09, 0.07, L(col, -0.15), r=0.05)
    c.rrect(0.31, 0.35, 0.65, 0.69, 0.04, L(MET, 0.1), 0.0, 0.2, 0.35)
    c.rrect(0.38, 0.42, 0.58, 0.62, 0.03, col, 0.12, 0.3, 0.3)
    for k in range(3):
        c.stroke([(0.43, 0.47 + k * 0.05), (0.53, 0.47 + k * 0.05)], L(col, 0.6), 0.012, 0.9)


@icon("gpu")
def _gpu(c, col):
    c.box3(0.08, 0.36, 0.78, 0.34, 0.09, 0.07, INKB, 0.0, 0.2, r=0.03)
    c.rrect(0.10, 0.37, 0.15, 0.69, 0.01, MET, 0.1, 0.2, 0.2)
    for cx in (0.34, 0.62):
        c.ball(cx, 0.53, 0.14, L(col, -0.2), spec=0.4)
        c.ball(cx, 0.53, 0.04, L(col, 0.3), spec=0.5)
        for k in range(7):
            a = k * 2 * math.pi / 7
            c.poly_flat([(cx + 0.04 * math.cos(a), 0.53 + 0.04 * math.sin(a)),
                         (cx + 0.12 * math.cos(a + 0.35), 0.53 + 0.12 * math.sin(a + 0.35)),
                         (cx + 0.12 * math.cos(a - 0.1), 0.53 + 0.12 * math.sin(a - 0.1))], L(col, 0.5), 0.55)
    for k in range(10):                                                # tilla kontaktlar
        c.stroke([(0.20 + k * 0.045, 0.74), (0.20 + k * 0.045, 0.80)], GOLD, 0.02)
    c.line([(0.78, 0.40), (0.78, 0.66)], col, 0.018, cap=False)


@icon("ram")
def _ram(c, col):
    c.box3(0.08, 0.34, 0.80, 0.32, 0.08, 0.06, PCB, 0.0, 0.2, r=0.015)
    for k in range(4):
        c.rrect(0.16 + k * 0.18, 0.39, 0.30 + k * 0.18, 0.55, 0.015, INKB, 0.0, 0.2, 0.3)
    for k in range(14):
        c.stroke([(0.13 + k * 0.05, 0.60), (0.13 + k * 0.05, 0.66)], GOLD, 0.018)
    c.rrect(0.43, 0.61, 0.47, 0.66, 0.005, (0, 0, 0), 0.0, 0.0, 0.0)
    c.dot(0.82, 0.42, 0.018, col)


@icon("ssd")
def _ssd(c, col):
    c.box3(0.10, 0.30, 0.70, 0.40, 0.11, 0.08, (88, 100, 118), 0.0, 0.25, r=0.035)
    c.rrect(0.18, 0.40, 0.56, 0.58, 0.02, col, 0.0, 0.22, 0.25)
    for k in range(5):
        c.stroke([(0.22 + k * 0.07, 0.46), (0.26 + k * 0.07, 0.46)], L(col, 0.6), 0.012, 0.8)
    c.ball(0.17, 0.35, 0.018, L(MET, 0.2), 0.5)
    c.ball(0.73, 0.35, 0.018, L(MET, 0.2), 0.5)
    for k in range(6):
        c.stroke([(0.62 + k * 0.025, 0.62), (0.62 + k * 0.025, 0.68)], GOLD, 0.014)


@icon("disk", "hdd")
def _hdd(c, col):
    c.box3(0.12, 0.26, 0.66, 0.48, 0.11, 0.08, (150, 164, 184), 0.0, 0.25, r=0.04)
    c.ball(0.40, 0.50, 0.17, (60, 70, 86), spec=0.5)
    c.ball(0.40, 0.50, 0.05, L(MET, 0.3), spec=0.5)
    c.line([(0.40, 0.50), (0.66, 0.34)], L(MET, 0.2), 0.03)
    c.dot(0.70, 0.66, 0.02, (90, 235, 130))


@icon("motherboard")
def _mb(c, col):
    c.box3(0.08, 0.14, 0.78, 0.74, 0.07, 0.05, PCB, 0.0, 0.18, r=0.02)
    c.rrect(0.20, 0.24, 0.42, 0.46, 0.015, (60, 70, 86), 0.0, 0.2, 0.3)             # CPU soket
    c.rrect(0.25, 0.29, 0.37, 0.41, 0.01, L(MET, 0.15), 0.0, 0.2, 0.3)
    for k in range(4):                                                              # RAM slotlari
        c.rrect(0.52 + k * 0.065, 0.20, 0.57 + k * 0.065, 0.50, 0.008, INKB, 0.0, 0.1, 0.1)
    c.rrect(0.16, 0.60, 0.78, 0.66, 0.008, INKB, 0.0, 0.1, 0.1)                     # PCIe
    c.rrect(0.16, 0.74, 0.60, 0.79, 0.008, INKB, 0.0, 0.1, 0.1)
    for k in range(4):
        c.cyl(0.50 + k * 0.07, 0.56, 0.57, 0.022, 0.012, (180, 180, 190), lid=True)
    c.rrect(0.66, 0.70, 0.78, 0.82, 0.01, col, 0.0, 0.2, 0.3)


@icon("psu")
def _psu(c, col):
    c.box3(0.12, 0.28, 0.66, 0.50, 0.14, 0.09, (74, 84, 100), 0.0, 0.2, r=0.03)
    c.ball(0.40, 0.53, 0.19, (40, 48, 62), spec=0.3)
    for k in (0.17, 0.12, 0.07):
        c.ell(0.40 - k, 0.53 - k, 0.40 + k, 0.53 + k, L((40, 48, 62), 0.25), 0.0, 0.1)
    c.ball(0.40, 0.53, 0.035, L(col, 0.2), spec=0.4)
    c.rrect(0.62, 0.36, 0.74, 0.70, 0.015, col, 0.0, 0.2, 0.3)
    c.line([(0.74, 0.62), (0.88, 0.70), (0.90, 0.84)], col, 0.04)


@icon("fan")
def _fan(c, col):
    c.rrect(0.10, 0.10, 0.90, 0.90, 0.10, INKB, 0.0, 0.2, 0.25)
    for k in range(7):
        a = k * 2 * math.pi / 7
        cx, cy = 0.5, 0.5
        pts = [(cx + 0.06 * math.cos(a), cy + 0.06 * math.sin(a)),
               (cx + 0.36 * math.cos(a + 0.55), cy + 0.36 * math.sin(a + 0.55)),
               (cx + 0.34 * math.cos(a + 0.12), cy + 0.34 * math.sin(a + 0.12))]
        c.poly(pts, col, 0.0, 0.2)
    c.ball(0.5, 0.5, 0.075, L(MET, -0.1), spec=0.6)
    for p in ((0.17, 0.17), (0.83, 0.17), (0.17, 0.83), (0.83, 0.83)):
        c.ball(p[0], p[1], 0.022, MET, spec=0.5)


@icon("tower", "pc")
def _tower(c, col):
    c.box3(0.26, 0.10, 0.42, 0.82, 0.18, 0.09, (50, 58, 74), 0.0, 0.18, r=0.03)
    c.rrect(0.31, 0.17, 0.62, 0.62, 0.02, (16, 24, 36), 0.0, 0.1, 0.35)
    c.ball(0.465, 0.30, 0.09, col, spec=0.5)
    c.ball(0.465, 0.30, 0.03, L(col, 0.6), spec=0.5)
    c.ball(0.465, 0.52, 0.07, mixc(col, (255, 120, 190), 0.6), spec=0.5)
    c.stroke([(0.34, 0.66), (0.59, 0.66)], col, 0.016)
    c.ball(0.36, 0.76, 0.03, (60, 70, 86), spec=0.5)
    c.dot(0.58, 0.77, 0.018, (90, 235, 130))
    for k in range(4):
        c.stroke([(0.34, 0.82 + k * 0.025), (0.60, 0.82 + k * 0.025)], L((50, 58, 74), -0.4), 0.01, 0.8)


@icon("monitor", "screen")
def _monitor(c, col):
    c.rrect(0.07, 0.12, 0.93, 0.66, 0.05, (36, 44, 58), 0.0, 0.18, 0.18)
    s = c.rrect(0.11, 0.16, 0.89, 0.62, 0.03, mixc(col, (20, 30, 46), 0.55), 0.0, 0.28, 0.0)
    c.poly_flat([(0.11, 0.62), (0.40, 0.16), (0.58, 0.16), (0.29, 0.62)], (255, 255, 255), 0.10)
    for k in range(3):
        c.stroke([(0.18, 0.28 + k * 0.1), (0.28 + k * 0.12, 0.28 + k * 0.1)], L(col, 0.5), 0.016, 0.85)
    c.poly([(0.44, 0.66), (0.56, 0.66), (0.60, 0.82), (0.40, 0.82)], (110, 122, 140), 0.0, 0.2)
    c.ell(0.26, 0.78, 0.74, 0.90, (96, 108, 126), 0.0, 0.2, 0.2)


@icon("laptop")
def _laptop(c, col):
    c.rrect(0.16, 0.14, 0.84, 0.60, 0.04, (40, 48, 62), 0.0, 0.16, 0.14)
    c.rrect(0.20, 0.18, 0.80, 0.56, 0.025, mixc(col, (20, 30, 46), 0.55), 0.0, 0.25, 0.0)
    c.poly_flat([(0.20, 0.56), (0.42, 0.18), (0.56, 0.18), (0.34, 0.56)], (255, 255, 255), 0.09)
    for k in range(3):
        c.stroke([(0.26, 0.26 + k * 0.09), (0.36 + k * 0.1, 0.26 + k * 0.09)], L(col, 0.5), 0.015, 0.85)
    c.poly([(0.06, 0.66), (0.94, 0.66), (0.84, 0.80), (0.16, 0.80)], (120, 132, 150), 0.0, 0.22, gl=0.2)
    c.poly([(0.16, 0.80), (0.84, 0.80), (0.84, 0.84), (0.16, 0.84)], (70, 80, 96), 0.0, 0.1)
    c.rrect(0.40, 0.70, 0.60, 0.76, 0.012, L((120, 132, 150), -0.3), 0.0, 0.1, 0.0)


@icon("phone")
def _phone(c, col):
    c.box3(0.30, 0.08, 0.40, 0.84, 0.08, 0.04, (36, 44, 58), 0.0, 0.2, r=0.07)
    c.rrect(0.34, 0.15, 0.66, 0.82, 0.04, mixc(col, (20, 30, 46), 0.5), 0.0, 0.25, 0.0)
    c.poly_flat([(0.34, 0.82), (0.50, 0.15), (0.60, 0.15), (0.44, 0.82)], (255, 255, 255), 0.10)
    c.ball(0.50, 0.12, 0.016, (90, 100, 120), 0.4)
    for k in range(3):
        c.stroke([(0.39, 0.30 + k * 0.12), (0.52 + (k % 2) * 0.05, 0.30 + k * 0.12)], L(col, 0.5), 0.016, 0.85)


@icon("browser")
def _browser(c, col):
    c.box3(0.08, 0.18, 0.80, 0.62, 0.08, 0.05, (46, 56, 72), 0.0, 0.18, r=0.04)
    c.rrect(0.08, 0.18, 0.88, 0.31, 0.04, L(col, -0.1), 0.0, 0.2, 0.3)
    for i, cc in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        c.ball(0.15 + i * 0.06, 0.245, 0.017, cc, 0.7)
    c.rrect(0.34, 0.21, 0.80, 0.28, 0.03, L(col, 0.5), 0.0, 0.1, 0.0)
    c.rrect(0.13, 0.36, 0.38, 0.74, 0.02, mixc(col, (20, 30, 46), 0.55), 0.0, 0.2, 0.0)
    for k in range(4):
        c.stroke([(0.45, 0.40 + k * 0.09), (0.45 + 0.30 - (k % 2) * 0.08, 0.40 + k * 0.09)], L(col, 0.45), 0.02, 0.9)


@icon("cloud")
def _cloud(c, col):
    base = L(col, 0.1)
    c.rrect(0.10, 0.50, 0.90, 0.74, 0.12, base, -0.1, 0.18, 0.1)
    c.ball(0.30, 0.52, 0.18, base, 0.5)
    c.ball(0.52, 0.40, 0.25, L(col, 0.15), 0.6)
    c.ball(0.72, 0.54, 0.17, base, 0.5)
    c.rrect(0.10, 0.60, 0.90, 0.74, 0.07, L(col, -0.05), -0.05, 0.12, 0.0)


@icon("file", "doc")
def _file(c, col):
    c.box3(0.20, 0.10, 0.50, 0.80, 0.07, 0.03, (232, 238, 248), 0.0, 0.1, r=0.02)
    c.poly([(0.56, 0.10), (0.70, 0.24), (0.56, 0.24)], L(col, 0.1), 0.0, 0.2)
    for k in range(5):
        c.stroke([(0.28, 0.34 + k * 0.1), (0.62 - (k % 2) * 0.14, 0.34 + k * 0.1)], L(col, -0.1), 0.022, 0.9)
    c.rrect(0.28, 0.12, 0.44, 0.19, 0.01, col, 0.0, 0.2, 0.3)


@icon("folder")
def _folder(c, col):
    c.poly([(0.08, 0.28), (0.34, 0.28), (0.42, 0.36), (0.92, 0.36), (0.92, 0.82), (0.08, 0.82)], L(col, -0.3), 0.0, 0.12)
    c.box3(0.08, 0.40, 0.84, 0.44, 0.0, 0.0, col, 0.0, 0.3, r=0.03)
    c.stroke([(0.12, 0.45), (0.88, 0.45)], L(col, 0.6), 0.012, 0.8)


@icon("lock")
def _lock(c, col):
    n = 0.5
    for rr, w in ((0.20, 0.07),):
        m = c._mask(lambda d, nn: d.arc([(n - rr) * nn, 0.10 * nn, (n + rr) * nn, 0.60 * nn], 180, 360, fill=255, width=int(w * nn)))
        m = ImageChops.lighter(m, c._mask(lambda d, nn: (d.line([((n - rr) * nn, 0.35 * nn), ((n - rr) * nn, 0.52 * nn)], fill=255, width=int(w * nn)),
                                                          d.line([((n + rr) * nn, 0.35 * nn), ((n + rr) * nn, 0.52 * nn)], fill=255, width=int(w * nn)))))
        c.paint(m, L(MET, 0.3), L(MET, -0.3), ridge=True)
    c.box3(0.22, 0.46, 0.52, 0.42, 0.09, 0.05, col, 0.0, 0.25, r=0.06)
    c.ball(0.48, 0.64, 0.05, (30, 36, 50), spec=0.3)
    c.rrect(0.465, 0.66, 0.495, 0.78, 0.01, (30, 36, 50), 0.0, 0.0, 0.0)


@icon("key")
def _key(c, col):
    m = c._mask(lambda d, nn: d.ellipse([0.10 * nn, 0.24 * nn, 0.46 * nn, 0.60 * nn], fill=255))
    m2 = c._mask(lambda d, nn: d.ellipse([0.19 * nn, 0.33 * nn, 0.37 * nn, 0.51 * nn], fill=255))
    c.paint(ImageChops.subtract(m, m2), L(col, 0.35), L(col, -0.25), ridge=True)
    c.line([(0.44, 0.46), (0.88, 0.46)], col, 0.07, cap=False)
    c.rrect(0.70, 0.46, 0.76, 0.66, 0.01, col, 0.0, 0.15, 0.2)
    c.rrect(0.80, 0.46, 0.86, 0.60, 0.01, col, 0.0, 0.15, 0.2)


@icon("gear", "cog")
def _gear(c, col):
    pts = []
    teeth = 10
    for i in range(teeth * 2):
        a = i * math.pi / teeth
        r = 0.40 if i % 2 == 0 else 0.31
        for da in (-0.09, 0.09):
            pts.append((0.5 + (r if i % 2 == 0 else r) * math.cos(a + da), 0.5 + (r) * math.sin(a + da)))
    c.poly([(x + 0.03, y + 0.04) for x, y in pts], L(col, -0.4), 0.0, 0.05)       # qalinlik (orqa yuz)
    c.poly(pts, col, 0.05, 0.2, gl=0.28)
    c.ball(0.5, 0.5, 0.17, L(col, -0.25), spec=0.35)
    c.ball(0.5, 0.5, 0.10, L(MET, -0.1), spec=0.6)


@icon("globe", "world")
def _globe(c, col):
    c.ball(0.5, 0.5, 0.40, col, spec=0.7)
    n = c.n
    for rx in (0.40, 0.24, 0.10):
        m = c._mask(lambda d, nn: d.ellipse([(0.5 - rx) * nn, 0.10 * nn, (0.5 + rx) * nn, 0.90 * nn], outline=255, width=max(1, int(0.012 * nn))))
        lay = Image.new("RGBA", (n, n), (255, 255, 255, 0))
        lay.putalpha(m.point(lambda v: int(v * 0.45)))
        c.im.alpha_composite(lay)
    for yy in (0.32, 0.5, 0.68):
        c.stroke([(0.12 if yy == 0.5 else 0.18, yy), (0.88 if yy == 0.5 else 0.82, yy)], (255, 255, 255), 0.012, 0.4)
    c.poly_flat([(0.30, 0.30), (0.42, 0.24), (0.48, 0.36), (0.38, 0.46), (0.28, 0.42)], L(col, 0.55), 0.65)
    c.poly_flat([(0.56, 0.52), (0.70, 0.46), (0.74, 0.62), (0.62, 0.72)], L(col, 0.55), 0.65)


@icon("router")
def _router(c, col):
    for x in (0.22, 0.78):
        c.line([(x, 0.52), (x - 0.03 + (0.06 if x > 0.5 else 0.0), 0.16)], L(MET, -0.2), 0.03)
    c.box3(0.10, 0.52, 0.74, 0.26, 0.10, 0.06, (62, 72, 90), 0.0, 0.22, r=0.04)
    for k in range(4):
        c.dot(0.22 + k * 0.10, 0.65, 0.022, (90, 235, 130) if k != 2 else (255, 190, 80))
    c.rrect(0.62, 0.60, 0.78, 0.70, 0.01, col, 0.0, 0.2, 0.2)


@icon("wifi")
def _wifi(c, col):
    n = c.n
    for i, r in enumerate((0.40, 0.28, 0.16)):
        m = c._mask(lambda d, nn: d.arc([(0.5 - r) * nn, (0.74 - r) * nn, (0.5 + r) * nn, (0.74 + r) * nn], 218, 322, fill=255, width=int(0.07 * nn)))
        c.paint(m, L(col, 0.35), L(col, -0.2))
    c.ball(0.5, 0.74, 0.07, col, 0.7)


@icon("bolt")
def _bolt(c, col):
    pts = [(0.58, 0.06), (0.22, 0.54), (0.46, 0.54), (0.36, 0.94), (0.78, 0.40), (0.52, 0.40)]
    c.poly([(x + 0.03, y + 0.03) for x, y in pts], L(col, -0.45), 0.0, 0.05)
    c.poly(pts, col, 0.1, 0.26, gl=0.35)


@icon("shield", "security")
def _shield(c, col):
    pts = [(0.5, 0.06), (0.86, 0.20), (0.82, 0.58), (0.5, 0.94), (0.18, 0.58), (0.14, 0.20)]
    c.poly([(x + 0.025, y + 0.03) for x, y in pts], L(col, -0.5), 0.0, 0.05)
    c.poly(pts, col, 0.0, 0.22, gl=0.3)
    inner = [(0.5, 0.15), (0.77, 0.26), (0.74, 0.56), (0.5, 0.84), (0.26, 0.56), (0.23, 0.26)]
    c.poly(inner, L(col, 0.2), 0.0, 0.18)
    c.stroke([(0.36, 0.50), (0.46, 0.62), (0.66, 0.38)], (255, 255, 255), 0.065)


@icon("user")
def _user(c, col):
    c.ball(0.5, 0.30, 0.19, L(col, 0.15), 0.8)
    m = c._mask(lambda d, nn: d.pieslice([0.14 * nn, 0.52 * nn, 0.86 * nn, 1.14 * nn], 180, 360, fill=255))
    c.paint(m, L(col, 0.2), L(col, -0.3))
    c.gloss(m, 0.3, 0.4)


@icon("users")
def _users(c, col):
    for dx, k, cc in ((-0.26, 0.78, L(col, -0.25)), (0.26, 0.78, L(col, -0.25)), (0.0, 1.0, col)):
        cx = 0.5 + dx
        c.ball(cx, 0.32 - (1 - k) * 0.0, 0.14 * k, L(cc, 0.15), 0.7)
        m = c._mask(lambda d, nn: d.pieslice([(cx - 0.36 * k) * nn, (0.52 - (1 - k) * 0.0) * nn, (cx + 0.36 * k) * nn, (0.52 + 0.58 * k) * nn], 180, 360, fill=255))
        c.paint(m, L(cc, 0.2), L(cc, -0.3))


@icon("bot")
def _bot(c, col):
    c.line([(0.5, 0.12), (0.5, 0.24)], MET, 0.025)
    c.dot(0.5, 0.10, 0.03, (255, 120, 120))
    c.box3(0.16, 0.26, 0.60, 0.50, 0.10, 0.06, col, 0.0, 0.25, r=0.10)
    for cx in (0.32, 0.58):
        c.ball(cx, 0.46, 0.075, (240, 250, 255), 0.5)
        c.ball(cx, 0.47, 0.035, (30, 40, 60), 0.3)
    c.rrect(0.32, 0.62, 0.62, 0.68, 0.025, (30, 40, 60), 0.0, 0.1, 0.0)
    c.rrect(0.06, 0.40, 0.14, 0.60, 0.02, MET, 0.0, 0.2, 0.2)
    c.rrect(0.80, 0.40, 0.86, 0.60, 0.02, MET, 0.0, 0.2, 0.2)
    c.rrect(0.30, 0.80, 0.62, 0.90, 0.03, L(col, -0.2), 0.0, 0.15, 0.2)


@icon("code")
def _code(c, col):
    c.box3(0.08, 0.16, 0.80, 0.64, 0.08, 0.05, (30, 38, 54), 0.0, 0.18, r=0.05)
    c.rrect(0.08, 0.16, 0.88, 0.28, 0.04, (54, 66, 88), 0.0, 0.2, 0.2)
    for i, cc in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        c.ball(0.14 + i * 0.06, 0.22, 0.016, cc, 0.7)
    c.stroke([(0.34, 0.42), (0.22, 0.54), (0.34, 0.66)], (126, 231, 135), 0.045)
    c.stroke([(0.62, 0.42), (0.74, 0.54), (0.62, 0.66)], (126, 231, 135), 0.045)
    c.stroke([(0.52, 0.38), (0.44, 0.70)], (255, 255, 255), 0.04, 0.9)


@icon("terminal")
def _terminal(c, col):
    c.box3(0.08, 0.16, 0.80, 0.64, 0.08, 0.05, (16, 22, 34), 0.0, 0.14, r=0.05)
    c.rrect(0.08, 0.16, 0.88, 0.28, 0.04, (46, 56, 76), 0.0, 0.2, 0.2)
    for i, cc in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        c.ball(0.14 + i * 0.06, 0.22, 0.016, cc, 0.7)
    c.stroke([(0.20, 0.40), (0.34, 0.51), (0.20, 0.62)], (126, 231, 135), 0.045)
    c.stroke([(0.42, 0.64), (0.62, 0.64)], (255, 255, 255), 0.045)
    c.dot(0.72, 0.64, 0.02, (126, 231, 135), glow=True)


@icon("mail")
def _mail(c, col):
    c.box3(0.10, 0.28, 0.76, 0.50, 0.06, 0.04, (240, 244, 250), 0.0, 0.1, r=0.03)
    c.poly([(0.10, 0.28), (0.86, 0.28), (0.48, 0.58)], col, 0.0, 0.2, gl=0.2)
    c.stroke([(0.10, 0.78), (0.40, 0.52)], L(col, -0.1), 0.015, 0.7)
    c.stroke([(0.86, 0.78), (0.56, 0.52)], L(col, -0.1), 0.015, 0.7)
    c.ball(0.48, 0.58, 0.05, (255, 100, 100), 0.7)


@icon("chat")
def _chat(c, col):
    c.rrect(0.10, 0.14, 0.90, 0.64, 0.14, col, 0.0, 0.22, 0.3)
    c.poly([(0.28, 0.60), (0.20, 0.86), (0.50, 0.62)], L(col, -0.1), 0.0, 0.15)
    for k in range(3):
        c.ball(0.34 + k * 0.16, 0.39, 0.04, (255, 255, 255), 0.5)


@icon("clock")
def _clock(c, col):
    c.ball(0.5, 0.5, 0.42, L(MET, -0.15), 0.7)
    c.ball(0.5, 0.5, 0.35, (245, 248, 255), 0.4)
    for k in range(12):
        a = k * math.pi / 6
        r0, r1 = (0.28, 0.33) if k % 3 else (0.25, 0.33)
        c.stroke([(0.5 + r0 * math.sin(a), 0.5 - r0 * math.cos(a)), (0.5 + r1 * math.sin(a), 0.5 - r1 * math.cos(a))], (50, 60, 80), 0.014 if k % 3 else 0.022)
    c.line([(0.5, 0.5), (0.5, 0.28)], (40, 50, 70), 0.03)
    c.line([(0.5, 0.5), (0.66, 0.58)], col, 0.03)
    c.ball(0.5, 0.5, 0.035, col, 0.6)


@icon("bug")
def _bug(c, col):
    for sgn in (-1, 1):
        for k, (y0, y1) in enumerate(((0.38, 0.28), (0.52, 0.52), (0.64, 0.76))):
            c.stroke([(0.5 + sgn * 0.14, y0), (0.5 + sgn * 0.32, y1)], L(col, -0.4), 0.03)
        c.stroke([(0.5 + sgn * 0.07, 0.20), (0.5 + sgn * 0.17, 0.08)], L(col, -0.4), 0.02)
    c.ell(0.30, 0.26, 0.70, 0.88, col, 0.0, 0.24, gl=0.3)
    c.stroke([(0.5, 0.34), (0.5, 0.86)], L(col, -0.5), 0.012, 0.7)
    c.ball(0.5, 0.22, 0.10, L(col, -0.15), 0.6)
    c.ball(0.45, 0.20, 0.02, (255, 255, 255), 0.0)
    c.ball(0.55, 0.20, 0.02, (255, 255, 255), 0.0)
    for p in ((0.40, 0.50), (0.60, 0.50), (0.42, 0.68), (0.58, 0.68)):
        c.ball(p[0], p[1], 0.045, (30, 36, 50), 0.4)


@icon("box", "cube")
def _cube(c, col):
    c.box3(0.14, 0.30, 0.52, 0.52, 0.22, 0.17, col, 0.0, 0.25, r=0.015)
    c.stroke([(0.14, 0.30), (0.66, 0.30)], (255, 255, 255), 0.01, 0.5)


@icon("check")
def _check(c, col):
    c.ball(0.5, 0.5, 0.42, col, 0.8)
    c.stroke([(0.30, 0.52), (0.44, 0.66), (0.70, 0.36)], (255, 255, 255), 0.09)


@icon("cross")
def _cross(c, col):
    c.ball(0.5, 0.5, 0.42, col, 0.8)
    c.stroke([(0.34, 0.34), (0.66, 0.66)], (255, 255, 255), 0.09)
    c.stroke([(0.66, 0.34), (0.34, 0.66)], (255, 255, 255), 0.09)


# =============================================================================================== sprite va animatsiya
class Sprite:
    def __init__(self, kind, px, color):
        self.kind, self.px, self.color = kind, px, color
        c = Cv(px)
        fn = DRAW.get(kind) or DRAW["box"]
        fn(c, color)
        self.body, self.alpha = c.finish()
        # yumshoq yer soyasi (tebranmaydi)
        sh = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        m = Image.new("L", (px, px), 0)
        bb = self.alpha.getbbox() or (int(px * 0.1), int(px * 0.1), int(px * 0.9), int(px * 0.9))
        bw = bb[2] - bb[0]
        cy = min(px * 0.97, bb[3] + px * 0.015)
        ImageDraw.Draw(m).ellipse([bb[0] + bw * 0.06, cy - px * 0.035, bb[2] - bw * 0.02, cy + px * 0.035], fill=150)
        m = m.filter(ImageFilter.GaussianBlur(px * 0.022))
        # ikonka shaklining soyasi (biroz pastga-o'ngga siljigan, xira)
        dm = ImageChops.offset(self.alpha, int(px * 0.025), int(px * 0.03)).filter(ImageFilter.GaussianBlur(px * 0.02))
        dm = dm.point(lambda v: int(v * 0.35))
        sh.putalpha(ImageChops.lighter(m, dm))
        self.shadow = sh
        # yaltirash yo'li: diagonal yumshoq yo'l (3x kenglikda), siljitib qirqiladi
        tile = Image.new("L", (px * 3, px), 0)
        ImageDraw.Draw(tile).polygon([(px * 1.30, 0), (px * 1.62, 0), (px * 1.32, px), (px * 1.00, px)], fill=255)
        self.band = tile.filter(ImageFilter.GaussianBlur(px * 0.05))

    def frame(self, t: float, phase: float = 0.0, wob: float = 1.0, glint: float = 1.0) -> Image.Image:
        px = self.px
        w = 2 * math.pi / 2.6
        ang = 3.4 * wob * math.sin(w * t + phase)
        body = self.body
        if glint > 0.01:
            pos = math.sin(w * t + phase + 0.5)                          # tebranish bilan bir fazada: nur ikonka bo'ylab sirpanadi
            inten = glint * (0.28 + 0.55 * abs(math.cos(w * t + phase + 0.5)))
            off = int(px * (1.0 + 0.62 * pos))
            band = self.band.crop((off, 0, off + px, px))
            m = ImageChops.multiply(band, self.alpha).point(lambda v, k=inten: int(v * k))
            lay = Image.new("RGBA", (px, px), (255, 255, 255, 0))
            lay.putalpha(m)
            body = Image.alpha_composite(body, lay)
        if abs(ang) > 0.05:
            body = body.rotate(ang, resample=Image.BICUBIC, center=(px * 0.5, px * 0.7))
        breathe = 1.0 + 0.016 * wob * math.sin(w * t * 1.7 + phase)
        dy = int(-px * 0.014 * wob * (0.5 + 0.5 * math.sin(w * t + phase + 1.2)))
        out = self.shadow.copy()
        sz = max(8, int(round(px * breathe)))
        if sz != px:
            body = body.resize((sz, sz), Image.BILINEAR)
        paste_alpha(out, body, (px - sz) // 2, (px - sz) + dy)
        return out


def paste_alpha(dst: Image.Image, src: Image.Image, x: int, y: int):
    """RGBA src ni dst ustiga alfa bilan qo'yadi (chegaradan chiqqan qismi kesiladi)."""
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(dst.width, x + src.width), min(dst.height, y + src.height)
    if x1 <= x0 or y1 <= y0:
        return
    part = src.crop((x0 - x, y0 - y, x1 - x, y1 - y))
    base = dst.crop((x0, y0, x1, y1))
    dst.paste(Image.alpha_composite(base, part), (x0, y0))


class Icons3D:
    """Sprite keshi. `render` har kadrda chaqiriladi (arzon); sprite bir marta chiziladi."""

    def __init__(self):
        self._cache: dict = {}

    @staticmethod
    def base_px(px: float) -> int:
        return max(96, int(math.ceil(px / 32.0) * 32))

    def sprite(self, kind: str, px: int, color) -> Sprite:
        key = (kind, px, tuple(color))
        sp = self._cache.get(key)
        if sp is None:
            if len(self._cache) > 160:
                self._cache.clear()
            sp = self._cache[key] = Sprite(kind, px, tuple(color))
        return sp

    def render(self, kind: str, px: float, color, t: float = 0.0, phase: float = 0.0, wob: float = 1.0,
               glint: float = 1.0) -> Image.Image:
        """px o'lchamli RGBA (soya bilan). Sprite kattaroq (32 ga yaxlitlangan) chiziladi va kerak bo'lsa kichraytiriladi."""
        bp = self.base_px(px)
        out = self.sprite(kind if kind in DRAW else "box", bp, color).frame(t, phase, wob, glint)
        p = max(8, int(round(px)))
        if p != bp:
            out = out.resize((p, p), Image.BILINEAR)
        return out


I3 = Icons3D()


def kinds() -> list:
    return sorted(DRAW)


from . import icons3d_more  # noqa: E402,F401  (qo'shimcha ikonkalarni ro'yxatga oladi)
