"""Avto-tozalash va "Qayta yaratilganlar" saqlamasi.

Avto-tozalash: oxirgi yaratilgan videoni eslab qoladi, qolgan barcha lokal fayllarni (video, muqova, subtitr,
ishchi papkalar, ovoz keshi) butunlay o'chiradi. Himoyalanadi: yuklashni kutayotgan (ready) epizodlar
va "Qayta yaratilganlar" papkasi (data/regen) - unga tegilmaydi.
"""
from __future__ import annotations

import os
import time
import re
import shutil
from pathlib import Path

from .util import iso_now, log

EP_FILE = re.compile(r"^ep(\d+)\.")
EP_DIR = re.compile(r"^ep(\d+)$")


def regen_dir(cfg) -> Path:
    d = cfg.data / "regen"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _rm(p: Path) -> int:
    try:
        if p.is_dir():
            n = sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
            shutil.rmtree(p, ignore_errors=True)
            return n
        n = p.stat().st_size
        p.unlink()
        return n
    except OSError:
        return 0


def protected_eps(db) -> set:
    """O'chirilmaydigan epizod raqamlari (gno): oxirgi yaratilgan + yuklashni kutayotganlar."""
    keep = {e["gno"] for e in db.by_status("ready", "rendered", "scripted")}
    last = db.kv_get("last_created_gno")
    if last and last.isdigit():
        keep.add(int(last))
    return keep


def clean(cfg, db, force=False) -> dict:
    """Qaytaradi: {"files": n, "bytes": n}. force=False bo'lsa AUTO_CLEAN o'chiq bo'lganda hech narsa qilmaydi."""
    if not force and not cfg.bool("AUTO_CLEAN"):
        return {"files": 0, "bytes": 0, "skipped": True}
    keep = protected_eps(db)
    freed = files = 0
    # 1) bazadagi epizod fayllari
    for e in db.all_episodes():
        if e["gno"] in keep:
            continue
        changed = {}
        for k in ("video_path", "thumb_path", "srt_path"):
            p = e.get(k)
            if p and Path(p).exists():
                freed += _rm(Path(p))
                files += 1
            if p:
                changed[k] = None
        if changed:
            db.ep_update(e["id"], **changed)
    # 2) out/ ichidagi yetim fayllar
    for f in list(cfg.dirs["out"].iterdir()):
        m = EP_FILE.match(f.name)
        if m and int(m.group(1)) in keep:
            continue
        freed += _rm(f)
        files += 1
    # 3) work/ dagi epizod ishchi papkalari va vaqtinchalik fayllar
    for f in list(cfg.dirs["work"].iterdir()):
        m = EP_DIR.match(f.name)
        if m and int(m.group(1)) in keep:
            continue
        if m or f.suffix in (".wav", ".tmp", ".mp3") or f.name.startswith(("tts_test", "client_secret")):
            freed += _rm(f)
            files += 1
    # 4) ovoz keshi
    cutoff = time.time() - 2 * 86400     # yaqinda yasalgan ovoz keshi qoladi (eski ovozni qayta ishlatish uchun)
    for f in list(cfg.dirs["cache"].glob("tts_*")):
        try:
            if f.stat().st_mtime > cutoff:
                continue
        except OSError:
            continue
        freed += _rm(f)
        files += 1
    if files:
        log.info("Avto-tozalash: %d fayl, %.1f MB", files, freed / 1048576)
    return {"files": files, "bytes": freed}


# ---------------------------------------------------------------- qayta yaratilganlar
def _link_or_copy(src: Path, dst: Path):
    try:
        os.link(src, dst)           # Termux/Android da os.link yo'q yoki taqiqlangan bo'lishi mumkin
    except (OSError, AttributeError, NotImplementedError):
        shutil.copy2(src, dst)


def save_regenerated(cfg, db, ep, note="") -> int | None:
    """Tayyor epizodni "Qayta yaratilganlar" ga ko'chirib saqlaydi (avto-tozalash tegmaydi)."""
    vp = ep.get("video_path")
    if not vp or not Path(vp).exists():
        return None
    ver = len(db.regen_list(ep["gno"])) + 1
    d = regen_dir(cfg)
    base = f"ep{ep['gno']:03d}_v{ver}_{iso_now()[:19].replace(':', '').replace('-', '').replace('T', '_')}"
    dst = d / f"{base}.mp4"
    _link_or_copy(Path(vp), dst)
    tdst = None
    if ep.get("thumb_path") and Path(ep["thumb_path"]).exists():
        tdst = d / f"{base}.jpg"
        _link_or_copy(Path(ep["thumb_path"]), tdst)
    return db.regen_add(ep_id=ep["id"], gno=ep["gno"], title=ep["title"], video_path=str(dst),
                        thumb_path=str(tdst) if tdst else None, duration=ep.get("duration"),
                        size_bytes=ep.get("size_bytes"), created=iso_now(), note=note)


def _copy_if_different(src: Path, dst: Path):
    try:
        if dst.exists() and os.path.samefile(src, dst):
            return      # qattiq havola: allaqachon bir xil fayl
    except (OSError, AttributeError):
        pass
    shutil.copy2(src, dst)


def delete_regenerated(db, rid) -> bool:
    r = db.regen_get(rid)
    if not r:
        return False
    for k in ("video_path", "thumb_path"):
        if r.get(k):
            _rm(Path(r[k]))
    db.regen_del(rid)
    return True


def promote_regenerated(cfg, db, rid) -> str | None:
    """Saqlangan versiyani epizodning asosiy videosi qiladi (faqat yuklanmagan epizod uchun). Xato matni yoki None."""
    r = db.regen_get(rid)
    if not r or not Path(r["video_path"] or "").exists():
        return "fayl topilmadi"
    ep = db.ep_by_gno(r["gno"])
    if not ep:
        return "epizod topilmadi"
    if ep["status"] == "uploaded":
        return "bu epizod allaqachon yuklangan (avval /forget)"
    if not ep.get("script"):
        return "epizod ssenariysi yo'q (avval qayta yasang)"
    out = cfg.dirs["out"] / f"ep{ep['gno']:03d}.mp4"
    thumb = cfg.dirs["out"] / f"ep{ep['gno']:03d}.jpg"
    _copy_if_different(Path(r["video_path"]), out)
    if r.get("thumb_path") and Path(r["thumb_path"]).exists():
        _copy_if_different(Path(r["thumb_path"]), thumb)
    elif not thumb.exists():
        return "muqova yo'q"
    db.ep_update(ep["id"], video_path=str(out), thumb_path=str(thumb), duration=r.get("duration"),
                 size_bytes=r.get("size_bytes"), status="ready", error=None)
    return None
