"""Umumiy yordamchi funksiyalar."""
from __future__ import annotations

import hashlib
import html
import json
import logging
import os
import re
import shutil
import subprocess
import time
import threading
import traceback
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

import requests

log = logging.getLogger("aitube")

_session = requests.Session()
_session.headers.update({
    "User-Agent": ("Mozilla/5.0 (Linux; Android 13; Termux) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"),
})


class NetWatch:
    """Internet holatini kuzatadi. Aloqa uzilsa, so'rovlar to'xtab turadi va aloqa qaytishi bilan
    aynan to'xtagan joyidan davom etadi (bir vaqtda faqat bitta ish tekshiradi, qolganlari kutadi)."""

    PROBES = ("https://www.google.com/generate_204", "https://api.telegram.org", "https://www.cloudflare.com/cdn-cgi/trace")

    def __init__(self):
        self.cond = threading.Condition()
        self.offline = False
        self.last_ok = True
        self.since = 0.0
        self.max_wait = 12 * 3600       # shuncha vaqt kutadi, keyin taslim bo'ladi
        self.on_event = None            # callback(event, soniya): "down" | "up" | "giveup"
        self.probe_fn = None            # sinov uchun almashtiriladi
        self.delay0 = 3.0

    def probe(self) -> bool:
        if self.probe_fn:
            return bool(self.probe_fn())
        for url in self.PROBES:
            try:
                _session.head(url, timeout=(5, 6), allow_redirects=False)
                return True          # har qanday HTTP javob = internet bor
            except requests.RequestException:
                continue
        return False

    def _emit(self, ev, secs=0.0):
        cb = self.on_event
        if cb:
            threading.Thread(target=lambda: cb(ev, secs), daemon=True).start()

    def wait_online(self, max_wait=None) -> tuple:
        """(online, uzilgan_edi): internet bo'lguncha kutadi."""
        max_wait = self.max_wait if max_wait is None else max_wait
        with self.cond:
            if self.offline:                      # boshqa ish allaqachon kutmoqda
                self.cond.wait_for(lambda: not self.offline, timeout=max_wait + 5)
                return self.last_ok, True
            if self.probe():                      # internet bor: uzilish emas, oddiy xato
                return True, False
            self.offline, self.since = True, time.time()
        log.warning("Internet uzildi, aloqa kutilmoqda…")
        self._emit("down")
        delay, ok = self.delay0, False
        deadline = time.time() + max_wait
        while time.time() < deadline:
            time.sleep(delay)
            if self.probe():
                ok = True
                break
            delay = min(30.0, delay * 1.5)
        secs = time.time() - self.since
        with self.cond:
            self.offline, self.last_ok = False, ok
            self.cond.notify_all()
        log.warning("Internet %s (%.0fs)", "qaytdi" if ok else "qaytmadi, taslim", secs)
        self._emit("up" if ok else "giveup", secs)
        return ok, True


NET = NetWatch()


def is_net_error(e: BaseException) -> bool:
    if isinstance(e, (requests.ConnectionError, requests.Timeout, ConnectionError, TimeoutError)):
        return True
    n = type(e).__name__.lower()
    m = str(e).lower()
    return any(w in n for w in ("connection", "timeout", "gaierror", "network", "ssl")) or any(
        w in m for w in ("name resolution", "temporary failure", "network is unreachable",
                         "connection reset", "connection aborted", "timed out", "failed to establish",
                         "cannot connect", "no route to host"))


def _http_once(method, url, retries, timeout, backoff, retry_status, kw):
    last: Exception | None = None
    for i in range(max(1, retries)):
        try:
            r = _session.request(method, url, timeout=timeout, **kw)
            if r.status_code in retry_status and i < retries - 1:
                time.sleep(backoff * (i + 1))
                continue
            return r
        except (requests.ConnectionError, requests.Timeout) as e:
            last = e
            if i < retries - 1:
                time.sleep(backoff * (i + 1))
    assert last is not None
    raise last


def http(method: str, url: str, retries: int = 3, timeout=(15, 90), backoff: float = 1.5,
         retry_status=(500, 502, 503, 504), wait_net: bool = False, up_retries: int = 5, **kw) -> requests.Response:
    """Qayta urinishli HTTP so'rov. wait_net=True: internet uzilsa u qaytguncha kutib, so'rovni takrorlaydi.
    up_retries: internet BOR bo'lsa-yu so'rov xato bersa, shuncha marta darhol qayta uriniladi (0 = darhol xato:
    LLM chaqiruvlarida shunday — keyingi kalitga kutmasdan o'tiladi)."""
    spent = 0
    ups = 0
    while True:
        try:
            return _http_once(method, url, retries, timeout, backoff, retry_status, kw)
        except (requests.ConnectionError, requests.Timeout):
            if not wait_net or spent >= 40:
                raise
            ok, was_down = NET.wait_online()
            if not ok:
                raise
            if not was_down:
                ups += 1
                if ups > up_retries:
                    raise
            spent += 1 if was_down else 8


def setup_logging(cfg) -> logging.Logger:
    lg = logging.getLogger("aitube")
    if getattr(lg, "_configured", False):
        return lg
    lg.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S")
    fh = RotatingFileHandler(cfg.dirs["logs"] / "aitube.log", maxBytes=1_000_000,
                             backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    lg.addHandler(fh)
    lg.addHandler(sh)
    lg._configured = True  # type: ignore[attr-defined]
    return lg


def esc(s) -> str:
    return html.escape(str(s), quote=False)


def clip(s: str, n: int) -> str:
    s = str(s)
    return s if len(s) <= n else s[: max(0, n - 1)].rstrip() + "…"


def sha1(*parts) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p).encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return now_utc().strftime("%Y-%m-%d %H:%M:%S")


def local_now(cfg) -> datetime:
    return now_utc().astimezone(timezone(timedelta(hours=cfg.float("TZ_OFFSET"))))


def fmt_dur(sec: float) -> str:
    sec = int(round(sec))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def human_size(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def disk_free_mb(path) -> int:
    try:
        return int(shutil.disk_usage(str(path)).free / 1048576)
    except OSError:
        return -1


def run(cmd: list, timeout: int | None = None, cwd=None) -> tuple:
    """subprocess ishga tushiradi: (kod, stdout, stderr)."""
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, cwd=cwd)
        return (p.returncode, p.stdout.decode("utf-8", "replace"),
                p.stderr.decode("utf-8", "replace"))
    except FileNotFoundError:
        return (127, "", f"buyruq topilmadi: {cmd[0]}")
    except subprocess.TimeoutExpired:
        return (124, "", f"vaqt tugadi ({timeout}s): {cmd[0]}")


def tb_short(limit: int = 1500) -> str:
    t = traceback.format_exc()
    return t if len(t) <= limit else "…" + t[-limit:]


def tail_file(path: Path, n: int = 40) -> str:
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-n:])


def atomic_write(path: Path, data: str | bytes):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    if isinstance(data, str):
        tmp.write_text(data, encoding="utf-8")
    else:
        tmp.write_bytes(data)
    os.replace(tmp, path)


def words(text: str) -> list:
    return re.findall(r"[^\W_]+(?:['ʻʼ’`‘][^\W_]+)*", text.lower(), flags=re.UNICODE)


def significant(text: str, minlen: int = 4) -> set:
    return {re.sub(r"['ʻʼ’`‘]", "", w) for w in words(text) if len(w) >= minlen}


def json_dumps(o) -> str:
    return json.dumps(o, ensure_ascii=False)


def json_loads(s, default=None):
    try:
        return json.loads(s) if s else default
    except (TypeError, ValueError):
        return default


def export_to_downloads(path):
    """Faylni telefonning Yuklanmalar papkasiga nusxalaydi (Termux). Natija yo'li yoki None."""
    src = Path(path)
    cands = [Path.home() / "storage" / "downloads", Path("/sdcard/Download"),
             Path("/storage/emulated/0/Download")]
    for d in cands:
        try:
            if d.is_dir():
                dst = d / src.name
                shutil.copyfile(src, dst)
                return dst
        except OSError:
            continue
    return None


TG_LIMIT = 49 * 1024 * 1024


def telegram_copy(path, limit=TG_LIMIT):
    """Telegram uchun yuborish mumkin bo'lgan fayl yo'li.
    Fayl limitdan kichik bo'lsa o'zi qaytadi; katta bo'lsa 720p siqilgan ko'rinish
    yasaladi (asl fayl YouTube uchun o'zgarmaydi). Bo'lmasa None."""
    p = Path(path)
    try:
        if p.stat().st_size <= limit:
            return p
        out = p.with_name(p.stem + ".tg.mp4")
        if out.exists() and out.stat().st_size <= limit and out.stat().st_mtime >= p.stat().st_mtime:
            return out
        for crf, h in ((28, 720), (32, 720), (34, 480)):
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(p), "-vf", f"scale=-2:{h}",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-c:a", "aac",
                   "-b:a", "96k", "-movflags", "+faststart", str(out)]
            subprocess.run(cmd, check=True, timeout=1800)
            if out.stat().st_size <= limit:
                return out
        return None
    except Exception as e:
        log.warning("Telegram nusxasini yasab bo'lmadi: %s", e)
        return None
