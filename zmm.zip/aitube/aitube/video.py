"""Video yig'ish: sahnalar -> ovoz -> so'z vaqtlari -> kadrlar -> ffmpeg (MP4) + SRT + bo'limlar (chapters).

Sinxronlash tamoyili: hamma narsa bitta kadr to'rida; ovoz shu to'rga namuna aniqligida joylanadi;
subtitr so'zlari ovozning haqiqiy vaqtiga qarab (sync.py) yurib yoziladi.
"""
from __future__ import annotations

import math
import os
import random
import re
import subprocess
import threading
import time
import wave
from pathlib import Path

from PIL import Image

from . import sfx
from .hwenc import HW, HW_ERR
from .render import CONTINUOUS, ENTER_END, Renderer, scene_units
from .speak import speak_words
from .sync import align_words, make_chunks, proportional
from .text import clean_narration
from .tts import SR, TTS, TTSError, wav_duration
from .util import fmt_dur, log, run

LEAD_FIRST = 0.45     # birinchi sahna ovozidan oldingi jimlik (s)
LEAD = 0.22           # keyingi sahnalar: sahna almashinuvi (crossfade) uchun
PAD = 0.50            # sahna ovozidan keyingi jimlik
PAD_LAST = 1.60       # video oxiridagi jimlik
TRANS_S = 0.32        # sahnalar orasidagi yumshoq o'tish
CAP_LEAD = 0.04       # subtitr so'zi ovozdan 1 kadr oldin chiqadi (ko'z shunda "mos" deb sezadi)
HL_TAIL = 0.15        # so'z tugagach ajratish (highlight) shuncha vaqt turadi
CAP_HOLD = 0.60       # bo'lak oxirgi so'zdan keyin shuncha vaqt ko'rinib turadi
MIN_UNIT = {"bullets": 0.9, "flow": 1.0, "code": 0.4, "diagram": 2.0, "compare": 1.1, "parts": 1.6, "explain": 2.0}     # bo'lakcha (band/qadam/qator) minimal ko'rinish vaqti
HOLD = {"bullets": 1.4, "flow": 1.5, "code": 1.2, "diagram": 2.2, "compare": 1.6, "parts": 2.0, "explain": 2.2}         # oxirgi bo'lakchadan keyin ushlab turish
ANTICIPATE = 0.12    # band/qadam ovozdan biroz oldin paydo bo'ladi (animatsiya tugaguncha so'z aytiladi)
MIN_STATIC = 2.6      # sarlavha/xulosa/yakun sahnalarining minimal davomiyligi


def unit_texts(sc) -> list:
    """Bo'lakchalar (band/qadam) matnlari; kod uchun None."""
    if sc["type"] == "bullets":
        return list(sc.get("bullets", []))
    if sc["type"] == "flow":
        return list(sc.get("steps", []))
    if sc["type"] == "parts":
        return [f"{it.get('name', '')} {it.get('role', '')}".strip() for it in sc.get("items", [])]
    if sc["type"] == "explain":
        from .cards import explain_blocks
        return [tx for _, tx in explain_blocks(sc)]
    if sc["type"] == "diagram":
        names = {n["id"]: n.get("label", "") for n in sc.get("nodes", [])}
        return [f"{lk.get('label', '')} {names.get(lk.get('to'), '')}".strip() for lk in sc.get("links", [])]
    if sc["type"] == "compare":
        l, r = sc.get("left", {}).get("items", []), sc.get("right", {}).get("items", [])
        return [f"{l[i] if i < len(l) else ''} {r[i] if i < len(r) else ''}".strip() for i in range(max(len(l), len(r)))]
    return []


def _norm(w: str) -> str:
    return re.sub(r"[^\w]", "", w.lower().replace("'", "").replace("\u2019", "").replace("\u02bb", ""), flags=re.U)


def match_units(texts, words, wtimes):
    """Har bir band/qadam diktor uni aytayotgan paytda paydo bo'lishi uchun: band matnidagi so'zlarga
    (kamida 4 harfli, 4 harfli o'xshash boshlanish) mos keladigan birinchi aytilgan so'zni topadi.
    Qaytaradi: [soniya yoki None] (ovoz boshiga nisbatan), yoki texts bo'sh bo'lsa None."""
    if not texts:
        return None
    nw = [_norm(w["w"]) for w in words]
    out, last = [], -1
    for tx in texts:
        keys = [k for k in (_norm(t) for t in tx.split()) if len(k) >= 4]
        found = None
        for i in range(last + 1, len(words)):
            if not words[i]["s"] or len(nw[i]) < 4:
                continue
            if any(nw[i][:4] == k[:4] for k in keys):
                found = i
                break
        if found is None:
            out.append(None)
        else:
            out.append(max(0.0, wtimes[found][0] - ANTICIPATE))
            last = found
    return out


class VideoError(Exception):
    pass


def srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, r = divmod(ms, 3600000)
    m, r = divmod(r, 60000)
    s, ms = divmod(r, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def pick_codec() -> list:
    """Eski nom (moslik uchun): CPU kodlovchi. Haqiqiy tanlov `hwenc.HW` orqali (GPU -> CPU)."""
    rc, out, _ = run(["ffmpeg", "-hide_banner", "-encoders"], timeout=20)
    if "libx264" in out:
        return ["-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage"]
    return ["-c:v", "mpeg4", "-q:v", "5"]


def motion_cad(fps: int, motion: int, continuous: bool = False, anim_fps: int = 0) -> int:
    """Fon harakati necha kadrda bir yangilanadi (0 = yangilanmaydi). FPS ga BOG'LANGAN: harakat tezligi (soniyadagi
    siljish) har qanday fps da bir xil, faqat silliqligi (yangilanish soni) fps ga qarab o'zgaradi.
    anim_fps>0: animatsiya kadr tezligi qo'lda (fps dan oshmaydi); 0 = avto: silliq rejimda fps, oddiyda fps/2."""
    if motion <= 0 and not continuous:
        return 0
    if anim_fps and anim_fps > 0 and motion > 0:
        target = min(float(fps), float(anim_fps))
    elif motion >= 2:
        target = float(fps)
    else:
        target = fps / 2.0
    return max(1, int(round(fps / max(1.0, target))))


_CHORDS = [(110, 165, 220, 277), (98, 147, 196, 247), (123, 185, 246, 311), (87, 131, 175, 220),
           (104, 156, 208, 262), (116, 174, 233, 293), (131, 196, 262, 330), (93, 139, 185, 233)]


def make_music(path: Path, seconds: float, seed: int = 0) -> bool:
    """ffmpeg yordamida yumshoq fon musiqasi (akkord) yaratadi. `seed` bo'yicha akkord, sekinlik va aks-sado
    o'zgaradi: har epizodning musiqasi boshqacha."""
    dur = f"{seconds + 2:.2f}"
    chord = _CHORDS[int(seed) % len(_CHORDS)]
    trem = (0.12, 0.18, 0.24, 0.30)[int(seed // 3) % 4]
    echo = ("aecho=0.8:0.55:620:0.28", "aecho=0.8:0.6:900:0.22", "anull")[int(seed // 2) % 3]
    parts = [f"sine=frequency={f}:sample_rate=44100:duration={dur}" for f in chord]
    cmd = ["ffmpeg", "-y", "-loglevel", "error"]
    for p in parts:
        cmd += ["-f", "lavfi", "-i", p]
    cmd += ["-filter_complex",
            f"[0][1][2][3]amix=inputs=4:normalize=0,lowpass=f=900,tremolo=f={trem}:d=0.35,{echo},"
            f"afade=t=in:st=0:d=3,afade=t=out:st={max(0, seconds - 2):.2f}:d=3,volume=0.5",
            "-ac", "1", "-ar", "44100", "-c:a", "pcm_s16le", str(path)]
    rc, _, err = run(cmd, timeout=120)
    if rc != 0:
        log.warning("Musiqa yaratilmadi: %s", err[-200:])
        return False
    return path.exists()


_TTS_SEM = threading.BoundedSemaphore(24)      # bir vaqtda ko'pi bilan 16 ta ovoz so'rovi (barcha bo'laklar uchun umumiy)


class VideoBuilder:
    """Video yig'ish. Barcha vaqtlar bitta KADR to'rida (fps) hisoblanadi, ovoz esa shu to'rga butun
    namuna (sample) aniqligida joylanadi. Shuning uchun ovoz, subtitr va kadrlar orasida siljish bo'lmaydi:
    sahna chegarasi = kadr chegarasi = ovoz namunasi chegarasi."""

    def __init__(self, cfg, tts: TTS):
        self.cfg = cfg
        self.tts = tts
        # Translatsiya (stream) bo'laklari uchun: davomiy rejim sozlamalari
        self.lead_first = LEAD_FIRST      # birinchi sahnadan oldingi jimlik
        self.pad_last = PAD_LAST          # oxirgi sahnadan keyingi jimlik
        self.prev_content = None          # oldingi bo'lakning oxirgi kadri (yumshoq o'tish uchun); None = qoradan
        self.last_content = None          # shu bo'lakning oxirgi kadri (keyingi bo'lak uchun)
        self.motion_step = 1               # fon animatsiyasi har necha kadrda yangilanadi (stream: tezlik uchun)
        self.tick = None                   # kadrlar progressi uchun qayta chaqiruv(n)
        self.extra_v: list = []           # qo'shimcha video kodlash parametrlari (masalan -maxrate)
        self.cancel = None                # chaqirilsa True qaytarsa - qurish to'xtatiladi
        self.anim_fps = 0                 # fon animatsiyasi kadr tezligi (0 = avto, fps ga bog'liq)

    def _int(self, key: str, default: int = 0) -> int:
        try:
            return int(float(self.cfg.get(key) or default))
        except (TypeError, ValueError, KeyError):
            return default

    def fps(self) -> int:
        fps = self.cfg.int("VIDEO_FPS")
        if fps < 10 or fps > 60 or SR % fps:
            fps = 25            # 44100 ga bo'linadigan qiymat kerak (namuna aniqligi uchun)
        return fps

    # ----------------------------------------------------------- 1) ovoz va so'z vaqtlari
    def _audio_scene(self, i: int, sc: dict, workdir: Path, only=None) -> str:
        display = clean_narration(sc["narration"])
        words = speak_words(display)
        spoken = " ".join(w["s"] for w in words if w["s"]).strip()
        if not spoken:
            raise TTSError(f"{i + 1}-sahnada aytiladigan matn yo'q")
        wavp = workdir / f"v{i:02d}.wav"
        with _TTS_SEM:
            prov, bounds = self.tts.synth_ex(spoken, wavp, prepared=True, only=only)
        try:
            times = align_words(wavp, words, bounds)
        except Exception as e:   # tahlil muvaffaqiyatsiz bo'lsa ham video yasaladi
            log.warning("So'z vaqtlari aniqlanmadi (%s), mutanosib taqsimot ishlatiladi", e)
            d = wav_duration(wavp)
            times = proportional(words, 0.0, d)
        with wave.open(str(wavp), "rb") as w:
            sc["wav_samples"] = w.getnframes()
        sc["wav"] = wavp
        sc["voice_dur"] = sc["wav_samples"] / float(SR)
        sc["words"] = words
        sc["wtimes"] = times
        return prov

    def make_audio(self, scenes: list, workdir: Path, progress=lambda i, n, info: None, workers: int = 1) -> dict:
        """Har sahna ovozi. workers>1: sahnalar parallel (bir vaqtda) ovozlanadi - natija tartibi o'zgarmaydi."""
        workdir.mkdir(parents=True, exist_ok=True)
        providers = {}
        n = len(scenes)
        if workers == 0:
            workers = 24                      # avto: hamma sahna bir vaqtda (stream kabi parallel)
        if workers <= 1 or n <= 1:
            for i, sc in enumerate(scenes):
                prov = self._audio_scene(i, sc, workdir)
                providers[prov] = providers.get(prov, 0) + 1
                progress(i + 1, n, f"{prov} {sc['voice_dur']:.1f}s")
            return {"providers": providers}
        from concurrent.futures import ThreadPoolExecutor
        done = [0]
        lock = threading.Lock()

        def one(i):
            if self.cancel and self.cancel():
                raise VideoError("bekor qilindi")
            err = None
            for attempt in (1, 2, 3):          # xato bergan sahna o'zi alohida qayta uriniladi
                try:
                    prov = self._audio_scene(i, scenes[i], workdir)
                    break
                except TTSError as e:
                    err = e
                    log.warning("Ovoz %d-sahna: %d-urinish xato: %s", i + 1, attempt, str(e)[:150])
                    if self.cancel and self.cancel():
                        raise VideoError("bekor qilindi")
                    if attempt > 1:     # 1-qayta urinish DARHOL; keyingisida qisqa tasodifiy tanaffus
                        time.sleep(0.4 * attempt * (0.5 + random.random()))
            else:
                raise err
            with lock:
                done[0] += 1
                progress(done[0], n, prov)
            return prov

        with ThreadPoolExecutor(max_workers=min(max(workers, n), 24)) as ex:      # hamma sahna bir vaqtda
            res = list(ex.map(one, range(n)))
        # Ovoz bir xil bo'lsin: ba'zi sahnalar zaxira ovozga (google) tushib qolgan bo'lsa, ularni asosiy ovozda qayta yasaymiz
        provs = self.tts.providers() if hasattr(self.tts, "providers") else []
        main = (provs or [""])[0]
        if main and main != "google" and "google" in res and any(p in ("edge", "cache") for p in res):
            for rnd in range(3):
                bad = [i for i, p in enumerate(res) if p == "google"]
                if not bad:
                    break
                if rnd:
                    time.sleep(0.6 * rnd * (0.5 + random.random()))
                for i in bad:
                    try:
                        res[i] = self._audio_scene(i, scenes[i], workdir, only=main)
                    except Exception as e:
                        log.warning("Ovoz %d-sahna asosiy ovozda qayta yasalmadi: %s", i + 1, str(e)[:120])
        for prov in res:
            providers[prov] = providers.get(prov, 0) + 1
        return {"providers": providers}

    # ----------------------------------------------------------- 2) vaqt chizig'i
    def plan(self, scenes: list, fps: int) -> int:
        """Har sahna uchun kadr hisobida joy (start_f, slot_f, lead_f) va bo'lakchalar paydo bo'lish vaqtlarini
        belgilaydi. Ovoz tez bo'lsa ham bo'lakchalar kamida MIN_UNIT soniya ko'rinadi: sahna uzayadi, ovoz
        kesilmaydi (qolgan vaqt jimlik)."""
        spf = SR // fps
        n = len(scenes)
        f0 = 0
        for i, sc in enumerate(scenes):
            lead_s = self.lead_first if i == 0 else LEAD
            lead_f = int(round(lead_s * fps))
            pad_f = int(round((self.pad_last if i == n - 1 else PAD) * fps))
            voice_f = int(math.ceil(sc["wav_samples"] / spf))
            need_f = lead_f + voice_f + pad_f
            units = scene_units(sc)
            rel, anim_len = [], []
            if units:
                tw = [t[0] for w, t in zip(sc["words"], sc["wtimes"]) if w["s"]]
                nw = len(tw)
                mu = MIN_UNIT[sc["type"]]
                matched = match_units(unit_texts(sc), sc["words"], sc["wtimes"])
                prev = None
                for k in range(units):
                    tgt = matched[k] if matched and matched[k] is not None else None
                    if tgt is None:     # mos so'z topilmasa: ovoz bo'yicha mutanosib o'rin
                        tgt = tw[min(nw - 1, int(k * nw / units))] if nw else k * mu
                    t = tgt if prev is None else max(tgt, prev + mu)
                    rel.append(t)
                    prev = t
                for k in range(units):
                    gap = (rel[k + 1] - rel[k]) if k + 1 < units else 1.0
                    if sc["type"] == "code":
                        ln = len((sc.get("code") or "").split("\n")[k]) if k < units else 10
                        a = min(max(0.25, 0.035 * ln), 0.9)
                    elif sc["type"] == "diagram":
                        a = 0.6
                    else:
                        a = 0.32
                    anim_len.append(max(0.1, min(a, gap - 0.05)))
                req_s = lead_s + rel[-1] + HOLD[sc["type"]]
            else:
                req_s = lead_s + MIN_STATIC
            slot_f = max(need_f, int(math.ceil(req_s * fps)))
            sc.update(lead_f=lead_f, slot_f=slot_f, start_f=f0, unit_rel=rel, unit_anim=anim_len,
                      start=f0 / fps, fps=fps)
            f0 += slot_f
        return f0

    def write_voice(self, scenes: list, fps: int, workdir: Path) -> Path:
        """Barcha sahna ovozlarini kadr to'riga mos holda bitta WAV ga yig'adi."""
        spf = SR // fps
        out = workdir / "voice.wav"
        with wave.open(str(out), "wb") as o:
            o.setnchannels(1)
            o.setsampwidth(2)
            o.setframerate(SR)
            for sc in scenes:
                lead_n = sc["lead_f"] * spf
                o.writeframes(b"\x00\x00" * lead_n)
                with wave.open(str(sc["wav"]), "rb") as w:
                    if (w.getnchannels(), w.getsampwidth(), w.getframerate()) != (1, 2, SR):
                        raise VideoError(f"WAV formati mos emas: {sc['wav']}")
                    data = w.readframes(w.getnframes())
                o.writeframes(data)
                rest = sc["slot_f"] * spf - lead_n - len(data) // 2
                if rest < 0:
                    raise VideoError("ovoz sahna oralig'idan uzun (ichki xato)")
                o.writeframes(b"\x00\x00" * rest)
        return out

    # ----------------------------------------------------------- 3) subtitr bo'laklari
    def captions(self, scenes: list, fps: int, max_chars: int):
        """Har sahna uchun subtitr bo'laklari va so'z kadrlari. SRT uchun (boshi, oxiri, matn) ro'yxatini qaytaradi."""
        srt = []
        for sc in scenes:
            vstart_s = (sc["start_f"] + sc["lead_f"]) / fps
            words, times = sc["words"], sc["wtimes"]
            ab = [(vstart_s + a, vstart_s + b) for a, b in times]
            chunks = make_chunks(words, times, max_chars)
            rf = []
            for a, b in ab:
                f = int(math.floor((a - CAP_LEAD) * fps + 1e-6))
                f = max(f, sc["start_f"], rf[-1] if rf else 0)
                rf.append(f)
            hl_off = {}
            for k in range(len(words) - 1):
                off = int(math.ceil((ab[k][1] + HL_TAIL) * fps))
                if off < rf[k + 1]:
                    hl_off[k] = off
            if words:
                hl_off[len(words) - 1] = int(math.ceil((ab[-1][1] + HL_TAIL) * fps))
            scene_end = sc["start_f"] + sc["slot_f"]
            for ci, ch in enumerate(chunks):
                ch["show_start"] = rf[ch["i0"]]
                last_end = int(math.ceil((ab[ch["i1"]][1] + CAP_HOLD) * fps))
                nxt = rf[chunks[ci + 1]["i0"]] if ci + 1 < len(chunks) else scene_end
                ch["show_end"] = max(ch["show_start"] + 1, min(last_end, nxt, scene_end))
                srt.append((vstart_s + ch["start"], vstart_s + ch["end"],
                            " ".join(w["w"] for w in words[ch["i0"]:ch["i1"] + 1])))
            sc["chunks"], sc["rf"], sc["hl_off"] = chunks, rf, hl_off
        return srt

    # ----------------------------------------------------------- 4) kadrlar -> ffmpeg (quvur orqali)
    @staticmethod
    def _unit_state(sc, t_rel):
        """Bo'lakchalar (band/qadam/qator) holati: (ko'rinayotganlar soni, oxirgisining paydo bo'lish bosqichi 0..1)."""
        rel = sc["unit_rel"]
        shown = sum(1 for r in rel if r <= t_rel + 1e-9)
        if shown == 0:
            return 0, 1.0
        k = shown - 1
        a = (t_rel - rel[k]) / sc["unit_anim"][k]
        return shown, max(0.0, min(1.0, a))

    def _emit_frames(self, sc, fps, motion, k_trans_f):
        """Sahnada kadr chiqariladigan (o'zgarish bo'ladigan) kadr raqamlari. Animatsiya vaqtida har kadr,
        qolganda fon harakati uchun har 2-kadr (silliq rejimda har kadr), shuningdek so'z/bo'lak hodisalarida."""
        S, E = sc["start_f"], sc["start_f"] + sc["slot_f"]
        vstart_s = (S + sc["lead_f"]) / fps
        ev = {S}

        def window(a, b):
            ev.update(range(max(S, a), min(E, b)))

        window(S, S + k_trans_f + 1)
        window(S, S + int(math.ceil(ENTER_END.get(sc["type"], 1.0) * fps)))
        for r, ln in zip(sc["unit_rel"], sc["unit_anim"]):
            fa = int(math.floor((vstart_s + r) * fps + 1e-6))
            window(fa, fa + int(math.ceil(ln * fps)) + 1)
        cad = motion_cad(fps, motion, sc["type"] in CONTINUOUS, self.anim_fps)
        if cad and (motion > 0 or sc["type"] in CONTINUOUS):
            ev.update(range(S, E, cad))
        ev.update(sc["rf"])
        ev.update(sc["hl_off"].values())
        for ch in sc["chunks"]:
            ev.add(ch["show_start"])
            ev.add(ch["show_end"])
        return sorted(f for f in ev if S <= f < E)

    def _ffmpeg_cmd(self, vin, voice, music, total, tail, fps, renderer, wave, sfx=None):
        cmd = ["ffmpeg", "-y", "-loglevel", "error"] + vin + ["-i", str(voice)]
        if music:
            cmd += ["-i", str(music)]
        if sfx:
            cmd += ["-i", str(sfx)]
        fc = []
        if wave:
            x, y, w, h = renderer.wave_rect
            col = "0x%02x%02x%02x" % tuple(renderer.accent2)
            fc.append("[1:a]asplit=2[av][aw]")
            fc.append(f"[aw]showwaves=s={w}x{h}:mode=cline:rate={fps}:colors={col}:scale=sqrt,"
                      "format=rgba,colorkey=0x000000:0.14:0.25[wv]")
            fc.append(f"[0:v][wv]overlay={x}:{y}:format=auto[v]")
            a_in = "[av]"
        else:
            fc.append("[0:v]null[v]")
            a_in = "[1:a]"
        mix_in, k = [a_in], 2
        if music:
            fc.append(f"[{k}:a]volume={self.cfg.float('MUSIC_VOLUME')}[m]")
            mix_in.append("[m]")
            k += 1
        if sfx:
            fc.append(f"[{k}:a]volume={max(0.0, self.cfg.float('SFX_VOLUME')) * 0.8:.3f}[x]")
            mix_in.append("[x]")
        if len(mix_in) > 1:
            fc.append(f"{''.join(mix_in)}amix=inputs={len(mix_in)}:duration=first:normalize=0[a]")
        else:
            fc.append(f"{a_in}anull[a]")
        cmd += ["-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]"]
        cmd += tail
        return cmd

    def _pick_encoder(self, renderer, voice, music, total, fps, sfx=None):
        """Videoga ovoz to'lqini va musiqa qo'shish mumkinligini 1 soniyalik sinov bilan tekshiradi.
        Eng boy ishlaydigan variantni qaytaradi: (wave, music, sfx)."""
        want_wave = bool(self.cfg.bool("VIDEO_WAVE") and renderer.wave_rect)
        want_music, want_sfx = bool(music), bool(sfx)
        W, H = renderer.RW, renderer.RH
        vin = ["-f", "lavfi", "-i", f"color=c=black:s={W}x{H}:r={fps}:d=1"]
        for wave, mus, fx in ((want_wave, want_music, want_sfx), (want_wave, want_music, False),
                              (want_wave, False, False), (False, want_music, want_sfx), (False, False, False)):
            cmd = self._ffmpeg_cmd(vin, voice, music if mus else None, total,
                                   ["-t", "1", "-c:v", "mpeg4", "-c:a", "aac", "-f", "null", "-"], fps, renderer, wave,
                                   sfx if fx else None)
            rc, _, err = run(cmd, timeout=60)
            if rc == 0:
                return wave, mus, fx
            log.warning("ffmpeg varianti ishlamadi (to'lqin=%s, musiqa=%s, sfx=%s): %s", wave, mus, fx, err[-200:])
        raise VideoError("ffmpeg ishga tushmadi (ovoz/video birlashtirish sinovi muvaffaqiyatsiz)")

    def render_encode(self, scenes, renderer: Renderer, fps: int, total_f: int, voice: Path, out: Path,
                      workdir: Path, progress=lambda i, n: None):
        """Kadrlarni chizadi va ffmpeg ga uzatadi. Avval GPU (NVENC/QSV/AMF), xato bo'lsa avtomatik CPU (libx264)."""
        try:
            enc = self._render_encode_once(scenes, renderer, fps, total_f, voice, out, workdir, progress, False)
        except VideoError as e:
            codec = list(getattr(self, "last_codec", []))
            if HW.is_hw(codec) and "bekor" not in str(e) and HW_ERR.search(str(e)):
                HW.report(codec, False, str(e))
                log.warning("GPU kodlash xato berdi (%s) — video CPU da qayta kodlanadi", str(e)[-160:])
                out.unlink(missing_ok=True)
                enc = self._render_encode_once(scenes, renderer, fps, total_f, voice, out, workdir, progress, True)
            else:
                raise
        HW.report(self.last_codec, True)
        enc["encoder"] = HW.label(HW.name_of(self.last_codec))
        return enc

    def _render_encode_once(self, scenes, renderer: Renderer, fps: int, total_f: int, voice: Path, out: Path,
                            workdir: Path, progress, force_cpu: bool):
        """Kadrlarni chizadi va to'g'ridan-to'g'ri ffmpeg ga uzatadi (diskka kadr yozilmaydi)."""
        total = total_f / fps
        music = workdir / "music.wav"
        seed = getattr(renderer, "bg_seed", 0)
        has_music = bool(self.cfg.bool("MUSIC") and make_music(music, total, seed))
        sfx_p = workdir / "sfx.wav"
        has_sfx = bool(self.cfg.bool("SFX") and sfx.make_sfx(sfx_p, scenes, total, seed))
        wave, use_music, use_sfx = self._pick_encoder(renderer, voice, music if has_music else None, total, fps,
                                                      sfx_p if has_sfx else None)
        W, H = renderer.RW, renderer.RH
        vin = ["-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps), "-i", "pipe:0"]
        # Sifat BELGILANGAN: GPU da doimiy sifat (CQ) + bitrate chegarasi, CPU da CRF — kodlovchiga qarab tushib ketmaydi
        codec = HW.venc("video", fps, self._int("VIDEO_BITRATE"), self.cfg.int("VIDEO_CRF"), None, min(W, H),
                        still=True, force_cpu=force_cpu)
        self.last_codec = codec
        tail = codec + list(self.extra_v) + ["-r", str(fps), "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
                                             "-t", f"{total:.6f}", "-movflags", "+faststart", str(out)]
        cmd = self._ffmpeg_cmd(vin, voice, music if use_music else None, total, tail, fps, renderer, wave,
                               sfx_p if use_sfx else None)
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        err_tail: list = []

        def drain():
            for line in proc.stderr:
                err_tail.append(line.decode("utf-8", "replace"))
                del err_tail[:-30]

        th = threading.Thread(target=drain, daemon=True)
        th.start()
        written = 0
        t_loop = time.time()
        try:
            k_trans_f = max(1, int(round(TRANS_S * fps)))
            prev_final = self.prev_content if self.prev_content is not None else renderer.black()
            for si, sc in enumerate(scenes):
                if self.cancel and self.cancel():
                    raise VideoError("bekor qilindi")
                S, E = sc["start_f"], sc["start_f"] + sc["slot_f"]
                vstart_s = (S + sc["lead_f"]) / fps
                frames = self._emit_frames(sc, fps, renderer.motion, k_trans_f)
                ckey, cimg, cmask = None, None, None
                for n_, f in enumerate(frames):
                    if self.cancel and n_ % 8 == 0 and self.cancel():
                        raise VideoError("bekor qilindi")
                    t_rel = f / fps - vstart_s
                    age = (f - S) / fps
                    shown, anim = self._unit_state(sc, t_rel) if sc["unit_rel"] else (0, 1.0)
                    k = f - S
                    alpha = (k + 1) / (k_trans_f + 1) if k < k_trans_f else 1.0
                    key = (shown, round(anim, 3), renderer.age_key(sc, age), round(alpha, 3))
                    if key != ckey:
                        cur = renderer.content(sc, shown, anim, age)
                        if alpha < 1.0:
                            cur = renderer.blend(prev_final, cur, alpha)
                        ckey, cimg, cmask = key, cur, renderer.mask_for(cur)
                    cap = None
                    for ch in sc["chunks"]:
                        if ch["show_start"] <= f < ch["show_end"]:
                            nshow = sum(1 for g in range(ch["i0"], ch["i1"] + 1) if sc["rf"][g] <= f)
                            cur_i = nshow - 1
                            off = sc["hl_off"].get(ch["i0"] + cur_i)
                            if off is not None and f >= off:
                                cur_i = -1
                            cap = {"words": [w["w"] for w in sc["words"][ch["i0"]:ch["i1"] + 1]],
                                   "n": nshow, "cur": cur_i}
                            break
                    img = renderer.compose(f / fps, cimg, cmask, cap, (f + 0.5) / total_f)
                    dur = (frames[n_ + 1] if n_ + 1 < len(frames) else E) - f
                    buf = img.tobytes()
                    try:
                        for _ in range(dur):
                            proc.stdin.write(buf)
                    except (BrokenPipeError, OSError):
                        raise VideoError("ffmpeg kodlash vaqtida to'xtadi: " + "".join(err_tail)[-500:])
                    written += dur
                prev_final = renderer.content(sc, scene_units(sc), 1.0, 99.0)
                self.last_content = prev_final
                progress(si + 1, len(scenes))
            if written != total_f:
                raise VideoError(f"kadrlar soni mos emas: {written} != {total_f} (ichki xato)")
            t_loop = time.time() - t_loop
            t_enc = time.time()
            try:
                proc.stdin.close()
            except OSError:
                pass
            rc = proc.wait(timeout=3600)
            th.join(timeout=5)
        except BaseException:
            try:
                proc.kill()
            except OSError:
                pass
            raise
        if rc != 0 or not out.exists() or out.stat().st_size < 5000:
            raise VideoError(f"ffmpeg xatosi (kod {rc}): {''.join(err_tail)[-500:]}")
        return {"render_sec": t_loop, "encode_sec": time.time() - t_enc, "music": use_music, "wave": wave, "sfx": use_sfx,
                "frames_written": written}

    # ----------------------------------------------------------- stream: qismlab render
    def render_range(self, scenes, renderer: Renderer, fps: int, total_f: int, out: Path, f0: int, f1: int,
                     codec_args: list, prev_content=None, threads: int = 0, step: int = 1, tick=None):
        """Faqat [f0, f1) kadrlarni (ovozsiz) MP4 ga yozadi. Bir nechta qism bir vaqtda (parallel) chizilishi
        mumkin; keyin `concat` bilan ulanadi. Har qism o'z kalit kadri (IDR) bilan boshlanadi."""
        W, H = renderer.RW, renderer.RH
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
               "-r", str(fps), "-i", "pipe:0", "-an"] + list(codec_args)
        if threads:
            cmd += ["-threads", str(threads)]
        if "-pix_fmt" not in codec_args:
            cmd += ["-pix_fmt", "yuv420p"]
        cmd += ["-r", str(fps)]
        if "-g" not in codec_args:
            cmd += ["-g", str(fps * 2)]
        cmd += ["-frames:v", str(f1 - f0), str(out)]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        err_tail: list = []

        def drain():
            for line in proc.stderr:
                err_tail.append(line.decode("utf-8", "replace"))
                del err_tail[:-20]

        th = threading.Thread(target=drain, daemon=True)
        th.start()
        written = 0
        cver, last_bkey, last_sig, base, cur_buf = 0, None, None, None, None
        try:
            k_trans_f = max(1, int(round(TRANS_S * fps)))
            for si, sc in enumerate(scenes):
                S, E = sc["start_f"], sc["start_f"] + sc["slot_f"]
                if E <= f0 or S >= f1:
                    continue
                if self.cancel and self.cancel():
                    raise VideoError("bekor qilindi")
                vstart_s = (S + sc["lead_f"]) / fps
                frames = self._emit_frames(sc, fps, renderer.motion, k_trans_f)
                if prev_content is not None and si == 0:
                    prev_final = prev_content
                elif si == 0:
                    prev_final = renderer.black()
                else:
                    prev_final = None           # kerak bo'lsa (faqat o'tish kadrlarida) hisoblanadi
                ckey, cimg, cmask = None, None, None
                for n_, f in enumerate(frames):
                    nxt = frames[n_ + 1] if n_ + 1 < len(frames) else E
                    a, b = max(f, f0), min(nxt, f1)
                    if b <= a:
                        continue
                    if self.cancel and n_ % 8 == 0 and self.cancel():
                        raise VideoError("bekor qilindi")
                    # animatsiya holati (har step kadrda) kvantlanadi: o'tish kadrlari va hodisalar aniq qoladi, doimiy
                    # animatsiyalar (diagramma, urg'u) esa kam hisoblanadi
                    k = f - S
                    fq = f if (step <= 1 or k <= k_trans_f + 1) else f - (k % step)
                    t_rel = fq / fps - vstart_s
                    age = (fq - S) / fps
                    shown, anim = self._unit_state(sc, t_rel) if sc["unit_rel"] else (0, 1.0)
                    alpha = (k + 1) / (k_trans_f + 1) if k < k_trans_f else 1.0
                    key = (shown, round(anim, 3), renderer.age_key(sc, age), round(alpha, 3))
                    if key != ckey:
                        cur = renderer.content(sc, shown, anim, age)
                        if alpha < 1.0:
                            if prev_final is None:
                                ps = scenes[si - 1]
                                prev_final = renderer.content(ps, scene_units(ps), 1.0, 99.0)
                            cur = renderer.blend(prev_final, cur, alpha)
                        ckey, cimg, cmask = key, cur, renderer.mask_for(cur)
                        cver += 1
                    cap = None
                    for ch in sc["chunks"]:
                        if ch["show_start"] <= f < ch["show_end"]:
                            nshow = sum(1 for g in range(ch["i0"], ch["i1"] + 1) if sc["rf"][g] <= f)
                            cur_i = nshow - 1
                            off = sc["hl_off"].get(ch["i0"] + cur_i)
                            if off is not None and f >= off:
                                cur_i = -1
                            cap = {"words": [w["w"] for w in sc["words"][ch["i0"]:ch["i1"] + 1]],
                                   "n": nshow, "cur": cur_i}
                            break
                    if renderer.motion > 0 or cap is not None:
                        for ff in range(a, b):
                            # fon harakati har `step` kadrda yangilanadi (oraliqdagilar takrorlanadi); asos kadr (fon+mazmun)
                            # qayta ishlatiladi, har kadrda faqat subtitr chiziladi: CPU bir necha baravar kam
                            q = 0 if renderer.motion <= 0 else (ff - (ff % step) if step > 1 else ff)
                            bkey = (cver, q)
                            if bkey != last_bkey:
                                base = renderer.compose_base(max(q, 0) / fps, cimg, cmask)
                                last_bkey, last_sig = bkey, None
                            csig = None if cap is None else (cap["n"], cap["cur"], cap["words"][0] if cap["words"] else "",
                                                             len(cap["words"]))
                            sig = (bkey, csig, ff if renderer.show_progress else 0)
                            if sig != last_sig:
                                if cap is None and not renderer.show_progress:
                                    cur_buf = base.tobytes()
                                else:
                                    cur_buf = renderer.finish(base.copy(), cap, (ff + 0.5) / total_f).tobytes()
                                last_sig = sig
                            try:
                                proc.stdin.write(cur_buf)
                            except (BrokenPipeError, OSError):
                                raise VideoError("ffmpeg to'xtadi: " + "".join(err_tail)[-300:])
                            written += 1
                            if tick and written % 30 == 0:
                                tick(30)
                    else:
                        buf = renderer.compose(a / fps, cimg, cmask, cap, (a + 0.5) / total_f).tobytes()
                        try:
                            for _ in range(b - a):
                                proc.stdin.write(buf)
                        except (BrokenPipeError, OSError):
                            raise VideoError("ffmpeg to'xtadi: " + "".join(err_tail)[-300:])
                        written += b - a
                        if tick:
                            tick(b - a)
            if written != f1 - f0:
                raise VideoError(f"qism kadrlari mos emas: {written} != {f1 - f0} (ichki xato)")
            try:
                proc.stdin.close()
            except OSError:
                pass
            rc = proc.wait(timeout=1800)
            th.join(timeout=5)
        except BaseException:
            try:
                proc.kill()
            except OSError:
                pass
            raise
        if rc != 0 or not out.exists() or out.stat().st_size < 500:
            raise VideoError(f"qism kodlanmadi (ffmpeg {rc}): {''.join(err_tail)[-300:]}")
        return written

    def mix_audio(self, voice: Path, sfx_path, total: float, out: Path) -> bool:
        """Ovoz (+ ovoz effektlari) ni bir marta AAC ga kodlaydi (butun bo'lak uchun; qismlar chegarasida
        AAC 'tutashuv' bo'lmasligi uchun audio qismlarga bo'linmaydi)."""
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(voice)]
        if sfx_path:
            cmd += ["-i", str(sfx_path), "-filter_complex",
                    f"[1:a]volume={max(0.0, self.cfg.float('SFX_VOLUME')) * 0.8:.3f}[x];"
                    "[0:a][x]amix=inputs=2:duration=first:normalize=0[a]", "-map", "[a]"]
        cmd += ["-t", f"{total:.6f}", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "1", str(out)]
        rc, _, err = run(cmd, timeout=600)
        if rc != 0 and sfx_path:
            return self.mix_audio(voice, None, total, out)
        if rc != 0:
            raise VideoError("audio kodlanmadi: " + err[-300:])
        return True

    # ----------------------------------------------------------- hammasi
    def prepare_stream(self, scenes: list, workdir: Path, portrait: bool, tts_workers: int = 3, progress=None) -> dict:
        """Chizishsiz tayyorlov: ovoz (sahnalar parallel), vaqt rejasi, ovoz fayli, sarlavhalar. Render bilan bir vaqtda
        keyingi bo'lak uchun chaqirilishi mumkin."""
        workdir.mkdir(parents=True, exist_ok=True)
        fps = self.fps()
        a = self.make_audio(scenes, workdir, progress or (lambda i, n, info: None), workers=tts_workers)
        total_f = self.plan(scenes, fps)
        voice = self.write_voice(scenes, fps, workdir)
        self.captions(scenes, fps, 40 if portrait else 66)
        return {"total_f": total_f, "voice": voice, "providers": a["providers"], "fps": fps}

    def render_stream(self, pr: dict, scenes: list, workdir: Path, out: Path, borrow, release, ex, part_sec: float,
                      codec_args: list, t_off: float, progress=None, threads_each: int = 0, remote=None,
                      spec_base: dict | None = None, fallback_args: list | None = None) -> dict:
        """Video ~part_sec soniyalik qismlarga bo'linib parallel chiziladi/kodlanadi (`ex` umumiy pul); ovoz bir marta
        AAC ga kodlanadi (qismlar chegarasida uzilish bo'lmasin); so'ng hammasi ulanadi (qayta kodlashsiz)."""
        progress = progress or (lambda stage, a, b, info="": None)
        t1 = time.time()
        fps, total_f, voice = pr["fps"], pr["total_f"], pr["voice"]
        total = total_f / fps
        r0 = borrow()
        try:
            seed = getattr(r0, "bg_seed", 0)
        finally:
            release(r0)
        sfx_p = workdir / "sfx.wav"
        has_sfx = bool(self.cfg.bool("SFX") and sfx.make_sfx(sfx_p, scenes, total, seed))
        aud = workdir / "audio.m4a"
        fa = ex.submit(self.mix_audio, voice, sfx_p if has_sfx else None, total, aud)
        per = max(1, int(round(part_sec * fps)))
        ranges = [(f0, min(total_f, f0 + per)) for f0 in range(0, total_f, per)]
        if len(ranges) > 1 and ranges[-1][1] - ranges[-1][0] < fps:   # juda qisqa dumni oldingisiga qo'shamiz
            last = ranges.pop()
            ranges[-1] = (ranges[-1][0], last[1])
        done = [0]
        lock = threading.Lock()
        progress("parts", 0, len(ranges))
        remote_tick = self.tick
        cur = {"codec": list(codec_args), "tag": ""}      # GPU xato bersa butun bo'lak CPU kodlovchiga o'tadi
        stop = threading.Event()

        def part_remote(idx, f0, f1, pth):
            """Qismni alohida jarayonda chizadi (GIL yo'q: haqiqiy parallel). Muvaffaqiyatsiz bo'lsa False."""
            from .renderpool import RemoteCancelled, RemoteUnavailable
            spec = dict(spec_base, scenes=scenes, fps=fps, total_f=total_f, out=str(pth), f0=f0, f1=f1, codec=cur["codec"],
                        prev=(self.prev_content if f0 == 0 else None), t_off=t_off, threads=threads_each,
                        step=self.motion_step, cancel_file=None)
            for attempt in (1, 2):
                try:
                    remote.run(spec, cancel=self.cancel, on_tick=remote_tick)
                    return True
                except RemoteCancelled:
                    raise VideoError("bekor qilindi")
                except RemoteUnavailable as e:
                    log.warning("Render ishchisi ishlamadi (%s) — oqimlarda davom etiladi", str(e)[:120])
                    return False
                except Exception as e:  # noqa: BLE001
                    log.warning("Qism %d ishchida yiqildi (%d): %s", idx, attempt, str(e)[:150])
                    pth.unlink(missing_ok=True)
            return False

        def part(idx, f0, f1):
            if (self.cancel and self.cancel()) or stop.is_set():
                raise VideoError("bekor qilindi")
            codec = cur["codec"]
            pth = workdir / f"p{idx:03d}{cur['tag']}.mp4"
            # GPU: bir vaqtda ochiladigan kodlash sessiyalari soni cheklangan (drayver chegarasi) — navbat kutiladi
            with HW.session(codec, cancel=lambda: stop.is_set() or bool(self.cancel and self.cancel())):
                if remote is not None and not getattr(remote, "broken", False) and part_remote(idx, f0, f1, pth) \
                        and pth.exists() and pth.stat().st_size > 500:
                    with lock:
                        done[0] += 1
                        progress("parts", done[0], len(ranges))
                    return pth
                r = borrow()
                try:
                    r.t_off = t_off
                    for attempt in (1, 2):             # bitta qism yiqilsa — bir marta qayta urinadi
                        try:
                            self.render_range(scenes, r, fps, total_f, pth, f0, f1, codec,
                                              prev_content=self.prev_content, threads=threads_each,
                                              step=self.motion_step, tick=self.tick)
                            break
                        except VideoError as e:
                            if attempt == 2 or "bekor" in str(e) or (HW.is_hw(codec) and HW_ERR.search(str(e))):
                                raise                  # GPU xatosi: qayta urinmay, butun bo'lak CPU ga o'tadi
                            log.warning("Qism %d qayta uriniladi: %s", idx, str(e)[:150])
                            pth.unlink(missing_ok=True)
                finally:
                    release(r)
            with lock:
                done[0] += 1
                progress("parts", done[0], len(ranges))
            return pth

        def run_parts() -> list:
            futs = [ex.submit(part, i, f0, f1) for i, (f0, f1) in enumerate(ranges)]
            try:
                res = [f.result() for f in futs]
                fa.result()
                return res
            except BaseException:
                stop.set()
                for f in futs:
                    f.cancel()
                from concurrent.futures import wait as _wait
                _wait(futs, timeout=120)               # ishlayotgan qismlar tugasin (ffmpeg jarayonlari qolib ketmasin)
                for i in range(len(ranges)):
                    (workdir / f"p{i:03d}{cur['tag']}.mp4").unlink(missing_ok=True)
                raise

        try:
            paths = run_parts()
        except VideoError as e:
            if fallback_args and HW.is_hw(cur["codec"]) and "bekor" not in str(e) and HW_ERR.search(str(e)) \
                    and not (self.cancel and self.cancel()):
                HW.report(cur["codec"], False, str(e))
                log.warning("GPU kodlash xato berdi (%s) — bo'lak CPU da qayta kodlanadi", str(e)[-160:])
                cur["codec"], cur["tag"] = list(fallback_args), "c"
                stop.clear()
                done[0] = 0
                progress("parts", 0, len(ranges))
                paths = run_parts()
            else:
                raise
        HW.report(cur["codec"], True)
        pr["encoder"] = HW.name_of(cur["codec"])
        lst = workdir / "parts.txt"
        lst.write_text("".join(f"file '{pp.name}'\n" for pp in paths), encoding="utf-8")
        progress("mux", len(ranges), len(ranges))
        rc, _, err = run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                          "-i", str(aud.resolve()), "-map", "0:v:0", "-map", "1:a:0", "-c", "copy", "-t", f"{total:.6f}",
                          "-movflags", "+faststart", str(out.resolve())], timeout=900, cwd=str(workdir))
        if rc != 0 or not out.exists() or out.stat().st_size < 5000:
            raise VideoError("qismlar ulanmadi: " + err[-300:])
        for pp in paths:
            pp.unlink(missing_ok=True)
        r0 = borrow()
        try:
            ls = scenes[-1]
            self.last_content = r0.content(ls, scene_units(ls), 1.0, 99.0)
        finally:
            release(r0)
        return {"duration": total, "size": out.stat().st_size, "frames": total_f, "tts_providers": pr["providers"],
                "parts": len(ranges), "t_render": time.time() - t1, "fps": fps}

    def _parallel_ok(self, renderer, fps: int, total_f: int) -> bool:
        """Video qismlarga bo'lib parallel chizishga mosmi (to'lqin/musiqa butun video bo'ylab filtr talab qiladi)."""
        c = self.cfg
        try:
            if not c.bool("VIDEO_PARALLEL") or c.bool("VIDEO_WAVE") or c.bool("MUSIC"):
                return False
        except (KeyError, ValueError):
            return False
        return callable(renderer) and total_f >= fps * 25 and (os.cpu_count() or 1) >= 2

    def _render_parallel(self, scenes, make_renderer, fps, total_f, voice, providers, out, workdir, progress, rargs):
        """Video qismlarga bo'linib PARALLEL chiziladi (stream bilan bir xil mexanizm): bir nechta jarayon kadr chizadi, kodlash
        GPU sessiyalarida (yoki CPU da), keyin qismlar nusxalanib (re-kodlashsiz) ovoz bilan birlashtiriladi."""
        import queue
        from concurrent.futures import ThreadPoolExecutor
        c = self.cfg
        n_cpu = os.cpu_count() or 2
        procs = c.int("VIDEO_PROCS") or min(8, n_cpu)
        W, H = c.base_size
        t0 = time.time()
        rq: queue.Queue = queue.Queue()
        n_local = 2 if procs > 1 else 1
        for _ in range(n_local):
            rq.put(make_renderer())
        remote, spec_base = None, None
        if rargs and procs > 1:
            try:
                from .renderpool import RenderPool
                remote = RenderPool(procs, c.root)
                safe = {k: v for k, v in c.overrides.items() if not any(x in k.upper() for x in ("KEY", "TOKEN", "SECRET", "PASSWORD"))}
                spec_base = {"rkey": f"v:{rargs.get('seed')}:{c.get('VIDEO_RES')}:{fps}:{c.get('VIDEO_FORMAT')}:{rargs.get('style')}:{rargs.get('accent_idx')}",
                             "rargs": rargs, "show_progress": True,
                             "cfg": {"root": str(c.root), "env_file": str(c.env_file), "overrides": safe, "over": {}}}
            except Exception as e:  # noqa: BLE001
                log.warning("Parallel render jarayonlari ochilmadi (%s) — oqimlar ishlatiladi", e)
                remote = None
        workers = max(2, min(procs if remote else n_local, 12))
        ex = ThreadPoolExecutor(max_workers=workers + 2, thread_name_prefix="vpar")
        codec = HW.venc("video", fps, self._int("VIDEO_BITRATE"), c.int("VIDEO_CRF"), None, min(W, H), still=True)
        fb = HW.venc("video", fps, self._int("VIDEO_BITRATE"), c.int("VIDEO_CRF"), None, min(W, H), still=True,
                     force_cpu=True) if HW.is_hw(codec) else None
        pr = {"fps": fps, "total_f": total_f, "voice": voice, "providers": providers}
        self.motion_step = max(1, motion_cad(fps, c.int("VIDEO_MOTION"), False, self.anim_fps) or 1)
        part_sec = max(8.0, float(c.get("VIDEO_PART_SEC") or 20))

        def prog(stage, a, b, *_):
            progress("frames", a, b) if stage == "parts" else None

        try:
            self.render_stream(pr, scenes, workdir, out, rq.get, rq.put, ex, part_sec, codec, 0.0, prog,
                               threads_each=max(1, n_cpu // workers), remote=remote, spec_base=spec_base, fallback_args=fb)
        finally:
            ex.shutdown(wait=False, cancel_futures=True)
            if remote is not None:
                try:
                    remote.close()
                except Exception:  # noqa: BLE001
                    pass
        el = time.time() - t0
        return {"music": False, "wave": False, "render_sec": el, "encode_sec": 0.0,
                "encoder": HW.label(pr.get("encoder")) if pr.get("encoder") else HW.label()}

    def build(self, scenes: list, workdir: Path, out: Path, renderer, progress=None, portrait: bool | None = None,
              rargs: dict | None = None) -> dict:
        """Video yig'ish. `renderer` Renderer yoki uni yaratuvchi funksiya (kechiktirilgan: AI rasmlar tayyor bo'lishini
        ovoz yaratilgandan KEYIN kutish uchun — ovoz va rasmlar bir vaqtda parallel tayyorlanadi)."""
        progress = progress or (lambda stage, a, b, info="": None)
        t0 = time.time()
        fps = self.fps()
        # hamma sahna ovozi PARALLEL (stream kabi); har biri tugashi bilan keyingi bosqich kutmaydi
        a = self.make_audio(scenes, workdir, lambda i, n, info: progress("tts", i, n, info), workers=0)
        total_f = self.plan(scenes, fps)
        voice = self.write_voice(scenes, fps, workdir)
        total = total_f / fps
        if portrait is None:
            if callable(renderer):
                bw, bh = self.cfg.base_size
                portrait = bh > bw
            else:
                portrait = renderer.portrait
        srt = self.captions(scenes, fps, 40 if portrait else 66)
        t1 = time.time()
        progress("encode", 0, 1)
        enc = None
        if self._parallel_ok(renderer, fps, total_f):
            try:
                enc = self._render_parallel(scenes, renderer, fps, total_f, voice, a["providers"], out, workdir, progress, rargs)
            except VideoError as e:
                if "bekor" in str(e):
                    raise
                log.warning("Parallel render yiqildi (%s) — ketma-ket usulga o'tiladi", str(e)[-160:])
                out.unlink(missing_ok=True)
            except Exception as e:  # noqa: BLE001
                log.warning("Parallel render kutilmagan xato (%s) — ketma-ket usulga o'tiladi", e)
                out.unlink(missing_ok=True)
        if enc is None:
            if callable(renderer):
                renderer = renderer()
            enc = self.render_encode(scenes, renderer, fps, total_f, voice, out, workdir,
                                     lambda i, n: progress("frames", i, n))
        srt_path = out.with_suffix(".srt")
        srt_path.write_text("\n".join(
            f"{i}\n{srt_time(s)} --> {srt_time(e)}\n{c}\n" for i, (s, e, c) in enumerate(srt, 1)) + "\n",
            encoding="utf-8")
        return {
            "duration": total, "size": out.stat().st_size, "frames": total_f,
            "tts_providers": a["providers"], "music": enc["music"], "wave": enc["wave"],
            "t_tts": t1 - t0, "t_frames": enc["render_sec"], "t_encode": enc["encode_sec"],
            "srt": srt_path, "fps": fps, "encoder": enc.get("encoder", ""),
        }


def chapters(scenes: list) -> list:
    """YouTube bo'limlari uchun [(sekund, nom)] (kamida 10 soniyadan, birinchisi 0:00)."""
    out = []
    for sc in scenes:
        name = sc.get("chapter") or sc.get("heading") or ""
        if not name:
            continue
        if out and sc["start"] - out[-1][0] < 10:
            continue
        out.append((sc["start"], name))
    if out and out[0][0] > 0:
        out[0] = (0.0, out[0][1])
    if len(out) < 3 or out[0][0] != 0:
        return []
    return out


def chapters_text(scenes: list, title: str) -> str:
    ch = chapters(scenes)
    return "\n".join(f"{fmt_dur(t)} {name}" for t, name in ch)
