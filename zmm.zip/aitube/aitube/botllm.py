"""Bot buyruqlari: LLM modellari, API kalitlari, provayder tartibi, pleylist ta'mirlash."""
from __future__ import annotations

from . import llmadmin as adm
from .llm import PROVIDERS
from .tg import PANELS
from .util import clip, esc
from .youtube import YTError

SECRET_CMDS = {"addkey", "editkey"}   # xabar chatdan o'chiriladi (kalit bor)


def _parse(arg):
    parts = arg.split()
    return parts


class LLMAdminMixin:
    # ------------------------------------------------------------- modellar
    def c_model(self, arg, chat):
        a = self.app
        p = arg.split()
        if len(p) < 2:
            return "Foydalanish: /model use|add|del|edit|set|find|auto PROVAYDER ... (ro'yxat: /models)"
        act, prov = p[0].lower(), adm.norm(p[1])
        if not prov:
            return "Provayder: " + ", ".join(adm.PROV)
        rest = p[2:]
        if act == "find":
            return self._find_models(prov, chat)
        if act == "auto":
            return self._auto_models(prov, chat)
        if act == "add" and rest:
            ok, msg = adm.add_model(a.cfg, prov, rest[0], first=len(rest) > 1 and rest[1] == "first")
        elif act == "use" and rest:
            ok, msg = adm.use_model(a.cfg, prov, rest[0])
        elif act in ("del", "rm", "remove") and rest:
            ok, msg = adm.del_model(a.cfg, prov, rest[0])
        elif act == "edit" and len(rest) >= 2:
            ok, msg = adm.edit_model(a.cfg, prov, rest[0], rest[1])
        elif act == "set" and rest:
            ok, msg = adm.set_models(a.cfg, prov, " ".join(rest).replace(",", " ").split())
        else:
            return "Foydalanish: /model use|add|del|edit|set|find|auto PROVAYDER ..."
        if ok:
            a.llm.reset_health()
            msg = "✅ " + msg + "\nSinash: /llm"
        return msg

    def _find_models(self, prov, chat):
        a = self.app
        if prov == "pollinations":
            return "Pollinations uchun qidirish yo'q: /model set pollinations openai,mistral"

        def job():
            p = PROVIDERS[prov](a.cfg)
            try:
                found = a.llm.discover(p)
            except Exception as e:  # noqa: BLE001
                a.n.error("Modellarni topib bo'lmadi", f"{prov}: {clip(str(e), 300)}")
                return
            if not found:
                a.n.say(f"🔎 {prov}: mos model topilmadi (kalit bormi? /keys).")
                return
            lines = [f"🔎 <b>{prov}</b>: hozir mavjud ({len(found)} ta, eng yaxshilari yuqorida)"]
            lines += [f"{i}. <code>{esc(m)}</code>" for i, m in enumerate(found[:12], 1)]
            lines.append("\n«Almashtirish» — ro'yxat shu birinchi 4 tasi bilan almashadi.")
            mk = {"inline_keyboard": [[{"text": "✅ Almashtirish", "callback_data": f"mdl:auto:{prov}"},
                                       {"text": "✖️ Yopish", "callback_data": "m:models"}]]}
            self.tg.send("\n".join(lines), chat=chat, markup=mk)

        if not a.jobs.submit_light(f"find-{prov}", job):
            return "ℹ️ Band."
        return f"🔎 {prov}: jonli ro'yxat so'ralmoqda…"

    def _auto_models(self, prov, chat):
        a = self.app

        def job():
            p = PROVIDERS[prov](a.cfg)
            try:
                found = a.llm.discover(p)[:4]
            except Exception as e:  # noqa: BLE001
                a.n.error("Modellarni topib bo'lmadi", f"{prov}: {clip(str(e), 300)}")
                return
            ok, msg = adm.set_models(a.cfg, prov, found) if found else (False, "Mos model topilmadi.")
            if ok:
                a.llm.reset_health()
            a.n.say(("✅ " if ok else "⚠️ ") + msg + (("\n" + "\n".join(f"• <code>{esc(m)}</code>" for m in found)) if ok else ""))

        return "🔄 Yangilanmoqda…" if a.jobs.submit_light(f"auto-{prov}", job) else "ℹ️ Band."

    def c_order(self, arg, chat):
        a = self.app
        if not arg.strip():
            return ("Hozirgi tartib: <code>" + " → ".join(a.cfg.list("LLM_ORDER")) + "</code>\n"
                    "O'zgartirish: <code>/order groq,gemini,openrouter,pollinations</code>")
        ok, msg = adm.set_order(a.cfg, arg.replace(",", " ").split())
        if ok:
            a.llm.reset_health()
        return ("✅ " if ok else "⚠️ ") + msg

    # ------------------------------------------------------------- kalitlar
    def _after_key_change(self):
        self.app.llm.reset_health()

    def c_addkey(self, arg, chat):
        p = arg.split()
        if len(p) != 2 or not adm.norm(p[0]):
            return "Foydalanish: /addkey gemini|groq|openrouter KALIT"
        ok, msg = adm.add_key(self.app.cfg, adm.norm(p[0]), p[1])
        if ok:
            self._after_key_change()
            msg += "\nSinash: /testkeys"
        return ("✅ " if ok else "⚠️ ") + esc(msg)

    def c_delkey(self, arg, chat):
        p = arg.split()
        if len(p) != 2 or not adm.norm(p[0]) or not p[1].isdigit():
            return "Foydalanish: /delkey groq 2  (raqamlar: /keys)"
        ok, msg = adm.del_key(self.app.cfg, adm.norm(p[0]), int(p[1]))
        if ok:
            self._after_key_change()
        return ("✅ " if ok else "⚠️ ") + esc(msg)

    def c_editkey(self, arg, chat):
        p = arg.split()
        if len(p) != 3 or not adm.norm(p[0]) or not p[1].isdigit():
            return "Foydalanish: /editkey groq 2 YANGI_KALIT"
        ok, msg = adm.edit_key(self.app.cfg, adm.norm(p[0]), int(p[1]), p[2])
        if ok:
            self._after_key_change()
            msg += "\nSinash: /testkeys"
        return ("✅ " if ok else "⚠️ ") + esc(msg)

    def c_testkeys(self, arg, chat):
        a = self.app
        only = adm.norm(arg) if arg.strip() else None

        def job():
            lines = ["🧪 <b>Kalitlar sinovi</b>"]
            for prov in ("gemini", "groq", "openrouter"):
                if only and prov != only:
                    continue
                p = PROVIDERS[prov](a.cfg)
                ks = adm.keys(a.cfg, prov)
                if not ks:
                    lines.append(f"<b>{prov}</b>: kalit yo'q")
                    continue
                for i, k in enumerate(ks, 1):
                    ok, info = a.llm.test_key(p, k)
                    lines.append(f"{'✅' if ok else '❌'} {prov} #{i} <code>{adm.mask(k)}</code> — {esc(clip(info, 110))}")
            if not only:
                p = PROVIDERS["pollinations"](a.cfg)
                ok, info = a.llm.test_key(p, "")
                lines.append(f"{'✅' if ok else '❌'} pollinations (kalitsiz) — {esc(clip(info, 90))}")
            a.n.say("\n".join(lines))

        return "🧪 Sinov ketmoqda…" if a.jobs.submit_light("testkeys", job) else "ℹ️ Band."

    def mdl_callback(self, val, chat):
        act, _, prov = val.partition(":")
        prov = adm.norm(prov)
        if not prov:
            return None
        if act == "find":
            return self._find_models(prov, chat)
        if act == "auto":
            return self._auto_models(prov, chat)
        return None

    # ------------------------------------------------------------- pleylist
    def c_playlist(self, arg, chat):
        """Pleylistni tekshiradi; o'chirilgan bo'lsa qayta yaratib, videolarni qo'shadi."""
        a = self.app
        from .playlist import sync_season

        def job():
            if not a.yt.authorized():
                a.n.say("🔑 YouTube ulanmagan: /auth")
                return
            sids = []
            if arg.strip().isdigit():
                sids = [int(arg)]
            else:
                sids = [s["id"] for s in a.db.seasons()
                        if any(e["status"] == "uploaded" for e in a.db.season_episodes(s["id"]))]
            if not sids:
                a.n.say("ℹ️ Yuklangan video yo'q — pleylist kerak emas.")
                return
            out = ["📚 <b>Pleylist tekshiruvi</b>"]
            for sid in sids:
                try:
                    notes = sync_season(a.yt, a.db, a.cfg, sid)
                    out.append(f"Fasl {sid}: " + (" · ".join(notes) if notes else "✅ hammasi joyida"))
                except YTError as e:
                    out.append(f"Fasl {sid}: ⚠️ {esc(clip(str(e), 150))}")
                    if e.quota or e.auth:
                        break
            a.n.say("\n".join(out))

        return "📚 Tekshirilmoqda…" if a.jobs.submit_light("playlist-sync", job) else "ℹ️ Band."

    # ------------------------------------------------------------- tugmali boshqaruv (inline)
    def _screen(self, chat, text, rows):
        mk = {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]}
        mid = getattr(self, "_cb_msg", None)
        if mid:
            try:
                self.tg.edit(mid, text, chat=chat, markup=mk)
                self.last_screen = (chat, mid)
                return
            except Exception:  # noqa: BLE001  (o'zgarmagan matn va h.k.)
                pass
        ids = self.tg.send(text, chat=chat, markup=mk)
        self.last_screen = (chat, ids[-1] if ids else None)
        if ids:
            PANELS[chat] = ids[-1]

    def c_models(self, arg, chat):
        a = self.app
        order = a.cfg.list("LLM_ORDER")
        lines = ["🤖 <b>AI modellari</b>", "Ishlatish tartibi: <b>" + " → ".join(order) + "</b>", ""]
        rows = []
        for prov in adm.PROV:
            n = len(adm.models(a.cfg, prov))
            k = "kalitsiz" if prov == "pollinations" else f"🔑{len(adm.keys(a.cfg, prov))}"
            first = (adm.models(a.cfg, prov) or ["-"])[0]
            lines.append(f"• <b>{prov}</b> ({k}, {n} model) — asosiy: <code>{esc(first)}</code>")
            rows.append([(f"⚙️ {prov} modellari", f"ui:mp:{prov}")])
        rows.append([(f"⬆️ {p} birinchi", f"ui:ord:{p}") for p in ("gemini", "groq", "openrouter")])
        rows.append([("🔑 Kalitlar", "ui:keys"), ("🧪 AI ni sinash", "m:llm")])
        rows.append([("⬅️ Menyu", "m:menu")])
        self._screen(chat, "\n".join(lines), rows)

    def _model_prov(self, prov, chat):
        a = self.app
        ms = adm.models(a.cfg, prov)
        lines = [f"🤖 <b>{prov}</b> modellari (yuqoridagisi birinchi ishlatiladi)", ""]
        rows = []
        for i, m in enumerate(ms, 1):
            dead = (prov, m) in a.llm.bad_models
            lines.append(f"{i}. <code>{esc(m)}</code>" + (" ❌ ishlamadi" if dead else ""))
            rows.append([(f"🥇 {i}", f"ui:mu:{prov}:{i}"), (f"✏️ {i}", f"ui:me:{prov}:{i}"),
                         (f"🗑 {i}", f"ui:md:{prov}:{i}")])
        if not ms:
            lines.append("(model yo'q)")
        lines.append("\n🥇 asosiy qilish · ✏️ nomini o'zgartirish · 🗑 o'chirish")
        rows.append([("➕ Qo'shish", f"ui:ma:{prov}")] + ([("🔎 Internetdan topish", f"mdl:find:{prov}")]
                                                           if prov != "pollinations" else []))
        rows.append([("🧪 Sinash", f"ui:kt:{prov}"), ("⬅️ Orqaga", "ui:models")])
        self._screen(chat, "\n".join(lines), rows)

    def c_keys(self, arg, chat):
        a = self.app
        lines = ["🔑 <b>API kalitlari</b>", ""]
        rows = []
        for prov in ("gemini", "groq", "openrouter"):
            ks = adm.keys(a.cfg, prov)
            lines.append(f"• <b>{prov}</b>: " + (f"{len(ks)} ta" if ks else "yo'q"))
            rows.append([(f"🔑 {prov} ({len(ks)})", f"ui:kp:{prov}")])
        lines.append("\nKalit yuborgan xabaringiz chatdan avtomatik o'chiriladi.")
        rows.append([("🧪 Hammasini sinash", "m:testkeys"), ("🤖 Modellar", "ui:models")])
        rows.append([("⬅️ Menyu", "m:menu")])
        self._screen(chat, "\n".join(lines), rows)

    _KEY_LINKS = {"gemini": "aistudio.google.com/apikey", "groq": "console.groq.com/keys",
                  "openrouter": "openrouter.ai/keys"}

    def _key_prov(self, prov, chat):
        ks = adm.keys(self.app.cfg, prov)
        lines = [f"🔑 <b>{prov}</b> kalitlari", ""]
        rows = []
        for i, k in enumerate(ks, 1):
            lines.append(f"{i}. <code>{adm.mask(k)}</code>")
            rows.append([(f"✏️ {i} almashtirish", f"ui:ke:{prov}:{i}"), (f"🗑 {i}", f"ui:kd:{prov}:{i}")])
        if not ks:
            lines.append("(kalit yo'q)")
        lines.append(f"\nOlish: {self._KEY_LINKS.get(prov, '')}")
        rows.append([("➕ Kalit qo'shish", f"ui:ka:{prov}"), ("🧪 Sinash", f"ui:kt:{prov}")])
        rows.append([("⬅️ Orqaga", "ui:keys")])
        self._screen(chat, "\n".join(lines), rows)

    def _ask(self, chat, kind, data, text):
        self.pending = (kind, data)
        self._screen(chat, text + "\n\nHozir shu chatga yozib yuboring.",
                     [[("✖️ Bekor qilish", "ui:cancel")]])

    def ui_callback(self, val, chat):
        a = self.app
        p = val.split(":")
        act = p[0]
        prov = adm.norm(p[1]) if len(p) > 1 else None
        idx = int(p[2]) if len(p) > 2 and p[2].isdigit() else 0
        self.pending = None
        if act == "models":
            return self.c_models("", chat)
        if act == "keys":
            return self.c_keys("", chat)
        if act == "cancel":
            return self.c_models("", chat)
        if act == "ord" and prov:
            names = [prov] + [x for x in a.cfg.list("LLM_ORDER") if x != prov]
            adm.set_order(a.cfg, names)
            a.llm.reset_health()
            return self.c_models("", chat)
        if not prov:
            return None
        if act == "mp":
            return self._model_prov(prov, chat)
        if act == "kp":
            return self._key_prov(prov, chat)
        if act == "mu":
            adm.use_model(a.cfg, prov, str(idx))
            a.llm.reset_health()
            return self._model_prov(prov, chat)
        if act == "md":
            ok, msg = adm.del_model(a.cfg, prov, str(idx))
            a.llm.reset_health()
            if not ok:
                self.tg.send("⚠️ " + msg, chat=chat)
            return self._model_prov(prov, chat)
        if act == "ma":
            return self._ask(chat, "addmodel", prov, f"➕ <b>{prov}</b>: yangi model nomini yozing (masalan <code>openai/gpt-oss-120b</code>)")
        if act == "me":
            cur = (adm.models(a.cfg, prov) or [""])[idx - 1] if idx else ""
            return self._ask(chat, "editmodel", (prov, idx), f"✏️ <b>{prov}</b> #{idx}: <code>{esc(cur)}</code> o'rniga yangi nom yozing")
        if act == "ka":
            return self._ask(chat, "addkey", prov, f"➕ <b>{prov}</b>: yangi API kalitni yuboring ({self._KEY_LINKS.get(prov, '')})")
        if act == "ke":
            return self._ask(chat, "editkey", (prov, idx), f"✏️ <b>{prov}</b> #{idx}: yangi API kalitni yuboring")
        if act == "kd":
            return self._screen(chat, f"🗑 <b>{prov}</b> #{idx} kalitni o'chirishni tasdiqlaysizmi?",
                                [[("✅ Ha, o'chirish", f"ui:kdok:{prov}:{idx}"), ("✖️ Yo'q", f"ui:kp:{prov}")]])
        if act == "kdok":
            ok, msg = adm.del_key(a.cfg, prov, idx)
            a.llm.reset_health()
            self.tg.send(("✅ " if ok else "⚠️ ") + esc(msg), chat=chat)
            return self._key_prov(prov, chat)
        if act == "kt":
            return self.c_testkeys(prov, chat)
        return None

    def handle_pending(self, text, msg, chat):
        """Tugma orqali so'ralgan matnni (kalit/model nomi) qabul qiladi. True: qabul qilindi."""
        pend = getattr(self, "pending", None)
        if not pend:
            return False
        self.pending = None
        kind, data = pend
        a = self.app
        text = text.strip()
        if kind == "resched":
            self.sc_pending(data, text, chat)
            return True
        if kind.startswith("dc_"):
            self.dc_pending(kind, data, text, chat)
            return True
        if kind.startswith("post_"):
            self.post_pending(kind, text, chat)
            return True
        if kind.startswith("st_"):
            self.st_pending(kind, data, text, msg, chat)
            return True
        if kind in ("addkey", "editkey"):  # kalit chatda qolmasin
            try:
                self.tg.api("deleteMessage", {"chat_id": chat, "message_id": msg["message_id"]}, retries=1)
            except Exception:  # noqa: BLE001
                pass
        if kind == "addkey":
            ok, res = adm.add_key(a.cfg, data, text)
            prov = data
        elif kind == "editkey":
            prov = data[0]
            ok, res = adm.edit_key(a.cfg, prov, data[1], text)
        elif kind == "addmodel":
            prov = data
            ok, res = adm.add_model(a.cfg, prov, text)
        elif kind == "editmodel":
            prov = data[0]
            ok, res = adm.edit_model(a.cfg, prov, str(data[1]), text)
        else:
            return False
        if ok:
            a.llm.reset_health()
        self.tg.send(("✅ " if ok else "⚠️ ") + (res if kind.endswith("model") else esc(res)), chat=chat)
        self._cb_msg = None
        if kind.endswith("key"):
            self._key_prov(prov, chat)
        else:
            self._model_prov(prov, chat)
        return True
