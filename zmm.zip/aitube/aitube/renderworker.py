"""Alohida jarayonda video qismlarini chizuvchi ishchi (GIL cheklovini chetlab o'tish uchun).

Bosh dastur bilan stdin/stdout orqali ishlaydi (multiprocessing/sem_open kerak emas: Termux/Android da ham ishlaydi).
Protokol: [4 bayt uzunlik][pickle]. So'rov: spec (dict). Javob: ("tick", n)* so'ng ("ok", yo'l) yoki ("err", matn)."""
from __future__ import annotations

import os
import pickle
import struct
import sys
from pathlib import Path


def _read_exact(f, n):
    buf = b""
    while len(buf) < n:
        chunk = f.read(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def run_job(spec, state, send):
    from .config import Config
    from .render import Renderer
    from .stream import StreamCfg
    from .video import VideoBuilder
    key = spec["rkey"]
    if state.get("key") != key:
        c = Config(root=spec["cfg"]["root"], env_file=spec["cfg"]["env_file"])
        c.overrides.update(spec["cfg"]["overrides"])
        cfg = StreamCfg(c, spec["cfg"]["over"])
        rd = Renderer(cfg, **spec["rargs"])
        rd.show_progress = bool(spec.get("show_progress", False))     # stream: yo'q; oddiy video: progress chizig'i bor
        state.clear()
        state.update(key=key, rd=rd, vb=VideoBuilder(cfg, None))
    rd, vb = state["rd"], state["vb"]
    rd.t_off = spec["t_off"]
    cf = spec["cancel_file"]
    vb.cancel = (lambda: os.path.exists(cf)) if cf else None
    vb.render_range(spec["scenes"], rd, spec["fps"], spec["total_f"], Path(spec["out"]), spec["f0"], spec["f1"],
                    spec["codec"], prev_content=spec.get("prev"), threads=spec.get("threads", 0), step=spec.get("step", 1),
                    tick=lambda n: send(("tick", n)))
    return spec["out"]


def main():
    out = sys.stdout.buffer
    inp = sys.stdin.buffer
    sys.stdout = sys.stderr            # tasodifiy print protokolni buzmasin

    def send(obj):
        b = pickle.dumps(obj, protocol=4)
        out.write(struct.pack(">I", len(b)))
        out.write(b)
        out.flush()

    state: dict = {}
    send(("ready", os.getpid()))
    while True:
        hdr = _read_exact(inp, 4)
        if hdr is None:
            return
        data = _read_exact(inp, struct.unpack(">I", hdr)[0])
        if data is None:
            return
        try:
            spec = pickle.loads(data)
            send(("ok", run_job(spec, state, send)))
        except BaseException as e:  # noqa: BLE001
            send(("err", f"{type(e).__name__}: {e}"))


if __name__ == "__main__":
    main()
