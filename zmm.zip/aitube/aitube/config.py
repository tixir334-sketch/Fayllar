"""Sozlamalar: .env fayli + muhit o'zgaruvchilari + standart qiymatlar."""
from __future__ import annotations

import os
import threading
from pathlib import Path

ROOT = Path(os.environ.get("AITUBE_HOME") or Path(__file__).resolve().parent.parent).resolve()

DEFAULTS = {
    # --- Telegram ---
    "TELEGRAM_BOT_TOKEN": "",
    "ADMIN_ID": "",
    # --- Kanal ---
    "CHANNEL_NAME": "Kod va Tizimlar",
    "CHANNEL_NICHE": ("dasturlash (Python, JavaScript, Go, Bash), tizimlar (Linux, tarmoq, "
                      "ma'lumotlar bazasi, arxitektura, DevOps), AI vositalari, mini-loyihalar, "
                      "texnologiya tarixi va turli xil qiziqarli texnik mavzular"),
    "LANGUAGE": "uz",
    "SEASON_LENGTH": "8",
    "EPISODE_MINUTES": "5",
    "VIDEO_FORMAT": "landscape",     # landscape | shorts
    "VIDEO_RES": "1080",             # 1080 = Full HD (1920x1080 / 1080x1920) | 720
    "VIDEO_FPS": "30",
    "VIDEO_MOTION": "1",             # 0: statik fon | 1: harakatlanuvchi fon (fps/2 kadr/s) | 2: silliq (har kadr = fps)
    "VIDEO_ANIM_FPS": "0",           # fon animatsiyasi kadr tezligi; 0 = avto (fps ga bog'liq: silliq=fps, oddiy=fps/2)
    "VIDEO_BITRATE": "0",            # kbit/s (GPU kodlash uchun chegara); 0 = avto (1080p ~9000, 720p ~5000)
    "VIDEO_PARALLEL": "1",           # video qismlarga bo'lib PARALLEL jarayonlarda chiziladi (stream kabi); to'lqin/musiqa yoqilgan bo'lsa ketma-ket
    "VIDEO_PROCS": "0",              # parallel render jarayonlari soni; 0 = avto (yadrolar soni, eng ko'pi 8)
    "VIDEO_PART_SEC": "20",          # parallel qism uzunligi (soniya)
    "VIDEO_AI_RACE": "2",            # ssenariy uchun bir vaqtda nechta AI poygalashadi (0 = ketma-ket)
    "VIDEO_WAVE": "1",               # ovoz to'lqini (ekvalayzer) animatsiyasi
    "VIDEO_CRF": "23",
    # --- Kodlash (GPU/CPU) ---
    "ENCODER": "auto",               # auto | nvenc (NVIDIA) | qsv (Intel) | amf (AMD) | videotoolbox (Apple) | cpu
    "ENC_SESSIONS": "0",             # bir vaqtda GPU kodlash sessiyalari; 0 = avto (o'lchab aniqlanadi)
    "BG_STYLE": "auto",
    "AI_IMAGES": "0",                # AI rasm yaratish BUTUNLAY o'chirilgan (kodda qat'iy: .env qiymati ahamiyatsiz)
    "IMG_ORDER": "pollinations,together,huggingface",
    "IMG_STYLE": "auto",
    "POLLINATIONS_IMG_BASE": "https://image.pollinations.ai",
    "TOGETHER_API_KEYS": "",
    "HF_API_KEYS": "",
    "SFX": "1",
    "SFX_VOLUME": "0.5",
    "MUSIC": "1",
    "MUSIC_VOLUME": "0.12",
    # --- LLM ---
    "LLM_ORDER": "gemini,groq,openrouter,pollinations",
    "GEMINI_API_KEYS": "",
    # Modellar 2026-10 holatiga ko'ra (rasmiy hujjatlardan). Eskirsa, LLM_AUTO_MODELS avtomatik yangisini topadi.
    "GEMINI_MODELS": "gemini-3.8-flash,gemini-3.6-flash,gemini-3.5-flash-lite,gemini-2.5-flash",
    "GROQ_API_KEYS": "",
    "GROQ_MODELS": "openai/gpt-oss-120b,qwen/qwen3.8-27b,openai/gpt-oss-20b",
    "OPENROUTER_API_KEYS": "",
    "OPENROUTER_MODELS": "openrouter/free",
    "PRON_LLM": "1",                  # ingliz so'zlar talaffuzini LLM aniqlasin (bazaga saqlanadi)
    "PRON_WAIT": "10",                # stream: talaffuz lug'ati uchun ovozdan oldin eng ko'pi bilan shuncha soniya kutiladi
    "LLM_AUTO_MODELS": "1",           # barcha modellar o'lik bo'lsa provayderdan yangisini o'zi topadi
    "POLLINATIONS_MODELS": "openai,mistral",
    "LLM_TEMPERATURE": "0.8",
    "LLM_PASSES": "2",                # hamma kalit/model xato bersa, nechta to'liq aylanish (kutishsiz almashtirish)
    "LLM_WAIT": "25",                 # hamma kalit 'dam olayotgan' bo'lsa eng ko'pi bilan shuncha soniya kutiladi
    # --- Ovoz ---
    "TTS_ORDER": "edge,google",
    "TTS_VOICE": "uz-UZ-MadinaNeural",
    "TTS_LANG": "uz",
    "TTS_RATE": "+0%",
    "TTS_PITCH": "+0Hz",
    "TTS_ALLOW_SILENT": "0",
    # --- Jadval ---
    "UPLOAD_TIMES": "18:00",
    "TZ_OFFSET": "5",
    "DIGEST_TIME": "21:30",
    "BUFFER_AHEAD": "1",
    "AUTO_UPLOAD": "1",
    "YT_SCHEDULE": "1",
    "SCHEDULE_AHEAD": "3",
    "APPROVAL_MODE": "0",
    "PAUSED": "0",
    "STATS_EVERY_HOURS": "6",
    "KEEP_LOCAL_VIDEOS": "3",
    "AUTO_CLEAN": "1",               # oxirgi yaratilgan videodan boshqasini (yuklashni kutayotganlardan tashqari) o'chiradi
    "SEND_VIDEO_TO_ADMIN": "1",
    # --- YouTube ---
    "YT_CLIENT_ID": "",
    "YT_CLIENT_SECRET": "",
    "YT_PRIVACY": "public",
    "YT_CATEGORY": "28",
    "YT_SYNTHETIC": "1",
    "YT_PLAYLIST_PER_SEASON": "1",
    "YT_AUTH_MODE": "auto",   # auto | device | loopback
    # --- Test uchun manzillarni almashtirish ---
    "TG_API_BASE": "https://api.telegram.org",
    "YT_API_BASE": "https://www.googleapis.com",
    "OAUTH_BASE": "https://oauth2.googleapis.com",
    "GEMINI_BASE": "https://generativelanguage.googleapis.com",
    "GROQ_BASE": "https://api.groq.com/openai/v1",
    "OPENROUTER_BASE": "https://openrouter.ai/api/v1",
    "POLLINATIONS_BASE": "https://text.pollinations.ai/openai",
    "GTTS_BASE": "https://translate.google.com/translate_tts",
    # --- Jonli translatsiya (stream) ---
    "STREAM_RES": "720",             # 480 | 720 | 1080
    "STREAM_FPS": "25",              # 44100 ga bo'linadigan: 10,12,15,20,25,30,50,60
    "STREAM_FORMAT": "landscape",    # landscape | shorts
    "STREAM_BITRATE": "0",           # kbit/s (video); 0 = avto: o'lcham va FPS ga qarab (480p 1500 · 720p 3200 · 1080p 5500)
    "STREAM_SEG_SEC": "600",         # bitta bo'lak davomiyligi (soniya)
    "STREAM_WARN_SEC": "600",        # shuncha vaqt qolganda "Efir tugasinmi?" deb so'raladi
    "STREAM_ASK_TIMEOUT": "180",     # javob kutish (soniya); o'tsa - to'xtat
    "STREAM_DROP_DELAY": "3",        # bo'lak tugagach RAMdan o'chirilishidan oldin kutish (soniya)
    "STREAM_FAREWELL_SEC": "45",     # xayrlashuv bo'lagi davomiyligi
    "STREAM_MIDCUT": "1",            # bo'lak gap o'rtasida uzilib, keyingisi davom etadi
    "STREAM_MUSIC": "0",             # fon musiqasi (bo'laklar chegarasida uzilishi mumkin)
    "STREAM_MODE": "api",            # api (YouTube Live API) | manual (RTMP kalit qo'lda)
    "STREAM_PRIVACY": "public",
    "STREAM_RTMP_URL": "rtmp://a.rtmp.youtube.com/live2",
    "STREAM_KEY": "",
    "STREAM_TEST": "",               # sinov: RTMP o'rniga shu faylga yozadi
    "STREAM_PREROLL": "10",          # efirdan OLDIN tayyorlanadigan bo'laklar soni
    "STREAM_BUFFER": "16",           # tayyor bo'laklar zaxirasi (diskda); kamaysa yangisi tayyorlanadi
    "STREAM_FIRST_SEC": "0",          # birinchi AI bo'lak uzunligi (soniya); 0 = oddiy uzunlik (qisqartirilmaydi)
    "STREAM_WORKERS": "0",           # parallel ishchilar (0 = avto: barcha yadro, 10 tagacha)
    "STREAM_PART_SEC": "30",         # bo'lak shuncha soniyalik qismlarga bo'linib parallel chiziladi
    "STREAM_PREROLL_WAIT": "0",      # preroll uchun kutishning eng ko'pi (soniya); 0 = CHEKSIZ kutish (efir taymaut bilan o'zi ochilmaydi; «Hozir boshlash» bor)
    "STREAM_BUFFER_CAP": "0",        # tayyor bo'laklar zaxirasi chegarasi (soni); 0 = CHEKSIZ (faqat disk bo'sh joyi himoyasi)
    "STREAM_ASK_END": "0",           # 1 = kontent tugayotganda admindan «Efir tugasinmi?» deb so'raladi; 0 = so'ralmaydi, AI bo'laklar cheksiz davom etadi
    "STREAM_BG_FPS": "0",            # fon animatsiyasi yangilanish tezligi (kadr/s); 0 = avto: STREAM_FPS ga teng (silliq)
    "STREAM_AI_RACE": "5",           # ssenariy uchun bir vaqtda nechta AI poygalashadi (0 = ketma-ket)
    "STREAM_BATCH": "1",             # 1 = bo'laklar ketma-ket (har biri 5 ta AI poygasi); >1 = shuncha bo'lak bir vaqtda (partiya)
    "STREAM_SPLIT": "0",             # 1 = uzun bo'lak ssenariysi qismlarga bo'linib parallel yoziladi
    "STREAM_AUTO": "0",              # 1 = qurilma sekin bo'lsa sifat (o'lcham/FPS) efir boshida avtomatik tushiriladi; 0 = belgilangan sifat O'ZGARMAYDI
    "STREAM_TARGET_SPEED": "2.0",    # maqsad: real vaqtdan kamida shuncha marta tez tayyorlash
    "STREAM_PROCS": "0",             # render jarayonlari (haqiqiy parallel): 0 = avto (yadro soni, 8 gacha), -1 = o'chiq (oqimlar)
    "STREAM_CRF": "20",              # sifat (kamroq = yaxshiroq; 18-23)
    "STREAM_PRESET": "superfast",    # x264 tezligi: ultrafast|superfast|veryfast|faster|fast
    "STREAM_GEN_SEGS": "4",          # yangi 'AI bo'lak' elementi uchun standart bo'laklar soni (0 = cheksiz)
    "HIDE_STATS": "1",               # videolarda ochiq statistika (yoqtirishlar) yopiq; har safar tekshiriladi
    "THROTTLE_SEC": "0.4",           # bir chatga xabar yuborish/tahrirlash orasidagi eng kam vaqt
    "TG_RATE": "25",                 # botning umumiy xabar/tahrir tezligi (soniyasiga); Telegram ~30 gacha ruxsat beradi
    "POST_MAX_MB": "20",             # /post: Telegram orqali qabul qilinadigan video hajmi (bot API chegarasi 20 MB)
    # --- Stream tizimi (nazorat, profillar, qo'shimcha manzillar) ---
    "STREAM_PROFILE": "custom",      # custom | tejamkor | standart | sifatli | maksimal  (/stream profil)
    "STREAM_EXTRA_RTMP": "",         # qo'shimcha efir manzillari (vergul bilan): rtmp://host/app/kalit — bir vaqtda hammasiga uzatiladi
    "STREAM_WATCHDOG": "1",          # nazoratchi: qotib qolgan jarayon, past tezlik, disk, GPU holatini kuzatadi va xabar beradi
    "STREAM_STALL_SEC": "300",       # tayyorlov shuncha vaqt hech qanday kadr chiqarmasa 'qotdi' deb hisoblanadi
    "STREAM_MIN_DISK_MB": "2048",    # bo'sh joy shundan kam bo'lsa ogohlantiradi va yangi bo'laklar tayyorlashni vaqtincha to'xtatadi
    "STREAM_AT": "",                 # rejalashtirilgan boshlanish (HH:MM, TZ_OFFSET bo'yicha); bo'sh = qo'lda
}

# Telegram /set orqali o'zgartirish mumkin bo'lgan (maxfiy bo'lmagan) kalitlar
SAFE_KEYS = [
    "CHANNEL_NAME", "CHANNEL_NICHE", "LANGUAGE", "SEASON_LENGTH", "EPISODE_MINUTES",
    "VIDEO_FORMAT", "VIDEO_RES", "VIDEO_FPS", "VIDEO_CRF", "VIDEO_MOTION", "VIDEO_WAVE", "MUSIC", "MUSIC_VOLUME", "BG_STYLE", "SFX", "SFX_VOLUME", "TTS_VOICE", "TTS_RATE", "TTS_PITCH", "UPLOAD_TIMES",
    "TZ_OFFSET", "DIGEST_TIME", "BUFFER_AHEAD", "AUTO_UPLOAD", "YT_SCHEDULE", "SCHEDULE_AHEAD", "APPROVAL_MODE",
    "YT_PRIVACY", "YT_CATEGORY", "YT_SYNTHETIC", "SEND_VIDEO_TO_ADMIN",
    "KEEP_LOCAL_VIDEOS", "STATS_EVERY_HOURS", "LLM_ORDER", "TTS_ORDER", "LLM_AUTO_MODELS", "AUTO_CLEAN",
    "STREAM_RES", "STREAM_FPS", "STREAM_FORMAT", "STREAM_BITRATE", "STREAM_SEG_SEC", "STREAM_WARN_SEC", "STREAM_ASK_TIMEOUT",
    "STREAM_DROP_DELAY", "STREAM_FAREWELL_SEC", "STREAM_MIDCUT", "STREAM_MUSIC", "STREAM_MODE", "STREAM_PRIVACY", "STREAM_RTMP_URL",
    "STREAM_GEN_SEGS", "STREAM_PREROLL", "STREAM_FIRST_SEC", "STREAM_BUFFER", "STREAM_WORKERS", "STREAM_PART_SEC", "STREAM_PRESET", "STREAM_CRF", "STREAM_PROCS", "STREAM_AUTO", "STREAM_TARGET_SPEED", "STREAM_BATCH", "STREAM_SPLIT", "STREAM_AI_RACE", "STREAM_PREROLL_WAIT", "STREAM_BG_FPS", "HIDE_STATS",
    "ENCODER", "ENC_SESSIONS", "VIDEO_PARALLEL", "VIDEO_PROCS", "VIDEO_PART_SEC", "VIDEO_BITRATE", "VIDEO_ANIM_FPS", "VIDEO_AI_RACE", "STREAM_PROFILE", "STREAM_EXTRA_RTMP",
    "STREAM_WATCHDOG", "STREAM_STALL_SEC", "STREAM_MIN_DISK_MB", "STREAM_AT", "STREAM_BUFFER_CAP", "STREAM_ASK_END", "LLM_PASSES", "LLM_WAIT",
]
SECRET_KEYS = {"TELEGRAM_BOT_TOKEN", "GEMINI_API_KEYS", "GROQ_API_KEYS",
               "OPENROUTER_API_KEYS", "YT_CLIENT_SECRET", "TOGETHER_API_KEYS", "HF_API_KEYS", "STREAM_KEY"}


def parse_env(path: Path) -> dict:
    data = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            data[k] = v
    return data


class Config:
    def __init__(self, root: Path | str | None = None, env_file: Path | str | None = None,
                 data: Path | str | None = None):
        self.root = Path(root or ROOT).resolve()
        self.env_file = Path(env_file) if env_file else self.root / ".env"
        self.overrides: dict = {}
        self._file: dict = {}
        self._lock = threading.RLock()
        self.reload()
        self.data = Path(data) if data else Path(os.environ.get("AITUBE_DATA") or (self.root / "data"))
        self.dirs = {n: self.data / n for n in ("work", "out", "cache", "logs", "tokens")}
        for d in [self.data, *self.dirs.values()]:
            d.mkdir(parents=True, exist_ok=True)
        self.fonts_dir = self.root / "assets" / "fonts"
        self.db_path = self.data / "aitube.db"

    # ------------------------------------------------------------------ o'qish
    def reload(self):
        with self._lock:
            self._file = parse_env(self.env_file)

    def get(self, key: str, default: str | None = None) -> str:
        with self._lock:
            if key in self.overrides:
                return str(self.overrides[key])
            v = os.environ.get(key)
            if v not in (None, ""):
                return v
            v = self._file.get(key)
            if v not in (None, ""):
                return v
        if default is not None:
            return default
        return DEFAULTS.get(key, "")

    def int(self, key: str, default: int | None = None) -> int:
        try:
            return int(float(self.get(key)))
        except (TypeError, ValueError):
            return int(default if default is not None else float(DEFAULTS.get(key, "0") or 0))

    def float(self, key: str, default: float | None = None) -> float:
        try:
            return float(self.get(key))
        except (TypeError, ValueError):
            return float(default if default is not None else float(DEFAULTS.get(key, "0") or 0))

    def bool(self, key: str) -> bool:
        return self.get(key).strip().lower() in ("1", "true", "yes", "on", "ha")

    def list(self, key: str) -> list:
        return [x.strip() for x in self.get(key).split(",") if x.strip()]

    @property
    def admin_id(self) -> int | None:
        v = self.get("ADMIN_ID").strip()
        try:
            return int(v)
        except ValueError:
            return None

    @property
    def size(self) -> tuple:
        """Haqiqiy video o'lchami. VIDEO_RES: 1080 (standart, Full HD) yoki 720."""
        short = self.get("VIDEO_FORMAT").lower().startswith("short")
        res = self.int("VIDEO_RES")
        if res <= 480:
            return (480, 854) if short else (854, 480)
        hi = res >= 1080
        if short:
            return (1080, 1920) if hi else (720, 1280)
        return (1920, 1080) if hi else (1280, 720)

    @property
    def base_size(self) -> tuple:
        """Maket (mantiqiy) o'lchami; render shu birlikda yozilib, haqiqiy o'lchamga ko'paytiriladi."""
        return (720, 1280) if self.get("VIDEO_FORMAT").lower().startswith("short") else (1280, 720)

    # ------------------------------------------------------------------ yozish
    def set(self, key: str, value: str):
        """Qiymatni .env ga yozadi (qolgan qatorlarni saqlab)."""
        value = str(value).replace("\n", " ").strip()
        with self._lock:
            lines = []
            found = False
            if self.env_file.exists():
                for line in self.env_file.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.strip().startswith(key + "=") or line.strip().startswith(key + " ="):
                        lines.append(f"{key}={value}")
                        found = True
                    else:
                        lines.append(line)
            if not found:
                lines.append(f"{key}={value}")
            tmp = self.env_file.with_suffix(".tmp")
            tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, self.env_file)
            self._file[key] = value
            self.overrides.pop(key, None)

    def masked(self, key: str) -> str:
        v = self.get(key)
        if key in SECRET_KEYS and v:
            return v[:4] + "…" + v[-3:] if len(v) > 10 else "***"
        return v
