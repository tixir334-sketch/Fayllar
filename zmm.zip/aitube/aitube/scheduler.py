"""Ishlar navbati (bitta og'ir ish) va jadval: yuklash vaqtlari, bufer, statistika, kunlik hisobot."""
from __future__ import annotations

import queue
import threading
import time
from datetime import datetime, timedelta

from . import health, schedule as sched
from .util import esc, fmt_dur, local_now, log, tb_short


class JobRunner(threading.Thread):
    def __init__(self, notifier):
        super().__init__(daemon=True, name="jobs")
        self.n = notifier
        self.waiting = None
        self.q: queue.Queue = queue.Queue()
        self.names: set = set()
        self.light: set = set()
        self.current = None
        self.started = 0.0
        self.lock = threading.Lock()

    def submit(self, name, fn, *args) -> bool:
        with self.lock:
            if name in self.names:
                return False
            self.names.add(name)
        self.q.put((name, fn, args))
        return True

    def submit_light(self, name, fn, *args) -> bool:
        """Yengil ish: alohida oqimda, asosiy (og'ir) navbatga xalaqit bermaydi va uni kutmaydi."""
        with self.lock:
            if name in self.light:
                return False
            self.light.add(name)

        def wrap():
            try:
                fn(*args)
            except Exception as e:
                log.error("Yengil ish '%s' xatosi: %s\n%s", name, e, tb_short(1500))
                self.n.error(f"Ish xatosi: {name}", f"{type(e).__name__}: {e}")
            finally:
                with self.lock:
                    self.light.discard(name)

        threading.Thread(target=wrap, daemon=True, name=f"light-{name}").start()
        return True

    def stop(self):
        self.q.put(None)

    def idle(self) -> bool:
        with self.lock:
            return self.current is None and self.waiting is None and self.q.empty() and not self.light

    def busy(self) -> bool:
        return self.current is not None or self.waiting is not None or not self.q.empty()

    def describe(self) -> str:
        if self.waiting:
            return f"{self.waiting} (boshqa ish tugashini kutmoqda)"
        if self.current:
            return f"{self.current} ({fmt_dur(time.time() - self.started)} dan beri)"
        return f"navbatda {self.q.qsize()} ta" if not self.q.empty() else "bo'sh"

    def run(self):
        while True:
            item = self.q.get()
            if item is None:                  # to'xtatish belgisi (ish maydoni xotiradan chiqarilmoqda)
                return
            name, fn, args = item
            self.current, self.started = name, time.time()
            try:
                fn(*args)
            except Exception as e:
                log.error("Ish '%s' xatosi: %s\n%s", name, e, tb_short(2500))
                self.n.error(f"Ish xatosi: {name}", f"{type(e).__name__}: {e}\n{tb_short(900)}")
            finally:
                self.current = None
                with self.lock:
                    self.names.discard(name)


def parse_times(s: str) -> list:
    out = []
    for p in str(s).split(","):
        p = p.strip()
        try:
            h, m = p.split(":")
            h, m = int(h), int(m)
            if 0 <= h < 24 and 0 <= m < 60:
                out.append((h, m))
        except ValueError:
            continue
    return sorted(set(out))


def next_slot(cfg):
    now = local_now(cfg)
    times = parse_times(cfg.get("UPLOAD_TIMES"))
    if not times:
        return None
    for day in (0, 1):
        for h, m in times:
            dt = (now + timedelta(days=day)).replace(hour=h, minute=m, second=0, microsecond=0)
            if dt > now:
                return dt
    return None


class Scheduler(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True, name="scheduler")
        self.app = app
        self.stop_flag = threading.Event()

    def run(self):
        time.sleep(5)
        while not self.stop_flag.is_set():
            try:
                self.tick()
            except Exception as e:
                log.error("Scheduler xatosi: %s\n%s", e, tb_short(1500))
            self.stop_flag.wait(20)

    # ------------------------------------------------------------------
    def tick(self):
        a = self.app
        cfg, db, jobs = a.cfg, a.db, a.jobs
        now = local_now(cfg)
        today = now.strftime("%Y-%m-%d")

        sched_mode = sched.active(cfg)
        # 0) rejalashtirish rejimi: tayyor bo'lishi bilan yuklab, keyingi bo'sh vaqtga qo'yadi
        if sched_mode and not cfg.bool("PAUSED"):
            self._auto_schedule()
        if sched_mode or db.scheduled():
            if time.time() - float(db.kv_get("sched_rc_last", "0") or 0) > 120:
                db.kv_set("sched_rc_last", str(time.time()))
                jobs.submit("sched-reconcile", lambda: sched.reconcile(a))

        # 1) yuklash vaqtlari (o'tkazib yuborilgan bo'lsa ham kun ichida bajariladi)
        if not cfg.bool("PAUSED") and not sched_mode:
            for h, m in parse_times(cfg.get("UPLOAD_TIMES")):
                slot_dt = now.replace(hour=h, minute=m, second=0, microsecond=0)
                key = f"slot:{today}:{h:02d}:{m:02d}"
                if now >= slot_dt and not db.kv_get(key):
                    if float(db.kv_get("slot_retry_at", "0") or 0) > time.time():
                        continue
                    jobs.submit(f"slot-{h:02d}:{m:02d}", self._slot, key)
                    break

        # 2) bufer: tayyor epizodlar yetarli bo'lmasa, bo'sh vaqtda oldindan yasash
        if (not cfg.bool("PAUSED") and not jobs.busy() and not a.pipeline.halted()
                and float(db.kv_get("buffer_next_try", "0") or 0) < time.time()):
            need = max(0, cfg.int("BUFFER_AHEAD"))
            if len(a.pipeline.ready_episodes()) < need:
                db.kv_set("buffer_next_try", str(time.time() + 1200))
                jobs.submit("buffer", a.pipeline.produce_next)

        # 3) statistika
        every = max(1, cfg.int("STATS_EVERY_HOURS")) * 3600
        last = float(db.kv_get("stats_last", "0") or 0)
        if a.yt.authorized() and time.time() - last > every and not jobs.busy():
            db.kv_set("stats_last", str(int(time.time())))
            jobs.submit("stats", self._stats)

        # 4) kunlik hisobot
        dh = parse_times(cfg.get("DIGEST_TIME"))
        if dh:
            h, m = dh[0]
            dkey = f"digest:{today}"
            if now >= now.replace(hour=h, minute=m, second=0, microsecond=0) and not db.kv_get(dkey):
                db.kv_set(dkey, "1")
                jobs.submit("digest", self._digest)

        # 5) salomatlik (faqat holat o'zgarganda xabar beradi)
        hl = float(db.kv_get("health_last", "0") or 0)
        if time.time() - hl > 1800:       # tizim salomatligi (kalitlar, ffmpeg, kodlash...)
            db.kv_set("health_last", str(int(time.time())))
            items = health.check(a)
            sig = health.signature(items)
            if sig != (db.kv_get("health_sig") or ""):
                db.kv_set("health_sig", sig)
                if sig:
                    a.n.say(health.format_report(items))
                elif hl:
                    a.n.say("✅ Salomatlik muammolari bartaraf etildi.")

    # ------------------------------------------------------------------
    def _auto_schedule(self):
        """Rejalashtirilgan videolar SCHEDULE_AHEAD dan kam bo'lsa: tayyorini yuklaydi, bo'lmasa yangisini yasaydi."""
        a = self.app
        cfg, db, jobs = a.cfg, a.db, a.jobs
        if jobs.busy() or a.pipeline.halted() or float(db.kv_get("auto_sched_next", "0") or 0) > time.time():
            return
        ahead = max(1, cfg.int("SCHEDULE_AHEAD"))
        waiting = len(db.scheduled())
        if waiting >= ahead:
            return
        ready = a.pipeline.ready_episodes()
        if ready:
            if cfg.bool("APPROVAL_MODE") or not cfg.bool("AUTO_UPLOAD"):
                return                      # admin tasdiqlaydi (tugma yoki /upload)
            why = a.pipeline.can_upload()
            if why:
                db.kv_set("auto_sched_next", str(time.time() + 900))
                return
            db.kv_set("auto_sched_next", str(time.time() + 120))
            jobs.submit("auto-sched-upload", a.pipeline.upload_next_ready)
        else:
            if not a.yt.authorized():
                return
            db.kv_set("auto_sched_next", str(time.time() + 600))
            jobs.submit("auto-sched-make", a.pipeline.produce_next)

    def _slot(self, key):
        a = self.app
        tries_key = f"{key}:tries"
        ok = a.pipeline.run_slot()
        if ok:
            a.db.kv_set(key, "1")
            a.db.kv_set("slot_retry_at", "0")
        else:
            n = int(a.db.kv_get(tries_key, "0") or 0) + 1
            a.db.kv_set(tries_key, str(n))
            if n >= 6:
                a.db.kv_set(key, "failed")
                a.n.say(f"⛔ Jadval bajarilmadi (6 urinish): {esc(key)}. Keyingi vaqtni kuting yoki /make, /upload.")
            else:
                a.db.kv_set("slot_retry_at", str(time.time() + 900))
                a.n.say(f"🔁 Jadval bajarilmadi, 15 daqiqadan keyin qayta uriniladi ({n}/6).")

    def _stats(self):
        a = self.app
        a.stats.refresh()
        a.stats.check_comments(notify=True)

    def _digest(self):
        a = self.app
        a.stats.refresh()
        a.n.say(a.stats.digest())
