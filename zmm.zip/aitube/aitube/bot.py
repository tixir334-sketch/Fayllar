"""Telegram bot: faqat admin uchun boshqaruv paneli (long polling)."""
from __future__ import annotations

import os
import shutil
import threading
import time
from pathlib import Path

from . import chain, health, planner, speak
from .config import SAFE_KEYS, SECRET_KEYS
from .scheduler import next_slot, parse_times
from .dispatch import Dispatcher
from .tg import THROTTLE, TGError
from .util import (clip, disk_free_mb, esc, export_to_downloads, telegram_copy, fmt_dur, human_size, local_now, log, tail_file, tb_short)
from .botdict import DictMixin
from .botllm import SECRET_CMDS, LLMAdminMixin
from .botmenu import MenuMixin
from .botretry import RetryMixin
from .botsched import SchedMixin
from .botsec import SecurityMixin
from .botstream import StreamMixin
from .botpost import PostMixin
from .botvid import VideoMixin
from .youtube import YTError, parse_client_json

COMMANDS = [
    ("menu", "Bosh menyu"), ("status", "Tizim holati"), ("make", "Keyingi epizodni hozir yasash"),
    ("upload", "Tayyor epizodni YouTube ga yuklash"), ("queue", "Navbat va reja"),
    ("episodes", "Oxirgi epizodlar"), ("ep", "Epizod tafsiloti: /ep 5"), ("plan", "Joriy fasl rejasi"),
    ("newseason", "Yangi fasl rejalash"), ("stats", "Statistika yangilash"), ("comments", "Yangi izohlar"),
    ("pause", "Jadvalni to'xtatish"), ("resume", "Jadvalni davom ettirish"),
    ("times", "Yuklash vaqtlari: /times 12:00,18:00"), ("topic", "Keyingi faslga mavzu: /topic ..."),
    ("note", "Keyingi epizodga ko'rsatma: /note ..."), ("retry", "Xato epizodni qayta urinish"),
    ("skip", "Epizodni o'tkazish: /skip 5"), ("remake", "Epizodni qayta yasash: /remake 5"),
    ("set", "Sozlama: /set KEY VALUE"), ("config", "Sozlamalar"), ("logs", "Oxirgi loglar"),
    ("health", "Salomatlik tekshiruvi"), ("auth", "YouTube ga ulanish"), ("llm", "AI ni sinash"),
    ("tts", "Ovozni sinash"), ("video", "Videoni qayta yuborish: /video 1"), ("backup", "Bazani yuklab olish"), ("restart", "Qayta ishga tushirish"),
    ("seasons", "Fasllar ro'yxati va holati"), ("season", "Faslni boshqarish: /season 1 restart"),
    ("back", "Epizodga qaytish: /back 5"), ("unskip", "O'tkazilganni qaytarish: /unskip 5"),
    ("edit", "Rejadagi epizodni tahrirlash"), ("voice", "Ovoz variantlari: /voice"),
    ("format", "Format: /format landscape|shorts"), ("clean", "Vaqtinchalik fayllarni tozalash"),
    ("forget", "Yuklangan videoni unutish: /forget 5 yoki /forget all"),
    ("models", "AI modellari ro'yxati va boshqaruvi"), ("model", "Model: /model use|add|del|edit|find groq ..."),
    ("keys", "API kalitlari ro'yxati"), ("addkey", "Kalit qo'shish: /addkey groq KALIT"),
    ("editkey", "Kalitni almashtirish: /editkey groq 1 KALIT"), ("delkey", "Kalitni o'chirish: /delkey groq 1"),
    ("testkeys", "Kalitlarni sinash"), ("order", "AI provayder tartibi: /order groq,gemini"),
    ("playlist", "Pleylistni tekshirish/qayta yaratish"),
    ("videos", "Videolar ro'yxati va boshqaruvi"), ("regen", "Qayta yaratilganlar"),
    ("autoclean", "Avto-tozalash: /autoclean on|off"),
    ("pron", "Ingliz so'zlar talaffuzi: /pron shape sheyp"),
    ("sozlar", "So'zlar lug'ati: qidirish, qo'shish, txt"),
    ("stream", "Jonli translatsiya (YouTube Live)"),
    ("schedule", "Rejalashtirilgan chiqarish va boshqaruv"), ("reschedule", "Vaqt: /reschedule 5 18:30"),
    ("publish", "Hozir ochish: /publish 5"), ("unschedule", "Rejani bekor qilish: /unschedule 5"),
    ("swap", "Vaqtlarni almashtirish: /swap 5 6"), ("shift", "Hammasini surish: /shift +1d"),
    ("reslot", "Vaqtlarni tartiblash"),
    ("blocked", "Bloklangan foydalanuvchilar"), ("security", "Himoya holati"),
    ("post", "Video joylash (YouTube)"),
    ("gpu", "Video kodlash: GPU/CPU holati va tanlash"),
]

HELP = """🤖 <b>{channel}</b> — buyruqlar (hammasi tugmalarda ham bor: /menu)

<b>Yasash</b>  /make · /upload · /retry [N] · /remake N · /skip N · /unskip N · /back N
<b>Reja</b>  /plan · /queue · /episodes · /ep N · /seasons · /season N · /newseason · /topic · /note · /edit N …
<b>Jadval</b>  /times 12:00,18:00 · /pause · /resume · /forget N|all
<b>Rejalashtirish</b>  /schedule · /reschedule N vaqt · /publish N · /unschedule N · /swap A B · /shift +1d · /reslot
<b>Translatsiya</b>  /stream — yaratish, navbat, sifat/FPS/format, boshlash/to'xtatish (hammasi tugmalarda)
<b>Videolar</b>  /videos · /regen · /video N · /clean · /autoclean on|off · /playlist · /backup
<b>AI</b>  /models · /model … · /order · /keys · /addkey · /editkey · /delkey · /testkeys · /llm
<b>Ovoz</b>  /voice · /tts · /pron so'z talaffuz (ingliz so'zlar)
<b>Sozlama</b>  /config · /set KEY VALUE · /format landscape|shorts
<b>Joylash</b>  /post — o'z videongizni YouTube'ga joylash (nom, tavsif, maxfiylik, vaqt)
<b>Himoya</b>  /security · /blocked
<b>Kodlash</b>  /gpu — GPU (NVENC/QSV/AMF) yoki CPU holati, tanlash va qayta sinash
<b>Tizim</b>  /status · /stats · /comments · /health · /logs [n] · /auth · /restart"""


def validate_setting(key: str, val: str):
    """Noto'g'ri qiymat videoni buzmasin: xato matnini yoki None (to'g'ri) qaytaradi."""
    v = val.strip().lower()
    if key == "VIDEO_RES" and v not in ("480", "720", "1080"):
        return "faqat 480, 720 yoki 1080"
    if key == "VIDEO_FPS":
        if not v.isdigit() or not (10 <= int(v) <= 60) or 44100 % int(v):
            return "10..60 oralig'ida va 44100 ga bo'linadigan son (25, 30, 36, 42, 45, 49, 50, 60)"
    if key == "VIDEO_FORMAT" and v not in ("landscape", "shorts"):
        return "landscape yoki shorts"
    if key == "VIDEO_CRF" and not (v.isdigit() and 14 <= int(v) <= 36):
        return "14..36 (kichik = sifatliroq)"
    if key == "VIDEO_MOTION" and v not in ("0", "1", "2"):
        return "0, 1 yoki 2"
    if key in ("MUSIC", "VIDEO_WAVE", "AUTO_UPLOAD", "APPROVAL_MODE", "AUTO_CLEAN", "LLM_AUTO_MODELS",
               "SEND_VIDEO_TO_ADMIN", "YT_SYNTHETIC", "YT_SCHEDULE", "SFX", "HIDE_STATS") and v not in ("0", "1"):
        return "0 yoki 1"
    if key == "STREAM_RES" and v not in ("480", "720", "1080"):
        return "480, 720 yoki 1080"
    if key == "STREAM_FPS" and (not v.isdigit() or not (10 <= int(v) <= 60) or 44100 % int(v)):
        return "10..60 oralig'ida, 44100 ga bo'linadigan (15, 20, 25, 30, 50, 60)"
    if key == "STREAM_FORMAT" and v not in ("landscape", "shorts"):
        return "landscape yoki shorts"
    if key == "STREAM_MODE" and v not in ("api", "manual"):
        return "api yoki manual"
    if key == "STREAM_PRIVACY" and v not in ("public", "unlisted", "private"):
        return "public, unlisted yoki private"
    if key in ("STREAM_MIDCUT", "STREAM_MUSIC", "STREAM_AUTO", "STREAM_SPLIT") and v not in ("0", "1"):
        return "0 yoki 1"
    if key in ("STREAM_PREROLL", "STREAM_BUFFER") and not (v.isdigit() and 1 <= int(v) <= 30):
        return "1..30 oralig'ida son"
    if key == "STREAM_PROCS" and not (v.lstrip("-").isdigit() and -1 <= int(v) <= 16):
        return "-1 (o'chiq), 0 (avto) yoki 1..16"
    if key == "STREAM_WORKERS" and not (v.isdigit() and 0 <= int(v) <= 16):
        return "0..16 oralig'ida son (0 = avto)"
    if key == "STREAM_PART_SEC" and not (v.isdigit() and 5 <= int(v) <= 300):
        return "5..300 soniya"
    if key == "STREAM_PRESET" and v not in ("ultrafast", "superfast", "veryfast", "faster", "fast"):
        return "ultrafast | superfast | veryfast | faster | fast"
    if key in ("STREAM_BITRATE", "STREAM_SEG_SEC", "STREAM_WARN_SEC", "STREAM_ASK_TIMEOUT", "STREAM_FAREWELL_SEC",
               "STREAM_GEN_SEGS") and not (v.isdigit() and int(v) >= 0):
        return "butun son kerak"
    if key == "STREAM_SEG_SEC" and int(v) < 30:
        return "kamida 30 soniya"
    if key == "STREAM_BITRATE" and not (int(v) == 0 or 300 <= int(v) <= 25000):
        return "0 (avto) yoki 300..25000 kbit/s"
    if key == "YT_PRIVACY" and v not in ("public", "unlisted", "private"):
        return "public, unlisted yoki private"
    if key == "BG_STYLE":
        from .bgfx import STYLES
        if v != "auto" and v not in STYLES:
            return "auto yoki: " + ", ".join(STYLES)
    if key in ("MUSIC_VOLUME", "SFX_VOLUME"):
        try:
            if not 0 <= float(v) <= 1:
                return "0..1"
        except ValueError:
            return "0..1 oralig'idagi son"
    if key == "ENCODER":
        from .hwenc import ALIASES, MODES
        if ALIASES.get(v, v) not in MODES:
            return "auto | nvenc | qsv | amf | videotoolbox | cpu"
    if key == "ENC_SESSIONS" and not (v.isdigit() and 0 <= int(v) <= 16):
        return "0 (avto, o'lchab aniqlanadi) yoki 1..16"
    if key == "VIDEO_BITRATE" and not (v.isdigit() and (int(v) == 0 or 500 <= int(v) <= 40000)):
        return "0 (avto) yoki 500..40000 kbit/s"
    if key in ("VIDEO_ANIM_FPS", "STREAM_BG_FPS") and not (v.isdigit() and (int(v) == 0 or 4 <= int(v) <= 60)):
        return "0 (avto: fps ga teng) yoki 4..60 kadr/s"
    if key == "VIDEO_PARALLEL" and v not in ("0", "1"):
        return "0 yoki 1"
    if key == "VIDEO_PROCS" and not (v.isdigit() and 0 <= int(v) <= 16):
        return "0 (avto) .. 16"
    if key == "VIDEO_PART_SEC" and not (v.isdigit() and 8 <= int(v) <= 120):
        return "8..120 soniya"
    if key == "VIDEO_AI_RACE" and not (v.isdigit() and 0 <= int(v) <= 5):
        return "0 (ketma-ket) .. 5"
    if key == "STREAM_CRF" and not (v.isdigit() and 10 <= int(v) <= 36):
        return "10..36 (kichik = sifatliroq)"
    if key == "STREAM_PROFILE":
        from .streamsys import PROFILES
        if v != "custom" and v not in PROFILES:
            return "custom | " + " | ".join(PROFILES)
    if key == "STREAM_AT":
        from .streamsys import Planner
        from .util import now_utc
        if v and Planner.parse(v, now_utc()) is None:
            return "HH:MM yoki YYYY-MM-DD HH:MM (bo'sh = o'chirish)"
    if key == "STREAM_EXTRA_RTMP":
        from .streamsys import parse_extra
        items = [x for x in __import__("re").split(r"[,\s]+", val.strip()) if x]
        if len(parse_extra(val)) != len(items):
            return "rtmp:// yoki rtmps:// manzillar, vergul bilan (eng ko'pi 6 ta)"
    if key == "STREAM_BUFFER_CAP" and not (v.isdigit() and 0 <= int(v) <= 500):
        return "0 (cheksiz) .. 500 bo'lak"
    if key == "STREAM_ASK_END" and v not in ("0", "1"):
        return "0 (so'ralmaydi, AI cheksiz davom etadi) yoki 1 (so'raladi)"
    if key == "STREAM_PREROLL_WAIT" and not (v.isdigit() and (int(v) == 0 or int(v) >= 60)):
        return "0 (cheksiz kutish) yoki kamida 60 soniya"
    if key == "STREAM_WATCHDOG" and v not in ("0", "1"):
        return "0 yoki 1"
    if key == "STREAM_STALL_SEC" and not (v.isdigit() and 60 <= int(v) <= 3600):
        return "60..3600 soniya"
    if key == "STREAM_MIN_DISK_MB" and not (v.isdigit() and 100 <= int(v) <= 100000):
        return "100..100000 MB"
    if key == "LLM_PASSES" and not (v.isdigit() and 1 <= int(v) <= 5):
        return "1..5"
    if key == "LLM_WAIT" and not (v.isdigit() and 0 <= int(v) <= 120):
        return "0..120 soniya"
    if key in ("EPISODE_MINUTES", "SEASON_LENGTH", "KEEP_LOCAL_VIDEOS", "BUFFER_AHEAD", "SCHEDULE_AHEAD", "TZ_OFFSET", "STATS_EVERY_HOURS"):
        try:
            int(v)
        except ValueError:
            return "butun son kerak"
    return None


def menu_markup():
    rows = [
        [("📊 Holat", "m:status"), ("🎬 Yasash", "m:make"), ("⬆️ Yuklash", "m:upload")],
        [("📋 Navbat", "m:queue"), ("🗓 Reja", "m:plan"), ("📺 Epizodlar", "m:episodes")],
        [("📈 Statistika", "m:stats"), ("🩺 Salomatlik", "m:health"), ("📜 Loglar", "m:logs")],
        [("⏸ To'xtat", "m:pause"), ("▶️ Davom", "m:resume"), ("⚙️ Sozlama", "m:config")],
        [("🤖 Modellar", "m:models"), ("🔑 Kalitlar", "m:keys"), ("📚 Pleylist", "m:playlist")],
        [("🎞 Videolar", "m:videos"), ("📁 Qayta yaratilgan", "m:regen"), ("🛡 Himoya", "m:security")],
        [("🗂 Fasllar", "m:seasons"), ("🆕 Yangi fasl", "m:newseason"), ("🗑 Unutish", "m:forget")],
        [("🎙 Ovoz", "m:voice"), ("🔐 YouTube", "m:auth"), ("🧪 AI sinov", "m:llm")],
        [("🧹 Tozalash", "m:clean"), ("💾 Zaxira", "m:backup"), ("🔁 Qayta urinish", "m:retry")],
        [("🔤 Talaffuz", "m:pron")],
    ]
    return {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]}


class Bot(MenuMixin, RetryMixin, SchedMixin, StreamMixin, DictMixin, VideoMixin, LLMAdminMixin, SecurityMixin,
          PostMixin, threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True, name="bot")
        self.app = app
        self.tg = app.tg
        self.stop_flag = threading.Event()
        self.unauth_seen: dict = {}
        self.auth_thread = None
        self.pending = None
        self._cb_msg = None
        self.guard = app.guard
        self.disp = Dispatcher(lambda: THROTTLE.sec, on_error=self._lane_error)

    # ------------------------------------------------------------------ tsikl
    def set_commands(self):
        try:
            self.tg.set_commands(COMMANDS)
        except Exception as e:
            log.warning("Buyruqlar ro'yxati o'rnatilmadi: %s", self.tg._clean(e))

    def _lane_error(self, key, e):
        a = self.app
        if key == a.cfg.admin_id:
            a.n.error("Buyruqni bajarishda xato", f"{type(e).__name__}: {e}")
        else:
            try:
                self.tg.send("⚠️ Kutilmagan xato yuz berdi. Birozdan keyin qayta urinib ko'ring yoki /menu bosing.", chat=key)
            except Exception:  # noqa: BLE001
                pass

    @staticmethod
    def _dedup(u):
        """Bir xil tugmaning navbatdagi takrori tashlanadi (xabar matnlari hech qachon tashlanmaydi)."""
        cb = u.get("callback_query")
        if cb:
            m = cb.get("message") or {}
            return f"{(cb.get('from') or {}).get('id')}:{m.get('message_id')}:{cb.get('data')}"
        return None

    def run(self):
        a = self.app
        self.set_commands()
        offset = int(a.db.kv_get("tg_offset", "0") or 0)
        warned_conflict = False
        while not self.stop_flag.is_set():
            try:
                ups = self.tg.updates(offset, 25)
                warned_conflict = False
            except TGError as e:
                msg = self.tg._clean(e)
                log.warning("getUpdates xato: %s", msg)
                if "409" in msg or "Conflict" in msg:
                    if not warned_conflict:
                        warned_conflict = True
                        log.error("Boshqa bot nusxasi ishlayapti (409 Conflict)")
                    time.sleep(30)
                else:
                    time.sleep(5)
                continue
            except Exception as e:
                log.warning("getUpdates kutilmagan xato: %s", self.tg._clean(e))
                time.sleep(5)
                continue
            if ups:  # offset butun paket uchun bir marta yoziladi (begona oqim bazani yuklamasin)
                offset = max(offset, max(u["update_id"] for u in ups) + 1)
                a.db.kv_set("tg_offset", str(offset))
            for u in ups:
                try:
                    verdict = self.guard.classify(u)
                    if not verdict:
                        continue   # begona/bloklangan: HECH QANDAY javob yo'q
                    if verdict == "setup":
                        self.handle_setup(u)
                        continue
                    # Polling hech qachon kutmaydi: har foydalanuvchining update lari o'z navbatida (0.4 s oralig'ida)
                    uid = ((u.get("callback_query") or u.get("message") or {}).get("from") or {}).get("id")
                    fn = lambda u=u: self.handle(u)  # noqa: E731
                    accepted = self.disp.submit(uid, fn, dedup=self._dedup(u))
                    cbq = u.get("callback_query")
                    if not accepted and cbq:   # takroriy bosish: tugma "aylanib" turib qolmasin
                        threading.Thread(target=self.tg.answer_cb, args=(cbq["id"],), daemon=True).start()
                except Exception as e:
                    log.error("Update xatosi: %s\n%s", e, tb_short(1500))
                    a.n.error("Buyruqni bajarishda xato", f"{type(e).__name__}: {e}")

    # ------------------------------------------------------------------ kirish
    def handle_setup(self, u):
        """ADMIN_ID hali yozilmagan: faqat shaxsiy chatda, daqiqasiga bir marta ID ni aytadi."""
        msg = u["message"]
        uid = msg["from"]["id"]
        now = time.time()
        if now - self.unauth_seen.get(uid, 0) < 60 or len(self.unauth_seen) > 200:
            return
        self.unauth_seen[uid] = now
        self.tg.send(f"👋 Sizning Telegram ID raqamingiz: <code>{uid}</code>\n"
                     f".env faylida <code>ADMIN_ID={uid}</code> deb yozing va tizimni qayta ishga tushiring.",
                     chat=msg["chat"]["id"])

    def handle(self, u):
        """Guard dan o'tgan (admin) update i.
        Tugma bosilsa — o'sha xabar TAHRIRLANADI; /buyruq yoki matn kelsa — yangi panel yuboriladi va eskisi o'chiriladi."""
        a = self.app
        tg = self.tg
        if "callback_query" in u:
            cb = u["callback_query"]
            uid = cb["from"]["id"]
            chat = cb["message"]["chat"]["id"] if cb.get("message") else uid
            mid = cb["message"]["message_id"] if cb.get("message") else None
            tg.answer_cb(cb["id"])
            self._cb_msg = mid
            self.pending = None            # tugma bosildi: kutilayotgan matn so'rovi bekor (kerak bo'lsa handler o'zi qo'yadi)
            try:
                with tg.ctx(chat, "cb", mid):
                    self.callback(cb["data"], chat)
            finally:
                self._cb_msg = None
            return
        msg = u.get("message")
        if not msg:
            return
        chat = msg["chat"]["id"]
        with tg.ctx(chat, "input"):
            if "photo" in msg:
                self.st_photo(msg)
                return
            if "video" in msg or (msg.get("document") or {}).get("mime_type", "").startswith("video/"):
                if not self.post_video_msg(msg):
                    self.st_video_msg(msg)
                return
            if "document" in msg:
                self.import_document(msg)
                return
        if "text" not in msg:
            return
        text = msg["text"].strip()
        tg.delete_async(chat, msg.get("message_id"))      # foydalanuvchi yozganlari chatda to'planib qolmasin
        if not text.startswith("/"):
            if self.pending:
                with tg.ctx(chat, "input"):
                    if self.handle_pending(text, msg, chat):
                        return
            self._cb_msg = None
            with tg.ctx(chat, "cmd"):
                self.c_start("", chat)
            return
        self.pending = None
        self._cb_msg = None
        cmd, _, arg = text.partition(" ")
        cmd = cmd.split("@")[0][1:].lower()
        with tg.ctx(chat, "cmd"):
            self.command(cmd, arg.strip(), chat)

    def callback(self, data, chat):
        a = self.app
        kind, _, val = data.partition(":")
        if kind == "m":
            self.command(val, "", chat)
        elif kind == "approve":
            ep = a.db.ep(int(val))
            if ep and a.jobs.submit(f"upload-{ep['id']}", a.pipeline.upload_episode, ep):
                self.tg.send(f"✅ #{ep['gno']} yuklash navbatga qo'yildi.", chat=chat)
            else:
                self.tg.send("ℹ️ Allaqachon navbatda yoki epizod topilmadi.", chat=chat)
        elif kind == "regen":
            ep = a.db.ep(int(val))
            if ep and ep["status"] != "uploaded":
                self.ask_remake(ep, chat)
            else:
                self.tg.send("ℹ️ Topilmadi yoki allaqachon yuklangan.", chat=chat)
        elif kind == "v":
            if val == "test":
                out = self._voice_test(chat)
            else:
                out = self.c_voice(val, chat)
            if out:
                self.tg.send(out, chat=chat)
        elif kind == "e":
            act, _, g = val.partition(":")
            if g.isdigit():
                out = self._ep_callback(act, int(g), chat)
                if out:
                    self.tg.send(out, chat=chat)
        elif kind == "s":
            act, _, g = val.partition(":")
            if g.isdigit():
                sid = int(g)
                if act == "view":
                    self._season_view(sid, chat)
                elif act in ("restart", "skip", "unskip"):
                    out = self._season_action(act, sid, chat, False)
                    if out:
                        self.tg.send(out, chat=chat)
                elif act in ("restartok", "skipok", "unskipok"):
                    out = self._season_action(act[:-2], sid, chat, True)
                    if out:
                        self.tg.send(out, chat=chat)
        elif kind == "vd":
            self.vd_callback(val, chat)
        elif kind == "sc":
            self.sc_callback(val, chat)
        elif kind == "dc":
            self.dc_callback(val, chat)
        elif kind == "rt":
            self.rt_callback(val, chat)
        elif kind == "st":
            self.st_callback(val, chat)
        elif kind == "gpu":
            self.gpu_callback(val, chat)
        elif kind == "sec":
            out = self.sec_callback(val, chat)
            if out:
                self.tg.send(out, chat=chat)
        elif kind == "mn":
            self.mn_callback(val, chat)
        elif kind == "q":
            self.q_callback(val, chat)
        elif kind == "ui":
            self.ui_callback(val, chat)
        elif kind == "mdl":
            out = self.mdl_callback(val, chat)
            if out:
                self.tg.send(out, chat=chat)
        elif kind == "pst":
            self.pst_callback(val, chat)
        elif kind == "skip":
            ep = a.db.ep(int(val))
            if ep:
                self.tg.send(self.c_skip(str(ep["gno"]), chat), chat=chat)
            else:
                self.tg.send("ℹ️ Epizod topilmadi.", chat=chat)

    def import_document(self, msg):
        """Google'dan yuklangan client_secret_*.json faylini qabul qilib, kalitlarni saqlaydi."""
        a = self.app
        chat = msg["chat"]["id"]
        doc = msg["document"]
        name = doc.get("file_name", "")
        if name.lower().endswith((".txt", ".csv", ".tsv", ".dic", ".lst")):
            self.dc_import_file(msg)
            return
        if not name.lower().endswith(".json") or doc.get("file_size", 0) > 20000:
            self.tg.send("ℹ️ Faqat Google Cloud'dan yuklangan <code>client_secret_...json</code> fayli qabul qilinadi.",
                         chat=chat)
            return
        dest = a.cfg.dirs["work"] / "client_secret_import.json"
        try:
            self.tg.download_file(doc["file_id"], dest)
            cid, sec = parse_client_json(dest.read_text(encoding="utf-8"))
        except Exception as e:
            self.tg.send(f"❌ Fayl o'qilmadi: {esc(clip(self.tg._clean(e), 200))}", chat=chat)
            return
        finally:
            try:
                dest.unlink()
            except OSError:
                pass
        a.cfg.set("YT_CLIENT_ID", cid)
        a.cfg.set("YT_CLIENT_SECRET", sec)
        try:  # maxfiy fayl chatda qolib ketmasin
            self.tg.api("deleteMessage", {"chat_id": chat, "message_id": msg["message_id"]}, retries=1)
        except TGError:
            pass
        self.tg.send("✅ YouTube kalitlari saqlandi (fayl chatdan o'chirildi).\nEndi /auth yuboring.", chat=chat)

    # ------------------------------------------------------------------ buyruqlar
    def cmd_allowed(self, cmd) -> bool:
        return True            # yagona admin: hamma buyruq ruxsat etilgan

    def command(self, cmd, arg, chat):
        fn = getattr(self, "c_" + cmd, None)
        if fn and not self.cmd_allowed(cmd):
            self.tg.send("🔒 Bu buyruq faqat admin uchun.", chat=chat)
            return
        if not fn:
            self.tg.send("Noma'lum buyruq. /menu", chat=chat)
            return
        out = fn(arg, chat)
        if out:
            mk = None
            if cmd in ("status", "health", "stats", "queue", "episodes", "plan", "config", "logs", "pron"):
                mk = {"inline_keyboard": [[{"text": "🔄 Yangilash", "callback_data": f"m:{cmd}"},
                                           {"text": "⬅️ Menyu", "callback_data": "mn:main"}]]}
            self.tg.send(out, chat=chat, markup=mk)

    def _sched_status_line(self):
        from . import schedule as sc
        a = self.app
        try:
            items = a.db.scheduled()
            if not sc.active(a.cfg):
                return "⏰ Rejalashtirilgan chiqarish: o'chiq"
            if not items:
                return "⏰ Rejalashtirilgan: yo'q"
            d = sc.from_iso(items[0]["publish_at"])
            return (f"⏰ Rejalashtirilgan: {len(items)} ta · eng yaqini #{items[0]['gno']} "
                    f"{sc.fmt_local(a.cfg, d)} ({sc.eta(d) if d else ''})")
        except Exception as e:  # noqa: BLE001
            return f"⏰ Rejalashtirish holati olinmadi: {esc(str(e))[:80]}"

    def c_start(self, arg, chat):
        self._cb_msg = None
        self.tg.send(self.main_text(), chat=chat, markup={"inline_keyboard": [
            [{"text": t, "callback_data": c} for t, c in r] for r in self.main_rows()]})

    c_menu = c_start

    def c_help(self, arg, chat):
        self.tg.send(HELP.format(channel=esc(self.app.cfg.get("CHANNEL_NAME"))), chat=chat,
                     markup={"inline_keyboard": [[{"text": "⬅️ Menyu", "callback_data": "mn:main"}]]})

    def c_ping(self, arg, chat):
        return f"🏓 pong · ishlayapti {fmt_dur(time.time() - self.app.started)}"

    def c_id(self, arg, chat):
        return f"ID: <code>{self.app.cfg.admin_id}</code>"

    def c_status(self, arg, chat):
        a = self.app
        cfg, db = a.cfg, a.db
        c = db.counts()
        nxt = next_slot(cfg)
        lines = [
            "📊 <b>Holat</b>",
            f"⏱ Ishlash vaqti: {fmt_dur(time.time() - a.started)} · 🕒 {local_now(cfg).strftime('%H:%M')} (UTC+{cfg.get('TZ_OFFSET')})",
            f"🔄 Joriy ish: {esc(a.jobs.describe())}",
            f"{'⏸ To`xtatilgan' if cfg.bool('PAUSED') else '▶️ Faol'}"
            + (f" · ⛔ {esc(db.kv_get('halt_reason'))}" if db.kv_get("halt_reason") else ""),
            f"📅 Jadval: {esc(cfg.get('UPLOAD_TIMES'))} · keyingi: {nxt.strftime('%m-%d %H:%M') if nxt else '-'}",
            self._sched_status_line(),
            f"🎬 Yuklangan {c.get('uploaded', 0)} · tayyor {c.get('ready', 0)} · rejada {c.get('planned', 0)} · "
            f"xato {c.get('failed', 0)} · o'tkazilgan {c.get('skipped', 0)}",
        ]
        ups = db.uploaded(1)
        if ups:
            e = ups[0]
            lines.append(f"🆕 Oxirgi: #{e['gno']} {esc(clip(e['title'], 45))} · 👁 {e['views'] or 0} · {e['yt_url']}")
        nx = db.by_status("ready", "planned", limit=1)
        if nx:
            lines.append(f"⏭ Keyingi: #{nx[0]['gno']} {esc(clip(nx[0]['title'], 50))} [{nx[0]['status']}]")
        lines += [
            f"🤖 LLM: {esc(a.llm.describe())}" + (f" · oxirgi: {esc(a.llm.last_label)}" if a.llm.last_label else ""),
            "<pre>" + esc(a.llm.report()) + "</pre>",
            f"🎙 Ovoz: {esc(', '.join(a.tts.providers()))} · {esc(cfg.get('TTS_VOICE'))}",
            f"📺 YouTube: {'ulangan ✅' if a.yt.authorized() else 'ulanmagan ❌'} · maxfiylik: {esc(cfg.get('YT_PRIVACY'))}",
            f"⚙️ Avto-yuklash: {'ha' if cfg.bool('AUTO_UPLOAD') else 'yo`q'} · tasdiq rejimi: "
            f"{'ha' if cfg.bool('APPROVAL_MODE') else 'yo`q'} · format: {esc(cfg.get('VIDEO_FORMAT'))}",
            f"🎞 Sifat: {cfg.get('VIDEO_RES')}p · {cfg.get('VIDEO_FPS')} fps · CRF {cfg.get('VIDEO_CRF')} · "
            f"🔤 talaffuz lug'ati: {len(speak.EN)}+{len(speak.ACTIVE)} so'z",
            f"💾 Disk: {disk_free_mb(cfg.data)} MB bo'sh",
        ]
        return "\n".join(lines)

    def c_make(self, arg, chat):
        a = self.app
        if a.pipeline.halted():
            return f"⛔ To'xtatilgan: {esc(a.pipeline.halted())}\n/retry yoki /skip bilan davom eting."
        ok = a.jobs.submit("make", a.pipeline.produce_next)
        return "🎬 Yasash navbatga qo'yildi. Jarayon shu yerda ko'rinadi." if ok else \
            f"ℹ️ Allaqachon ishlayapti: {esc(a.jobs.describe())}"

    def c_upload(self, arg, chat):
        a = self.app
        why = a.pipeline.can_upload()
        if why:
            return f"ℹ️ Yuklab bo'lmaydi: {esc(why)}"
        ok = a.jobs.submit("upload", a.pipeline.upload_next_ready)
        return "⬆️ Yuklash navbatga qo'yildi." if ok else f"ℹ️ Band: {esc(a.jobs.describe())}"

    def c_queue(self, arg, chat):
        db = self.app.db
        rows = db.by_status("ready", "scripted", "rendered", "planned", "failed", limit=14)
        if not rows:
            return "Navbat bo'sh. /make"
        icon = {"ready": "✅", "planned": "🕓", "failed": "❌", "scripted": "📝", "rendered": "🎞"}
        return "📋 <b>Navbat</b>\n" + "\n".join(
            f"{icon.get(e['status'], '•')} #{e['gno']} {esc(clip(e['title'], 55))} <i>[{e['kind']}]</i>" for e in rows)

    def c_episodes(self, arg, chat):
        n = int(arg) if arg.isdigit() else 8
        rows = self.app.db.recent(min(25, n))
        if not rows:
            return "Hali epizod yo'q."
        lines = ["📺 <b>Oxirgi epizodlar</b>"]
        for e in rows:
            tail = f"👁 {e['views'] or 0} 👍 {e['likes'] or 0} · {e['yt_url']}" if e["status"] == "uploaded" else e["status"]
            lines.append(f"#{e['gno']} {esc(clip(e['title'], 45))}\n   {tail}")
        return "\n".join(lines)

    def c_ep(self, arg, chat):
        if not arg.strip().isdigit():
            return "Foydalanish: /ep 5"
        e = self.app.db.ep_by_gno(int(arg))
        if not e:
            return "Topilmadi."
        sc = e.get("script") or {}
        lines = [f"🎞 <b>#{e['gno']} {esc(e['title'])}</b> [{e['status']}]",
                 f"Tur: {e['kind']} · fasl {e['season_id']} · {e['num']}-qism",
                 f"Mavzu: {esc(clip(e['topic'] or '', 300))}"]
        if e["duration"]:
            lines.append(f"⏱ {fmt_dur(e['duration'])} · {human_size(e['size_bytes'] or 0)} · LLM {esc(e['llm'] or '-')} · ovoz {esc(e['tts'] or '-')}")
        if e["summary"]:
            lines.append(f"Xulosa: {esc(clip(e['summary'], 600))}")
        if sc.get("teaser"):
            lines.append(f"Keyingiga chorlov: {esc(clip(sc['teaser'], 300))}")
        if e["yt_url"]:
            lines.append(f"🔗 {e['yt_url']} · 👁 {e['views']} 👍 {e['likes']} 💬 {e['comments']}")
        if e["error"]:
            lines.append(f"❗ {esc(clip(e['error'], 300))}")
        old = (e.get("plan") or {}).get("old_uploads")
        if old:
            lines.append("🗃 Eski yuklamalar: " + ", ".join(str(o.get("url") or o.get("id")) for o in old[-3:]))
        self.tg.send("\n".join(lines), chat=chat, markup=self._ep_buttons(e))
        return None

    def c_plan(self, arg, chat):
        db = self.app.db
        s = db.last_season()
        if not s:
            return "Reja hali yo'q. /make yoki /newseason"
        eps = db.season_episodes(s["id"])
        icon = {"uploaded": "✅", "ready": "🟢", "planned": "🕓", "failed": "❌", "skipped": "⏭"}
        return (f"🗓 <b>Fasl #{s['id']}: {esc(s['theme'])}</b>\n<i>{esc(clip(s['description'] or '', 300))}</i>\n"
                + "\n".join(f"{icon.get(e['status'], '📝')} {e['gno']}. {esc(clip(e['title'], 60))} <i>[{e['kind']}]</i>"
                            for e in eps))

    def c_newseason(self, arg, chat):
        a = self.app
        ok = a.jobs.submit("newseason", lambda: planner.plan_season(a.cfg, a.db, a.llm, a.n.say))
        return "🗓 Yangi fasl rejalanmoqda…" if ok else "ℹ️ Band."

    def c_stats(self, arg, chat):
        a = self.app

        def job():
            a.stats.refresh()
            a.n.say(a.stats.digest())

        if not a.yt.authorized():
            return a.stats.digest() + "\n\nℹ️ YouTube ulanmagan - ko'rishlar yangilanmadi."
        return "📈 Statistika yangilanmoqda…" if a.jobs.submit_light("stats", job) else "ℹ️ Band."

    def c_comments(self, arg, chat):
        a = self.app
        if not a.yt.authorized():
            return "YouTube ulanmagan."

        def job():
            n = a.stats.check_comments(notify=True)
            if not n:
                a.n.say("💬 Yangi izoh yo'q.")

        return "💬 Tekshirilmoqda…" if a.jobs.submit_light("comments", job) else "ℹ️ Band."

    def c_pause(self, arg, chat):
        self.app.cfg.set("PAUSED", "1")
        return "⏸ Jadval to'xtatildi. /resume bilan davom ettiring."

    def c_resume(self, arg, chat):
        self.app.cfg.set("PAUSED", "0")
        return "▶️ Jadval davom etmoqda."

    def c_times(self, arg, chat):
        if not arg:
            return f"Hozirgi vaqtlar: <code>{esc(self.app.cfg.get('UPLOAD_TIMES'))}</code>\nO'zgartirish: /times 12:00,18:00"
        t = parse_times(arg)
        if not t:
            return "Format xato. Misol: /times 12:00,18:00"
        val = ",".join(f"{h:02d}:{m:02d}" for h, m in t)
        self.app.cfg.set("UPLOAD_TIMES", val)
        return f"📅 Yuklash vaqtlari: <code>{val}</code> (UTC+{self.app.cfg.get('TZ_OFFSET')})"

    def c_topic(self, arg, chat):
        if not arg:
            q = self.app.db.kv_json("topic_queue", [])
            return "Mavzular navbati: " + (", ".join(esc(x) for x in q) if q else "bo'sh") + "\nQo'shish: /topic matn"
        q = self.app.db.kv_json("topic_queue", []) or []
        q.append(clip(arg, 200))
        self.app.db.kv_set_json("topic_queue", q[-10:])
        return f"➕ Mavzu navbatga qo'shildi (keyingi fasl rejasida hisobga olinadi): {esc(arg)}"

    def c_note(self, arg, chat):
        if not arg:
            return "Foydalanish: /note matn (keyingi epizod ssenariysi uchun ko'rsatma)"
        self.app.db.kv_set("admin_note", clip(arg, 500))
        return "📝 Ko'rsatma saqlandi. Keyingi ssenariyda hisobga olinadi."

    def c_skip(self, arg, chat):
        a = self.app
        if arg.isdigit():
            e = a.db.ep_by_gno(int(arg))
        else:
            rows = a.db.by_status("failed", "ready", "planned")
            e = rows[0] if rows else None
        if not e:
            return "Epizod topilmadi."
        if e["status"] == "uploaded":
            return "O'tkazib bo'lmadi (yuklangan)."
        return self._mutate(f"skip-{e['id']}", lambda: a.pipeline.skip(e["id"]), chat,
                            lambda ok: f"⏭ #{e['gno']} o'tkazib yuborildi." if ok else "O'tkazib bo'lmadi.", resume=False)

    def c_remake(self, arg, chat):
        a = self.app
        if not arg.isdigit():
            return "Foydalanish: /remake 5"
        e = a.db.ep_by_gno(int(arg))
        if not e:
            return "Topilmadi."
        if e["status"] == "uploaded":
            return f"Yuklangan epizodni qayta yasab bo'lmaydi. Avval unuting: /forget {e['gno']}"
        self.ask_remake(e, chat)
        return None

    def c_set(self, arg, chat):
        key, _, val = arg.partition(" ")
        key = key.upper()
        if key not in SAFE_KEYS:
            return "Ruxsat etilgan kalitlar:\n<code>" + ", ".join(SAFE_KEYS) + "</code>"
        if not val.strip():
            return f"{key} = <code>{esc(self.app.cfg.get(key))}</code>"
        val = val.strip()
        err = validate_setting(key, val)
        if err:
            return f"⚠️ {key}: {err}"
        self.app.cfg.set(key, val)
        return f"✅ {key} = <code>{esc(val)}</code>"

    def c_config(self, arg, chat):
        cfg = self.app.cfg
        lines = ["⚙️ <b>Sozlamalar</b> (o'zgartirish: /set KEY VALUE)"]
        for k in SAFE_KEYS:
            lines.append(f"<code>{k}</code> = {esc(clip(cfg.get(k), 70))}")
        lines.append("\n<b>Maxfiy (ko'rsatilmaydi):</b> " + ", ".join(
            f"{k}: {'bor' if cfg.get(k) else 'yo`q'}" for k in sorted(SECRET_KEYS)))
        return "\n".join(lines)

    def c_logs(self, arg, chat):
        n = int(arg) if arg.isdigit() else 25
        t = tail_file(self.app.cfg.dirs["logs"] / "aitube.log", min(80, n))
        return f"<pre>{esc(t[-3500:])}</pre>" if t else "Log bo'sh."

    def c_health(self, arg, chat):
        return health.format_report(health.check(self.app, network=True))

    def c_llm(self, arg, chat):
        a = self.app

        def job():
            try:
                t, label = a.llm.complete("Siz qisqa javob beruvchi yordamchisiz.",
                                          "Bitta jumlada o'zbek tilida salomlashing.", max_tokens=100)
                a.n.say(f"🤖 <b>{esc(label)}</b>\n{esc(clip(t, 300))}")
            except Exception as e:
                a.n.error("LLM ishlamayapti", str(e))

        return "🤖 Sinov ketmoqda…" if a.jobs.submit_light("llmtest", job) else "ℹ️ Band."

    def c_tts(self, arg, chat):
        a = self.app

        def job():
            out = a.cfg.dirs["work"] / "tts_test.wav"
            try:
                prov = a.tts.synth(arg or "Salom! Bu ovoz sinovi. Kanal ishlashga tayyor.", out)
                a.n.file("document", str(out), f"🎙 Ovoz sinovi · provayder: {esc(prov)}")
            except Exception as e:
                a.n.error("Ovoz ishlamayapti", str(e))

        return "🎙 Sinov ketmoqda…" if a.jobs.submit_light("ttstest", job) else "ℹ️ Band."

    def c_video(self, arg, chat):
        a = self.app
        if not arg.strip().isdigit():
            return "Foydalanish: /video 1"
        e = a.db.ep_by_gno(int(arg))
        if not e or not e.get("video_path") or not Path(e["video_path"]).exists():
            return "Bu epizod videosi topilmadi (o'chirilgan yoki hali yasalmagan)."

        def job():
            tgp = telegram_copy(e["video_path"])
            sent = tgp and a.n.file("video", str(tgp), f"▶️ #{e['gno']} {esc(clip(e['title'], 80))}")
            if not sent:
                dst = export_to_downloads(e["video_path"])
                a.n.say("⚠️ Yuborib bo'lmadi. " + (f"Telefon Yuklanmalar papkasiga nusxalandi: <code>{esc(dst.name)}</code>"
                                                   if dst else f"Fayl: <code>{esc(e['video_path'])}</code>"))

        return "📤 Yuborilmoqda…" if a.jobs.submit_light(f"sendvideo-{e['id']}", job) else "ℹ️ Band."

    # ------------------------------------------------- fasllar va qaytish
    def _mutate(self, name, fn, chat, done_text, resume=True):
        """O'zgartiruvchi amal: og'ir navbatda (boshqa ishlar tugagach, ketma-ket) bajariladi,
        shuning uchun ishlayotgan jarayonga xalaqit bermaydi va rad etilmaydi."""
        a = self.app

        def job():
            res = fn()
            msg = done_text(res) if callable(done_text) else done_text
            a.n.say(msg)
            if resume and not a.cfg.bool("PAUSED"):
                a.pipeline.produce_next()

        queued_behind = a.jobs.busy()
        if not a.jobs.submit(name, job):
            return "ℹ️ Bu amal allaqachon navbatda."
        return "🕓 Joriy ish tugagach bajariladi (navbatga qo'yildi)." if queued_behind else "⏳ Bajarilmoqda…"

    @staticmethod
    def _fmt_reset(rows, limit=12):
        lines = [f"• #{g} {esc(clip(t, 40))} <i>[{st}]</i>" for g, t, st in rows[:limit]]
        if len(rows) > limit:
            lines.append(f"… va yana {len(rows) - limit} ta")
        return "\n".join(lines) or "(o'zgarish yo'q)"

    def _confirm(self, chat, text, yes_cb, yes_label="✅ Tasdiqlash"):
        mk = {"inline_keyboard": [[{"text": yes_label, "callback_data": yes_cb},
                                   {"text": "✖️ Bekor", "callback_data": "m:menu"}]]}
        self.tg.send(text, chat=chat, markup=mk)

    def c_seasons(self, arg, chat):
        rows = chain.seasons_overview(self.app.db)
        if not rows:
            return "Fasl yo'q. /make yoki /newseason"
        lines = ["🗂 <b>Fasllar</b>"]
        for r in rows:
            s, c = r["season"], r["counts"]
            lines.append(f"<b>#{s['id']}</b> {esc(clip(s['theme'] or '-', 50))} — {r['total']} qism"
                         + (f" (#{r['first']}–#{r['last']})" if r["first"] else ""))
            lines.append(f"   ✅ {c.get('uploaded', 0)} · 🟢 {c.get('ready', 0)} · 🕓 {c.get('planned', 0)} · "
                         f"❌ {c.get('failed', 0)} · ⏭ {c.get('skipped', 0)}")
        mk = {"inline_keyboard": [[{"text": f"Fasl {r['season']['id']}", "callback_data": f"s:view:{r['season']['id']}"}
                                   for r in rows[-4:]]]}
        self.tg.send("\n".join(lines), chat=chat, markup=mk)

    def _season_view(self, sid, chat):
        db = self.app.db
        s = db.season(sid)
        if not s:
            return self.tg.send("Fasl topilmadi.", chat=chat)
        icon = {"uploaded": "✅", "ready": "🟢", "planned": "🕓", "failed": "❌", "skipped": "⏭"}
        eps = db.season_episodes(sid)
        txt = (f"🗓 <b>Fasl #{sid}: {esc(s['theme'])}</b>\n<i>{esc(clip(s['description'] or '', 250))}</i>\n"
               + "\n".join(f"{icon.get(e['status'], '📝')} {e['gno']}. {esc(clip(e['title'], 55))}" for e in eps))
        mk = {"inline_keyboard": [[
            {"text": "🔁 Qaytadan", "callback_data": f"s:restart:{sid}"},
            {"text": "⏭ O'tkazish", "callback_data": f"s:skip:{sid}"},
            {"text": "↩️ Qaytarish", "callback_data": f"s:unskip:{sid}"}]]}
        self.tg.send(txt, chat=chat, markup=mk)

    def c_season(self, arg, chat):
        db = self.app.db
        parts = arg.split()
        if not parts or not parts[0].isdigit():
            return ("Foydalanish:\n/season N — ko'rish\n/season N restart — yuklanmaganlarni qaytadan\n"
                    "/season N skip · /season N unskip\n/season N rename Yangi mavzu")
        sid = int(parts[0])
        if not db.season(sid):
            return "Fasl topilmadi. /seasons"
        sub = parts[1].lower() if len(parts) > 1 else "view"
        if sub == "view":
            return self._season_view(sid, chat)
        if sub == "rename":
            name = " ".join(parts[2:]).strip()
            if not name:
                return "Foydalanish: /season 1 rename Yangi mavzu"
            db.rename_season(sid, clip(name, 120))
            return f"✅ Fasl #{sid} nomi o'zgartirildi."
        if sub in ("restart", "skip", "unskip"):
            return self._season_action(sub, sid, chat, confirmed=parts[-1].lower() == "ok")
        return "Noma'lum amal. /season"

    def _season_action(self, sub, sid, chat, confirmed):
        db = self.app.db
        fn = {"restart": chain.season_restart, "skip": chain.season_skip, "unskip": chain.season_unskip}[sub]
        if not confirmed:
            r = fn(db, sid, dry=True)
            rows = r.get("reset") or r.get("skipped") or []
            if not rows:
                return "ℹ️ O'zgartiradigan epizod yo'q."
            what = {"restart": "qaytadan boshlanadi", "skip": "o'tkazib yuboriladi", "unskip": "zanjirga qaytariladi"}[sub]
            self._confirm(chat, f"⚠️ Fasl #{sid}: quyidagi epizodlar {what} (fayllari o'chadi, yuklanganlarga tegilmaydi):\n"
                          + self._fmt_reset(rows), f"s:{sub}ok:{sid}")
            return None
        def done(r):
            rows = r.get("reset") or r.get("skipped") or []
            return f"✅ Fasl #{sid}: {len(rows)} ta epizod yangilandi." + (" Ishlab chiqarish davom etadi." if sub != "skip" else "")
        return self._mutate(f"season-{sub}-{sid}", lambda: fn(db, sid), chat, done, resume=sub != "skip")

    def c_back(self, arg, chat):
        parts = arg.split()
        if not parts or not parts[0].isdigit():
            return ("Foydalanish: /back 5 — 5-epizod va undan keyingilarni qaytadan yasash.\n"
                    "Yuklangan epizod uchun: /back 5 force (YouTube'dagi eski video o'chmaydi).")
        gno = int(parts[0])
        force = "force" in [p.lower() for p in parts[1:]]
        return self._back(gno, force, chat, confirmed=parts[-1].lower() == "ok")

    def _back(self, gno, force, chat, confirmed):
        db = self.app.db
        r = chain.rewind(db, gno, force=force, dry=True)
        if r.get("error") == "topilmadi":
            return "Epizod topilmadi."
        if r.get("error") == "uploaded":
            self._confirm(chat, f"⚠️ #{gno} allaqachon YouTube'ga yuklangan. Baribir qaytadan yasaymizmi? "
                          "Eski video YouTube'da qoladi (uni o'zingiz o'chirasiz), yangisi alohida yuklanadi.",
                          f"e:backokf:{gno}", "✅ Ha, force")
            return None
        if not r["reset"]:
            return "ℹ️ Qaytadan boshlanadigan epizod yo'q (hammasi rejada)."
        if not confirmed:
            self._confirm(chat, f"⚠️ #{gno} dan boshlab qaytadan yasaladi:\n" + self._fmt_reset(r["reset"]),
                          f"e:backok{'f' if force else ''}:{gno}")
            return None
        return self._mutate(f"back-{gno}", lambda: chain.rewind(db, gno, force=force), chat,
                            lambda r: f"↩️ #{gno} ga qaytildi: {len(r.get('reset', []))} ta epizod qayta rejaga qo'yildi. Yasash davom etadi.")

    def c_unskip(self, arg, chat):
        db = self.app.db
        parts = arg.split()
        if not parts or not parts[0].isdigit():
            rows = db.by_status("skipped")
            if not rows:
                return "O'tkazilgan epizod yo'q."
            mk = {"inline_keyboard": [[{"text": f"↩️ #{e['gno']}", "callback_data": f"e:unskip:{e['gno']}"}
                                       for e in rows[:6]]]}
            self.tg.send("⏭ <b>O'tkazilganlar</b>\n" + "\n".join(
                f"#{e['gno']} {esc(clip(e['title'], 55))}" for e in rows[:20])
                + "\n\nQaytarish: /unskip N  (keyingi tayyorlarni saqlash: /unskip N keep)", chat=chat, markup=mk)
            return None
        return self._unskip(int(parts[0]), "keep" not in [p.lower() for p in parts[1:]], chat,
                            confirmed=parts[-1].lower() == "ok")

    def _unskip(self, gno, cascade, chat, confirmed):
        db = self.app.db
        r = chain.unskip(db, gno, cascade=cascade, dry=True)
        if r.get("error") == "topilmadi":
            return "Epizod topilmadi."
        if r.get("error") == "not_skipped":
            return f"ℹ️ #{gno} o'tkazilmagan (holat: {r['ep']['status']})."
        if not confirmed:
            extra = "\nKeyingi tayyor epizodlar ham qayta yasaladi (ular zanjirda shu qismga bog'liq)." if len(r["reset"]) > 1 else ""
            self._confirm(chat, f"↩️ #{gno} zanjirga qaytariladi:\n" + self._fmt_reset(r["reset"]) + extra,
                          f"e:unskipok{'' if cascade else 'k'}:{gno}")
            return None
        return self._mutate(f"unskip-{gno}", lambda: chain.unskip(db, gno, cascade=cascade), chat,
                            lambda r: f"✅ #{gno} qaytarildi ({len(r.get('reset', []))} ta epizod rejada). Yasash davom etadi.")

    def c_forget(self, arg, chat):
        db = self.app.db
        parts = arg.split()
        if not parts:
            rows = sorted(db.uploaded(100), key=lambda e: e["gno"])
            if not rows:
                return "Yuklangan epizod yo'q."
            btn = [{"text": f"🗑 #{e['gno']}", "callback_data": f"e:forget:{e['gno']}"} for e in rows[-6:]]
            mk = {"inline_keyboard": [btn, [{"text": "🗑 Hammasini unutish", "callback_data": "e:forgetall:0"}]]}
            self.tg.send("🗑 <b>Yuklangan videolarni unutish</b>\n" + "\n".join(
                f"#{e['gno']} {esc(clip(e['title'], 55))}" for e in rows[-20:])
                + "\n\nUnutilgan epizod yuklanmagan holatga qaytadi va noldan qayta yasaladi.\n"
                  "/forget N · /forget all", chat=chat, markup=mk)
            return None
        confirmed = parts[-1].lower() == "ok"
        if parts[0].lower() in ("all", "hammasi"):
            return self._forget(None, chat, confirmed)
        if parts[0].isdigit():
            return self._forget(int(parts[0]), chat, confirmed)
        return "Foydalanish: /forget 5 yoki /forget all"

    def _forget(self, gno, chat, confirmed):
        db = self.app.db
        r = chain.forget_uploaded(db, gno, dry=True)
        if r.get("error") == "topilmadi":
            return "Epizod topilmadi."
        if r.get("error") == "yo'q":
            return "Yuklangan epizod yo'q."
        if r.get("error") == "not_uploaded":
            return f"ℹ️ #{gno} yuklanmagan (holat: {r['ep']['status']})."
        who = "Barcha yuklangan videolar" if gno is None else f"#{gno}"
        if not confirmed:
            self._confirm(chat, f"🗑 {who} unutiladi — yuklanmagan holatga qaytadi va eski ssenariy, ovoz va video "
                                "sozlamalari tashlanib, joriy sozlamalar bilan <b>noldan</b> qayta yasaladi "
                                "(sarlavha, mavzu va va'da saqlanadi):\n" + self._fmt_reset(r["reset"])
                          + "\n\nYouTube'dagi eski video o'chmaydi (uni o'zingiz o'chirasiz); yangisi alohida yuklanadi.",
                          f"e:forgetok:{gno}" if gno is not None else "e:forgetallok:0", "✅ Unutish")
            return None
        return self._mutate(f"forget-{gno or 'all'}", lambda: chain.forget_uploaded(db, gno), chat,
                            lambda r: f"🗑 {len(r.get('reset', []))} ta epizod unutildi (yuklanmagan holatga qaytdi). "
                                      "Noldan qayta yasash boshlandi; tayyor bo'lgach /upload bilan yuklaysiz.")

    def c_edit(self, arg, chat):
        parts = arg.split(None, 2)
        if len(parts) < 3 or not parts[0].isdigit():
            return ("Foydalanish: /edit 7 title Yangi sarlavha\n/edit 7 topic Yangi mavzu\n"
                    "/edit 7 promise Nima o'rgatadi\n/edit 7 kind code|system|talk\n(faqat rejadagi epizodlar)")
        err = chain.edit_planned(self.app.db, int(parts[0]), parts[1].lower(), parts[2])
        return f"❌ {esc(err)}" if err else f"✅ #{parts[0]} {parts[1].lower()} yangilandi."

    def c_voice(self, arg, chat):
        from .tts import VOICE_ALIASES, VOICE_PRESETS
        a = self.app
        cfg = a.cfg
        parts = arg.split()
        if not parts:
            cur = f"{cfg.get('TTS_VOICE')} · {cfg.get('TTS_RATE')} · {cfg.get('TTS_PITCH')}"
            lines = [f"🎙 <b>Ovoz</b>: <code>{esc(cur)}</code>", ""]
            lines += [f"<code>{k}</code> — {esc(v[3])}" for k, v in VOICE_PRESETS.items()]
            lines.append("\nTanlash: /voice yigit2 · Eshitib ko'rish: /voice test qiz3")
            lines.append("Qo'lda: /voice uz-UZ-SardorNeural · /set TTS_RATE +5% · /set TTS_PITCH -8Hz")
            mk = {"inline_keyboard": [
                [{"text": k, "callback_data": f"v:{k}"} for k in ("yigit1", "yigit2", "yigit3")],
                [{"text": k, "callback_data": f"v:{k}"} for k in ("qiz1", "qiz2", "qiz3")],
                [{"text": "🎧 Joriyni eshitish", "callback_data": "v:test"}]]}
            self.tg.send("\n".join(lines), chat=chat, markup=mk)
            return None
        test = parts[0].lower() == "test"
        name = (parts[1] if test and len(parts) > 1 else parts[0]).lower()
        name = VOICE_ALIASES.get(name, name)
        if test and len(parts) == 1:
            return self._voice_test(chat)
        if name in VOICE_PRESETS:
            v, rate, pitch, desc = VOICE_PRESETS[name]
        elif name.startswith(("uz-uz-", "ru-ru-", "tr-tr-", "kk-kz-")) or "-" in parts[0] and "neural" in parts[0].lower():
            v, rate, pitch, desc = parts[-1] if not test else parts[1], cfg.get("TTS_RATE"), cfg.get("TTS_PITCH"), "qo'lda"
        else:
            return "Noma'lum ovoz. /voice — ro'yxat."
        if test:
            return self._voice_test(chat, (v, rate, pitch))
        cfg.set("TTS_VOICE", v)
        cfg.set("TTS_RATE", rate)
        cfg.set("TTS_PITCH", pitch)
        if v.startswith("uz-UZ-"):
            cfg.set("TTS_ORDER", "edge,google")
        self._voice_test(chat)
        return (f"✅ Ovoz: {esc(desc)}. Keyingi epizodlarda ishlaydi; tayyorlarini yangi ovozda: /remake N yoki /back N.\n"
                "Eslatma: edge-tts ishlamasa Google ovoziga (qiz) o'tadi.")

    def _voice_test(self, chat, spec=None):
        a = self.app
        cfg = a.cfg

        def job():
            out = cfg.dirs["work"] / f"voice_test_{int(time.time())}.wav"
            try:
                prov = a.tts.synth("Salom! Men sizning kanalingiz ovoziman. Keyingi qismda ko'rishguncha!", out,
                                   spec=spec or (cfg.get("TTS_VOICE"), cfg.get("TTS_RATE"), cfg.get("TTS_PITCH")))
                a.n.file("document", str(out), f"🎧 Ovoz namunasi · {esc(prov)}")
            except Exception as e:
                a.n.error("Ovoz namunasi chiqmadi", str(e))
            finally:
                try:
                    out.unlink()
                except OSError:
                    pass

        return "🎧 Namuna tayyorlanmoqda…" if a.jobs.submit_light("voicetest", job) else "ℹ️ Band."

    def c_format(self, arg, chat):
        v = arg.strip().lower()
        if v not in ("landscape", "shorts"):
            return f"Format: <code>{esc(self.app.cfg.get('VIDEO_FORMAT'))}</code>\n/format landscape yoki /format shorts"
        self.app.cfg.set("VIDEO_FORMAT", v)
        return f"✅ Format: {v}. Keyingi yasaladigan epizodlarga qo'llanadi."

    def _ep_buttons(self, e):
        st, g = e["status"], e["gno"]
        row = []
        if st == "skipped":
            row.append(("↩️ Qaytarish", f"e:unskip:{g}"))
        else:
            if st != "uploaded":
                row += [("🔄 Qayta", f"e:remake:{g}"), ("⏭ O'tkaz", f"e:skip:{g}")]
            else:
                row.append(("🗑 Unutish", f"e:forget:{g}"))
            row.append(("↩️ Shundan qayta", f"e:back:{g}"))
        if e.get("video_path") and Path(e["video_path"]).exists():
            row.append(("📤 Video", f"e:video:{g}"))
        return {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in row]]}

    def _ep_callback(self, act, gno, chat):
        a = self.app
        if act == "remake":
            return self.c_remake(str(gno), chat)
        if act == "skip":
            return self.c_skip(str(gno), chat)
        if act == "video":
            return self.c_video(str(gno), chat)
        if act == "back":
            return self._back(gno, False, chat, False)
        if act == "backok":
            return self._back(gno, False, chat, True)
        if act == "backokf":
            return self._back(gno, True, chat, True)
        if act == "forget":
            return self._forget(gno, chat, False)
        if act == "forgetok":
            return self._forget(gno, chat, True)
        if act == "forgetall":
            return self._forget(None, chat, False)
        if act == "forgetallok":
            return self._forget(None, chat, True)
        if act == "unskip":
            return self._unskip(gno, True, chat, False)
        if act == "unskipok":
            return self._unskip(gno, True, chat, True)
        if act == "unskipokk":
            return self._unskip(gno, False, chat, True)
        return None

    def c_backup(self, arg, chat):
        a = self.app
        dst = a.cfg.dirs["work"] / "aitube_backup.db"
        with a.db.lock:
            a.db.conn.commit()
            import sqlite3
            b = sqlite3.connect(str(dst))
            a.db.conn.backup(b)
            b.close()
        a.n.file("document", str(dst), "💾 Baza nusxasi")

    def c_restart(self, arg, chat):
        self.tg.send("♻️ Qayta ishga tushirilmoqda…", chat=chat)
        threading.Timer(1.5, lambda: os._exit(0)).start()

    def _auth_loopback(self, reason=""):
        a = self.app
        if self.auth_thread and self.auth_thread.is_alive():
            return "ℹ️ Avtorizatsiya jarayoni allaqachon ketmoqda."

        def on_url(url):
            a.n.say("🔑 <b>YouTube ga ulanish</b>\n1) Quyidagi havolani <b>shu telefonda</b> oching va hisobingizni tanlang:\n"
                    f"{esc(url)}\n2) «Google bu ilovani tekshirmagan» chiqsa: <i>Advanced → Continue</i>.\n"
                    "3) Barcha ruxsatlarni bering. «Tayyor!» sahifasi chiqsa, shu yerga qayting.\n"
                    "⏳ 10 daqiqa kutiladi. Termux ochiq turishi kerak.")

        def run():
            try:
                ok = a.yt.loopback_auth(on_url)
                if ok:
                    ch = {}
                    try:
                        ch = a.yt.channel()
                    except Exception:
                        pass
                    a.n.say("✅ <b>YouTube ulandi!</b>" + (f"\nKanal: {esc(ch.get('title', ''))} · obunachilar {ch.get('subs', 0)}" if ch else ""))
                else:
                    a.n.say("⌛ Avtorizatsiya vaqti tugadi. /auth ni qayta yuboring.")
            except Exception as e:
                a.n.say(f"❌ Avtorizatsiya xatosi: {esc(clip(str(e), 300))}")

        self.auth_thread = threading.Thread(target=run, daemon=True, name="yt-auth")
        self.auth_thread.start()
        return None

    def c_auth(self, arg, chat):
        a = self.app
        if arg.strip().lower() == "reset":
            a.yt.logout()
            return "🔓 YouTube hisobidan chiqildi."
        if not a.yt.configured():
            return ("YT_CLIENT_ID va YT_CLIENT_SECRET sozlanmagan.\n"
                    "Google Cloud Console → Credentials → OAuth client ID → <b>TVs and Limited Input devices</b>.\n"
                    "Qiymatlarni .env ga yozing yoki: python main.py setup")
        if self.auth_thread and self.auth_thread.is_alive():
            return "ℹ️ Avtorizatsiya jarayoni allaqachon ketmoqda."
        try:
            if a.cfg.get("YT_AUTH_MODE") == "loopback":
                raise YTError("loopback rejimi tanlangan")
            dev = a.yt.device_start()
        except Exception as e:
            if a.cfg.get("YT_AUTH_MODE") == "device":
                return f"❌ Boshlab bo'lmadi: <pre>{esc(clip(str(e), 500))}</pre>"
            return self._auth_loopback(str(e))
        url = dev.get("verification_url") or dev.get("verification_uri", "https://google.com/device")

        def poll():
            try:
                ok = a.yt.device_poll(dev)
                if ok:
                    ch = {}
                    try:
                        ch = a.yt.channel()
                    except Exception:
                        pass
                    a.n.say("✅ <b>YouTube ulandi!</b>" + (f"\nKanal: {esc(ch.get('title', ''))} · obunachilar {ch.get('subs', 0)}" if ch else ""))
                else:
                    a.n.say("⌛ Avtorizatsiya vaqti tugadi. /auth ni qayta yuboring.")
            except YTError as e:
                a.n.say(f"❌ Avtorizatsiya xatosi: {esc(clip(str(e), 300))}")

        self.auth_thread = threading.Thread(target=poll, daemon=True, name="yt-auth")
        self.auth_thread.start()
        return (f"🔑 <b>YouTube ga ulanish</b>\n1) Ochish: {url}\n2) Kodni kiriting: <code>{dev['user_code']}</code>\n"
                f"3) Kanalingiz hisobini tanlab ruxsat bering.\nKod {int(dev.get('expires_in', 1800)) // 60} daqiqa amal qiladi.")
