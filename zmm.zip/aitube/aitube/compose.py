"""Skriptdan to'liq sahnalar ro'yxatini (kirish, oldingi qism xulosasi, asosiy qism, keyingi qism taklifi)
va YouTube tavsifini yig'adi."""
from __future__ import annotations

import re

from .text import tr
from .util import clip
from .video import chapters

NEXT_MARKER = "▶ "


def episode_label(cfg, gno: int) -> str:
    return f"{tr(cfg.get('LANGUAGE'))['part'].upper()} {gno}"


def compose_scenes(cfg, ep, script, prev, nxt) -> list:
    lang = tr(cfg.get("LANGUAGE"))
    channel = cfg.get("CHANNEL_NAME")
    scenes = [{
        "type": "title", "title": script["title"], "label": episode_label(cfg, ep["gno"]),
        "subtitle": channel, "narration": script["hook"], "chapter": lang["intro_chapter"],
    }]
    if prev and script.get("recap"):
        scenes.append({
            "type": "recap", "label": lang["recap_label"].upper(), "title": prev["title"],
            "text": script["recap"], "narration": script["recap"], "chapter": lang["recap_chapter"],
        })
    for s in script["scenes"]:
        sc = dict(s)
        sc["chapter"] = sc.get("heading") or ""
        scenes.append(sc)
    teaser = script["teaser"].strip()
    scenes.append({
        "type": "outro", "label": lang["next_label"].upper(),
        "title": nxt["title"] if nxt else channel,
        "cta": lang["cta_short"].upper(), "narration": f"{teaser} {lang['cta']}".strip(),
        "chapter": lang["outro_chapter"],
    })
    return scenes


def yt_title(cfg, ep, script) -> str:
    suffix = f" (#{ep['gno']})"
    base = re.sub(r"[<>]", "", script["title"]).strip()
    return clip(base, 100 - len(suffix)) + suffix


def next_line(cfg, nxt_title: str, url: str | None) -> str:
    lang = tr(cfg.get("LANGUAGE"))
    marker = f"{NEXT_MARKER}{lang['next_link']}:"
    if url:
        return f"{marker} {nxt_title} → {url}"
    return f"{marker} {nxt_title} ({'tez orada' if cfg.get('LANGUAGE').startswith('uz') else 'coming soon'})"


def next_marker(cfg) -> str:
    return f"{NEXT_MARKER}{tr(cfg.get('LANGUAGE'))['next_link']}:"


def build_description(cfg, ep, script, scenes, prev_url: str | None, nxt_title: str | None, prev_title="") -> str:
    lang = tr(cfg.get("LANGUAGE"))
    parts = [script["description"].strip()]
    ch = chapters(scenes)
    if ch:
        from .util import fmt_dur
        parts.append(lang["chapters"] + ":\n" + "\n".join(f"{fmt_dur(t)} {n}" for t, n in ch))
    nav = []
    if prev_url:
        nav.append(f"◀ {lang['prev_link']}: {prev_title} → {prev_url}" if prev_title else
                   f"◀ {lang['prev_link']}: {prev_url}")
    if nxt_title:
        nav.append(next_line(cfg, nxt_title, None))
    if nav:
        parts.append("\n".join(nav))
    parts.append(lang["ai_note"])
    tags = ["#" + re.sub(r"[^\w]", "", t, flags=re.U) for t in script.get("tags", [])[:3]]
    tags = [t for t in tags if len(t) > 1]
    if tags:
        parts.append(" ".join(tags))
    return "\n\n".join(p for p in parts if p)
