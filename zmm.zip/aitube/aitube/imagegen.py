"""AI rasm yaratish BUTUNLAY O'CHIRILGAN (DISABLED = True): hech qanday tarmoq yoki LLM so'rovi yuborilmaydi,
.env dagi AI_IMAGES qiymatidan qat'i nazar. Video va muqova odatdagi (chizilgan) ko'rinishda yasaladi.
(Quyidagi kod faqat tarixiy sabab bilan saqlangan; hech qayerdan chaqirilmaydi.)

Eski tavsif — AI rasmlar (suv belgisiz): muqova va video foni uchun. Provayderlar ketma-ket sinaladi
(Pollinations - kalitsiz; Together FLUX va HuggingFace - kalit bo'lsa). Hech qachon istisno chiqarmaydi:
rasm olinmasa None qaytadi va video/muqova odatdagi (chizilgan) ko'rinishda yasaladi.
Har epizod uchun uslub va tasvir boshqacha (seed = epizod raqami)."""
from __future__ import annotations

import io
import random
import time
from pathlib import Path
from urllib.parse import quote

from PIL import Image, ImageOps, ImageStat

from .util import http, log, sha1

DISABLED = True       # AI rasm yaratilmaydi: fetch() va episode_art() darhol bo'sh natija qaytaradi

STYLES = [
    "isometric 3D illustration, soft studio light, pastel and neon accents",
    "cyberpunk neon city at night, volumetric light, cinematic",
    "minimal flat vector art, bold geometric shapes, clean gradients",
    "blueprint technical drawing glowing on dark navy, fine lines",
    "low-poly 3D scene, crystal facets, ambient occlusion",
    "glassmorphism abstract shapes, frosted glass, colorful depth of field",
    "holographic interface floating in space, particles, bokeh",
    "paper-cut layered art, depth shadows, vibrant gradient palette",
    "retro synthwave landscape, glowing grid, sunset gradient",
    "futuristic data center corridor, light trails, cinematic wide shot",
    "watercolor and ink tech concept art, textured paper",
    "dark mode abstract network of glowing nodes, macro photography look",
]
SUFFIX = ", no text, no letters, no words, no watermark, no logo, no signature, high detail, 4k"

SYSTEM = ("You write short English prompts for an AI image generator. The images illustrate Uzbek programming "
          "tutorial videos. Never include text, letters, logos or people's faces in the picture.")
PROMPT = """Video topic: {title}
Summary: {summary}

Write TWO image prompts (English, each 12-30 words) that visually symbolize this topic with concrete objects/metaphors \
(not code text). Art style for both: {style}.
1) "thumb": eye-catching hero image for the video cover (clear focal object, space on the left for a title).
2) "scene": calmer, darker, wide background image with low contrast (will be dimmed behind text).
Return ONLY JSON: {{"thumb": "...", "scene": "..."}}"""


def style_for(gno: int, override: str = "") -> str:
    if override and override.lower() != "auto":
        return override
    return STYLES[(int(gno) * 5 + 2) % len(STYLES)]


def _valid(data: bytes):
    """Baytlardan to'g'ri rasm (RGB) yoki None: buzuq/xato sahifa/bir tekis rasmlar rad etiladi."""
    if not data or len(data) < 4000:
        return None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
        im = im.convert("RGB")
    except Exception:  # noqa: BLE001
        return None
    if min(im.size) < 256:
        return None
    st = ImageStat.Stat(im.resize((32, 32)))
    if max(st.stddev) < 4:          # deyarli bir rang: xato yoki bo'sh rasm
        return None
    return im


def _pollinations(cfg, prompt, w, h, seed):
    base = (cfg.get("POLLINATIONS_IMG_BASE") or "https://image.pollinations.ai").rstrip("/")
    r = http("GET", f"{base}/prompt/{quote(prompt, safe='')}", retries=2, timeout=(15, 150),
             params={"width": w, "height": h, "seed": seed, "nologo": "true", "model": "flux",
                     "private": "true", "enhance": "false", "safe": "true"})
    ct = r.headers.get("Content-Type", "")
    if r.status_code != 200 or not ct.startswith("image"):
        raise RuntimeError(f"HTTP {r.status_code} {ct[:30]}")
    return r.content


def _together(cfg, prompt, w, h, seed):
    keys = cfg.list("TOGETHER_API_KEYS")
    if not keys:
        raise RuntimeError("kalit yo'q")
    import base64
    base = (cfg.get("TOGETHER_BASE") or "https://api.together.xyz").rstrip("/")
    last = None
    for k in keys:
        r = http("POST", f"{base}/v1/images/generations", retries=2, timeout=(15, 150),
                 headers={"Authorization": f"Bearer {k}"},
                 json={"model": cfg.get("TOGETHER_IMG_MODEL") or "black-forest-labs/FLUX.1-schnell-Free",
                       "prompt": prompt, "width": min(w, 1440), "height": min(h, 1440), "steps": 4, "seed": seed,
                       "n": 1, "response_format": "b64_json"})
        if r.status_code == 200:
            try:
                return base64.b64decode(r.json()["data"][0]["b64_json"])
            except Exception as e:  # noqa: BLE001
                last = e
                continue
        last = RuntimeError(f"HTTP {r.status_code}")
    raise last or RuntimeError("together xato")


def _huggingface(cfg, prompt, w, h, seed):
    keys = cfg.list("HF_API_KEYS")
    if not keys:
        raise RuntimeError("kalit yo'q")
    base = (cfg.get("HF_BASE") or "https://api-inference.huggingface.co").rstrip("/")
    model = cfg.get("HF_IMG_MODEL") or "black-forest-labs/FLUX.1-schnell"
    last = None
    for k in keys:
        r = http("POST", f"{base}/models/{model}", retries=2, timeout=(15, 150),
                 headers={"Authorization": f"Bearer {k}"},
                 json={"inputs": prompt, "parameters": {"width": w, "height": h, "seed": seed}})
        if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
            return r.content
        last = RuntimeError(f"HTTP {r.status_code}")
    raise last or RuntimeError("huggingface xato")


PROVIDERS = {"pollinations": _pollinations, "together": _together, "huggingface": _huggingface}


def fetch(cfg, prompt: str, w: int, h: int, seed: int):
    """(PIL.Image | None, provayder_nomi). Kesh: bir xil so'rov qayta yuklanmaydi."""
    if DISABLED:
        return None, ""
    full = prompt.strip().rstrip(".") + SUFFIX
    key = sha1(full, w, h, seed)
    cp = cfg.dirs["cache"] / f"img_{key}.jpg"
    if cp.exists():
        try:
            im = Image.open(cp)
            im.load()
            return im.convert("RGB"), "cache"
        except Exception:  # noqa: BLE001
            pass
    for name in cfg.list("IMG_ORDER") or ["pollinations"]:
        fn = PROVIDERS.get(name)
        if not fn:
            continue
        for attempt in range(2):
            try:
                im = _valid(fn(cfg, full, w, h, seed + attempt * 7))
                if im is not None:
                    im = ImageOps.fit(im, (w, h), Image.LANCZOS)
                    try:
                        im.save(cp, "JPEG", quality=88)
                    except OSError:
                        pass
                    return im, name
                log.warning("AI rasm yaroqsiz (%s, urinish %d)", name, attempt + 1)
            except Exception as e:  # noqa: BLE001
                log.warning("AI rasm xatosi (%s): %s", name, str(e)[:160])
                break
            # yaroqsiz rasm: kutmasdan boshqa urug' (seed) bilan darhol qayta uriniladi
    return None, ""


def _fallback_prompts(script: dict, style: str) -> dict:
    t = (script.get("title") or "programming").split("(")[0].strip()
    return {"thumb": f"symbolic hero illustration for the topic '{t}', one clear focal object, {style}",
            "scene": f"wide dark abstract background inspired by '{t}', low contrast, {style}"}


def make_prompts(cfg, llm, script: dict, style: str) -> dict:
    fb = _fallback_prompts(script, style)
    if llm is None:
        return fb
    try:
        obj, _ = llm.complete_json(SYSTEM, PROMPT.format(title=script.get("title", ""),
                                                         summary=(script.get("summary") or "")[:400], style=style),
                                   tries=2)
        out = {}
        for k in ("thumb", "scene"):
            v = str(obj.get(k, "")).strip() if isinstance(obj, dict) else ""
            out[k] = v if 8 <= len(v) <= 400 else fb[k]
        return out
    except Exception as e:  # noqa: BLE001
        log.warning("Rasm so'rovlarini yozib bo'lmadi, standart ishlatiladi: %s", str(e)[:120])
        return fb


def episode_art(cfg, llm, script: dict, gno: int, budget: float = 240.0) -> dict:
    """{'thumb': Image|None, 'bg': Image|None, 'style': str, 'src': {...}}. Hech qachon istisno chiqarmaydi."""
    res = {"thumb": None, "bg": None, "style": "", "src": {}}
    if DISABLED:
        return res
    try:
        if not cfg.bool("AI_IMAGES"):
            return res
        t0 = time.time()
        style = style_for(gno, cfg.get("IMG_STYLE"))
        res["style"] = style
        pr = make_prompts(cfg, llm, script, style)
        seed = 1000 + int(gno) * 37
        im, src = fetch(cfg, pr["thumb"], 1280, 720, seed)
        res["thumb"], res["src"]["thumb"] = im, src
        if im is not None and time.time() - t0 < budget:
            bg, src2 = fetch(cfg, pr["scene"], 1280, 720, seed + 1)
            res["bg"], res["src"]["bg"] = bg, src2
    except Exception as e:  # noqa: BLE001
        log.warning("AI rasmlar yaratilmadi: %s", e)
    return res
