"""Faqat sinov (selftest) uchun: tarmoqsiz deterministik 'LLM'.

Haqiqiy ishda ishlatilmaydi (LLM_ORDER da 'mock' yo'q). Selftest butun zanjirni
(reja -> ssenariy -> ovoz -> video -> yuklash) tarmoqsiz tekshirishi uchun kerak.
"""
from __future__ import annotations

import json
import re

TOPICS = [
    ("Python bilan birinchi skript", "code"),
    ("Funksiyalar va modullar", "code"),
    ("Linux buyruqlar qatori asoslari", "system"),
    ("HTTP so'rovlar va API", "code"),
    ("Ma'lumotlar bazasi SQLite", "system"),
    ("Telegram bot yaratamiz", "project"),
    ("Docker nima va nega kerak", "explainer"),
    ("Git bilan jamoada ishlash", "tool"),
    ("Dasturlash tillari tarixi", "history"),
    ("Mini-loyiha: vazifalar ro'yxati", "project"),
]

CODES = [
    ("main.py", "python", "name = 'dunyo'\nprint('salom', name)\nfor i in range(3):\n    print(i * 2)"),
    ("calc.py", "python", "def add(a, b):\n    return a + b\n\nprint(add(2, 3))\nprint(add(10, 5))"),
    ("run.sh", "bash", "#!/bin/sh\nfor f in *.txt; do\n  wc -l \"$f\"\ndone"),
    ("data.py", "python", "import json\nd = {'a': 1, 'b': [1, 2, 3]}\ns = json.dumps(d)\nprint(json.loads(s)['b'])"),
]


def _ctx(prompt: str) -> dict:
    m = re.search(r"KONTEKST \(JSON\):\n(.*)\Z", prompt, re.S)
    return json.loads(m.group(1)) if m else {}


def _narr(subject: str, n: int) -> str:
    base = (f"Bu sahnada {subject} haqida gaplashamiz va har bir qadamni sekin tushuntiramiz. "
            f"Ekrandagi misolga e'tibor bering, chunki aynan shu yerda asosiy g'oya ko'rinadi. "
            f"Keyin buni o'zingiz sinab ko'rishingiz mumkin bo'ladi. Qadam raqami {n}.")
    return base


def mock_llm(system: str, prompt: str) -> str:
    if "Write TWO image prompts" in prompt:
        return json.dumps({"thumb": "a glowing server rack with cables, cinematic light, one focal object",
                           "scene": "wide dark abstract network of nodes, low contrast background"})
    ctx = _ctx(prompt)
    if "TASK: stream_outline" in prompt:
        k = int(re.search(r"next (\d+) consecutive", prompt).group(1))
        return json.dumps({"parts": [{"focus": f"Qism {i + 1} mavzusi"} for i in range(k)]})
    if "TASK: stream_segment" in prompt:
        final = "THIS IS THE FINAL SEGMENT" in prompt
        m = re.search(r"Segment number: (\d+)", prompt)
        no = int(m.group(1)) if m else 1
        n = 1 if final else 2
        scenes = []
        for i in range(n):
            kind = ["bullets", "flow", "diagram"][(no + i) % 3]
            sc = {"type": kind, "heading": f"Bo'lak {no}.{i + 1}",
                  "narration": ("API deganda ikki dastur bir-biri bilan so'rov va javob orqali gaplashadi va "
                                f"shu tarzda ish ko'rinishi {no} dan {i + 1} qadamda tushuntiriladi, kalit va manzil bilan.")}
            if kind == "bullets":
                sc["bullets"] = ["So'rov", "Javob", "Kalit"]
            elif kind == "flow":
                sc["steps"] = ["Mijoz", "Server", "Javob"]
            else:
                sc["nodes"] = [{"id": "u", "kind": "user", "label": "Mijoz"}, {"id": "s", "kind": "server", "label": "API"}]
                sc["links"] = [{"from": "u", "to": "s", "label": "so'rov"}, {"from": "s", "to": "u", "label": "javob", "kind": "response"}]
            scenes.append(sc)
        out = {"scenes": scenes, "summary": f"{no}-bo'lak API asoslarini tushuntirdi.", "covered": [f"qadam {no}"]}
        if final:
            out["goodbye"] = "Bugungi translatsiya tugadi. E'tiboringiz uchun rahmat, yana ko'rishamiz."
        return json.dumps(out, ensure_ascii=False)
    if "TASK: plan_season" in prompt:
        n = int(re.search(r"exactly (\d+) episodes", prompt).group(1))
        have = len(ctx.get("existing_titles", []))
        eps = []
        for i in range(n):
            t, kind = TOPICS[(have + i) % len(TOPICS)]
            title = f"{t} (S{have // max(1, n) + 1}-{i + 1})"
            eps.append({"title": title, "topic": f"{t} mavzusini amaliy misollar bilan o'rganamiz.",
                        "promise": f"{t} bo'yicha asosiy ko'nikmalarni egallaysiz.", "kind": kind})
        return json.dumps({"season_theme": f"Dasturchi yo'li {have // max(1, n) + 1}-fasl",
                           "season_description": "Noldan boshlab amaliy loyihagacha ketma-ket kurs.",
                           "episodes": eps}, ensure_ascii=False)
    if "TASK: write_episode" in prompt:
        ep = ctx["episode"]
        prev, nxt = ctx.get("previous"), ctx.get("next")
        scenes = []
        for i in range(8):
            kind = ["bullets", "code", "diagram", "explain", "compare", "parts", "code", "diagram"][i]
            sc = {"type": kind, "heading": f"{i + 1}. {ep['title'][:30]}", "narration": _narr(ep["topic"][:50], i + 1)}
            if kind == "bullets":
                sc["bullets"] = ["Asosiy g'oya", "Amaliy misol", "Keng tarqalgan xato", "Tezkor maslahat"]
            elif kind == "flow":
                sc["steps"] = ["Reja tuzish", "Kod yozish", "Sinab ko'rish", "Yaxshilash"]
            elif kind == "diagram":
                sc["nodes"] = [{"id": "u", "kind": "user", "label": "Foydalanuvchi"},
                               {"id": "s", "kind": "server", "label": "Server"},
                               {"id": "d", "kind": "db", "label": "Baza"}]
                sc["links"] = [{"from": "u", "to": "s", "label": "so'rov"},
                               {"from": "s", "to": "d", "label": "SQL", "kind": "data"},
                               {"from": "d", "to": "s", "label": "natija", "kind": "response"},
                               {"from": "s", "to": "u", "label": "javob", "kind": "response"}]
            elif kind == "explain":
                sc.update({"term": "API", "icon": "link", "definition": "API — ikki dastur bir-biri bilan gaplashadigan qoidalar to'plami.",
                           "analogy": "Xuddi restorandagi ofitsiant kabi: buyurtmani oshxonaga olib boradi.",
                           "points": ["So'rov yuboriladi", "Javob qaytadi"]})
            elif kind == "parts":
                sc["items"] = [{"icon": "user", "name": "Mijoz", "role": "So'rov yuboradi"},
                               {"icon": "server", "name": "Server", "role": "So'rovni qabul qiladi"},
                               {"icon": "db", "name": "Baza", "role": "Ma'lumotni saqlaydi"}]
            elif kind == "compare":
                sc["left"] = {"title": "Eski usul", "items": ["Qo'lda ishlash", "Sekin", "Xato ko'p"]}
                sc["right"] = {"title": "Yangi usul", "items": ["Avtomatik", "Tez", "Ishonchli"]}
            else:
                fn, lang, code = CODES[(ep["gno"] + i) % len(CODES)]
                sc.update({"filename": fn, "language": lang, "code": code})
            scenes.append(sc)
        recap = ""
        if prev:
            recap = (f"Oldingi qismda biz {prev['title']} mavzusini ko'rdik. "
                     f"{prev['summary'][:120]}")
        teaser = "Bu hozircha hammasi. "
        if nxt:
            teaser = f"Keyingi qismda {nxt['title']} haqida gaplashamiz. {nxt['topic']} Sizni kutib qolamiz."
        return json.dumps({
            "title": ep["title"],
            "description": f"{ep['topic']} Bu video seriyaning davomi. Kod va tushuntirishlar ketma-ket beriladi.",
            "tags": ["dasturlash", "python", "linux", "darslik", "uzbek"],
            "thumb_text": ep["title"].split("(")[0][:30],
            "hook": f"Bugun {ep['title'].split('(')[0].strip()} mavzusini boshdan oxirigacha o'rganamiz.",
            "recap": recap,
            "scenes": scenes,
            "summary": (f"Bu qismda {ep['topic']} Biz amaliy misollar yozdik va asosiy xatolarni ko'rib chiqdik. "
                        f"Natijada {ep['promise']}"),
            "key_points": ["Asosiy g'oya", "Amaliy misol", "Xatolardan qochish"],
            "teaser": teaser,
        }, ensure_ascii=False)
    return "{}"
