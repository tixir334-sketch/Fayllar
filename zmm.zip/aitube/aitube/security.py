"""Himoya: faqat admin (ADMIN_ID) o'zining shaxsiy chatida bot bilan ishlay oladi.

Boshqa har qanday foydalanuvchi (xabar, /start, tugma, hatto callback) BIR MARTA aniqlanishi bilan
doimiy bloklanadi: unga hech qanday javob berilmaydi (ma'lumotnoma ham, "ruxsat yo'q" ham), keyingi
update lar parse ham qilinmasdan tashlab yuboriladi (server yuklanmaydi). Admin ga bir marta ogohlantirish boradi.
"""
from __future__ import annotations

import os
import time

from .util import clip, esc, log

MAX_BLOCKED = 5000
ALERTS_PER_HOUR = 8


def harden_files(cfg):
    """Maxfiy fayllarga faqat egasi kira oladigan ruxsat (Termux/Linux)."""
    targets = [(cfg.env_file, 0o600), (cfg.db_path, 0o600), (cfg.data, 0o700), (cfg.dirs["tokens"], 0o700)]
    targets += [(p, 0o600) for p in cfg.dirs["tokens"].glob("*")]
    targets += [(cfg.db_path.with_name(cfg.db_path.name + s), 0o600) for s in ("-wal", "-shm")]
    for p, mode in targets:
        try:
            if os.path.exists(p):
                os.chmod(p, mode)
        except OSError:
            pass


class Guard:
    def __init__(self, cfg, db, notifier):
        self.cfg, self.db, self.n = cfg, db, notifier
        self.blocked = [int(x) for x in (db.kv_json("blocked_ids", []) or [])]
        self._set = set(self.blocked)
        self.info: dict = db.kv_json("blocked_info", {}) or {}
        self._alerts: list = []
        self.dropped = 0

    # ------------------------------------------------------------------ holat
    def is_blocked(self, uid) -> bool:
        return uid in self._set

    def _persist(self):
        self.db.kv_set_json("blocked_ids", self.blocked)
        if len(self.info) > 300:
            for k in list(self.info)[:len(self.info) - 300]:
                self.info.pop(k, None)
        self.db.kv_set_json("blocked_info", self.info)

    def block(self, uid, frm=None, what=""):
        if uid in self._set or uid == self.cfg.admin_id:
            return False
        frm = frm or {}
        self._set.add(uid)
        self.blocked.append(uid)
        if len(self.blocked) > MAX_BLOCKED:
            old = self.blocked.pop(0)
            self._set.discard(old)
        self.info[str(uid)] = {"t": int(time.time()), "u": clip(str(frm.get("username") or ""), 40),
                               "n": clip(str(frm.get("first_name") or ""), 40), "w": clip(what, 60)}
        self._persist()
        log.warning("Ruxsatsiz foydalanuvchi bloklandi: id=%s", uid)
        self._alert(uid)
        return True

    def unblock(self, uid) -> bool:
        if uid not in self._set:
            return False
        self._set.discard(uid)
        self.blocked = [x for x in self.blocked if x != uid]
        self.info.pop(str(uid), None)
        self._persist()
        return True

    def _alert(self, uid):
        now = time.time()
        self._alerts = [t for t in self._alerts if now - t < 3600]
        if len(self._alerts) >= ALERTS_PER_HOUR:
            return  # ogohlantirish bilan ham ortiqcha yuk bo'lmasin
        self._alerts.append(now)
        i = self.info.get(str(uid), {})
        text = (f"🛡 <b>Begona foydalanuvchi bloklandi</b>\nID: <code>{uid}</code>"
                + (f" · @{esc(i.get('u'))}" if i.get("u") else "")
                + (f"\nIsm: {esc(i.get('n'))}" if i.get("n") else "")
                + (f"\nUrinish: <code>{esc(i.get('w'))}</code>" if i.get("w") else "")
                + "\nUnga hech narsa javob berilmadi. Ro'yxat: /blocked")
        mk = {"inline_keyboard": [[{"text": "🔓 Blokdan chiqarish", "callback_data": f"sec:unblock:{uid}"}]]}
        try:
            self.n.say(text, markup=mk)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ asosiy filtr
    def classify(self, u: dict):
        """True: admin · "setup": ADMIN_ID hali yo'q · False: tashlab yuboriladi (begona foydalanuvchi bloklanadi)."""
        cb, msg = u.get("callback_query"), u.get("message")
        if cb:
            frm = cb.get("from") or {}
            m = cb.get("message") or {}
            chat = m.get("chat") or {}
            what = "tugma: " + str(cb.get("data") or "")
        elif msg:
            frm = msg.get("from") or {}
            chat = msg.get("chat") or {}
            what = str(msg.get("text") or ("fayl" if msg.get("document") else "xabar"))
        else:
            return False
        uid = frm.get("id")
        admin = self.cfg.admin_id
        if not isinstance(uid, int):
            return False
        if uid in self._set:
            self.dropped += 1
            return False
        if admin is None:
            return "setup" if (msg and chat.get("type") == "private" and chat.get("id") == uid) else False
        if uid != admin:
            self.block(uid, frm, what)
            return False
        # admin: faqat o'zining shaxsiy chatida (guruh/kanalga hech qachon javob ketmasin)
        return bool(not frm.get("is_bot") and chat.get("type") == "private" and chat.get("id") == admin
                    and not (msg or {}).get("sender_chat"))
