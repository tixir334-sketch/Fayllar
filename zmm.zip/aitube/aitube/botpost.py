"""📤 Post joylash: foydalanuvchi (va admin) o'z videosini YouTube kanaliga joylaydi.

Oqim (hammasi BITTA xabarni tahrirlab boradi): video yuborish → sarlavha → tavsif → maxfiylik → qachon (hozir/vaqt) → tasdiq → joylash.
Tayyor (AI yasagan) epizodlarni ham shu yerdan bir tugmada joylash mumkin.
Eslatma: Telegram bot API orqali faqat 20 MB gacha fayl olinadi (POST_MAX_MB); kattasi uchun «Tayyor epizod» yoki /stream.
"""
from __future__ import annotations

import time
from pathlib import Path

from . import schedule as sc
from .tg import PANELS, TGError
from .util import clip, esc, fmt_dur, human_size, log
from .youtube import YTError

PRIV = {"public": "🌍 Hammaga ochiq", "unlisted": "🔗 Havola bilan", "private": "🔒 Yopiq"}


class PostMixin:
    # ------------------------------------------------------------------ ekran yordamchisi
    def _pst_screen(self, chat, text, rows, force_new=False):
        """Panelni (ctx ichida ham, oqimdan ham) tahrirlaydi; bo'lmasa yangisini yuboradi."""
        mk = {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]}
        mid = None if force_new else (getattr(self, "_cb_msg", None) or PANELS.get(chat))
        if mid:
            try:
                self.tg.edit(mid, text, chat=chat, markup=mk)
                PANELS[chat] = mid
                return
            except TGError:
                pass
        ids = self.tg.send(text, chat=chat, markup=mk)
        if ids:
            PANELS[chat] = ids[-1]

    def _post_draft(self):
        d = getattr(self, "post", None)
        if d is None:
            d = self.post = {}
        return d

    def _post_reset(self, delete_file=True):
        d = getattr(self, "post", None) or {}
        if delete_file and d.get("path"):
            try:
                Path(d["path"]).unlink()
            except OSError:
                pass
        self.post = {}

    # ------------------------------------------------------------------ bosh ekran
    def c_post(self, arg, chat):
        a = self.app
        self.pending = None
        yt = "ulangan ✅" if a.yt.authorized() else "ulanmagan ❌ (avval 🔐 YouTube ulash)"
        ready = a.db.by_status("ready", limit=50)
        hist = a.db.kv_json("posts", []) or []
        text = ("📤 <b>Post joylash</b>\n"
                "O'z videongizni YouTube kanalingizga joylang: video yuborasiz → sarlavha → tavsif → maxfiylik → vaqt.\n\n"
                f"📺 YouTube: {yt}\n"
                f"🎞 Joylashga tayyor AI epizodlar: {len(ready)} · oxirgi joylashlar: {len(hist)}\n"
                f"<i>Telegram orqali {a.cfg.int('POST_MAX_MB', 20)} MB gacha video qabul qilinadi.</i>")
        rows = [[("🎥 Video yuborib joylash", "pst:new")]]
        if ready:
            rows.append([(f"🎞 Tayyor epizodni joylash ({len(ready)})", "pst:ep")])
        if hist:
            rows.append([("📋 Oxirgi joylashlar", "pst:hist")])
        if not a.yt.authorized():
            rows.insert(0, [("🔐 YouTube ulash", "m:auth")])
        rows.append([("⬅️ Menyu", "mn:main")])
        self._pst_screen(chat, text, rows) if getattr(self, "_cb_msg", None) else self.tg.send(
            text, chat=chat, markup={"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]})
        return None

    # ------------------------------------------------------------------ tugmalar
    def pst_callback(self, val, chat):
        a = self.app
        act, _, arg = val.partition(":")
        if act == "home":
            return self.c_post("", chat)
        if act == "new":
            if not a.yt.authorized():
                return self._pst_screen(chat, "🔐 Avval YouTube kanalingizni ulang.",
                                        [[("🔐 YouTube ulash", "m:auth")], [("⬅️ Orqaga", "pst:home")]])
            self._post_reset()
            self.pending = ("post_video", None)
            return self._pst_screen(chat, "🎥 <b>Videoni shu chatga yuboring</b>\n"
                                          f"(mp4, {a.cfg.int('POST_MAX_MB', 20)} MB gacha). Fayl sifatida ham, video sifatida ham bo'ladi.",
                                    [[("✖️ Bekor", "pst:cancel")]])
        if act == "cancel":
            self.pending = None
            self._post_reset()
            return self.c_post("", chat)
        if act == "skipdesc":
            self._post_draft()["desc"] = ""
            return self._post_ask_privacy(chat)
        if act == "pv" and arg in PRIV:
            self._post_draft()["privacy"] = arg
            return self._post_ask_when(chat)
        if act == "when":
            if arg == "now":
                self._post_draft()["publish_at"] = None
                return self._post_confirm(chat)
            self.pending = ("post_time", None)
            now = sc.fmt_local(a.cfg, sc.now_utc())
            return self._pst_screen(chat, f"⏰ <b>Qachon ochilsin?</b>\nHozir: {esc(now)}\n"
                                          "Yozing: <code>ertaga 12:00</code> · <code>18:30</code> · <code>2026-10-25 20:00</code> · <code>+2h</code>",
                                    [[("🚀 Hozir joylash", "pst:when:now"), ("✖️ Bekor", "pst:cancel")]])
        if act == "go":
            return self._post_go(chat)
        if act == "ep":
            return self._post_eps(chat)
        if act == "epu" and arg.isdigit():
            return self._post_ep_upload(int(arg), chat)
        if act == "hist":
            hist = (a.db.kv_json("posts", []) or [])[-8:][::-1]
            lines = ["📋 <b>Oxirgi joylashlar</b>"] + [
                f"• {esc(clip(h.get('title', ''), 50))} — {h.get('url', '')}" for h in hist] or ["(bo'sh)"]
            return self._pst_screen(chat, "\n".join(lines), [[("⬅️ Orqaga", "pst:home")]])
        return self.c_post("", chat)

    # ------------------------------------------------------------------ video qabul qilish
    def post_video_msg(self, msg) -> bool:
        """Video xabari kelganda: /post oqimi kutayotgan bo'lsa True (qabul qilindi), aks holda False (efir oqimiga o'tadi)."""
        pend = getattr(self, "pending", None)
        if not pend or pend[0] != "post_video":
            return False
        a = self.app
        chat = msg["chat"]["id"]
        v = msg.get("video") or msg.get("document") or {}
        limit = a.cfg.int("POST_MAX_MB", 20) * 1024 * 1024
        if (v.get("file_size") or 0) > limit:
            self._pst_screen(chat, f"⚠️ Fayl katta ({human_size(v.get('file_size') or 0)}). Telegram botlari "
                                   f"{a.cfg.int('POST_MAX_MB', 20)} MB dan kattasini ololmaydi.\nKichikroq video yuboring "
                             "yoki tayyor AI epizodni joylang.", [[("🎞 Tayyor epizod", "pst:ep"), ("✖️ Bekor", "pst:cancel")]])
            return True
        d = a.cfg.dirs["work"] / "post"
        d.mkdir(parents=True, exist_ok=True)
        name = Path(v.get("file_name") or f"video_{int(time.time())}.mp4").name
        dest = d / f"{int(time.time())}_{name}"
        self._pst_screen(chat, "⏳ Video qabul qilinmoqda…", [])
        try:
            self.tg.download_file(v["file_id"], dest)
        except Exception as e:  # noqa: BLE001
            self.pending = ("post_video", None)
            self._pst_screen(chat, f"❌ Video olinmadi: {esc(clip(self.tg._clean(e), 150))}\nQayta yuboring.",
                             [[("✖️ Bekor", "pst:cancel")]])
            return True
        self.tg.delete_async(chat, msg.get("message_id"))      # yuborilgan video chatda qolmasin (nusxasi serverda)
        self.pending = ("post_title", None)
        self.post = {"path": str(dest), "name": name, "size": dest.stat().st_size,
                     "title": "", "desc": "", "privacy": a.cfg.get("YT_PRIVACY") or "private", "publish_at": None}
        self._pst_screen(chat, f"✅ Video qabul qilindi: <code>{esc(clip(name, 40))}</code> · {human_size(self.post['size'])}\n\n"
                               "✏️ <b>Sarlavhani yozing</b> (eng ko'pi 100 belgi):", [[("✖️ Bekor", "pst:cancel")]])
        return True

    # ------------------------------------------------------------------ matnli javoblar
    def post_pending(self, kind, text, chat):
        d = self._post_draft()
        if not d.get("path"):
            self._pst_screen(chat, "ℹ️ Video topilmadi. Qaytadan boshlang.", [[("📤 Post joylash", "pst:home")]])
            return
        if kind == "post_title":
            t = text.strip()
            if not t:
                self.pending = ("post_title", None)
                return self._pst_screen(chat, "⚠️ Sarlavha bo'sh bo'lmasin. Qayta yozing:", [[("✖️ Bekor", "pst:cancel")]])
            d["title"] = clip(t, 100)
            self.pending = ("post_desc", None)
            return self._pst_screen(chat, f"✅ Sarlavha: <b>{esc(d['title'])}</b>\n\n📝 <b>Tavsifni yozing</b> (yoki o'tkazing):",
                                    [[("⏭ O'tkazish", "pst:skipdesc"), ("✖️ Bekor", "pst:cancel")]])
        if kind == "post_desc":
            d["desc"] = clip(text.strip(), 4900)
            return self._post_ask_privacy(chat)
        if kind == "post_time":
            dt, err = sc.parse_when(self.app.cfg, text.strip(), None)
            if err:
                self.pending = ("post_time", None)
                return self._pst_screen(chat, f"⚠️ {esc(err)}\nQayta yozing yoki hozir joylang:",
                                        [[("🚀 Hozir joylash", "pst:when:now"), ("✖️ Bekor", "pst:cancel")]])
            d["publish_at"] = sc.to_iso(dt)
            return self._post_confirm(chat)

    def _post_ask_privacy(self, chat):
        self.pending = None
        cur = self._post_draft().get("privacy", "private")
        rows = [[(("● " if k == cur else "○ ") + v, f"pst:pv:{k}")] for k, v in PRIV.items()]
        rows.append([("✖️ Bekor", "pst:cancel")])
        self._pst_screen(chat, "🔒 <b>Maxfiylikni tanlang</b>", rows)

    def _post_ask_when(self, chat):
        self._pst_screen(chat, "⏱ <b>Qachon joylansin?</b>\n«Vaqt belgilash» tanlansa, video yopiq yuklanadi va YouTube o'zi "
                               "shu vaqtda ochadi.",
                         [[("🚀 Hozir", "pst:when:now"), ("⏰ Vaqt belgilash", "pst:when:at")], [("✖️ Bekor", "pst:cancel")]])

    def _post_confirm(self, chat):
        a = self.app
        d = self._post_draft()
        self.pending = None
        when = sc.fmt_local(a.cfg, d["publish_at"]) if d.get("publish_at") else "hozir"
        text = ("📤 <b>Tasdiqlang</b>\n"
                f"🏷 {esc(d['title'])}\n"
                f"📝 {esc(clip(d.get('desc') or '(tavsifsiz)', 200))}\n"
                f"🔒 {PRIV.get(d['privacy'], d['privacy'])}\n"
                f"⏱ {esc(when)}\n"
                f"🎞 {esc(clip(d['name'], 40))} · {human_size(d['size'])}")
        self._pst_screen(chat, text, [[("✅ Joylash", "pst:go")], [("✖️ Bekor", "pst:cancel")]])

    # ------------------------------------------------------------------ joylash
    def _post_go(self, chat):
        a = self.app
        d = dict(self._post_draft())
        if not d.get("path") or not Path(d["path"]).exists():
            return self._pst_screen(chat, "ℹ️ Video topilmadi. Qaytadan boshlang.", [[("📤 Post joylash", "pst:home")]])
        if not a.yt.authorized():
            return self._pst_screen(chat, "🔐 YouTube ulanmagan.", [[("🔐 YouTube ulash", "m:auth")]])
        self.post = {}                         # qoralama endi ish oqimiga topshirildi
        self._pst_screen(chat, f"⬆️ <b>Yuklanmoqda…</b> {esc(clip(d['title'], 60))}\n0%", [])
        panel = PANELS.get(chat)
        state = {"t": 0.0}

        def progress(done, total):
            now = time.time()
            if now - state["t"] < 3 and done < total:
                return
            state["t"] = now
            try:
                self.tg.edit(panel, f"⬆️ <b>Yuklanmoqda…</b> {esc(clip(d['title'], 60))}\n{int(done * 100 / max(1, total))}% · "
                                    f"{human_size(done)} / {human_size(total)}", chat=chat,
                             markup={"inline_keyboard": []})
            except Exception:  # noqa: BLE001
                pass

        def job():
            try:
                res = a.yt.upload(d["path"], d["title"], d["desc"], [], privacy=d["privacy"],
                                  category=a.cfg.get("YT_CATEGORY") or "22", synthetic=False,
                                  progress=progress, publish_at=d.get("publish_at"))
                vid = res.get("id", "")
                url = f"https://youtu.be/{vid}" if vid else ""
                hist = a.db.kv_json("posts", []) or []
                hist.append({"title": d["title"], "url": url, "t": int(time.time())})
                a.db.kv_set_json("posts", hist[-30:])
                when = f"\n⏰ Ochilish: {esc(sc.fmt_local(a.cfg, d['publish_at']))}" if d.get("publish_at") else ""
                self._pst_final(chat, panel, f"✅ <b>Joylandi!</b>\n{esc(d['title'])}\n{url}{when}")
            except YTError as e:
                hint = "\n🔐 YouTube ulanishi eskirgan — qaytadan ulang." if getattr(e, "auth", False) else (
                    "\n📛 YouTube kunlik limiti tugagan bo'lishi mumkin — ertaga urinib ko'ring." if getattr(e, "quota", False) else "")
                self._pst_final(chat, panel, f"❌ <b>Joylanmadi</b>: {esc(clip(str(e), 300))}{hint}", retry=True)
            except Exception as e:  # noqa: BLE001
                log.error("Post joylash xatosi: %s", e)
                self._pst_final(chat, panel, f"❌ <b>Xato</b>: {esc(clip(str(e), 300))}", retry=True)
            finally:
                try:
                    Path(d["path"]).unlink()
                except OSError:
                    pass

        if not a.jobs.submit_light(f"post-{int(time.time())}", job):
            self._pst_screen(chat, "ℹ️ Band, birozdan keyin urinib ko'ring.", [[("⬅️ Orqaga", "pst:home")]])

    def _pst_final(self, chat, panel, text, retry=False):
        rows = [[("📤 Yana joylash", "pst:new")] if not retry else [("🔁 Qayta urinish", "pst:new")], [("⬅️ Menyu", "mn:main")]]
        mk = {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]}
        try:
            self.tg.edit(panel, text, chat=chat, markup=mk)
        except Exception:  # noqa: BLE001
            self.tg.send(text, chat=chat, markup=mk)

    # ------------------------------------------------------------------ tayyor epizodlar
    def _post_eps(self, chat):
        a = self.app
        rows_db = a.db.by_status("ready", limit=8)
        if not rows_db:
            return self._pst_screen(chat, "ℹ️ Joylashga tayyor epizod yo'q. /make bilan yasang.", [[("⬅️ Orqaga", "pst:home")]])
        lines = ["🎞 <b>Tayyor epizodlar</b> (bosib hozir joylang)"]
        rows = []
        for e in rows_db:
            lines.append(f"#{e['gno']} {esc(clip(e['title'], 50))} · {fmt_dur(e['duration'] or 0)}")
            rows.append([(f"⬆️ #{e['gno']} {clip(e['title'], 28)}", f"pst:epu:{e['id']}")])
        rows.append([("⬅️ Orqaga", "pst:home")])
        self._pst_screen(chat, "\n".join(lines), rows)

    def _post_ep_upload(self, eid, chat):
        a = self.app
        ep = a.db.ep(eid)
        why = a.pipeline.can_upload()
        if why:
            return self._pst_screen(chat, f"ℹ️ Yuklab bo'lmaydi: {esc(why)}", [[("⬅️ Orqaga", "pst:home")]])
        if ep and ep["status"] == "ready" and a.jobs.submit(f"upload-{ep['id']}", a.pipeline.upload_episode, ep):
            return self._pst_screen(chat, f"⬆️ #{ep['gno']} yuklash navbatga qo'yildi. Tugagach xabar keladi.",
                                    [[("⬅️ Orqaga", "pst:home"), ("⬅️ Menyu", "mn:main")]])
        self._pst_screen(chat, "ℹ️ Allaqachon navbatda yoki epizod topilmadi.", [[("⬅️ Orqaga", "pst:home")]])
