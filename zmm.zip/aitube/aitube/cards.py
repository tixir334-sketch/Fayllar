"""Tushuntirish kartalari (3D ikonkali sahnalar) va 3D ikonka qo'yish usuli.

  parts   — «Qismlar»: 2..6 ta karta, har birida 3D ikonka + nom + vazifasi (masalan, kompyuter qismlari). Qadam-baqadam chiqadi.
  explain — «Tushuncha kartasi»: chapda katta tebranuvchi 3D ikonka va atama, o'ngda: «Bu nima?», «Hayotdan misol», «Nima uchun kerak»
            bloklari ketma-ket paydo bo'ladi.
Diagramma tugunlari ham shu `icon3d` orqali 3D ikonka bilan chiziladi.
"""
from __future__ import annotations

import math

from .anim import KIND_COL, infer_kind, lighten, mix

LABELS = {"def": "BU NIMA?", "analogy": "HAYOTDAN MISOL", "point": "NIMA UCHUN KERAK"}


def explain_blocks(sc: dict) -> list:
    """explain sahnasining ketma-ket paydo bo'ladigan bloklari: [(tur, matn)]."""
    out = []
    if str(sc.get("definition") or "").strip():
        out.append(("def", str(sc["definition"]).strip()))
    if str(sc.get("analogy") or "").strip():
        out.append(("analogy", str(sc["analogy"]).strip()))
    for p in (sc.get("points") or [])[:3]:
        if str(p).strip():
            out.append(("point", str(p).strip()))
    return out


class CardsMixin:
    # ------------------------------------------------------------------ 3D ikonka
    def icon3d(self, kind, cx, cy, size, col, t, phase=0.0, hi=1.0, alpha=1.0) -> bool:
        """Pseudo-3D ikonka (tebranadi, yaltiraydi, soyasi bor)ni shisha qatlamga qo'yadi. cx, cy, size — mantiqiy koordinata.
        Muvaffaqiyatsiz bo'lsa False (chaqiruvchi tekis ikonkaga qaytadi)."""
        try:
            from .icons3d import I3
            S = self.S
            px = int(size * S)
            if px < 14:
                return False
            spr = I3.render(kind, px, tuple(col), t, phase, wob=0.3 + 0.7 * hi, glint=0.30 + 0.70 * hi)
            if alpha < 0.99:
                spr = spr.copy()
                spr.putalpha(spr.getchannel("A").point(lambda v: int(v * max(0.0, alpha))))
            self._paste_rgba(spr, int(cx * S - px / 2), int(cy * S - px / 2))
            return True
        except Exception:  # noqa: BLE001
            return False

    # ------------------------------------------------------------------ parts
    def _s_parts(self, img, d, sc, shown, anim, age):
        from .render import BORDER, TEXT, ease_out, ease_out_back, lerp
        x0, y0, x1, y1 = self.content_box
        y = self._heading(d, sc.get("heading", ""), y0, age)
        items = sc.get("items", [])
        n = len(items)
        if not n:
            return
        gap = 16
        avail = y1 - y - 12
        if self.portrait:
            cols = 1 if n > 4 else min(n, 2)
        else:
            cols = n if n <= 3 else (2 if n == 4 else 3)
        rows = math.ceil(n / cols)
        cw = (x1 - x0 - gap * (cols - 1)) / cols
        ch = min((avail - gap * (rows - 1)) / rows, 360 if not self.portrait else 330)
        vertical = ch > cw * 0.80                           # baland karta: ikonka tepada; past va keng karta: ikonka chapda
        top = y + 12 + max(0.0, (avail - (ch * rows + gap * (rows - 1))) / 2 * 0.5)
        e = ease_out_back(anim)
        pulse = 0.5 + 0.5 * math.sin(age * 2.2)
        for i, it in enumerate(items):
            r_, c_ = divmod(i, cols)
            in_row = min(cols, n - r_ * cols)
            bx0 = x0 + (cols - in_row) * (cw + gap) / 2 + c_ * (cw + gap)
            by0 = top + r_ * (ch + gap)
            if i >= shown:
                bgc = self.bgpx(bx0 + cw / 2, by0 + ch / 2)
                d.rounded_rectangle([bx0, by0, bx0 + cw, by0 + ch], radius=20,
                                    outline=lerp(bgc, BORDER, 0.20 + 0.16 * pulse), width=2)
                continue
            active = i == shown - 1
            k = (0.84 + 0.16 * e) if active else 1.0
            a = ease_out(anim) if active else 1.0
            cx, cy = bx0 + cw / 2, by0 + ch / 2
            bw, bh = cw * k, ch * k
            box = [cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2]
            kind = infer_kind(it.get("icon"), it.get("name"))
            col = KIND_COL.get(kind, self.accent)
            self._card(img, box, radius=20, glass=a, gfill=(20, 30, 46), gout=mix((60, 72, 92), col, 0.6 if active else 0.3),
                       galpha=0.72, width=3 if active else 2)
            name, role = str(it.get("name", "")), str(it.get("role", ""))
            if vertical:
                isz = min(bh * 0.46, bw * 0.58)
                icx, icy = cx, box[1] + 10 * k + isz / 2
                tx0, tw = box[0] + 14, bw - 28
                ty = icy + isz / 2 + 6 * k
                anchor, tx = "ma", cx
            else:
                isz = min(bh - 14 * k, bw * 0.36)
                icx, icy = box[0] + 10 * k + isz / 2, cy
                tx0 = box[0] + isz + 22 * k
                tw = box[2] - tx0 - 14
                ty = box[1] + 12 * k
                anchor, tx = "la", tx0
            if not self.icon3d(kind, icx, icy, isz, col, age + i * 0.6, phase=i * 0.85, hi=1.0 if active else 0.7, alpha=a):
                self._icon(self.D(img), kind, icx, icy, isz * 0.8, col, age)
            dd = self.D(img)
            br = max(11, int(min(bw, bh) * 0.055))
            bxn, byn = box[0] + 10 * k + br, box[1] + 10 * k + br
            dd.ellipse([bxn - br, byn - br, bxn + br, byn + br], fill=lerp(self.bgpx(bxn, byn), col, a))
            dd.text((bxn, byn), str(i + 1), font=self.font("bold", max(11, int(br * 1.1))), fill=(13, 19, 29), anchor="mm")
            fs_n = max(16, min(30, int(min(bh * 0.17, bw * 0.085))))
            fs_r = max(13, min(23, int(fs_n * 0.74)))
            fn, fr = self.font("bold", fs_n), self.font("sans", fs_r)
            for ln in self.wrap(name, fn, tw)[:2]:
                dd.text((tx, ty), ln, font=fn, fill=lerp(self.bgpx(tx, ty), TEXT, a), anchor=anchor)
                ty += fs_n + 3
            ty += 2
            room = max(1, int((box[3] - ty - 10 * k) // (fs_r + 4)))
            for ln in self.wrap(role, fr, tw)[:room]:
                dd.text((tx, ty), ln, font=fr, fill=lerp(self.bgpx(tx, ty), (180, 194, 212), a), anchor=anchor)
                ty += fs_r + 4

    # ------------------------------------------------------------------ explain
    def _s_explain(self, img, d, sc, shown, anim, age):
        from .render import TEXT, ease_out, ease_out_back, lerp
        x0, y0, x1, y1 = self.content_box
        y = self._heading(d, sc.get("heading", ""), y0, age)
        blocks = explain_blocks(sc)
        term = str(sc.get("term") or sc.get("heading") or "").strip()
        kind = infer_kind(sc.get("icon"), term)
        col = KIND_COL.get(kind, self.accent)
        W, avail = x1 - x0, y1 - y - 8
        top = y + 8
        e_in = ease_out(min(1.0, age / 0.7))
        if self.portrait:
            ib = [x0, top, x1, top + avail * 0.32]
            bx0, bx1, by0 = x0, x1, ib[3] + 14
        else:
            wl = W * 0.30
            ib = [x0, top, x0 + wl, y1]
            bx0, bx1, by0 = x0 + wl + 22, x1, top
        self._card(img, ib, radius=24, glass=e_in, gfill=(18, 28, 44), gout=mix((60, 72, 92), col, 0.5), galpha=0.7, width=3)
        icx, icw, ich = (ib[0] + ib[2]) / 2, ib[2] - ib[0], ib[3] - ib[1]
        self._glow(icx, ib[1] + ich * 0.42, min(icw, ich) * 0.42, col, 0.35 * e_in)
        fs_t = max(18, min(40, int(icw * 0.105)))
        ft = self.font("bold", fs_t)
        tl = self.wrap(term, ft, icw - 28)[:2]
        th = len(tl) * (fs_t + 5)
        isz = min(icw * 0.80, ich - th - 36)
        ik_cy = ib[1] + 14 + isz / 2
        pop = ease_out_back(min(1.0, age / 0.8))
        if not self.icon3d(kind, icx, ik_cy, isz * max(0.2, pop), col, age, phase=0.4, hi=1.0, alpha=e_in):
            self._icon(self.D(img), kind, icx, ik_cy, isz * 0.7, col, age)
        dd = self.D(img)
        ty = ib[3] - th - 10
        for ln in tl:
            dd.text((icx, ty), ln, font=ft, fill=lerp(self.bgpx(icx, ty), TEXT, e_in), anchor="ma")
            ty += fs_t + 5
        if not blocks:
            return
        singles = [(tp, tx) for tp, tx in blocks if tp != "point"]
        pts = [tx for tp, tx in blocks if tp == "point"]
        ns = len(singles)
        bw_ = bx1 - bx0
        avail_b = y1 - by0
        size = 27 if not self.portrait else 25
        while True:                                                   # hamma blok sig'guncha shrift kichraytiriladi
            fb = self.font("sans", size)
            lh = size + 6
            lab = max(11, size - 13)
            hs = []
            wr = []
            for tp, tx in singles:
                lines = self.wrap(tx, fb, bw_ - 40 - (58 if tp != "def" else 0))
                wr.append(lines)
                hs.append(len(lines) * lh + 20 + lab + 6)
            pw = [self.wrap(p, fb, bw_ - 40 - 52) for p in pts]
            ph = (sum(len(x) * lh + 6 for x in pw) + 20 + lab + 6) if pts else 0
            total = sum(hs) + ph + 12 * (ns + (1 if pts else 0) - 1)
            if total <= avail_b or size <= 16:
                break
            size -= 1
        flab = self.font("bold", lab)
        yy = by0 + max(0.0, (avail_b - total) / 2 * 0.35)
        a_e = ease_out(anim)
        for i, ((tp, tx), h, lines) in enumerate(zip(singles, hs, wr)):
            if i >= shown:
                break
            active = i == shown - 1
            dx = int((1 - a_e) * 60) if active else 0
            a = a_e if active else 1.0
            bcol = self.accent if tp == "def" else (255, 206, 86)
            box = [bx0 + dx, yy, bx1, yy + h]
            self._card(img, box, radius=18, glass=a, gfill=(26, 38, 58) if active else (20, 30, 46),
                       gout=mix((60, 72, 92), bcol, 0.7 if active else 0.35), galpha=0.86, width=3 if active else 2)
            dd = self.D(img)
            tx0 = box[0] + 18
            if tp == "analogy":
                self.icon3d("bulb", box[0] + 18 + 22, yy + h / 2, 52, bcol, age + i, phase=1.3, hi=0.8 if active else 0.5, alpha=a)
                tx0 = box[0] + 18 + 54
            ty = yy + 9
            dd.text((tx0, ty), LABELS[tp], font=flab, fill=lerp(self.bgpx(tx0, ty), bcol, a), anchor="la")
            ty += lab + 5
            for ln in lines:
                dd.text((tx0, ty), ln, font=fb, fill=lerp(self.bgpx(tx0, ty), TEXT if active else (194, 204, 218), a), anchor="la")
                ty += lh
            yy += h + 12
        if pts and shown > ns:
            vis = min(len(pts), shown - ns)
            box = [bx0, yy, bx1, yy + ph]
            self._card(img, box, radius=18, glass=1.0, gfill=(26, 38, 58), gout=mix((60, 72, 92), (63, 185, 80), 0.6), galpha=0.86, width=3)
            dd = self.D(img)
            ty = yy + 9
            gcol = (63, 185, 80)
            dd.text((bx0 + 18, ty), LABELS["point"], font=flab, fill=lerp(self.bgpx(bx0 + 18, ty), gcol, 1.0), anchor="la")
            ty += lab + 6
            for j in range(vis):
                act = j == vis - 1
                a = a_e if act else 1.0
                dx = int((1 - a_e) * 40) if act else 0
                rh = len(pw[j]) * lh + 6
                self.icon3d("check", bx0 + 18 + 15 + dx, ty + min(rh, 34) / 2, 30, gcol, age + j, phase=j * 1.7, hi=0.7, alpha=a)
                for ln in pw[j]:
                    dd.text((bx0 + 18 + 40 + dx, ty), ln, font=fb, fill=lerp(self.bgpx(bx0 + 60, ty), TEXT if act else (194, 204, 218), a), anchor="la")
                    ty += lh
                ty += 6
