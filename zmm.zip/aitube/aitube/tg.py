"""Telegram Bot API mijozi (faqat requests) + admin uchun xabar yuboruvchi va jonli 'doska'."""
from __future__ import annotations

import json
import mimetypes
import shutil
import subprocess
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from .util import esc, http, log


class TGError(Exception):
    pass


class Throttle:
    """Bitta chatga xabar yuborish/tahrirlash orasida kamida `sec` soniya (adminlar /throttle bilan o'zgartiradi).
    Navbat bo'yicha ishlaydi: vaqt oralig'i oldindan band qilinadi, shuning uchun ko'p oqim bir vaqtda yozsa ham
    ularning o'zaro tartibi saqlanadi va hech biri qotib qolmaydi."""

    def __init__(self, sec: float = 0.4):
        self.sec = sec
        self._last: dict = {}
        self._lock = threading.Lock()

    def set(self, sec) -> float:
        try:
            self.sec = max(0.0, min(5.0, float(sec)))
        except (TypeError, ValueError):
            pass
        return self.sec

    def wait(self, chat):
        if not chat or self.sec <= 0:
            return
        with self._lock:
            now = time.monotonic()
            slot = max(now, self._last.get(chat, 0.0) + self.sec)
            self._last[chat] = slot
            if len(self._last) > 4000:
                for k in [k for k, t in self._last.items() if t < now - 60][:2000]:
                    self._last.pop(k, None)
        d = slot - now
        if d > 0:
            time.sleep(d)


class GlobalRate:
    """Butun bot uchun umumiy chegara (Telegram ~30 xabar/s ruxsat beradi; 25 ga qo'yamiz). Navbat tartibida slot beriladi.
    Navbat 20 soniyadan uzun bo'lib ketsa, ortiqcha so'rov rad etiladi (qurilma osilib qolmasin)."""

    def __init__(self, rate: float = 25.0):
        self.rate = rate
        self._next = 0.0
        self._lock = threading.Lock()
        self.shed = 0

    def wait(self, max_wait: float = 20.0):
        step = 1.0 / max(1.0, self.rate)
        with self._lock:
            now = time.monotonic()
            slot = max(now, self._next)
            if slot - now > max_wait:
                self.shed += 1
                raise TGError("Telegram umumiy tezlik chegarasi: navbat juda uzun")
            self._next = slot + step
        d = slot - now
        if d > 0:
            time.sleep(d)


THROTTLE = Throttle()
GLOBAL = GlobalRate()
_SIG: dict = {}              # (chat, xabar) -> oxirgi matn+tugmalar imzosi (bir xil tahrir qayta yuborilmaydi)
PANELS: dict = {}            # chat_id -> so'nggi "jonli panel" xabari (tugmalar shuni tahrirlaydi)
_THROTTLED = {"sendMessage", "editMessageText", "sendPhoto", "sendVideo", "sendDocument", "editMessageReplyMarkup",
              "editMessageCaption"}
NAV = {"inline_keyboard": [[{"text": "⬅️ Menyu", "callback_data": "mn:main"}]]}


class Telegram:
    def __init__(self, cfg):
        self.cfg = cfg
        self._lock = threading.Lock()
        self._last = 0.0
        self._tl = threading.local()

    @property
    def token(self) -> str:
        return self.cfg.get("TELEGRAM_BOT_TOKEN").strip()

    @property
    def admin(self):
        return self.cfg.admin_id

    def enabled(self) -> bool:
        return bool(self.token) and self.admin is not None

    def _url(self, method):
        return f"{self.cfg.get('TG_API_BASE').rstrip('/')}/bot{self.token}/{method}"

    def _clean(self, msg: str) -> str:
        return str(msg).replace(self.token, "***") if self.token else str(msg)

    def api(self, method, params=None, files=None, timeout=(15, 40), retries=3):
        if not self.token:
            raise TGError("TELEGRAM_BOT_TOKEN sozlanmagan")
        last = None
        if method in _THROTTLED and isinstance(params, dict):
            GLOBAL.wait()
            THROTTLE.wait(params.get("chat_id"))
        for attempt in range(retries):
            with self._lock:  # umumiy tezlik cheklovi
                wait = 0.05 - (time.time() - self._last)
                if wait > 0:
                    time.sleep(wait)
                self._last = time.time()
            try:
                if files:
                    fh = {k: (Path(v).name, open(v, "rb"), mimetypes.guess_type(str(v))[0] or "application/octet-stream")
                          for k, v in files.items()}
                    try:
                        r = http("POST", self._url(method), data=params or {}, files=fh, timeout=(15, 600), retries=1)
                    finally:
                        for _, f, _ in fh.values():
                            f.close()
                else:
                    r = http("POST", self._url(method), json=params or {}, timeout=timeout, retries=2)
            except Exception as e:
                last = TGError(self._clean(f"{type(e).__name__}: {e}"))
                time.sleep(2 * (attempt + 1))
                continue
            try:
                j = r.json()
            except ValueError:
                last = TGError(f"JSON bo'lmagan javob (HTTP {r.status_code})")
                time.sleep(2)
                continue
            if j.get("ok"):
                return j.get("result")
            desc = j.get("description", "")
            if r.status_code == 429:
                ra = (j.get("parameters") or {}).get("retry_after", 3)
                time.sleep(min(60, float(ra) + 1))
                last = TGError(f"429 {desc}")
                continue
            raise TGError(f"{method}: {desc} ({r.status_code})")
        raise last or TGError(f"{method}: noma'lum xato")

    # ----------------------------------------------------------------- yuborish
    @staticmethod
    def split_text(text: str, limit: int = 3900) -> list:
        if len(text) <= limit:
            return [text]
        parts, cur = [], ""
        for line in text.split("\n"):
            while len(line) > limit:
                if cur:
                    parts.append(cur)
                    cur = ""
                parts.append(line[:limit])
                line = line[limit:]
            if len(cur) + len(line) + 1 > limit:
                parts.append(cur)
                cur = line
            else:
                cur = f"{cur}\n{line}" if cur else line
        if cur:
            parts.append(cur)
        return parts

    # ------------------------------------------------------------------ jonli panel (tahrirlash, yangi xabar emas)
    @contextmanager
    def ctx(self, chat, mode, mid=None):
        """Shu oqimdagi send() chaqiruvlari uchun qoida:
        mode="cb"    — tugma bosildi: tugma turgan xabar (mid) TAHRIRLANADI;
        mode="input" — matn/fayl keldi: oxirgi panel tahrirlanadi (yo'q bo'lsa yangisi);
        mode="cmd"   — /buyruq: yangi panel yuboriladi, eskisi darrov o'chiriladi.
        Bitta xabar uchun faqat birinchi send() panel bo'ladi, qolganlari oddiy yuboriladi."""
        old = PANELS.get(chat)
        prev = getattr(self._tl, "c", None)
        self._tl.c = {"chat": chat, "mode": mode, "mid": mid if mode == "cb" else old, "old": old, "used": False}
        try:
            yield
        finally:
            self._tl.c = prev

    def delete(self, chat, mid) -> bool:
        try:
            self.api("deleteMessage", {"chat_id": chat, "message_id": mid}, retries=1)
            return True
        except TGError:
            return False

    def delete_async(self, chat, mid):
        if mid:
            threading.Thread(target=self.delete, args=(chat, mid), daemon=True, name="tg-del").start()

    def send(self, text, chat=None, markup=None, parse="HTML", silent=False):
        chat = chat or self.admin
        c = getattr(self._tl, "c", None)
        text = str(text)
        if not c or c["used"] or c["chat"] != chat or len(text) > 3900:
            return self._send_raw(text, chat, markup, parse, silent)
        inline = markup is None or (isinstance(markup, dict) and "inline_keyboard" in markup)
        mid = c["mid"]
        if mid and inline and c["mode"] in ("cb", "input"):
            try:
                self.edit(mid, text, chat=chat, markup=markup if markup is not None else NAV, parse=parse)
                c["used"] = True
                PANELS[chat] = mid
                return [mid]
            except TGError as e:
                log.info("Panel tahrirlanmadi (%s), yangisi yuboriladi", self._clean(e)[:80])
        if markup is None:
            markup = NAV
        ids = self._send_raw(text, chat, markup, parse, silent)
        c["used"] = True
        if ids:
            PANELS[chat] = ids[-1]
            for old in {c["old"], c["mid"]} - {None, *ids}:
                self.delete_async(chat, old)       # eski panel/so'rov darrov o'chadi
        return ids

    def _send_raw(self, text, chat=None, markup=None, parse="HTML", silent=False):
        chat = chat or self.admin
        ids = []
        chunks = self.split_text(str(text))
        for i, ch in enumerate(chunks):
            p = {"chat_id": chat, "text": ch, "disable_web_page_preview": True,
                 "disable_notification": silent}
            if parse:
                p["parse_mode"] = parse
            if markup and i == len(chunks) - 1:
                p["reply_markup"] = markup
            try:
                res = self.api("sendMessage", p)
            except TGError as e:
                if parse and "parse" in str(e).lower():
                    p.pop("parse_mode", None)
                    res = self.api("sendMessage", p)
                else:
                    raise
            ids.append(res["message_id"])
        return ids

    def edit(self, message_id, text, chat=None, markup=None, parse="HTML"):
        p = {"chat_id": chat or self.admin, "message_id": message_id, "text": str(text)[:3990],
             "disable_web_page_preview": True}
        if parse:
            p["parse_mode"] = parse
        if markup is not None:
            p["reply_markup"] = markup
        chat_id = p["chat_id"]
        sig = hash((p["text"], p.get("parse_mode"), json.dumps(p.get("reply_markup"), sort_keys=True)))
        cc = getattr(self._tl, "c", None)
        pressed = bool(cc and cc["mode"] == "cb" and cc["mid"] == message_id)   # tugma bosilgan xabar aniq mavjud
        if pressed and _SIG.get((chat_id, message_id)) == sig:
            res = None                      # xuddi shu matn va tugmalar: Telegram'ga so'rov yuborilmaydi (limit tejaladi)
        else:
            try:
                res = self.api("editMessageText", p, retries=1)
            except TGError as e:
                if "not modified" not in str(e).lower():
                    _SIG.pop((chat_id, message_id), None)
                    raise
                res = None
            if len(_SIG) > 200_000:
                _SIG.clear()
            _SIG[(chat_id, message_id)] = sig
        c = getattr(self._tl, "c", None)
        if c and c["chat"] == chat_id and message_id in (c["mid"], c["old"]):
            c["used"] = True                    # shu amalda panel allaqachon yangilandi
        if c is not None or message_id in PANELS.values():
            PANELS[chat_id] = message_id
        return res

    def _curl_upload(self, method, params, files):
        """requests muvaffaqiyatsiz bo'lsa: curl orqali yuklash (sekin tarmoqda chidamliroq)."""
        curl = shutil.which("curl")
        if not curl:
            raise TGError("curl topilmadi (pkg install curl)")
        cmd = [curl, "-sS", "--fail-with-body", "--max-time", "1200", "--connect-timeout", "30",
               "--retry", "3", "--retry-delay", "3", "-K", "-"]
        for k, v in (params or {}).items():
            cmd += ["--form-string", f"{k}={v}"]
        for field, path in (files or {}).items():
            cmd += ["-F", f"{field}=@{path}"]
        cfg_in = f'url = "{self._url(method)}"\n'   # token buyruq satrida ko'rinmasligi uchun stdin orqali
        try:
            r = subprocess.run(cmd, input=cfg_in.encode(), capture_output=True, timeout=1300)
        except subprocess.TimeoutExpired:
            raise TGError("curl: vaqt tugadi")
        out = r.stdout.decode("utf-8", "replace")
        try:
            j = json.loads(out)
        except ValueError:
            raise TGError(self._clean(f"curl xato (kod {r.returncode}): {r.stderr.decode('utf-8', 'replace')[-200:]}"))
        if not j.get("ok"):
            raise TGError(f"{method}: {j.get('description', '')}")
        return j.get("result")

    def send_file(self, kind, path, caption="", chat=None, markup=None, extra=None):
        field = {"video": "video", "photo": "photo", "document": "document"}[kind]
        p = {"chat_id": chat or self.admin, "caption": str(caption)[:1000], "parse_mode": "HTML"}
        if kind == "video":
            p["supports_streaming"] = "true"
        if markup:
            p["reply_markup"] = json.dumps(markup)
        if extra:
            p.update(extra)
        method = "send" + kind.capitalize()
        try:
            return self.api(method, p, files={field: path}, retries=1)
        except TGError as e:
            log.warning("requests bilan yuborilmadi (%s), curl bilan uriniladi", self._clean(e))
            return self._curl_upload(method, p, {field: path})

    def download_file(self, file_id, dest):
        info = self.api("getFile", {"file_id": file_id})
        url = f"{self.cfg.get('TG_API_BASE').rstrip('/')}/file/bot{self.token}/{info['file_path']}"
        r = http("GET", url, timeout=(15, 60), retries=3)
        if r.status_code != 200:
            raise TGError(f"fayl yuklab olinmadi (HTTP {r.status_code})")
        Path(dest).write_bytes(r.content)
        return Path(dest)

    def answer_cb(self, cb_id, text="", alert=False):
        try:
            self.api("answerCallbackQuery", {"callback_query_id": cb_id, "text": text[:190],
                                             "show_alert": alert}, retries=1)
        except TGError:
            pass

    def updates(self, offset, timeout=25):
        return self.api("getUpdates", {"offset": offset, "timeout": timeout,
                                       "allowed_updates": ["message", "callback_query"]},
                        timeout=(15, timeout + 20), retries=1) or []

    def set_commands(self, cmds, chat=None):
        """chat berilsa: faqat shu chat uchun ro'yxat (adminga to'liq, qolganlarga qisqa ro'yxat)."""
        p = {"commands": [{"command": c, "description": d} for c, d in cmds]}
        if chat:
            p["scope"] = {"type": "chat", "chat_id": chat}
        self.api("setMyCommands", p)

    def me(self):
        return self.api("getMe")


class Notifier:
    """Admin ga xabar yuborish: hech qachon istisno ko'tarmaydi."""

    def __init__(self, tg: Telegram):
        self.tg = tg
        self.outbox: list = []     # internet yo'qligida yetib bormagan xabarlar (aloqa qaytgach yuboriladi)
        self._olock = threading.Lock()

    def say(self, text, markup=None, silent=False):
        log.info("TG> %s", str(text).replace("\n", " | ")[:300])
        if not self.tg.enabled():
            return None
        try:
            ids = self.tg.send(text, markup=markup, silent=silent)
            if self.outbox:
                self.flush_outbox()
            return ids[0] if ids else None
        except Exception as e:
            log.warning("Telegramga yuborib bo'lmadi: %s", self.tg._clean(e))
            with self._olock:
                self.outbox.append((time.strftime("%H:%M"), text, markup))
                del self.outbox[:-25]
            return None

    def flush_outbox(self):
        with self._olock:
            items, self.outbox = self.outbox, []
        for i, (hhmm, text, markup) in enumerate(items):
            try:
                self.tg.send(f"🕓 <i>({hhmm} da yuborilishi kerak edi, internet yo'q edi)</i>\n{text}", markup=markup)
            except Exception:  # noqa: BLE001
                with self._olock:
                    self.outbox = items[i:] + self.outbox
                return

    def file(self, kind, path, caption="", markup=None):
        if not self.tg.enabled():
            return None
        try:
            return self.tg.send_file(kind, path, caption, markup=markup)
        except Exception as e:
            log.warning("Telegramga fayl yuborib bo'lmadi: %s", self.tg._clean(e))
            return None

    def error(self, title, detail=""):
        self.say(f"❌ <b>{esc(title)}</b>\n<pre>{esc(str(detail)[-1500:])}</pre>" if detail
                 else f"❌ <b>{esc(title)}</b>")


class Board:
    """Bitta xabarni tahrirlab turuvchi jonli jarayon doskasi."""

    def __init__(self, notifier: Notifier, title: str):
        self.n = notifier
        self.title = title
        self.lines: dict = {}
        self.order: list = []
        self.mid = None
        self._last = 0.0
        self._lock = threading.Lock()

    def render(self) -> str:
        body = "\n".join(self.lines[k] for k in self.order)
        return f"<b>{self.title}</b>\n{body}"

    def set(self, key, text, force=False):
        with self._lock:
            if key not in self.lines:
                self.order.append(key)
            self.lines[key] = text
            now = time.time()
            if not force and self.mid is not None and now - self._last < 2.5:
                return
            self._last = now
            self._flush()

    def _flush(self):
        if not self.n.tg.enabled():
            return
        try:
            if self.mid is None:
                ids = self.n.tg.send(self.render())
                self.mid = ids[0]
            else:
                self.n.tg.edit(self.mid, self.render())
        except Exception as e:
            log.warning("Doska yangilanmadi: %s", self.n.tg._clean(e))

    def flush(self):
        with self._lock:
            self._flush()
