"""To'liq o'z-o'zini sinash: tarmoqsiz (mahalliy soxta serverlar bilan) butun zanjirni tekshiradi."""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
import traceback
from pathlib import Path

RESULTS = []


def ok(cond, msg):
    RESULTS.append((bool(cond), msg))
    print(("  ✅ " if cond else "  ❌ ") + msg)
    return bool(cond)


def section(t):
    print(f"\n== {t}")


def wait_jobs(app, timeout=240):
    t0 = time.time()
    time.sleep(0.3)
    while app.jobs.busy() and time.time() - t0 < timeout:
        time.sleep(0.3)
    return not app.jobs.busy()


def unit_tests():
    section("1) Birlik testlari")
    from aitube.highlight import highlight_line
    from aitube.llm import extract_json
    from aitube.text import clean_narration, split_captions, tts_prepare
    from aitube.video import chapters
    from aitube.writer import _check_code

    ok(extract_json('```json\n{"a": 1,}\n```') == {"a": 1}, "extract_json: ``` va ortiqcha vergulni tuzatadi")
    ok(extract_json('Mana javob: {"a": [1,2]} tamom') == {"a": [1, 2]}, "extract_json: atrofdagi matnni kesadi")
    caps = split_captions("Bu birinchi gap. Bu esa ancha uzunroq ikkinchi gap bo'lib, u ekranga sig'ishi uchun bo'laklarga ajratiladi.", 40)
    ok(len(caps) >= 3 and all(len(c) <= 48 for c in caps), f"split_captions: {len(caps)} bo'lak, uzunlik chegarasida")
    ok("**" not in clean_narration("**Salom** https://x.com dunyo 😀") and "http" not in clean_narration("a https://x.com b"),
       "clean_narration markdown/URL/emoji ni tozalaydi")
    ok(tts_prepare("print(x)").endswith("."), "tts_prepare nuqta qo'yadi")
    ok(_check_code("def f(:\n  pass", "python") is not None, "kod tekshiruvi: Python sintaksis xatosini topadi")
    ok(_check_code("print(1)", "python") is None, "kod tekshiruvi: to'g'ri kodni qabul qiladi")
    ok(_check_code("function f() { return [1, 2; }", "js") is not None, "kod tekshiruvi: JS qavs xatosini topadi")
    kinds = {k for _, k in highlight_line("def f(x): return 'a' # izoh", "python")}
    ok({"kw", "str", "comment"} <= kinds, "sintaksis bo'yash: kw/str/comment")
    sc = [{"start": 0, "chapter": "A"}, {"start": 12, "chapter": "B"}, {"start": 30, "chapter": "C"}]
    ok(len(chapters(sc)) == 3, "bo'limlar (chapters) 0:00 dan boshlanadi va yetarli")
    ok(chapters([{"start": 0, "chapter": "A"}, {"start": 3, "chapter": "B"}]) == [], "kam bo'limlar bo'lsa chapters yo'q")


def feature_tests():
    section("1e) Ingliz talaffuzi, animatsiyali sxema, 1080p, sozlama tekshiruvi")
    import os
    import tempfile
    from pathlib import Path

    from aitube import anim, cleaner, pronounce, speak
    from aitube.bot import validate_setting
    from aitube.config import Config
    from aitube.enwords import EN
    from aitube.render import Renderer
    from aitube.writer import normalize_scenes

    ok(len(EN) > 2000, f"ingliz lug'ati katta: {len(EN)} so'z")
    for src, want in (("shape", "sheyp"), ("like", "layk"), ("database", "deyta beys"), ("python", "payton"),
                      ("pandas", "pendas"), ("function", "fankshn"), ("server", "server"), ("cache", "kesh"),
                      ("framework", "freymvork"), ("commit", "komit"), ("hello", "helou")):
        ok(speak.speak_text(src) == want, f"talaffuz: {src} -> {want} (chiqdi: {speak.speak_text(src)})")
    ok(speak.speak_text("db") == "di bi" and speak.speak_text("DB") == "di bi", "talaffuz: db -> di bi")
    ok(speak.speak_text("Pythonda") == "paytonda", "talaffuz: o'zbek qo'shimchasi (Pythonda)")
    ok(speak.speak_text("shape'ni") == "sheypni", "talaffuz: shape'ni")
    ok(speak.speak_text("users") == "yuzerlar" or speak.speak_text("users").startswith("yuzer"), "talaffuz: users")
    speak.set_pron({"zzfoo": "zifu"})
    ok(speak.speak_text("zzfoo") == "zifu" and speak.speak_text("zzfoo'ni") == "zifuni", "talaffuz: qo'shimcha (LLM/foydalanuvchi) lug'at")
    speak.set_pron({})
    m = pronounce._clean_map({"words": {"Shape": "sheyp", "xyz": "zz", "bad key!": "x", "Same": "same", "Ok": "OK<>"}},
                             "shape same ok")
    ok(m == {"shape": "sheyp"}, f"pronounce: LLM javobi tozalanadi ({m})")

    # konfiguratsiya: 1080p, 30 fps
    with tempfile.TemporaryDirectory() as td:
        os.environ["AITUBE_DATA"] = str(Path(td) / "d")
        cfg = Config(root=td, env_file=Path(td) / ".env")
        ok(cfg.size == (1920, 1080) and cfg.int("VIDEO_FPS") == 30, f"standart: 1080p/30fps {cfg.size}")
        cfg.overrides["VIDEO_RES"] = "720"
        ok(cfg.size == (1280, 720), "720p tanlansa 1280x720")
        cfg.overrides["VIDEO_RES"] = "1080"
        cfg.overrides["VIDEO_FORMAT"] = "shorts"
        ok(cfg.size == (1080, 1920) and cfg.base_size == (720, 1280), "shorts 1080x1920 (maket 720x1280)")
        cfg.overrides["VIDEO_FORMAT"] = "landscape"

        # animatsiyali sahnalar: diagram va compare barcha o'lcham/formatlarda chiziladi
        diagram = {"type": "diagram", "heading": "Server va foydalanuvchi", "packet": "msg",
                   "nodes": [{"id": "u", "kind": "user", "label": "Foydalanuvchi"}, {"id": "s", "kind": "server", "label": "Server"},
                             {"id": "d", "kind": "db", "label": "Baza"}],
                   "links": [{"from": "u", "to": "s", "label": "so'rov"}, {"from": "s", "to": "d", "label": "SQL", "kind": "data"},
                             {"from": "d", "to": "s", "label": "natija", "kind": "response"},
                             {"from": "s", "to": "u", "label": "javob", "kind": "response"}]}
        big = {"type": "diagram", "heading": "Katta sxema", "nodes": [
            {"id": str(i), "kind": k, "label": f"Tugun {i}"} for i, k in enumerate(
                ["user", "browser", "lb", "server", "bolt", "db", "cloud", "ai"])],
            "links": [{"from": str(i), "to": str((i + 1) % 8), "label": "x"} for i in range(8)]}
        cmp_ = {"type": "compare", "heading": "A va B", "left": {"title": "A", "items": ["bir", "ikki"]},
                "right": {"title": "B", "items": ["uch", "to'rt"]}}
        for res, fmt in (("720", "landscape"), ("1080", "landscape"), ("1080", "shorts")):
            cfg.overrides["VIDEO_RES"], cfg.overrides["VIDEO_FORMAT"] = res, fmt
            r = Renderer(cfg, accent_idx=1, episode_label="QISM 1", channel="Sinov")
            good = True
            try:
                for sc, n in ((diagram, 4), (diagram, 1), (big, 8), (cmp_, 2)):
                    im = r.frame(sc, n, 1.0, None, 0.5, t=3.0, age=7.0)
                    good = good and im.size == cfg.size
            except Exception as ex:  # noqa: BLE001
                good = False
                print("   ", res, fmt, type(ex).__name__, ex)
            ok(good, f"sxema/taqqoslash sahnalari {res}p {fmt} da chizildi")
        cfg.overrides["VIDEO_RES"], cfg.overrides["VIDEO_FORMAT"] = "1080", "landscape"
        r = Renderer(cfg, accent_idx=1, episode_label="QISM 1", channel="Sinov")
        c1 = r.content(diagram, 4, 1.0, 7.0)
        ok(c1.plate is not None, "sxema sahnasida shaffof (shisha) qatlam bor")
        sc2 = dict(diagram)
        f1, f2 = r.compose(1.0, c1, r.mask_for(c1), None, 0.5), r.compose(1.0, r.content(diagram, 4, 1.0, 7.5), r.mask_for(c1), None, 0.5)
        ok(f1.tobytes() != f2.tobytes(), "sxema animatsiyasi vaqt o'tishi bilan o'zgaradi (paketlar yuradi)")

    # skript normalizatsiyasi: LLM xatolari tuzatiladi
    sc = normalize_scenes([
        {"type": "diagram", "heading": "x", "narration": "bir ikki uch " * 5,
         "nodes": [{"id": "a", "kind": "person", "label": "Mijoz"}, {"id": "b", "kind": "", "label": "Server"},
                   {"id": "c", "kind": "zzz", "label": "Ma'lumotlar bazasi"}],
         "links": [{"from": "a", "to": "b", "label": "so'rov"}, {"from": "b", "to": "yo'q"}, {"from": "a", "to": "a"}]},
        {"type": "diagram", "heading": "yaroqsiz", "narration": "x", "nodes": [{"id": "a"}], "links": []},
        {"type": "compare", "heading": "c", "narration": "x", "left": {"title": "A", "items": ["1"]},
         "right": {"title": "B", "items": []}}])
    ok(len(sc) == 1 and sc[0]["type"] == "diagram", "yaroqsiz diagram/compare sahnalari tashlanadi")
    ok([n["kind"] for n in sc[0]["nodes"]] == ["user", "server", "db"], "tugun turlari yorliq/sinonimdan aniqlanadi")
    ok(len(sc[0]["links"]) == 1, "mavjud bo'lmagan tugunga ulangan aloqalar olib tashlanadi")
    ok(anim.infer_kind("", "Redis kesh") == "bolt" and anim.infer_kind("postgres") == "db", "anim.infer_kind")

    # sozlamalarni tekshirish
    ok(validate_setting("VIDEO_FPS", "30") is None and validate_setting("VIDEO_FPS", "31"), "sozlama: fps tekshiriladi")
    ok(validate_setting("VIDEO_RES", "1440") and validate_setting("VIDEO_RES", "1080") is None, "sozlama: sifat tekshiriladi")

    # Termux: os.link bo'lmasa ham nusxalash ishlaydi
    with tempfile.TemporaryDirectory() as td:
        a, b = Path(td) / "a.txt", Path(td) / "b.txt"
        a.write_text("x")
        real = getattr(os, "link", None)
        try:
            if real:
                delattr(os, "link")
            cleaner._link_or_copy(a, b)
        finally:
            if real:
                os.link = real
        ok(b.exists() and b.read_text() == "x", "os.link yo'q bo'lsa (Termux) fayl nusxalanadi")


def sync_tests():
    section("1c) Talaffuz filtri, so'z vaqtlari va video sinxronligi")
    import math
    import random
    import struct
    import subprocess
    import wave
    from aitube.speak import speak_text, speak_words
    from aitube.sync import align_words, make_chunks, proportional, read_env, speech_span
    from aitube.video import match_units

    ok(speak_text("Fayl .pdf formatda") == "Fayl pi di ef formatda", "talaffuz: .pdf -> pi di ef")
    ok("main nuqta pay" in speak_text("main.py faylini oching"), "talaffuz: main.py -> main nuqta pay")
    ok("ey pi ay lar" in speak_text("API'lar orqali"), "talaffuz: API'lar -> ey pi ay lar")
    ok(speak_text("getUserName") == "get yuzer neym", "talaffuz: camelCase so'zlarga bo'linadi va ingliz aytilishi")
    ok(speak_text("DataFrame shape'ni ko'ring").startswith("deyta freym sheyp"), "talaffuz: DataFrame/shape")
    ok(speak_text("like tugmasi va db ga") == "layk tugmasi va di bi ga", "talaffuz: like, db")
    ok(speak_text("open('a.csv', 'w')").rstrip(",").endswith("dabilyu"), "talaffuz: bir harfli 'w'")
    ok(speak_text("files copied running") == "faylar kopid raning", "talaffuz: ingliz shakllari")
    ok("gigabayt" in speak_text("16GB xotira") and "nuqta" in speak_text("Python 3.11"), "talaffuz: birliklar va versiya")
    ok(speak_text("node.js va C++") == "node jey es va si plyus plyus", "talaffuz: Node.js va C++")
    ok([w["w"] for w in speak_words("Fayl .pdf bor.")] == ["Fayl", ".pdf", "bor."], "talaffuz: ekrandagi so'zlar o'zgarmaydi")

    td = Path(tempfile.mkdtemp())
    try:
        text = ("Bugun biz fayllar bilan ishlashni o'rganamiz. Avval main.py faylini ochamiz, so'ng config.json ni "
                "o'qiymiz. Natija ekranga chiqadi, keyin esa uni .pdf formatda saqlaymiz.")
        words = speak_words(text)
        SR = 44100
        rnd = random.Random(5)
        samples, truth, t = [0] * int(SR * 0.3), [], 0.3
        for w in words:
            sp = w["s"] or "x"
            letters = max(2, len(sp.rstrip(".,;:!?")))
            d = 0.055 * letters * rnd.uniform(0.75, 1.3) + 0.08
            f0, n = rnd.uniform(110, 220), int(SR * d)
            for k in range(n):
                x = k / SR
                env = 0.35 + 0.65 * abs(math.sin(math.pi * x / d * max(1, letters // 3)))
                fade = min(1.0, k / (0.02 * SR), (n - k) / (0.02 * SR))
                samples.append(int(9000 * env * fade * math.sin(2 * math.pi * f0 * x)))
            truth.append((t, t + d))
            t += d
            gap = rnd.uniform(.35, .5) if sp[-1] in ".!?" else rnd.uniform(.18, .3) if sp[-1] in ",;:" else 0.03
            samples.extend([0] * int(SR * gap))
            t += gap
        samples.extend([0] * int(SR * 0.3))
        wav = td / "s.wav"
        with wave.open(str(wav), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes(b"".join(struct.pack("<h", v) for v in samples))
        al = align_words(wav, words)
        env, _, _ = read_env(wav)
        t0, t1, _, _ = speech_span(env)
        pr = proportional(words, t0, t1)
        ea = sum(abs(a[0] - b[0]) for a, b in zip(al, truth)) / len(words)
        ep = sum(abs(a[0] - b[0]) for a, b in zip(pr, truth)) / len(words)
        ok(ea < 0.08 and ea < ep / 2, f"so'z vaqtlari: o'rtacha xato {ea * 1000:.0f}ms (mutanosib usulda {ep * 1000:.0f}ms)")
        ok(len(al) == len(words) and all(b >= a for (a, b) in al) and all(al[i][0] <= al[i + 1][0] for i in range(len(al) - 1)),
           "so'z vaqtlari: tartibli va musbat")
        ch = make_chunks(words, al, 60)
        ok(ch and ch[0]["i0"] == 0 and ch[-1]["i1"] == len(words) - 1
           and all(ch[i]["i1"] + 1 == ch[i + 1]["i0"] for i in range(len(ch) - 1)), f"subtitr bo'laklari: {len(ch)} ta, uzluksiz")
        mu = match_units(["Faylni ochish", "Natijani saqlash"], words, al)
        ok(mu and mu[0] is not None and mu[1] is not None and mu[0] < mu[1], "band/qadam ovozdagi o'z so'ziga mos paydo bo'ladi")
        # Edge so'z chegaralari (aniq mos kelsa) ishlatiladi
        bounds, tt = [], 0.0
        for w, (a, b) in zip(words, truth):
            for _ in (w["s"].split() if w["s"] else []):
                bounds.append((a + 0.02, b - a, "x"))
        al2 = align_words(wav, words, bounds)
        ok(abs(al2[3][0] - truth[3][0]) < 0.12, "Edge chegaralari ovoz oralig'iga tekislanadi")

        # --- to'liq video: soxta nutq bilan, ovoz tez bo'lsa ham kesilmasligi va davomiylik tengligi
        from aitube.compose import compose_scenes
        from aitube.config import Config
        from aitube.render import Renderer
        from aitube.video import VideoBuilder

        class FakeTTS:
            def __init__(self, k):
                self.k = k

            def synth_ex(self, text, out, allow_silent=None, spec=None, prepared=False, only=None):
                sm = [0] * int(SR * 0.1)
                for wd in text.split():
                    n = int(SR * (0.03 * max(2, len(wd)) * self.k + 0.04))
                    sm += [int(8000 * math.sin(2 * math.pi * 160 * i / SR)) for i in range(n)]
                    sm += [0] * int(SR * (0.25 if wd[-1] in ".!?" else 0.02))
                with wave.open(str(out), "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(SR)
                    w.writeframes(b"".join(struct.pack("<h", v) for v in sm))
                return "fake", []

        os.environ["AITUBE_DATA"] = str(td / "data")
        cfg = Config()
        cfg.overrides["VIDEO_MOTION"] = "1"
        script = {"title": "Sinov: .pdf", "hook": "Salom, bu sinov videosi. Fayl .pdf formatda.",
                  "recap": "", "teaser": "Keyingi qismda ko'rishamiz.",
                  "scenes": [{"type": "bullets", "heading": "Band", "bullets": ["Birinchi", "Ikkinchi", "Uchinchi", "To'rtinchi"],
                              "narration": "Birinchi ikkinchi uchinchi to'rtinchi."},
                             {"type": "code", "heading": "Kod", "filename": "a.py", "language": "python",
                              "code": "x = 1\ny = 2\nprint(x + y)", "narration": "Kod qisqa."}]}
        for k, label in ((1.0, "oddiy"), (0.25, "juda tez")):
            scenes = compose_scenes(cfg, {"gno": 1, "season_id": 1}, script, None, None)
            out = td / f"v_{label.replace(' ', '')}.mp4"
            rr = Renderer(cfg, accent_idx=0, episode_label="QISM 1", channel="Sinov")
            res = VideoBuilder(cfg, FakeTTS(k)).build(scenes, td / f"w_{k}", out, rr)

            def dur(stream):
                r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", stream, "-show_entries",
                                    "stream=duration", "-of", "csv=p=0", str(out)], capture_output=True, text=True)
                return float(r.stdout.split()[0])

            dv, da = dur("v:0"), dur("a:0")
            last_voice = max((s["start_f"] + s["lead_f"]) / res["fps"] + s["voice_dur"] for s in scenes)
            ok(abs(dv - da) < 0.06 and abs(dv - res["duration"]) < 0.06, f"video ({label}): video {dv:.2f}s = ovoz {da:.2f}s")
            ok(dv >= last_voice + 0.3, f"video ({label}): ovoz kesilmadi (oxirgi so'z {last_voice:.2f}s, video {dv:.2f}s)")
            bl = next(s for s in scenes if s["type"] == "bullets")
            gaps = [b - a for a, b in zip(bl["unit_rel"], bl["unit_rel"][1:])]
            ok(all(g >= 0.89 for g in gaps), f"video ({label}): bandlar kamida 0.9s ko'rinadi (eng qisqa {min(gaps):.2f}s)")
            ok(res["frames"] == round(res["duration"] * res["fps"]), f"video ({label}): kadrlar soni davomiylikka mos ({res['frames']})")
    finally:
        shutil.rmtree(td, ignore_errors=True)


def chain_tests():
    section("1b) Zanjirni boshqarish (qaytish, unskip, fasl)")
    from aitube import chain
    from aitube.db import DB
    td = Path(tempfile.mkdtemp())
    try:
        db = DB(td / "t.db")
        s1 = db.add_season("Fasl A", "d")
        s2 = db.add_season("Fasl B", "d")
        vid = td / "v.mp4"
        for i in range(1, 7):
            db.add_episode(s1 if i <= 3 else s2, i if i <= 3 else i - 3, i, f"Ep{i}", f"mavzu{i}", f"va'da{i}")
        e = lambda g: db.ep_by_gno(g)
        vid.write_bytes(b"x")
        db.ep_update(e(1)["id"], status="uploaded", yt_id="Y1", yt_url="u1", summary="s1", script={"a": 1})
        db.ep_update(e(2)["id"], status="skipped")
        db.ep_update(e(3)["id"], status="ready", video_path=str(vid), script={"a": 1}, summary="s3")
        db.ep_update(e(4)["id"], status="failed", error="x", tries=3)
        ok(chain.rewind(db, 1)["error"] == "uploaded", "rewind: yuklangan epizod force'siz rad etiladi")
        r = chain.rewind(db, 3, dry=True)
        ok([g for g, _, _ in r["reset"]] == [3, 4] and e(3)["status"] == "ready", "rewind dry: o'zgarishsiz, ro'yxat to'g'ri")
        db.kv_set("halt_reason", "x")
        r = chain.rewind(db, 3)
        ok(e(3)["status"] == "planned" and e(4)["status"] == "planned" and e(3)["script"] is None
           and not vid.exists() and db.kv_get("halt_reason") is None, "rewind: #3,#4 planned, fayl o'chdi, halt tozalandi")
        ok(e(1)["status"] == "uploaded", "rewind: yuklangan #1 ga tegilmadi")
        db.ep_update(e(3)["id"], status="ready", script={"a": 1})
        r = chain.unskip(db, 2, cascade=True, dry=True)
        ok([g for g, _, _ in r["reset"]] == [2, 3], "unskip cascade dry: #2 va keyingi tayyor #3")
        chain.unskip(db, 2, cascade=False)
        ok(e(2)["status"] == "planned" and e(3)["status"] == "ready", "unskip keep: faqat #2 qaytdi")
        ok(chain.unskip(db, 2)["error"] == "not_skipped", "unskip: o'tkazilmagan epizod xatosi")
        r = chain.rewind(db, 1, force=True)
        ok(e(1)["status"] == "planned" and e(1)["plan"].get("old_uploads", [{}])[0].get("id") == "Y1"
           and e(1)["yt_id"] is None, "force rewind: eski yuklama plan.old_uploads da saqlandi")
        db.ep_update(e(1)["id"], status="uploaded", yt_id="Y1", yt_url="u1")
        # --- forget_uploaded: yuklanganni unutish
        ok(chain.forget_uploaded(db, 3)["error"] == "not_uploaded", "forget: yuklanmagan epizod rad etiladi")
        ok(chain.forget_uploaded(db, 99)["error"] == "topilmadi", "forget: yo'q epizod")
        db.ep_update(e(3)["id"], status="ready", video_path=str(vid), script={"a": 1}, summary="s3", llm="L", tts="T")
        vid.write_bytes(b"x")
        r = chain.forget_uploaded(db, 1, dry=True)
        ok([g for g, _, _ in r["reset"]] == [1, 3] and e(1)["status"] == "uploaded", "forget dry: #1 va keyingi tayyor #3, o'zgarishsiz")
        chain.forget_uploaded(db, 1)
        ok(e(1)["status"] == "planned" and e(1)["yt_id"] is None and e(1)["uploaded"] is None and e(1)["script"] is None
           and e(1)["summary"] is None and e(1)["llm"] is None and e(1)["tts"] is None,
           "forget: #1 yuklanmagan holatga qaytdi, eski sozlamalar unutildi")
        ok(e(1)["title"] == "Ep1" and e(1)["topic"] == "mavzu1" and e(1)["promise"] == "va'da1", "forget: sarlavha/mavzu/va'da saqlandi")
        ok([o["id"] for o in e(1)["plan"]["old_uploads"]] == ["Y1", "Y1"], "forget: eski YouTube havolasi old_uploads da")
        ok(e(3)["status"] == "planned" and not vid.exists(), "forget: keyingi tayyor #3 ham qayta yasashga qaytdi, fayl o'chdi")
        db.ep_update(e(1)["id"], status="uploaded", yt_id="Y1", yt_url="u1")
        db.ep_update(e(2)["id"], status="uploaded", yt_id="Y2", yt_url="u2")
        r = chain.forget_uploaded(db, None)
        ok(r["forgotten"] == [1, 2] and e(1)["status"] == "planned" and e(2)["status"] == "planned", "forget all: barcha yuklanganlar qaytdi")
        ok(chain.forget_uploaded(db, None)["error"] == "yo'q", "forget all: yuklangan qolmasa xabar")
        db.ep_update(e(1)["id"], status="uploaded", yt_id="Y1", yt_url="u1")
        chain.season_skip(db, s2)
        ok(all(e(g)["status"] == "skipped" for g in (4, 5, 6)), "season_skip: fasl B o'tkazildi")
        chain.season_unskip(db, s2)
        ok(all(e(g)["status"] == "planned" for g in (4, 5, 6)), "season_unskip: fasl B qaytdi")
        db.ep_update(e(5)["id"], status="ready", script={"a": 1})
        r = chain.season_restart(db, s2)
        ok(e(5)["status"] == "planned" and r["total"] == 3, "season_restart ishladi")
        ok(chain.edit_planned(db, 5, "title", "Yangi") is None and e(5)["title"] == "Yangi", "edit_planned: sarlavha")
        ok(chain.edit_planned(db, 1, "title", "X") is not None, "edit_planned: yuklanganni rad etadi")
        ok(chain.edit_planned(db, 5, "bad", "X") is not None, "edit_planned: noto'g'ri maydon rad")
        db.rename_season(s2, "Yangi nom")
        ov = chain.seasons_overview(db)
        ok(len(ov) == 2 and ov[1]["season"]["theme"] == "Yangi nom" and ov[0]["total"] == 3, "seasons_overview")
    finally:
        shutil.rmtree(td, ignore_errors=True)


def llm_tests():
    section("1d) Modellar/kalitlar boshqaruvi va jonli model qidirish")
    from aitube import llmadmin as adm
    from aitube.config import DEFAULTS, Config
    from aitube.fakeserver import FakeServer
    from aitube.llm import LLM, PROVIDERS

    tmp = Path(tempfile.mkdtemp(prefix="aitube_llm_"))
    fake = FakeServer().start()
    try:
        old = [m for k in ("GEMINI_MODELS", "GROQ_MODELS", "OPENROUTER_MODELS") for m in DEFAULTS[k].split(",")]
        ok(not any(x in old for x in ("llama-3.1-70b-versatile", "llama-3.1-8b-instant", "gemini-2.0-flash",
                                      "deepseek/deepseek-chat-v3-0324:free")), "Standart ro'yxatda o'lik modellar yo'q")
        cfg = Config(root=tmp, env_file=tmp / ".env")
        cfg.overrides.update({"GEMINI_BASE": fake.url, "GROQ_BASE": fake.url, "OPENROUTER_BASE": fake.url})
        # kalitlar
        k1, k2 = "gsk_" + "a" * 30, "gsk_" + "b" * 30
        ok(adm.add_key(cfg, "groq", k1)[0] and adm.add_key(cfg, "groq", k2)[0], "Kalit qo'shish")
        ok(not adm.add_key(cfg, "groq", k1)[0], "Takroriy kalit rad etildi")
        ok(not adm.add_key(cfg, "groq", "qisqa")[0], "Yaroqsiz shakldagi kalit rad etildi")
        ok(cfg.list("GROQ_API_KEYS") == [k1, k2], "Kalitlar .env ga yozildi")
        ok(adm.mask(k1) == "gsk_…aaa" and k1 not in adm.edit_key(cfg, "groq", 1, "gsk_" + "c" * 30)[1],
           "Kalit tahrirlandi, javobda to'liq kalit yo'q")
        ok(cfg.list("GROQ_API_KEYS")[0] == "gsk_" + "c" * 30, "Tahrirlangan kalit saqlandi")
        ok(adm.del_key(cfg, "groq", 2)[0] and len(adm.keys(cfg, "groq")) == 1, "Kalitni o'chirish")
        ok(not adm.del_key(cfg, "groq", 9)[0], "Yo'q raqamni o'chirib bo'lmaydi")
        # modellar
        ok(adm.set_models(cfg, "groq", ["a-1", "b-2", "c-3"])[0], "Modellar ro'yxati o'rnatildi")
        ok(adm.use_model(cfg, "groq", "3")[0] and adm.models(cfg, "groq")[0] == "c-3", "Modelni asosiy qilish")
        ok(adm.add_model(cfg, "groq", "d-4")[0] and adm.models(cfg, "groq")[-1] == "d-4", "Model qo'shish")
        ok(adm.edit_model(cfg, "groq", "d-4", "e-5")[0] and "e-5" in adm.models(cfg, "groq"), "Modelni tahrirlash")
        ok(adm.del_model(cfg, "groq", "1")[0] and "c-3" not in adm.models(cfg, "groq"), "Modelni o'chirish")
        ok(adm.set_order(cfg, ["groq", "google"])[0] and cfg.get("LLM_ORDER") == "groq,gemini", "Provayder tartibi")
        ok(not adm.set_order(cfg, ["nomalum"])[0], "Noma'lum provayder rad etildi")
        # jonli qidirish
        llm = LLM(cfg)
        g = llm.discover(PROVIDERS["groq"](cfg), "k")
        ok(g[0] == "big-120b-chat" and not any("whisper" in x or "orpheus" in x for x in g),
           f"Groq: ovoz modellari yo'q, kattasi birinchi {g}")
        o = llm.discover(PROVIDERS["openrouter"](cfg), "k")
        ok(o == ["free/x-70b:free"], f"OpenRouter: faqat bepul modellar {o}")
        gm = llm.discover(PROVIDERS["gemini"](cfg), "k")
        ok(gm == ["gemini-9-flash", "gemini-9-flash-lite"], f"Gemini: flash oldin, pro/embedding/tts yo'q {gm}")
        # o'lik modellar -> avtomatik yangisini topadi va saqlaydi
        cfg.overrides.update({"LLM_ORDER": "groq", "GROQ_API_KEYS": "k1", "GROQ_MODELS": "dead404,dead400",
                              "LLM_AUTO_MODELS": "1"})
        llm = LLM(cfg)
        text, label = llm.complete("tizim", "salom", max_tokens=50)
        ok(label == "groq:big-120b-chat", f"O'lik modellar o'tkazildi, yangi model topildi ({label})")
        cfg.overrides.pop("GROQ_MODELS", None)
        ok(cfg.list("GROQ_MODELS")[0] == "big-120b-chat", "Topilgan modellar .env ga saqlandi")
        ok(llm.test_key(PROVIDERS["groq"](cfg), "k1")[0], "Kalitni sinash ishlaydi")
    finally:
        fake.stop()
        shutil.rmtree(tmp, ignore_errors=True)


def net_tests():
    section("1e) Internet uzilganda kutish va davom etish")
    import threading as th

    import requests

    from aitube import util
    NET = util.NET
    events, state, calls = [], {"online": False}, {"n": 0}
    old = (NET.on_event, NET.probe_fn, NET.delay0, util._session.request)

    class R:
        status_code, text, content = 200, "ok", b"ok"

    def fake_request(method, url, timeout=None, **kw):
        calls["n"] += 1
        if not state["online"]:
            raise requests.ConnectionError("internet yo'q")
        return R()

    NET.on_event = lambda ev, secs: events.append(ev)
    NET.probe_fn = lambda: state["online"]
    NET.delay0 = 0.05
    util._session.request = fake_request
    try:
        try:
            util.http("GET", "http://x", retries=1)
            plain = False
        except requests.ConnectionError:
            plain = True
        ok(plain, "wait_net=False: xato darrov ko'tariladi")
        res = []
        ths = [th.Thread(target=lambda: res.append(util.http("GET", "http://x", retries=1, wait_net=True).status_code))
               for _ in range(3)]
        th.Timer(0.8, lambda: state.update(online=True)).start()
        t0 = time.time()
        for t in ths:
            t.start()
        for t in ths:
            t.join(10)
        ok(res == [200, 200, 200] and time.time() - t0 >= 0.7, "Internet uzilgan: so'rovlar kutib, aloqa qaytgach muvaffaqiyatli bajarildi")
        time.sleep(0.4)
        ok(events.count("down") == 1 and events.count("up") == 1, f"Uzilish/qaytish haqida bir martadan xabar ({events})")
        state["online"] = False
        NET.max_wait = 0.3
        ok(NET.wait_online()[0] is False, "Internet qaytmasa, vaqt tugagach taslim bo'ladi")
        NET.max_wait = 12 * 3600
        ok(util.is_net_error(requests.ConnectionError("x")) and not util.is_net_error(ValueError("bad json")),
           "is_net_error to'g'ri ajratadi")
    finally:
        NET.on_event, NET.probe_fn, NET.delay0, util._session.request = old
        NET.offline, NET.last_ok = False, True


def security_tests():
    section("1f) Himoya: begona foydalanuvchilar")
    from aitube.config import Config
    from aitube.db import DB
    from aitube.security import Guard

    tmp = Path(tempfile.mkdtemp(prefix="aitube_sec_"))
    try:
        cfg = Config(root=tmp, env_file=tmp / ".env")
        cfg.overrides["ADMIN_ID"] = "111"
        db = DB(tmp / "t.db")
        sent = []

        class N:
            def say(self, text, markup=None, silent=False):
                sent.append((text, markup))

        g = Guard(cfg, db, N())
        pm = lambda uid, text="/start", cid=None: {"update_id": 1, "message": {"from": {"id": uid, "username": "x"},
                                                                              "chat": {"id": cid or uid, "type": "private"}, "text": text}}
        ok(g.classify(pm(111)) is True, "Admin shaxsiy chatda qabul qilinadi")
        ok(g.classify(pm(555, "/start")) is False and g.is_blocked(555), "Begona /start bosdi: darrov bloklandi")
        ok(len(sent) == 1 and "555" in sent[0][0], "Admin ga bitta ogohlantirish yuborildi")
        for _ in range(50):
            g.classify(pm(555, "/status"))
        ok(len(sent) == 1 and g.dropped == 50, "Bloklangan foydalanuvchi so'rovlari jim tashlab yuboriladi (qayta ogohlantirish ham yo'q)")
        cbq = {"update_id": 2, "callback_query": {"id": "c", "from": {"id": 777}, "data": "m:status",
                                                  "message": {"message_id": 1, "chat": {"id": 111, "type": "private"}}}}
        ok(g.classify(cbq) is False and g.is_blocked(777), "Begona tugma bosdi (admin chatidagi xabarga ham): bloklandi")
        ok(g.classify(pm(111, "/menu", cid=-100123)) is False, "Admin guruh chatida: javob berilmaydi")
        grp = pm(111)
        grp["message"]["chat"]["type"] = "supergroup"
        ok(g.classify(grp) is False, "Admin guruhdan yozsa ham ishlov berilmaydi (ma'lumot guruhga oqmasin)")
        ok(g.classify({"update_id": 3, "edited_message": {"from": {"id": 9}}}) is False and not g.is_blocked(9),
           "Noma'lum update turi e'tiborsiz")
        ok(g.classify({"update_id": 4, "message": {"chat": {"id": 1, "type": "private"}, "text": "x"}}) is False,
           "Yuboruvchisiz xabar tashlab yuboriladi")
        bot_msg = pm(111)
        bot_msg["message"]["from"]["is_bot"] = True
        ok(g.classify(bot_msg) is False, "is_bot yuboruvchi rad etiladi")
        # saqlanadi va tiklanadi
        g2 = Guard(cfg, db, N())
        ok(g2.is_blocked(555) and g2.is_blocked(777), "Bloklar bazada saqlanadi (qayta ishga tushganda ham)")
        ok(g2.unblock(555) and not g2.is_blocked(555) and not g2.unblock(555), "Blokdan chiqarish ishlaydi")
        for uid in range(1000, 1030):
            g.classify(pm(uid))
        ok(len(sent) <= 9, f"Ogohlantirishlar soat davomida cheklangan (jami {len(sent)})")
        ok(g.classify(pm(111)) is True, "Ommaviy hujumdan keyin ham admin ishlay oladi")
        cfg.overrides["ADMIN_ID"] = ""
        ok(g.classify(pm(2001)) == "setup" and g.classify(pm(2002, cid=-5)) is False,
           "ADMIN_ID yo'q: faqat shaxsiy chatda ID aytiladi")
        # fayl ruxsatlari
        import os as _os
        from aitube.security import harden_files
        (tmp / ".env").write_text("A=1\n")
        _os.chmod(tmp / ".env", 0o666)
        harden_files(cfg)
        ok((_os.stat(tmp / ".env").st_mode & 0o077) == 0, ".env fayliga faqat egasi kira oladi (600)")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def e2e():
    from aitube.app import App
    from aitube.bot import Bot
    from aitube.config import Config
    from aitube.fakeserver import FakeServer

    tmp = Path(tempfile.mkdtemp(prefix="aitube_selftest_"))
    os.environ["AITUBE_DATA"] = str(tmp / "data")
    fake = FakeServer().start()
    try:
        section("2) Soxta serverlar bilan to'liq zanjir")
        root = Path(__file__).resolve().parent.parent
        cfg = Config(root=root, env_file=tmp / ".env")
        cfg.overrides.update({
            "TELEGRAM_BOT_TOKEN": "123:TESTTOKEN", "ADMIN_ID": "111", "TG_API_BASE": fake.url,
            "YT_API_BASE": fake.url, "OAUTH_BASE": fake.url, "YT_CLIENT_ID": "cid", "YT_CLIENT_SECRET": "sec",
            "LLM_ORDER": "groq", "GROQ_API_KEYS": "k1,k2", "GROQ_BASE": fake.url, "GROQ_MODELS": "m1",
            "TTS_ORDER": "google", "GTTS_BASE": fake.url + "/translate_tts", "TTS_LANG": "uz",
            "EPISODE_MINUTES": "1", "SEASON_LENGTH": "3", "UPLOAD_TIMES": "00:00", "BUFFER_AHEAD": "0",
            "YT_PRIVACY": "public", "VIDEO_FPS": "20", "CHANNEL_NAME": "Test Kanal",
            "POLLINATIONS_IMG_BASE": fake.url, "IMG_ORDER": "pollinations",
        })
        app = App(cfg)
        app.jobs.start()
        st = fake.state

        # Telegram
        mid = app.n.say("<b>sinov</b>")
        ok(mid is not None and any(m == "sendMessage" for m, _ in st.tg_calls), "Telegram: sendMessage ishlaydi")
        ok(len(app.tg.split_text("x\n" * 5000)) >= 3, "Telegram: uzun matn bo'laklanadi")

        # YouTube device auth
        ok(not app.yt.authorized(), "YouTube: avvaliga avtorizatsiya yo'q")
        dev = app.yt.device_start()
        ok(dev["user_code"] == "ABCD-EFGH", "YouTube: device_start")
        ok(app.yt.device_poll(dev) and app.yt.authorized(), "YouTube: device_poll token saqladi")
        ok(app.yt.channel().get("title") == "Test kanal", "YouTube: channels.list")
        # Desktop turidagi kalit uchun telefon brauzeri (loopback) usuli
        app.yt.logout()
        ok(not app.yt.authorized(), "YouTube: logout ishladi")

        def fake_browser(url):
            import threading
            import urllib.parse
            import requests
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            redirect, state = q["redirect_uri"][0], q["state"][0]
            threading.Thread(target=lambda: (time.sleep(0.5), requests.get(
                redirect, params={"code": "C1", "state": state}, timeout=10)), daemon=True).start()

        ok(app.yt.loopback_auth(fake_browser, timeout=20) and app.yt.authorized(),
           "YouTube: loopback (Desktop kalit) avtorizatsiyasi ishladi")

        # yuklash uzilib qolsa: saqlangan seansdan to'xtagan baytdan davom etadi
        big = tmp / "resume.mp4"
        big.write_bytes(os.urandom(30000))
        st.uploads["SX"] = {"meta": {"snippet": {"title": "t"}, "status": {"privacyStatus": "public"}},
                            "data": bytearray(big.read_bytes()[:12345]), "total": 30000}

        class Sess:
            loc = fake.url + "/upload-session/SX"

            def get(self):
                return self.loc

            def set(self, v):
                self.loc = v

            def clear(self):
                self.loc = None

        sess = Sess()
        resp = app.yt.upload(str(big), "t", "d", [], session=sess)
        ok(resp["id"] in st.videos and st.videos[resp["id"]]["size"] == 30000 and sess.loc is None,
           "YouTube yuklash saqlangan seansdan (12345-baytdan) davom etdi, noldan boshlanmadi")

        # 1-epizod
        ep1 = app.pipeline.produce_next()
        from . import selftest_more as sm0
        if ep1:
            sm0.image_e2e(app, st, ep1)
        ok(ep1 and ep1["status"] == "ready", "Pipeline: 1-epizod tayyor")
        if not ep1:
            return
        ok(Path(ep1["video_path"]).exists() and Path(ep1["thumb_path"]).exists(), "Video va muqova fayllari bor")
        ok(ep1["duration"] > 20, f"Video davomiyligi {ep1['duration']:.0f}s")
        sc1 = ep1["script"]
        ok(sc1["recap"] == "", "1-epizodda 'oldingi qism' xulosasi yo'q")
        ok(any("tayyor" in t for t in fake.tg_texts()), "Admin ga 'epizod tayyor' hisoboti yuborildi")
        ok(any(m == "sendVideo" for m, _ in st.tg_calls), "Admin ga video yuborildi")

        # requests yuklash muvaffaqiyatsiz bo'lsa curl zaxirasi ishlashi kerak
        from aitube.tg import TGError
        orig_api = app.tg.api

        def flaky(method, params=None, files=None, **kw):
            if files:
                raise TGError("simulated write timeout")
            return orig_api(method, params, files, **kw)

        app.tg.api = flaky
        n_doc = sum(1 for m, _ in st.tg_calls if m == "sendDocument")
        try:
            res = app.tg.send_file("document", ep1["thumb_path"], "<b>curl sinov</b>")
        finally:
            app.tg.api = orig_api
        ok(res is not None and sum(1 for m, _ in st.tg_calls if m == "sendDocument") == n_doc + 1,
           "Telegram: requests muvaffaqiyatsiz bo'lsa curl orqali fayl yuboriladi")
        ok(any(p.get("caption") == "<b>curl sinov</b>" for m, p in st.tg_calls if m == "sendDocument"),
           "curl: '<' bilan boshlanuvchi sarlavha buzilmaydi")

        # yuklash: avval kvota xatosi
        st.fail_upload_once = True
        r = app.pipeline.upload_episode(ep1)
        ok(r is None and float(app.db.kv_get("upload_block_until", "0")) > time.time(), "Kvota xatosi: yuklash 4 soatga to'xtatildi")
        app.db.kv_set("upload_block_until", "0")
        r = app.pipeline.upload_episode(ep1)
        ok(r and r["status"] == "uploaded" and r["yt_id"] in st.videos, "1-epizod YouTube ga yuklandi")
        v1 = st.videos[r["yt_id"]]
        from . import selftest_more as sm
        sm.schedule_e2e(app, st, ep1, r)
        r = app.db.ep(r["id"])
        ok(v1["synthetic"] is True, "AI kontent belgisi (containsSyntheticMedia) yuborildi")
        ok(len(st.thumbs) == 1 and st.thumbs[0][0] == r["yt_id"], "Muqova o'rnatildi")
        ok(len(st.playlists) == 1 and len(st.playlist_items) == 1, "Fasl pleylisti yaratildi va video qo'shildi")
        ok(any("maxfiy" in t.lower() or "private" in t.lower() for t in fake.tg_texts()), "Maxfiy holat haqida ogohlantirish yuborildi")
        ok("tez orada" in v1["snippet"]["description"], "1-tavsifda 'keyingi qism: tez orada' bor")
        ok("Bo'limlar" in v1["snippet"]["description"], "Tavsifda bo'limlar (chapters) bor")

        # 2-epizod: oldingiga bog'liq
        ep2 = app.pipeline.produce_next()
        ok(ep2 and ep2["status"] == "ready", "2-epizod tayyor")
        sc2 = ep2["script"]
        ok(ep1["title"].split("(")[0].strip()[:12].lower() in sc2["recap"].lower(), "2-epizod recap oldingi qism nomiga bog'langan")
        ok(ep1["summary"][:20] in ep2["script"]["recap"] or len(sc2["recap"]) > 20, "recap oldingi xulosadan foydalanadi")
        nxt = app.db.next_planned_after(ep2["gno"])
        ok(nxt and any(w in sc2["teaser"].lower() for w in nxt["title"].lower().split()[:2]), "2-epizod teaser keyingi qism nomini aytadi")
        # oldingi qismning teaser nomi = haqiqiy 2-epizod nomi
        ok(ep2["title"].split("(")[0].strip().lower()[:10] in ep1["script"]["teaser"].lower(), "1-epizod teaseri aynan 2-epizod mavzusini va'da qildi")
        r2 = app.pipeline.upload_episode(ep2)
        ok(r2 and r2["status"] == "uploaded", "2-epizod yuklandi")
        d1 = st.videos[r["yt_id"]]["snippet"]["description"]
        ok(r2["yt_url"] in d1 and "tez orada" not in d1, "1-video tavsifiga 2-video havolasi yozildi")
        d2 = st.videos[r2["yt_id"]]["snippet"]["description"]
        ok(r["yt_url"] in d2, "2-video tavsifida oldingi video havolasi bor")

        # pleylist o'chirib yuborilsa: qayta yaratiladi va videolar qayta qo'shiladi
        from aitube.playlist import sync_season
        sid = app.db.ep(r["id"])["season_id"]
        pl_old = app.db.season(sid)["playlist_id"]
        ok(len(st.playlists) == 1 and sum(1 for i in st.playlist_items if i["snippet"]["playlistId"] == pl_old) == 2,
           "Pleylistda 2 ta video bor")
        ok(sync_season(app.yt, app.db, app.cfg, sid) == [], "Pleylist joyida bo'lsa hech narsa o'zgarmaydi")
        st.deleted_playlists.add(pl_old)
        notes = sync_season(app.yt, app.db, app.cfg, sid)
        pl_new = app.db.season(sid)["playlist_id"]
        ok(pl_new != pl_old and len(st.playlists) == 2, "O'chgan pleylist (404) qayta yaratildi")
        vids_new = [i["snippet"]["resourceId"]["videoId"] for i in st.playlist_items if i["snippet"]["playlistId"] == pl_new]
        ok(vids_new == [r["yt_id"], r2["yt_id"]], "Yangi pleylistga barcha yuklangan videolar tartib bilan qo'shildi")
        ok(any("qayta" in n or "o'chirib" in n for n in notes), "Foydalanuvchiga pleylist tiklangani aytildi")
        # yuklash paytida pleylist yo'qolgan bo'lsa ham xato chiqmaydi
        st.deleted_playlists.add(pl_new)
        notes = sync_season(app.yt, app.db, app.cfg, sid)
        ok(app.db.season(sid)["playlist_id"] not in (pl_old, pl_new) and len(st.playlists) == 3,
           "Ketma-ket ikkinchi marta o'chirilsa ham tiklanadi")

        # zanjir tartibi
        ep3 = app.pipeline.produce_next()
        ok(ep3 and ep3["gno"] == 3, "3-epizod (fasl oxiri) tayyor")
        ok(len(app.db.planned()) >= 1, "Yangi fasl avtomatik rejalandi (uzluksiz zanjir)")
        app.db.ep_update(ep3["id"], status="planned")
        app.db.ep_update(ep3["id"], status="ready")
        blk = app.pipeline.chain_blocker(app.db.ep(ep3["id"]))
        ok(blk is None, "Zanjir: oldingilar yuklangan bo'lsa to'siq yo'q")
        fut = app.db.next_planned_after(ep3["gno"])
        ok(fut is not None, "3-epizod uchun keyingi (yangi fasl) epizod mavjud")
        ep4 = app.db.ep_by_gno(4)
        blk = app.pipeline.chain_blocker({"gno": 5, "id": 0}) if app.db.ep_by_gno(5) else None
        ok(blk is None or blk["gno"] < 5, "Zanjir: kech epizod oldingisini kutadi")

        # statistika
        app.stats.refresh()
        ok(app.db.ep(r["id"])["views"] == 42, "Statistika: ko'rishlar DB ga yozildi")
        app.stats.check_comments(notify=False)
        ok("Kunlik hisobot" in app.stats.digest(), "Kunlik hisobot yig'iladi")

        # shorts formatida video
        section("3) Shorts formati")
        cfg.overrides["VIDEO_FORMAT"] = "shorts"
        ep5 = app.pipeline.produce_next()
        ok(ep5 and ep5["status"] == "ready", "Shorts epizodi tayyor")
        if ep5:
            from aitube.util import run
            rc, out, _ = run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height", "-of", "csv=p=0",
                              ep5["video_path"]])
            ok("1080,1920" in out, f"Shorts o'lchami 1080x1920 ({out.strip()})")
        cfg.overrides["VIDEO_FORMAT"] = "landscape"

        # bot (haqiqiy polling orqali)
        section("4) Telegram bot (polling)")
        bot = Bot(app)
        bot.start()
        before = len(fake.tg_texts())
        for i, text in enumerate(["/status", "/queue", "/plan", "/ep 1", "/episodes", "/config", "/set TTS_RATE +5%",
                                  "/times 10:00,19:30", "/topic Docker haqida", "/note qisqaroq bo'lsin", "/health",
                                  "/pause", "/resume", "/logs 5", "/ping", "/menu", "/noma'lum"]):
            st.updates.append({"update_id": 1000 + i, "message": {"from": {"id": 111, "username": "admin"},
                                                                  "chat": {"id": 111, "type": "private"}, "text": text}})
        st.updates.append({"update_id": 2000, "message": {"from": {"id": 999, "username": "xaker"},
                                                          "chat": {"id": 999, "type": "private"}, "text": "/status"}})
        t0 = time.time()
        while len(fake.tg_texts()) < before + 18 and time.time() - t0 < 25:
            time.sleep(0.4)
        texts = "\n".join(fake.tg_texts()[before:])
        ok("Holat" in texts, "Bot: /status javob berdi")
        ok("Navbat" in texts and "Fasl" in texts, "Bot: /queue va /plan")
        ok("TTS_RATE" in texts and cfg.get("TTS_RATE") == "+5%", "Bot: /set sozlamani o'zgartirdi")
        ok(cfg.get("UPLOAD_TIMES") == "10:00,19:30", "Bot: /times jadvalni o'zgartirdi")
        ok("Salomatlik" in texts, "Bot: /health")
        ok("bloklandi" in texts, "Bot: begona foydalanuvchi bloklandi va admin ogohlantirildi")
        ok(not any(p.get("chat_id") == 999 for m, p in st.tg_calls if m.startswith(("send", "answer", "edit"))),
           "Bot: begona foydalanuvchiga HECH QANDAY javob yuborilmadi")
        ok(app.guard.is_blocked(999), "Bot: begona foydalanuvchi doimiy bloklandi")
        ok(app.db.kv_json("topic_queue") == ["Docker haqida"] and app.db.kv_get("admin_note"), "Bot: /topic va /note saqlandi")
        ok(cfg.get("PAUSED") == "0", "Bot: /pause /resume")

        # client_secret JSON ni botga yuborib import qilish
        import json as _json
        st.file_bytes = _json.dumps({"installed": {"client_id": "newid.apps.googleusercontent.com",
                                                    "client_secret": "GOCSPX-newsecret"}}).encode()
        st.updates.append({"update_id": 2500, "message": {"message_id": 77, "from": {"id": 111}, "chat": {"id": 111, "type": "private"},
                                                          "document": {"file_id": "F", "file_name": "client_secret_x.json",
                                                                       "file_size": 300}}})
        t0 = time.time()
        while cfg.get("YT_CLIENT_ID") != "newid.apps.googleusercontent.com" and time.time() - t0 < 10:
            time.sleep(0.3)
        ok(cfg.get("YT_CLIENT_ID") == "newid.apps.googleusercontent.com" and cfg.get("YT_CLIENT_SECRET") == "GOCSPX-newsecret",
           "Bot: client_secret JSON fayli qabul qilindi va kalitlar saqlandi")
        time.sleep(1)
        ok(any(m == "deleteMessage" for m, _ in st.tg_calls), "Bot: maxfiy fayl xabari chatdan o'chirildi")

        # callback: tasdiqlash
        ep6id = ep5["id"]
        st.updates.append({"update_id": 3000, "callback_query": {"id": "cb1", "from": {"id": 111}, "data": f"skip:{ep6id}",
                                                                 "message": {"message_id": 5, "chat": {"id": 111, "type": "private"}}}})
        t0 = time.time()
        while app.db.ep(ep6id)["status"] != "skipped" and time.time() - t0 < 60:
            time.sleep(0.3)
        ok(app.db.ep(ep6id)["status"] == "skipped", "Bot: inline tugma (skip) ishladi")

        # jadval
        section("5) Jadval")
        from aitube.scheduler import next_slot, parse_times
        ok(parse_times("19:30, 10:00,xx") == [(10, 0), (19, 30)], "parse_times")
        ok(next_slot(cfg) is not None, "next_slot hisoblandi")
        cfg.overrides["UPLOAD_TIMES"] = "00:00"
        cfg.overrides["AUTO_UPLOAD"] = "1"
        wait_jobs(app, 120)      # oldingi (skip) ish tugasin: xabar yuborish endi 0.4 s throttle ga bo'ysunadi
        app.sched.tick()
        wait_jobs(app, 300)
        ups = app.db.counts().get("uploaded", 0)
        ok(ups >= 3, f"Jadval: slot ishga tushdi va keyingi epizod yuklandi (jami yuklangan: {ups})")
        ok(app.db.kv_get("health_last") is not None, "Jadval: salomatlik tekshiruvi ishladi")

        section("5b) Yangi bot buyruqlari")
        db = app.db
        for c, a_ in (("seasons", ""), ("season", "1"), ("back", "99"), ("unskip", ""), ("edit", "1 title x"),
                      ("voice", "male"), ("format", "shorts"), ("format", "landscape"), ("clean", ""), ("ep", "1"), ("forget", ""), ("forget", "99"), ("forget", "x")):
            try:
                bot.command(c, a_, 111)
                good = True
            except Exception as ex:
                good = False
                print("   ", c, type(ex).__name__, ex)
            ok(good, f"/{c} {a_}".strip() + " xatosiz ishladi")
        ok(cfg.get("TTS_VOICE") == "uz-UZ-SardorNeural", "/voice male: Sardor o'rnatildi")
        from . import selftest_more as sm2
        sm2.bot_ui_tests(app, bot)
        sm2.stream_tests(app, bot, fake, tmp)
        sm2.hide_stats_tests(app, fake)
        wait_jobs(app, 60)
        wait_jobs(app, 60)
        import threading as _th
        gate = _th.Event()
        app.jobs.submit("fake-heavy", lambda: gate.wait(20))
        time.sleep(0.4)
        t1 = time.time()
        r = bot.c_voice("test qiz2", 111)
        ok(r and "tayyorlan" in r and time.time() - t1 < 2, "Yengil ish (ovoz namunasi) og'ir ish ketayotganda ham darrov qabul qilindi")
        ok(cfg.get("TTS_VOICE") == "uz-UZ-SardorNeural" and cfg.get("TTS_PITCH") == "+0Hz",
           "Ovoz namunasi umumiy sozlamalarni o'zgartirmadi")
        r = bot.c_back("1 force ok", 111)
        ok(r and "navbat" in r.lower(), "O'zgartiruvchi amal og'ir ish paytida rad etilmadi, navbatga qo'yildi")
        gate.set()
        wait_jobs(app, 120)

        section("5c) Avto-tozalash, Qayta yaratilganlar, videolar boshqaruvi")
        from aitube import cleaner
        cfg.overrides["AUTO_CLEAN"] = "1"
        _cf = list(cfg.dirs["cache"].glob("tts_*"))
        r_ = cleaner.clean(cfg, db)
        ok(not _cf or any(f.exists() for f in _cf), "Avto-tozalash: yaqinda yasalgan ovoz keshi qoladi (eski ovozni qayta ishlatish uchun)")
        for _f in _cf:
            if _f.exists():
                os.utime(_f, (time.time() - 3 * 86400, time.time() - 3 * 86400))
        r_ = cleaner.clean(cfg, db)
        keep_g = cleaner.protected_eps(db)
        left = [e for e in db.all_episodes() if e.get("video_path") and Path(e["video_path"]).exists()]
        ok(all(e["gno"] in keep_g for e in left), f"Avto-tozalash: faqat oxirgi yaratilgan va yuklashni kutayotgan videolar qoldi ({[e['gno'] for e in left]})")
        ok(not list(cfg.dirs["cache"].glob("tts_*")), "Avto-tozalash: eski (2 kundan oshgan) ovoz keshi tozalandi")
        cfg.overrides["AUTO_CLEAN"] = "0"
        ok(cleaner.clean(cfg, db).get("skipped"), "Avto-tozalash o'chiq bo'lsa tegmaydi")
        cfg.overrides["AUTO_CLEAN"] = "1"
        cand = next((e for e in db.all_episodes() if e["status"] in ("ready", "planned", "scripted")), None)
        if cand:
            before_v = len(db.regen_list())
            ok(app.pipeline.regenerate(cand["id"], keep=True) is not None, "/retry N: epizod noldan qayta yasaldi")
            from . import selftest_more as sm3
            sm3.retry_tests(app, bot, fake, cand["gno"])
            rl = db.regen_list(cand["gno"])
            ok(bool(rl) and len(db.regen_list()) == before_v + 1 and Path(rl[0]["video_path"]).exists(),
               "Qayta yaratilgan video «Qayta yaratilganlar» ga saqlandi")
            cleaner.clean(cfg, db, force=True)
            ok(Path(rl[0]["video_path"]).exists(), "Avto-tozalash «Qayta yaratilganlar» ga tegmaydi")
            ok(db.kv_get("last_created_gno") == str(cand["gno"]), "Oxirgi yaratilgan video eslab qolindi")
            # boshqarish
            for cb in ("list:0", f"ep:{cand['gno']}:0", "rg:0", f"rge:{rl[0]['id']}", f"rgg:{cand['gno']}", "ac", "ac"):
                try:
                    bot.vd_callback(cb, 111)
                    good = True
                except Exception as ex:
                    good = False
                    print("   vd", cb, type(ex).__name__, ex)
                ok(good, f"Tugma vd:{cb} xatosiz ishladi")
            db.ep_update(cand["id"], status="planned")
            ok(cleaner.promote_regenerated(cfg, db, rl[0]["id"]) is None and db.ep(cand["id"])["status"] == "ready"
               and Path(db.ep(cand["id"])["video_path"]).exists(), "Saqlangan versiya asosiy video qilindi")
            ok(cleaner.delete_regenerated(db, rl[0]["id"]) and not Path(rl[0]["video_path"]).exists(),
               "Saqlangan versiya o'chirildi")
        ok("topilmadi" in bot.c_retry("9999", 111), "/retry 9999: epizod topilmadi")
        up1 = next((e for e in db.all_episodes() if e["status"] == "uploaded"), None)
        if up1:
            n_msg = len(fake.tg_texts())
            bot.c_retry(str(up1["gno"]), 111)
            ok(any("unutib" in t for t in fake.tg_texts()[n_msg:]), "/retry yuklangan epizodda: unutishni tasdiqlash so'raladi")
        for c, a_ in (("videos", ""), ("regen", ""), ("autoclean", "off"), ("autoclean", "on"), ("blocked", ""),
                      ("security", ""), ("models", ""), ("keys", ""), ("playlist", ""), ("order", "")):
            try:
                bot.command(c, a_, 111)
                good = True
            except Exception as ex:
                good = False
                print("   ", c, type(ex).__name__, ex)
            ok(good, f"/{c} xatosiz ishladi")
        for cb in ("ui:models", "ui:keys", "ui:mp:groq", "ui:kp:groq", "ui:ma:groq", "ui:cancel", "sec:unblock:1"):
            try:
                bot.callback(cb, 111)
                good = True
            except Exception as ex:
                good = False
                print("   ", cb, type(ex).__name__, ex)
            ok(good, f"Tugma {cb} xatosiz ishladi")
        bot.pending = ("addkey", "groq")
        k_new = "gsk_" + "z" * 30
        bot.handle_pending(k_new, {"message_id": 9}, 111)
        ok(k_new in cfg.list("GROQ_API_KEYS"), "Tugma orqali kalit qo'shildi (matn yuborib)")
        ok(all(k_new not in t for t in fake.tg_texts()), "Kalit chatga hech qachon to'liq chiqmadi")
        last = db.ep_by_gno(1)
        bot.callback(f"e:back:{last['gno']}", 111)
        ok(any("qaytadan yasaladi" in t or "yuklangan" in t for t in fake.tg_texts()[-3:]), "/back tasdiq so'rovi yuborildi")
        bot.stop_flag.set()
    finally:
        fake.stop()
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    t0 = time.time()
    try:
        unit_tests()
        feature_tests()
        from . import selftest_more as sm
        sm.schedule_tests()
        sm.dict_tests()
        sm.image_tests()
        from . import selftest_v2 as sv2
        sv2.run_all()
        sync_tests()
        chain_tests()
        llm_tests()
        net_tests()
        security_tests()
        e2e()
    except Exception:
        traceback.print_exc()
        ok(False, "Selftest kutilmagan istisno bilan to'xtadi")
    bad = [m for c, m in RESULTS if not c]
    print(f"\n{'=' * 50}\nNatija: {len(RESULTS) - len(bad)}/{len(RESULTS)} tekshiruv muvaffaqiyatli ({time.time() - t0:.0f}s)")
    for m in bad:
        print("  ❌", m)
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
