"""Ingliz (texnik) so'zlarining o'zbek lotin imlosidagi aytilishi.

O'zbekcha ovoz ingliz so'zini o'z harflari bilan o'qib buzib yubormasligi uchun, so'z ingliz talaffuziga mos
"o'zbekcha yozuv"ga o'giriladi: shape -> sheyp, python -> payton. Ekrandagi matn o'zgarmaydi.

Qoida: faqat aniq texnik/ingliz so'zlar (o'zbekcha so'z bilan to'qnashadigan qisqa so'zlar kiritilmagan).
Lug'atni bot ichida /pron bilan to'ldirish mumkin; yangi so'zlarni LLM o'zi aniqlaydi (pronounce.py).
"""

_RAW = """
python=payton; pandas=pendas; numpy=nampay; scipy=say pay; matplotlib=metplotlib; seaborn=sibon; sklearn=eskilern
jupyter=jupiter; notebook=noutbuk; django=jango; flask=flesk; fastapi=fast ey pi ay; pytest=paytest
pip=pip; conda=konda; venv=vi env; virtualenv=virtual env; anaconda=anakonda; pycharm=paycharm
github=git hab; gitlab=git leb; git=git; commit=komit; branch=branch; merge=merj; rebase=ribeys; clone=kloun
pull=pul; push=push; fork=fork; stash=stesh; checkout=chekaut; repository=ripozitori; repo=ripo; diff=dif
javascript=java skript; typescript=tayp skript; node=noud; nodejs=noud jey es; react=riakt; angular=angyular
vue=vyu; svelte=svelt; nextjs=nekst jey es; express=ekspres; webpack=ueb pek; npm=en pi em; yarn=yarn
docker=doker; dockerfile=doker fayl; container=konteyner; kubernetes=kubernetis; nginx=enjin eks; linux=linuks
ubuntu=ubuntu; debian=debian; windows=uindous; android=endroyd; macos=mak o es; ios=ay o es; bash=besh
shell=shel; terminal=terminal; console=konsol; sudo=sudo; chmod=ch mod; grep=grep; curl=kerl; wget=u get
ssh=es es eych; localhost=lokal host; server=server; client=klayent; backend=bekend; frontend=frontend
fullstack=full stek; framework=freymvork; library=layberi; package=pekij; module=modyul; plugin=plagin
database=deyta beys; datasets=deyta setlar; dataset=deyta set; data=deyta; dataframe=deyta freym
dataframes=deyta freymlar; frame=freym; series=siriz; shape=sheyp; size=sayz; length=lengs; width=uidt
height=hayt; dtype=di tayp; dtypes=di taypz; type=tayp; types=taypz; index=indeks; indexes=indekslar
column=kolam; columns=kolamz; row=rou; rows=rouz; cell=sel; table=teybl; field=fild; fields=fildz
head=hed; tail=teyl; describe=diskrayb; info=info; sample=sempl; merge=merj; join=joyn; concat=konket
groupby=grup bay; group=grup; pivot=pivot; sort=sort; sorted=sortid; filter=filtr; map=mep; reduce=ridyus
lambda=lemda; apply=eplay; query=kviri; select=silekt; where=uer; insert=insert; update=apdeyt
delete=dilit; create=kriyeyt; drop=drop; alter=olter; schema=skima; primary=praymeri; foreign=forin
sqlite=es kyu el layt; mysql=may es kyu el; postgres=postgres; postgresql=postgres es kyu el; mongodb=mongo di bi
redis=redis; orm=o ar em; crud=krud
print=print; input=input; output=autput; import=import; from=from; return=ritern; def=def; class=kles
self=self; init=init; object=obyekt; objects=obyektlar; method=metod; function=fankshn; functions=fankshnz
argument=argyument; arguments=argyumentlar; parameter=parametr; variable=veriabl; variables=veriablz
constant=konstant; string=string; strings=stringlar; integer=integer; int=int; float=flout; boolean=bulian
bool=bul; true=tru; false=fols; none=nan; null=nal; list=list; lists=listlar; tuple=tyupl; tuples=tyuplz
dict=dikt; dictionary=dikshneri; set=set; sets=setlar; array=arey; arrays=areyz; vector=vektor
matrix=meytriks; tensor=tensor; graph=graf; tree=tri; stack=stek; queue=kyu; heap=hip; hash=hesh
loop=lup; loops=lupz; while=uayl; else=els; elif=elif; break=breyk; continue=kontinyu; pass=pas
try=tray; except=iksept; finally=fayneli; raise=reyz; assert=asert; error=erer; errors=ererz
exception=iksepshn; exceptions=iksepshnz; bug=bag; bugs=bagz; debug=dibag; debugging=dibaging
traceback=treysbek; logging=loging; logger=loger; warning=uorning; yield=yild; generator=jeneyreyter
iterator=iterator; iterable=iterebl; enumerate=inyumereyt; range=reynj; zip=zip; len=len; split=split
strip=strip; replace=ripleys; format=format; slice=slays; append=apend; extend=ekstend; remove=rimuv
pop=pop; reverse=rivers; count=kaunt; keys=kiz; values=velyuz; items=aytemz; value=velyu; key=ki
name=neym; names=neymz; filename=fayl neym; path=pas; paths=pasz; file=fayl; files=faylz; folder=folder
directory=direktori; open=oupen; close=klouz; read=rid; write=rayt; writer=rayter; reader=rider
writerow=rayter rou; writerows=rayter rouz; dictwriter=dikt rayter; dictreader=dikt rider
load=loud; loads=loudz; dump=damp; dumps=dampz; encode=inkoud; decode=dikoud; encoding=inkouding
utf=yu ti ef; newline=nyulayn; delimiter=delimiter; indent=indent; separator=separator; header=heder
headers=hederz; with=uit; as=ez; lines=laynz; line=layn; text=tekst; binary=bayneri; byte=bayt; bytes=bayts
code=koud; script=skript; scripts=skriptlar; source=sors; compile=kompayl; compiler=kompayler
interpreter=interpriter; runtime=rantaym; run=ran; running=raning; execute=ekzikyut; build=bild
deploy=diploy; release=rilis; version=vershn; versions=vershnlar; update=apdeyt; upgrade=apgreyd
install=instol; installation=instolleyshn; download=daunloud; upload=aploud; setup=setap; config=konfig
configuration=konfigyureyshn; settings=setingz; option=opshn; options=opshnz; default=difolt
debugger=dibager; test=test; tests=testlar; testing=testing; unittest=yunit test; mock=mok
request=rikvest; requests=rikvests; response=rispons; status=steytas; endpoint=endpoynt; payload=peyloud
timeout=taymaut; retry=ritray; cache=kesh; cookie=kuki; cookies=kukilar; session=seshn; token=touken
auth=ot; authentication=otentikeyshn; password=pasvord; login=login; logout=logaut; username=yuzer neym
user=yuzer; users=yuzerlar; admin=admin; email=imeyl; link=link; links=linklar; url=yu ar el
web=ueb; website=uebsayt; site=sayt; page=peyj; pages=peyjlar; browser=brauzer; online=onlayn
offline=oflayn; internet=internet; wifi=vay fay; bluetooth=blutus; hosting=hosting; domain=domeyn
html=eych ti em el; css=si es es; scraping=skreyping; scraper=skreyper; scrape=skreyp; parser=parser
parse=pars; parsing=parsing; beautifulsoup=byutiful sup; soup=sup; selenium=silinium; requests=rikvests
crawler=krouler; spider=spayder; headless=hedles; proxy=proksi; api=ey pi ay; rest=rest; json=jeyson
csv=si es vi; xml=iks em el; yaml=yaml; pdf=pi di ef; excel=eksel; word=uord; sheet=shit; sheets=shits
button=batn; click=klik; scroll=skroul; tab=teb; window=uindou; screen=skrin; mouse=maus
keyboard=kiybord; laptop=leptop; smartphone=smartfon; app=ep; apps=eplar; widget=ujet; icon=aykon
design=dizayn; layout=leyaut; flex=fleks; grid=grid; style=stayl; styles=staylz; font=font
color=kalar; background=bekgraund; margin=marjin; padding=peding; border=border; div=div; span=span
template=templeyt; content=kontent; image=imij; images=imijlar; video=video; audio=audio
animation=animeyshn; canvas=kenvas; pixel=piksel; pixels=pikselz; frame=freym; frames=freymz
cloud=klaud; storage=storij; backup=bekap; restore=ristor; sync=sink; async=eysink; await=aveyt
thread=tred; threads=tredz; process=prosess; processes=prosesslar; lock=lok; memory=memori
cpu=si pi yu; gpu=ji pi yu; ram=ram; ssd=es es di; hdd=eych di di; usb=yu es bi; bios=bayos
algorithm=algoritm; algorithms=algoritmlar; machine=mashin; learning=lerning; deep=dip; neural=nyural
network=network; networks=networklar; model=model; models=modellar; training=treyning; train=treyn
prediction=pridikshn; predict=pridikt; feature=fiycher; features=fiycherz; label=leybl; labels=leyblz
accuracy=akyurasi; loss=los; epoch=ipok; batch=bech; layer=leyer; layers=leyerlar; token=touken
prompt=prompt; chatbot=chat bot; openai=open ey ay; chatgpt=chat ji pi ti; gemini=jemini; claude=klod
copilot=kopaylot; bot=bot; bots=botlar; telegram=telegram; youtube=yutub; google=gugl; microsoft=maykrosoft
apple=epl; facebook=feysbuk; instagram=instagram; twitter=tuiter; tiktok=tik tok; whatsapp=uots ep
stackoverflow=stek overflou; overflow=overflou; reddit=redit; wikipedia=vikipidiya; amazon=amazon
open source=oupen sors; opensource=oupen sors; devops=dev ops; agile=ejayl; scrum=skram; sprint=sprint
startup=startap; freelance=frilans; freelancer=frilanser; remote=rimout; senior=sinyor; junior=junior
developer=divelaper; developers=divelaperlar; programmer=programmer; engineer=injiner; coding=koding
programming=programming; software=softuer; hardware=hardver; firmware=firmver; engine=enjin
default=difolt; global=gloubl; local=loukal; public=pablik; private=prayvit; static=statik; super=syuper
override=overrayd; interface=interfeys; abstract=abstrakt; inheritance=inxeritans; polymorphism=polimorfizm
encapsulation=inkapsyuleyshn; constructor=konstraktor; instance=instans; attribute=atribyut
property=propirti; decorator=dekoreyter; context=kontekst; manager=menejer; handler=hendler
callback=kolbek; event=ivent; events=iventlar; listener=lisner; trigger=triger; hook=huk; middleware=midlver
router=router; route=rut; routes=rutlar; controller=kontroller; view=vyu; views=vyular; model=model
serializer=sirializer; migration=maygreyshn; admin=admin; static=statik; media=midiya
shapes=sheyps; ndarray=en di arey; arange=ey reynj; reshape=rishe yp; linspace=lin speys; random=rendom
mean=min; median=midian; std=es ti di; sum=sam; min=min; max=maks; abs=abs; round=raund; sqrt=skver rut
plot=plot; plots=plotlar; chart=chart; charts=chartlar; histogram=histogram; scatter=sketer; bar=bar
legend=lejend; title=taytl; xlabel=iks leybl; ylabel=uay leybl; figure=figyur; subplot=sab plot; show=shou
save=seyv; saved=seyvd; savefig=seyv fig; imshow=im shou; heatmap=hit mep; seaborn=sibon
isnull=ay snal; dropna=drop en ey; fillna=fil en ey; astype=es tayp; iloc=ay lok; loc=lok; tolist=tu list
toarray=tu arey; read_csv=rid si es vi; to_csv=tu si es vi; to_json=tu jeyson; read_json=rid jeyson
""".strip()

from . import enwords_gen, enwords_more, enwords_net, enwords_tech

EN = {}
for chunk in (_RAW + "\n" + enwords_gen.RAW + "\n" + enwords_net.RAW + "\n" + enwords_tech.RAW + "\n" + enwords_more.RAW).replace("\n", ";").split(";"):
    chunk = chunk.strip()
    if "=" in chunk:
        k, v = chunk.split("=", 1)
        k, v = k.strip().lower(), v.strip()
        if k and v:
            EN[k] = v          # keyingisi oldingisini almashtiradi
