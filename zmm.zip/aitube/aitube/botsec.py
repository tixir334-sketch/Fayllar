"""Himoya buyruqlari: /blocked, /unblock, /security."""
from __future__ import annotations

import time

from .util import esc


class SecurityMixin:
    def c_blocked(self, arg, chat):
        g = self.app.guard
        if not g.blocked:
            return "🛡 Bloklangan foydalanuvchi yo'q."
        rows, lines = [], [f"🛡 <b>Bloklanganlar</b>: {len(g.blocked)} ta (oxirgi 10 tasi)"]
        for uid in g.blocked[-10:][::-1]:
            i = g.info.get(str(uid), {})
            t = time.strftime("%m-%d %H:%M", time.localtime(i["t"])) if i.get("t") else "-"
            lines.append(f"• <code>{uid}</code> {('@' + esc(i['u'])) if i.get('u') else ''} · {t}")
            rows.append([{"text": f"🔓 {uid}", "callback_data": f"sec:unblock:{uid}"}])
        self.tg.send("\n".join(lines), chat=chat, markup={"inline_keyboard": rows})

    def c_unblock(self, arg, chat):
        if not arg.strip().lstrip("-").isdigit():
            return "Foydalanish: /unblock ID (ro'yxat: /blocked)"
        return "🔓 Blokdan chiqarildi." if self.app.guard.unblock(int(arg)) else "ℹ️ Bu ID bloklanmagan."

    def c_security(self, arg, chat):
        a = self.app
        g = a.guard
        return ("🛡 <b>Himoya holati</b>\n"
                f"• Ruxsat: faqat ADMIN_ID <code>{a.cfg.admin_id}</code> va faqat shaxsiy chatda\n"
                f"• Bloklangan: {len(g.blocked)} ta · tashlab yuborilgan so'rovlar: {g.dropped}\n"
                "• Begona foydalanuvchi bir marta yozsa/tugma bossa ham bloklanadi, javob berilmaydi\n"
                "• Kalitlar to'liq ko'rsatilmaydi; kalit yuborilgan xabar chatdan o'chiriladi\n"
                "• .env, baza va tokenlar fayl ruxsatlari faqat egasiga (600)\n"
                "/blocked — ro'yxat · /unblock ID")

    def sec_callback(self, val, chat):
        act, _, arg = val.partition(":")
        if act == "unblock" and arg.lstrip("-").isdigit():
            return "🔓 Blokdan chiqarildi." if self.app.guard.unblock(int(arg)) else "ℹ️ Allaqachon blokdan chiqqan."
        return None
