"""YouTube Data API v3 (faqat requests): qurilma orqali OAuth, resumable yuklash, muqova,
pleylist, tavsifni yangilash, statistika va izohlar."""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

import requests

from .util import NET, atomic_write, http, log

SCOPE = "https://www.googleapis.com/auth/youtube https://www.googleapis.com/auth/youtube.readonly"
QUOTA_REASONS = ("quotaExceeded", "dailyLimitExceeded", "uploadLimitExceeded", "rateLimitExceeded")


class YTError(Exception):
    def __init__(self, msg, status=0, reason=""):
        super().__init__(msg)
        self.status = status
        self.reason = reason

    @property
    def quota(self):
        return self.reason in QUOTA_REASONS

    @property
    def auth(self):
        return self.status in (401,) or self.reason in ("auth_revoked", "invalid_grant", "authError")


def _err_from(r) -> YTError:
    reason, msg = "", r.text[:300]
    try:
        j = r.json()
        e = j.get("error", {})
        if isinstance(e, dict):
            msg = e.get("message", msg)
            errs = e.get("errors") or []
            reason = errs[0].get("reason", "") if errs else e.get("status", "")
        else:
            reason, msg = str(e), j.get("error_description", msg)
    except ValueError:
        pass
    return YTError(f"HTTP {r.status_code} {reason}: {msg}", r.status_code, reason)


def parse_client_json(text: str) -> tuple:
    """Google Cloud'dan yuklangan client_secret_*.json dan (client_id, client_secret) ni oladi."""
    j = json.loads(text)
    for key in ("installed", "web"):
        d = j.get(key)
        if isinstance(d, dict) and d.get("client_id") and d.get("client_secret"):
            return d["client_id"].strip(), d["client_secret"].strip()
    raise ValueError("fayl ichida client_id / client_secret topilmadi")


def clean_text(s: str, limit: int) -> str:
    s = re.sub(r"[<>]", "", str(s or ""))
    s = s.replace("\r", "")
    return s[:limit].strip()


def clean_tags(tags) -> list:
    out, total = [], 0
    for t in tags or []:
        t = re.sub(r"[<>,\"]", "", str(t)).strip()
        if not t or t.lower() in [x.lower() for x in out]:
            continue
        if total + len(t) + 1 > 450:
            break
        out.append(t)
        total += len(t) + 1
    return out


class YouTube:
    def __init__(self, cfg):
        self.cfg = cfg
        self.token_file = cfg.dirs["tokens"] / "youtube.json"
        self._tok = self._load()

    # ------------------------------------------------------------------ tokenlar
    def _load(self) -> dict:
        try:
            return json.loads(self.token_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self):
        atomic_write(self.token_file, json.dumps(self._tok))
        try:
            self.token_file.chmod(0o600)
        except OSError:
            pass

    @property
    def base(self):
        return self.cfg.get("YT_API_BASE").rstrip("/")

    @property
    def oauth(self):
        return self.cfg.get("OAUTH_BASE").rstrip("/")

    def configured(self) -> bool:
        return bool(self.cfg.get("YT_CLIENT_ID") and self.cfg.get("YT_CLIENT_SECRET"))

    def authorized(self) -> bool:
        return self.configured() and bool(self._tok.get("refresh_token"))

    def logout(self):
        self._tok = {}
        try:
            self.token_file.unlink()
        except OSError:
            pass

    def device_start(self) -> dict:
        r = http("POST", f"{self.oauth}/device/code",
                 data={"client_id": self.cfg.get("YT_CLIENT_ID"), "scope": SCOPE}, retries=2)
        if r.status_code != 200:
            raise _err_from(r)
        return r.json()

    def device_poll(self, dev: dict, should_stop=lambda: False) -> bool:
        interval = int(dev.get("interval", 5))
        deadline = time.time() + int(dev.get("expires_in", 1800))
        while time.time() < deadline and not should_stop():
            time.sleep(interval)
            r = http("POST", f"{self.oauth}/token", data={
                "client_id": self.cfg.get("YT_CLIENT_ID"), "client_secret": self.cfg.get("YT_CLIENT_SECRET"),
                "device_code": dev["device_code"],
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"}, retries=2)
            j = r.json() if r.content else {}
            if r.status_code == 200 and j.get("refresh_token"):
                self._tok = {"refresh_token": j["refresh_token"], "access_token": j.get("access_token", ""),
                             "expires_at": time.time() + int(j.get("expires_in", 3600))}
                self._save()
                return True
            err = j.get("error", "")
            if err == "authorization_pending":
                continue
            if err == "slow_down":
                interval += 5
                continue
            raise YTError(f"Avtorizatsiya rad etildi: {err} {j.get('error_description', '')}", r.status_code, err)
        return False

    def loopback_auth(self, on_url, timeout=600, should_stop=lambda: False) -> bool:
        """Desktop turidagi kalit uchun: telefonning o'zida 127.0.0.1 da vaqtincha server ochiladi,
        foydalanuvchi havolani shu telefon brauzerida ochadi, Google kodni shu serverga qaytaradi."""
        import http.server as hs
        import secrets
        import urllib.parse
        state = secrets.token_urlsafe(16)
        result: dict = {}

        class H(hs.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                q = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
                if "code" in q or "error" in q:
                    result.update(q)
                    body = ("<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
                            "</head><body style='font-family:sans-serif;text-align:center;margin-top:25%'>"
                            "<h2>\u2705 Tayyor!</h2><p>Telegramga qayting.</p></body></html>").encode()
                    self.send_response(200)
                else:
                    body = b""
                    self.send_response(404)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        srv = hs.HTTPServer(("127.0.0.1", 0), H)
        srv.timeout = 1
        port = srv.server_address[1]
        redirect = f"http://127.0.0.1:{port}"
        params = {"client_id": self.cfg.get("YT_CLIENT_ID"), "redirect_uri": redirect, "response_type": "code",
                  "scope": SCOPE, "access_type": "offline", "prompt": "consent", "state": state}
        url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(params)
        try:
            on_url(url)
            deadline = time.time() + timeout
            while time.time() < deadline and not should_stop() and "code" not in result and "error" not in result:
                srv.handle_request()
        finally:
            srv.server_close()
        if "error" in result:
            raise YTError(f"Avtorizatsiya rad etildi: {result['error']}", 400, result["error"])
        if "code" not in result:
            return False
        if result.get("state") != state:
            raise YTError("Avtorizatsiya holati mos kelmadi (state)", 400, "state_mismatch")
        r = http("POST", f"{self.oauth}/token", data={
            "client_id": self.cfg.get("YT_CLIENT_ID"), "client_secret": self.cfg.get("YT_CLIENT_SECRET"),
            "code": result["code"], "redirect_uri": redirect, "grant_type": "authorization_code"}, retries=2)
        j = r.json() if r.content else {}
        if r.status_code != 200 or not j.get("refresh_token"):
            raise YTError(f"Token olinmadi: {r.text[:200]}", r.status_code, j.get("error", ""))
        self._tok = {"refresh_token": j["refresh_token"], "access_token": j.get("access_token", ""),
                     "expires_at": time.time() + int(j.get("expires_in", 3600))}
        self._save()
        return True

    def _access(self) -> str:
        if self._tok.get("access_token") and self._tok.get("expires_at", 0) - 90 > time.time():
            return self._tok["access_token"]
        if not self._tok.get("refresh_token"):
            raise YTError("YouTube avtorizatsiyadan o'tilmagan (/auth)", 401, "auth_revoked")
        r = http("POST", f"{self.oauth}/token", data={
            "client_id": self.cfg.get("YT_CLIENT_ID"), "client_secret": self.cfg.get("YT_CLIENT_SECRET"),
            "refresh_token": self._tok["refresh_token"], "grant_type": "refresh_token"}, retries=3, wait_net=True)
        if r.status_code != 200:
            e = _err_from(r)
            if "invalid_grant" in e.reason or "invalid_grant" in str(e):
                e.reason = "auth_revoked"
            raise e
        j = r.json()
        self._tok["access_token"] = j["access_token"]
        self._tok["expires_at"] = time.time() + int(j.get("expires_in", 3600))
        self._save()
        return self._tok["access_token"]

    # ------------------------------------------------------------------ so'rovlar
    def _req(self, method, path, params=None, json_body=None, data=None, headers=None, timeout=(15, 90)):
        for attempt in range(2):
            h = {"Authorization": f"Bearer {self._access()}"}
            h.update(headers or {})
            r = http(method, self.base + path, params=params, json=json_body, data=data, headers=h,
                     timeout=timeout, wait_net=True)
            if r.status_code == 401 and attempt == 0:
                self._tok["expires_at"] = 0
                continue
            return r
        return r

    def _ok(self, r, ok=(200, 201, 204)):
        if r.status_code not in ok:
            raise _err_from(r)
        return r.json() if r.content else {}

    # ------------------------------------------------------------------ yuklash
    def upload(self, path, title, description, tags, privacy="public", category="28", synthetic=True,
               progress=lambda done, total: None, session=None, publish_at=None) -> dict:
        path = Path(path)
        size = path.stat().st_size
        if size < 1000:
            raise YTError("video fayl bo'sh yoki buzilgan")
        meta = {"snippet": {"title": clean_text(title, 100), "description": clean_text(description, 4900),
                            "tags": clean_tags(tags), "categoryId": str(category)},
                "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False,
                           "embeddable": True, "publicStatsViewable": not self.cfg.bool("HIDE_STATS")}}
        if synthetic:
            meta["status"]["containsSyntheticMedia"] = True
        if publish_at:       # YouTube o'zi shu vaqtda ochadi (UTC, RFC3339); yuklash paytida yopiq turadi
            meta["status"]["privacyStatus"] = "private"
            meta["status"]["publishAt"] = publish_at
        hdr = {"X-Upload-Content-Length": str(size), "X-Upload-Content-Type": "video/mp4",
               "Content-Type": "application/json; charset=UTF-8"}
        tok = self._access()
        loc, pos, fails = None, 0, 0
        if session and session.get():          # oldingi (uzilgan) yuklashni davom ettirish
            loc = session.get()
            kind, val = self._session_status(loc, size, tok)
            if kind == "done":
                session.clear()
                progress(size, size)
                return val
            if kind == "pos":
                pos = val
                log.info("Yuklash %s baytdan davom ettiriladi", pos)
            else:
                session.clear()
                loc = None
        if not loc:
            r = self._req("POST", "/upload/youtube/v3/videos",
                          params={"uploadType": "resumable", "part": "snippet,status"},
                          data=json.dumps(meta, ensure_ascii=False).encode("utf-8"), headers=hdr)
            if r.status_code == 400 and synthetic and "containsSyntheticMedia" in r.text:
                meta["status"].pop("containsSyntheticMedia", None)
                r = self._req("POST", "/upload/youtube/v3/videos",
                              params={"uploadType": "resumable", "part": "snippet,status"},
                              data=json.dumps(meta, ensure_ascii=False).encode("utf-8"), headers=hdr)
            if r.status_code != 200 or not r.headers.get("Location"):
                raise _err_from(r)
            loc = r.headers["Location"]
            if session:
                session.set(loc)
        chunk = 8 * 1024 * 1024
        with open(path, "rb") as f:
            while True:
                f.seek(pos)
                data = f.read(chunk)
                end = pos + len(data) - 1
                headers = {"Content-Length": str(len(data)), "Content-Range": f"bytes {pos}-{end}/{size}",
                           "Content-Type": "video/mp4", "Authorization": f"Bearer {tok}"}
                try:
                    r = http("PUT", loc, data=data, headers=headers, allow_redirects=False,
                             timeout=(20, 300), retries=1)
                except requests.RequestException as e:
                    ok_net, was_down = NET.wait_online()   # internet uzilgan bo'lsa qaytguncha kutadi
                    if not ok_net:
                        raise YTError(f"yuklash tarmoq xatosi (internet qaytmadi): {e}")
                    if not was_down:
                        fails += 1
                        if fails > 8:
                            raise YTError(f"yuklash tarmoq xatosi: {e}")
                        time.sleep(min(60, 3 * fails))
                    self._tok["expires_at"] = 0
                    tok = self._access()   # uzoq uzilishdan keyin token eskirgan bo'lishi mumkin
                    pos = self._resume_pos(loc, size, tok, pos)
                    log.info("Yuklash %s baytdan davom etmoqda", pos)
                    progress(pos, size)
                    continue
                if r.status_code == 401 and fails < 8:
                    fails += 1
                    self._tok["expires_at"] = 0
                    tok = self._access()
                    continue
                if r.status_code in (200, 201):
                    progress(size, size)
                    if session:
                        session.clear()
                    return r.json()
                if r.status_code == 308:
                    rng = r.headers.get("Range", "")
                    pos = int(rng.split("-")[-1]) + 1 if rng else 0
                    progress(pos, size)
                    fails = 0
                    continue
                if r.status_code in (500, 502, 503, 504):
                    fails += 1
                    if fails > 8:
                        raise _err_from(r)
                    time.sleep(min(60, 3 * fails))
                    pos = self._resume_pos(loc, size, tok, pos)
                    continue
                raise _err_from(r)

    def _session_status(self, loc, size, tok):
        """Saqlangan yuklash seansi holati: ("done", json) | ("pos", bayt) | ("dead", None)."""
        try:
            r = http("PUT", loc, data=b"", headers={"Content-Length": "0", "Content-Range": f"bytes */{size}",
                                                    "Authorization": f"Bearer {tok}"},
                     allow_redirects=False, timeout=(15, 60), retries=2, wait_net=True)
        except requests.RequestException:
            return "dead", None
        if r.status_code in (200, 201):
            try:
                return "done", r.json()
            except ValueError:
                return "dead", None
        if r.status_code == 308:
            rng = r.headers.get("Range", "")
            return "pos", (int(rng.split("-")[-1]) + 1 if rng else 0)
        return "dead", None

    def _resume_pos(self, loc, size, tok, fallback) -> int:
        try:
            r = http("PUT", loc, data=b"", headers={"Content-Length": "0", "Content-Range": f"bytes */{size}",
                                                    "Authorization": f"Bearer {tok}"},
                     allow_redirects=False, timeout=(15, 60), retries=2, wait_net=True)
            if r.status_code == 308:
                rng = r.headers.get("Range", "")
                return int(rng.split("-")[-1]) + 1 if rng else 0
            if r.status_code in (200, 201):
                return size
        except requests.RequestException:
            pass
        return fallback

    # ------------------------------------------------------------------ boshqa amallar
    def set_thumbnail(self, video_id, path):
        path = Path(path)
        ctype = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
        r = self._req("POST", "/upload/youtube/v3/thumbnails/set",
                      params={"videoId": video_id, "uploadType": "media"},
                      data=path.read_bytes(), headers={"Content-Type": ctype}, timeout=(15, 120))
        self._ok(r)

    def video_info(self, video_id) -> dict:
        r = self._req("GET", "/youtube/v3/videos", params={"part": "snippet,status", "id": video_id})
        items = self._ok(r).get("items", [])
        if not items:
            raise YTError(f"video topilmadi: {video_id}", 404, "notFound")
        return items[0]

    def set_publish(self, video_id, publish_at=None, privacy="private"):
        """Rejalashtirilgan chiqarish vaqtini o'zgartiradi.
        publish_at berilsa: yopiq + shu vaqtda ochiladi. None: privacy ga qarab darhol (public) yoki yopiq qoladi."""
        info = self.video_info(video_id)
        st = dict(info.get("status") or {})
        body_st = {"privacyStatus": privacy if not publish_at else "private",
                   "embeddable": st.get("embeddable", True),
                   "publicStatsViewable": st.get("publicStatsViewable", True),
                   "selfDeclaredMadeForKids": st.get("selfDeclaredMadeForKids", False)}
        if st.get("containsSyntheticMedia") is not None:
            body_st["containsSyntheticMedia"] = st["containsSyntheticMedia"]
        if publish_at:
            body_st["publishAt"] = publish_at
        body = {"id": video_id, "status": body_st}
        r = self._req("PUT", "/youtube/v3/videos", params={"part": "status"}, json_body=body)
        if r.status_code == 400 and "containsSyntheticMedia" in r.text:
            body_st.pop("containsSyntheticMedia", None)
            r = self._req("PUT", "/youtube/v3/videos", params={"part": "status"}, json_body=body)
        return self._ok(r)

    # ------------------------------------------------------------------ jonli efir (Live)
    def live_create(self, title, description="", privacy="public", latency="low", fps_hint=30) -> dict:
        """Jonli efir yaratadi: broadcast + stream (RTMP kalit) va ularni bog'laydi.
        Qaytaradi: {broadcast_id, stream_id, rtmp, key, url}. enableAutoStart: video oqimi kelishi bilan efir boshlanadi."""
        r = self._req("POST", "/youtube/v3/liveBroadcasts", params={"part": "snippet,status,contentDetails"}, json_body={
            "snippet": {"title": clean_text(title, 100), "description": clean_text(description, 4500),
                        "scheduledStartTime": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(time.time() + 15))},
            "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False,
                       "containsSyntheticMedia": True},
            "contentDetails": {"enableAutoStart": True, "enableAutoStop": False, "enableDvr": True,
                               "latencyPreference": latency, "monitorStream": {"enableMonitorStream": False}}})
        if r.status_code == 400 and "containsSyntheticMedia" in r.text:
            return self._live_retry_nosynth(title, description, privacy, latency)
        b = self._ok(r)
        return self._live_bind_new(b, title)

    def _live_retry_nosynth(self, title, description, privacy, latency):
        r = self._req("POST", "/youtube/v3/liveBroadcasts", params={"part": "snippet,status,contentDetails"}, json_body={
            "snippet": {"title": clean_text(title, 100), "description": clean_text(description, 4500),
                        "scheduledStartTime": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(time.time() + 15))},
            "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False},
            "contentDetails": {"enableAutoStart": True, "enableAutoStop": False, "enableDvr": True,
                               "latencyPreference": latency}})
        return self._live_bind_new(self._ok(r), title)

    def _live_bind_new(self, b, title) -> dict:
        r = self._req("POST", "/youtube/v3/liveStreams", params={"part": "snippet,cdn,contentDetails"}, json_body={
            "snippet": {"title": clean_text(title, 100)},
            "cdn": {"frameRate": "variable", "ingestionType": "rtmp", "resolution": "variable"},
            "contentDetails": {"isReusable": False}})
        st = self._ok(r)
        r = self._req("POST", "/youtube/v3/liveBroadcasts/bind", params={"id": b["id"], "part": "id,contentDetails",
                                                                       "streamId": st["id"]})
        self._ok(r)
        ing = (st.get("cdn") or {}).get("ingestionInfo") or {}
        return {"broadcast_id": b["id"], "stream_id": st["id"], "rtmp": ing.get("ingestionAddress", ""),
                "key": ing.get("streamName", ""), "url": f"https://www.youtube.com/watch?v={b['id']}"}

    def live_status(self, broadcast_id) -> dict:
        """{'life': 'created|ready|testing|live|complete', 'stream': 'active|inactive|...', 'health': 'good|ok|bad|noData'}"""
        r = self._req("GET", "/youtube/v3/liveBroadcasts", params={"part": "status,contentDetails", "id": broadcast_id})
        items = self._ok(r).get("items", [])
        if not items:
            raise YTError(f"efir topilmadi: {broadcast_id}", 404, "notFound")
        it = items[0]
        out = {"life": (it.get("status") or {}).get("lifeCycleStatus", ""), "stream": "", "health": ""}
        sid = (it.get("contentDetails") or {}).get("boundStreamId")
        if sid:
            r2 = self._req("GET", "/youtube/v3/liveStreams", params={"part": "status", "id": sid})
            its = self._ok(r2).get("items", [])
            if its:
                stt = its[0].get("status") or {}
                out["stream"] = stt.get("streamStatus", "")
                out["health"] = (stt.get("healthStatus") or {}).get("status", "")
        return out

    def live_transition(self, broadcast_id, status):
        """status: testing | live | complete"""
        r = self._req("POST", "/youtube/v3/liveBroadcasts/transition",
                      params={"broadcastStatus": status, "id": broadcast_id, "part": "status"})
        return self._ok(r)

    def hide_stats(self, video_ids) -> list:
        """Ochiq statistikasi (yoqtirishlar/ko'rishlar) ko'rinib turgan videolarda uni yopadi.
        Qaytaradi: o'zgartirilgan video id lari. Rejalashtirilgan vaqt (publishAt) saqlanadi."""
        changed = []
        ids = [i for i in video_ids if i]
        for k in range(0, len(ids), 50):
            batch = ids[k:k + 50]
            r = self._req("GET", "/youtube/v3/videos", params={"part": "status", "id": ",".join(batch)})
            for it in self._ok(r).get("items", []):
                st = dict(it.get("status") or {})
                if st.get("publicStatsViewable", True) is False:
                    continue
                body_st = {"privacyStatus": st.get("privacyStatus", "private"),
                           "embeddable": st.get("embeddable", True), "publicStatsViewable": False,
                           "selfDeclaredMadeForKids": st.get("selfDeclaredMadeForKids", False)}
                if st.get("publishAt"):
                    body_st["publishAt"] = st["publishAt"]
                if st.get("containsSyntheticMedia") is not None:
                    body_st["containsSyntheticMedia"] = st["containsSyntheticMedia"]
                body = {"id": it["id"], "status": body_st}
                r2 = self._req("PUT", "/youtube/v3/videos", params={"part": "status"}, json_body=body)
                if r2.status_code == 400 and "containsSyntheticMedia" in r2.text:
                    body_st.pop("containsSyntheticMedia", None)
                    r2 = self._req("PUT", "/youtube/v3/videos", params={"part": "status"}, json_body=body)
                self._ok(r2)
                changed.append(it["id"])
        return changed

    def set_description_line(self, video_id, marker: str, new_line: str):
        """Tavsifdagi `marker` bor qatorni almashtiradi (yo'q bo'lsa oxiriga qo'shadi)."""
        info = self.video_info(video_id)
        sn = info["snippet"]
        desc = sn.get("description", "")
        lines = desc.split("\n")
        for i, ln in enumerate(lines):
            if marker in ln:
                lines[i] = new_line
                break
        else:
            lines += ["", new_line]
        desc = "\n".join(lines).strip()
        body = {"id": video_id, "snippet": {"title": sn["title"], "description": clean_text(desc, 4900),
                                            "categoryId": sn.get("categoryId", "28"),
                                            "tags": sn.get("tags", [])}}
        if sn.get("defaultLanguage"):
            body["snippet"]["defaultLanguage"] = sn["defaultLanguage"]
        self._ok(self._req("PUT", "/youtube/v3/videos", params={"part": "snippet"}, json_body=body))

    def ensure_playlist(self, title, description="", privacy="public") -> str:
        r = self._req("POST", "/youtube/v3/playlists", params={"part": "snippet,status"}, json_body={
            "snippet": {"title": clean_text(title, 150), "description": clean_text(description, 4000)},
            "status": {"privacyStatus": privacy}})
        return self._ok(r)["id"]

    def add_to_playlist(self, playlist_id, video_id):
        r = self._req("POST", "/youtube/v3/playlistItems", params={"part": "snippet"}, json_body={
            "snippet": {"playlistId": playlist_id, "resourceId": {"kind": "youtube#video", "videoId": video_id}}})
        self._ok(r)

    def playlist_exists(self, playlist_id) -> bool:
        """Pleylist hozir ham mavjudmi (o'chirib yuborilgan bo'lishi mumkin)."""
        r = self._req("GET", "/youtube/v3/playlists", params={"part": "id", "id": playlist_id})
        if r.status_code == 404:
            return False
        return bool(self._ok(r).get("items"))

    def playlist_video_ids(self, playlist_id) -> list:
        """Pleylistdagi video ID lari (sahifalab). Pleylist yo'q bo'lsa YTError(404)."""
        out, token = [], None
        for _ in range(20):
            params = {"part": "contentDetails", "playlistId": playlist_id, "maxResults": 50}
            if token:
                params["pageToken"] = token
            j = self._ok(self._req("GET", "/youtube/v3/playlistItems", params=params))
            out += [(it.get("contentDetails") or {}).get("videoId") for it in j.get("items", [])]
            token = j.get("nextPageToken")
            if not token:
                break
        return [v for v in out if v]

    def stats(self, ids) -> dict:
        out = {}
        ids = list(ids)
        for i in range(0, len(ids), 50):
            r = self._req("GET", "/youtube/v3/videos", params={"part": "statistics", "id": ",".join(ids[i:i + 50])})
            for it in self._ok(r).get("items", []):
                s = it.get("statistics", {})
                out[it["id"]] = {"views": int(s.get("viewCount", 0)), "likes": int(s.get("likeCount", 0)),
                                 "comments": int(s.get("commentCount", 0))}
        return out

    def channel(self) -> dict:
        r = self._req("GET", "/youtube/v3/channels", params={"part": "snippet,statistics", "mine": "true"})
        items = self._ok(r).get("items", [])
        if not items:
            return {}
        it = items[0]
        s = it.get("statistics", {})
        return {"title": it["snippet"]["title"], "id": it["id"], "subs": int(s.get("subscriberCount", 0)),
                "views": int(s.get("viewCount", 0)), "videos": int(s.get("videoCount", 0))}

    def comments(self, video_id, limit=20) -> list:
        r = self._req("GET", "/youtube/v3/commentThreads", params={
            "part": "snippet", "videoId": video_id, "order": "time", "maxResults": min(100, limit),
            "textFormat": "plainText"})
        if r.status_code == 403 and "commentsDisabled" in r.text:
            return []
        out = []
        for it in self._ok(r).get("items", []):
            sn = it["snippet"]["topLevelComment"]["snippet"]
            out.append({"id": it["id"], "author": sn.get("authorDisplayName", ""),
                        "text": sn.get("textDisplay", ""), "likes": sn.get("likeCount", 0)})
        return out
