"""Rejalashtirilgan chiqarish: video tayyor bo'lishi bilan YouTube'ga yopiq yuklanadi va
UPLOAD_TIMES dagi bo'sh vaqtda YouTube o'zi ochadi (telefon o'chiq bo'lsa ham).
Bu modul: vaqt hisoblash, bo'sh slot topish, vaqtni o'zgartirish/almashtirish/surish,
hoziroq chiqarish, bekor qilish va YouTube bilan solishtirish (reconcile)."""
from __future__ import annotations

import re
import time
from datetime import datetime, timedelta, timezone

from .util import clip, esc, fmt_dur, iso_now, local_now, log
from .youtube import YTError

UTC = timezone.utc
LEAD = timedelta(minutes=20)       # yangi video uchun eng yaqin vaqt (yuklash+qayta ishlash uchun zaxira)
MIN_EDIT = timedelta(minutes=5)    # YouTube kelajakdagi vaqtni talab qiladi
WD = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"]


def tzinfo(cfg):
    return timezone(timedelta(hours=cfg.float("TZ_OFFSET")))


def now_utc():
    return datetime.now(UTC)


def to_iso(dt) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def from_iso(s):
    if not s:
        return None
    try:
        return datetime.strptime(str(s)[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=UTC)
    except ValueError:
        return None


def fmt_local(cfg, dt_or_iso) -> str:
    dt = from_iso(dt_or_iso) if isinstance(dt_or_iso, str) else dt_or_iso
    if not dt:
        return "-"
    d = dt.astimezone(tzinfo(cfg))
    return f"{d.strftime('%m-%d')} {WD[d.weekday()]} {d.strftime('%H:%M')}"


def eta(dt) -> str:
    sec = (dt - now_utc()).total_seconds()
    return ("≈ " + fmt_dur(sec) + " qoldi") if sec > 0 else "vaqti o'tdi"


def _taken(db, exclude_id=None):
    out = []
    for e in db.scheduled() + db.with_planned_time():
        if e["id"] != exclude_id and e.get("publish_at"):
            d = from_iso(e["publish_at"])
            if d:
                out.append(d)
    return out


def slots_from(cfg, start, count=1, step_days=60):
    """`start` (UTC) dan keyin keladigan UPLOAD_TIMES slotlari (UTC datetime ro'yxati)."""
    from .scheduler import parse_times
    times = parse_times(cfg.get("UPLOAD_TIMES")) or [(18, 0)]
    tz = tzinfo(cfg)
    base = start.astimezone(tz)
    out = []
    for day in range(step_days):
        for h, m in times:
            dt = (base + timedelta(days=day)).replace(hour=h, minute=m, second=0, microsecond=0)
            if dt > base:
                out.append(dt.astimezone(UTC))
                if len(out) >= count:
                    return out
    return out


def next_free_slot(cfg, db, ep=None):
    """Epizod uchun keyingi bo'sh vaqt: oldingi (kichik gno) epizodlardan keyin, band vaqtlarni o'tkazib."""
    after = now_utc() + LEAD
    exclude = ep["id"] if ep else None
    for e in db.scheduled() + db.with_planned_time():
        if ep is not None and (e["id"] == exclude or e["gno"] > ep["gno"]):
            continue
        d = from_iso(e.get("publish_at"))
        if d and d > after:
            after = d
    taken = _taken(db, exclude)
    for dt in slots_from(cfg, after, 400):
        if all(abs((dt - t).total_seconds()) > 600 for t in taken):
            return dt
    return after + timedelta(hours=1)


def pick_time(cfg, db, ep):
    """Yuklash paytida ishlatiladigan chiqarish vaqti: admin belgilagan (kelajakda bo'lsa) yoki avtomatik slot."""
    d = from_iso(ep.get("publish_at")) if ep.get("pub_state") == "planned" else None
    if d and d > now_utc() + MIN_EDIT + timedelta(minutes=2):
        return d
    return next_free_slot(cfg, db, ep)


def active(cfg) -> bool:
    return cfg.bool("YT_SCHEDULE") and cfg.get("YT_PRIVACY") == "public"


# ------------------------------------------------------------------ vaqtni o'qish
_REL = re.compile(r"^([+-])\s*(\d+)\s*([mhdMHD])$")


def parse_when(cfg, text, base=None):
    """(datetime UTC | None, xato). Formatlar: 18:30 · 2026-10-20 18:30 · 10-20 18:30 · ertaga 18:30 ·
    bugun 20:00 · +2h · +30m · +1d · -1d (base ga nisbatan; base yo'q bo'lsa hozirga)."""
    t = (text or "").strip().lower()
    if not t:
        return None, "vaqt kiritilmagan"
    tz = tzinfo(cfg)
    now_l = now_utc().astimezone(tz)
    m = _REL.match(t)
    if m:
        n = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
        unit = m.group(3).lower()
        delta = timedelta(minutes=n) if unit == "m" else timedelta(hours=n) if unit == "h" else timedelta(days=n)
        return (base or now_utc()) + delta, None
    day_off = None
    for w, off in (("ertaga", 1), ("bugun", 0), ("indinga", 2)):
        if t.startswith(w):
            day_off, t = off, t[len(w):].strip()
    try:
        if re.fullmatch(r"\d{1,2}[:.]\d{2}", t):
            h, mi = map(int, re.split(r"[:.]", t))
            dt = now_l.replace(hour=h, minute=mi, second=0, microsecond=0)
            if day_off is not None:
                dt += timedelta(days=day_off)
            elif dt <= now_l + MIN_EDIT:
                dt += timedelta(days=1)
        elif re.fullmatch(r"\d{4}-\d{1,2}-\d{1,2}[ t]\d{1,2}[:.]\d{2}", t):
            d, tm = re.split(r"[ t]", t)
            y, mo, da = map(int, d.split("-"))
            h, mi = map(int, re.split(r"[:.]", tm))
            dt = datetime(y, mo, da, h, mi, tzinfo=tz)
        elif re.fullmatch(r"\d{1,2}-\d{1,2}[ t]\d{1,2}[:.]\d{2}", t):
            d, tm = re.split(r"[ t]", t)
            mo, da = map(int, d.split("-"))
            h, mi = map(int, re.split(r"[:.]", tm))
            dt = datetime(now_l.year, mo, da, h, mi, tzinfo=tz)
            if dt < now_l - timedelta(days=1):
                dt = dt.replace(year=now_l.year + 1)
        else:
            return None, "format tushunarsiz. Masalan: 18:30 · ertaga 12:00 · 2026-10-20 18:30 · +2h · +1d"
    except ValueError:
        return None, "sana/vaqt noto'g'ri"
    return dt.astimezone(UTC), None


# ------------------------------------------------------------------ amallar
def _ep_by(db, gno):
    return db.ep_by_gno(int(gno))


def set_time(app, ep, dt):
    """Epizod chiqarish vaqtini belgilaydi. Qaytaradi: (ok, matn)."""
    cfg, db, yt = app.cfg, app.db, app.yt
    if dt < now_utc() + MIN_EDIT:
        return False, "vaqt kamida 5 daqiqa keyin bo'lishi kerak"
    if ep["status"] == "uploaded":
        if ep.get("pub_state") == "public":
            return False, "video allaqachon ochiq - vaqtni o'zgartirib bo'lmaydi"
        if not ep.get("yt_id"):
            return False, "YouTube ID yo'q"
        try:
            yt.set_publish(ep["yt_id"], to_iso(dt))
        except YTError as e:
            return False, f"YouTube: {clip(str(e), 200)}"
        db.ep_update(ep["id"], publish_at=to_iso(dt), pub_state="scheduled")
    else:
        db.ep_update(ep["id"], publish_at=to_iso(dt), pub_state="planned")
    return True, f"#{ep['gno']} → {fmt_local(cfg, dt)} ({eta(dt)})"


def publish_now(app, ep):
    if ep["status"] != "uploaded" or not ep.get("yt_id"):
        return False, "video hali YouTube'ga yuklanmagan"
    try:
        app.yt.set_publish(ep["yt_id"], None, "public")
    except YTError as e:
        return False, f"YouTube: {clip(str(e), 200)}"
    app.db.ep_update(ep["id"], pub_state="public", publish_at=iso_now())
    return True, f"#{ep['gno']} hozir ochiq qilindi: {ep['yt_url']}"


def unschedule(app, ep):
    """Rejani bekor qiladi: yuklangan bo'lsa video yopiq (private) qoladi, sanasiz."""
    if ep["status"] == "uploaded":
        if ep.get("pub_state") == "public":
            return False, "video allaqachon ochiq"
        try:
            app.yt.set_publish(ep["yt_id"], None, "private")
        except YTError as e:
            return False, f"YouTube: {clip(str(e), 200)}"
        app.db.ep_update(ep["id"], pub_state="manual", publish_at=None)
        return True, f"#{ep['gno']} rejasi bekor qilindi (yopiq qoldi, qo'lda ochiladi)"
    app.db.ep_update(ep["id"], pub_state=None, publish_at=None)
    return True, f"#{ep['gno']} belgilangan vaqt olib tashlandi (avtomatik slot ishlatiladi)"


def schedule_manual(app, ep):
    """Qo'lda yopiq qolgan videoga avtomatik bo'sh slot belgilaydi."""
    dt = next_free_slot(app.cfg, app.db, ep)
    return set_time(app, ep, dt)


def swap(app, a, b):
    ta, tb = from_iso(a.get("publish_at")), from_iso(b.get("publish_at"))
    if not ta or not tb:
        return False, "ikkala epizodda ham vaqt belgilangan bo'lishi kerak"
    ok, msg = set_time(app, a, tb)
    if not ok:
        return False, msg
    ok2, msg2 = set_time(app, b, ta)
    if not ok2:
        set_time(app, a, ta)      # qaytarish
        return False, msg2
    return True, f"#{a['gno']} ↔ #{b['gno']} o'rin almashdi"


def move_step(app, ep, direction):
    """Navbatda bir qadam yuqoriga (-1) yoki pastga (+1) surish: qo'shni bilan vaqt almashadi."""
    items = app.db.scheduled()
    ids = [e["id"] for e in items]
    if ep["id"] not in ids:
        return False, "rejalashtirilgan emas"
    i = ids.index(ep["id"]) + direction
    if not 0 <= i < len(items):
        return False, "bu chekka o'rin"
    return swap(app, ep, items[i])


def shift_all(app, delta):
    done, fail = 0, []
    for e in app.db.scheduled():
        d = from_iso(e["publish_at"])
        if not d:
            continue
        ok, msg = set_time(app, e, d + delta)
        if ok:
            done += 1
        else:
            fail.append(f"#{e['gno']}: {msg}")
    return done, fail


def reslot(app):
    """Hamma rejalashtirilganlarni gno tartibida eng yaqin ketma-ket slotlarga qayta joylaydi."""
    items = sorted(app.db.scheduled(), key=lambda e: e["gno"])
    if not items:
        return 0, []
    slots = slots_from(app.cfg, now_utc() + LEAD, len(items))
    done, fail = 0, []
    for e, dt in zip(items, slots):
        if from_iso(e["publish_at"]) == dt:
            done += 1
            continue
        ok, msg = set_time(app, e, dt)
        if ok:
            done += 1
        else:
            fail.append(f"#{e['gno']}: {msg}")
    return done, fail


# ------------------------------------------------------------------ YouTube bilan solishtirish
def reconcile(app):
    """Vaqti kelgan/o'zgargan rejalashtirilgan videolarni YouTube holati bilan solishtiradi.
    Ochilganini xabar qiladi, Studio'da qo'lda o'zgartirilgan vaqtni bazaga oladi."""
    db, yt, cfg = app.db, app.yt, app.cfg
    if not yt.authorized():
        return
    for e in db.scheduled():
        if not e.get("yt_id"):
            continue
        d = from_iso(e.get("publish_at"))
        # vaqtga 6 soatdan ko'p bo'lsa, tez-tez so'ramaymiz (kvota tejash)
        last = float(db.kv_get(f"rc:{e['id']}", "0") or 0)
        gap = 6 * 3600 if d and (d - now_utc()).total_seconds() > 24 * 3600 else 600
        if d and (d - now_utc()).total_seconds() < 900:
            gap = 120
        if time.time() - last < gap:
            continue
        db.kv_set(f"rc:{e['id']}", str(time.time()))
        try:
            info = yt.video_info(e["yt_id"])
        except YTError as ex:
            if ex.status == 404:
                key = f"rcgone:{e['id']}"
                if not db.kv_get(key):
                    db.kv_set(key, "1")
                    app.n.say(f"⚠️ #{e['gno']} YouTube'da topilmadi (o'chirilgan?). /forget {e['gno']} bilan qayta yasash mumkin.")
            continue
        except Exception as ex:  # noqa: BLE001
            log.warning("Reconcile xatosi: %s", ex)
            continue
        st = info.get("status") or {}
        priv, pat = st.get("privacyStatus"), st.get("publishAt")
        if priv == "public":
            db.ep_update(e["id"], pub_state="public")
            app.n.say(f"🎉 <b>Video chiqdi!</b> #{e['gno']} {esc(clip(e['title'], 70))}\n🔗 {e['yt_url']}")
            continue
        if pat and from_iso(pat) and d and abs((from_iso(pat) - d).total_seconds()) > 60:
            db.ep_update(e["id"], publish_at=pat)          # Studio'da qo'lda o'zgartirilgan
            app.n.say(f"ℹ️ #{e['gno']} chiqish vaqti YouTube'da o'zgartirilgan: {fmt_local(cfg, pat)} (bazaga olindi).")
        elif not pat:
            db.ep_update(e["id"], pub_state="manual", publish_at=None)
            app.n.say(f"ℹ️ #{e['gno']} YouTube'da vaqtsiz yopiq turibdi (Studio'da bekor qilingan). Qo'lda boshqariladi.")
        elif d and now_utc() > d + timedelta(minutes=45):
            key = f"rcwarn:{e['id']}"
            if not db.kv_get(key):
                db.kv_set(key, "1")
                app.n.say(f"⚠️ #{e['gno']} vaqti o'tdi, lekin video hali yopiq. Google loyihangiz tekshirilmagan (unverified) "
                          f"bo'lishi mumkin. Studio'dan ochiq qiling yoki /schedule orqali «Hozir ochish».")


def summary_line(cfg, e) -> str:
    st = e.get("pub_state")
    if st == "scheduled":
        d = from_iso(e["publish_at"])
        return f"⏰ #{e['gno']} {esc(clip(e['title'], 34))} · {fmt_local(cfg, d)} · {eta(d) if d else ''}"
    if st == "manual":
        return f"🔒 #{e['gno']} {esc(clip(e['title'], 34))} · yopiq (vaqtsiz)"
    if st == "planned":
        return f"📌 #{e['gno']} {esc(clip(e['title'], 34))} · {fmt_local(cfg, e['publish_at'])} (belgilangan)"
    return f"#{e['gno']} {esc(clip(e['title'], 34))}"
