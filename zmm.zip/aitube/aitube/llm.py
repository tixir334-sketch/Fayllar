"""Bepul LLM zanjiri: Gemini -> Groq -> OpenRouter -> Pollinations (kalitsiz).

Har bir provayder uchun bir nechta kalit va model qo'llab-quvvatlanadi.
Kalitlar NAVBAT BILAN ishlatiladi (har yangi so'rov keyingi kalitdan boshlanadi — parallel so'rovlar hamma
kalitlarga teng taqsimlanadi). 429/5xx/tarmoq xatosida HECH QANDAY kutmasdan darhol keyingi kalit/modelga
o'tiladi; yaroqsiz kalit/model sessiya davomida o'chiriladi. `complete_many` ko'p so'rovni parallel yuboradi va
har biri tugashi bilan natijani qaytaradi (keyingi bosqich javobni kutib turmaydi).
"""
from __future__ import annotations

import json
import re
import threading
import time

from .util import http, log

DEAD_RE = re.compile(r"decommission|no longer supported|model_not_found|does not exist|not found|deprecated|"
                     r"unavailable for free|no endpoints|has been shut|not supported for", re.I)
THINK_RE = re.compile(r"<think>.*?</think>", re.S | re.I)
SKIP_ID = re.compile(r"whisper|tts|orpheus|guard|safeguard|compound|embed|image|audio|vision|moderation|"
                     r"transcrib|live|robotics|computer-use|deep-research|veo|imagen|lyria|aqa|learnlm", re.I)


class LLMError(Exception):
    pass


class ProviderError(Exception):
    def __init__(self, msg, status=0, retry_after=0):
        super().__init__(msg)
        self.status = status
        self.retry_after = retry_after


def extract_json(text: str):
    """Model javobidan JSON ob'ektini ishonchli ajratib oladi."""
    if text is None:
        raise ValueError("bo'sh javob")
    t = text.strip()
    t = re.sub(r"^```(?:json|JSON)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    start_candidates = [i for i in (t.find("{"), t.find("[")) if i >= 0]
    if not start_candidates:
        raise ValueError("JSON topilmadi")
    start = min(start_candidates)
    opener = t[start]
    closer = "}" if opener == "{" else "]"
    end = t.rfind(closer)
    if end <= start:
        raise ValueError("JSON tugallanmagan")
    body = t[start:end + 1]
    for candidate in (body, re.sub(r",\s*([}\]])", r"\1", body)):
        try:
            return json.loads(candidate, strict=False)
        except ValueError:
            continue
    # oxirgi urinish: boshqaruv belgilarini tozalash
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", body)
    cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
    return json.loads(cleaned, strict=False)


# --------------------------------------------------------------------------- provayderlar
class Provider:
    name = "base"
    needs_key = True

    def __init__(self, cfg):
        self.cfg = cfg
        self.keys = self._keys()
        self.models = self._models()

    def _keys(self):
        return []

    def _models(self):
        return []

    def available(self):
        return bool(self.models) and (bool(self.keys) or not self.needs_key)

    def call(self, key, model, system, prompt, json_mode, temperature, max_tokens) -> str:
        raise NotImplementedError

    def discover(self, key) -> list:
        """Provayderning hozirgi (jonli) model ro'yxatidan mos matn modellarini saralab qaytaradi."""
        return []


def _size_b(model_id: str) -> float:
    m = re.findall(r"(\d+(?:\.\d+)?)b\b", model_id.lower())
    return max(float(x) for x in m) if m else 0.0


def _get_json(url, **kw):
    r = http("GET", url, timeout=(15, 40), retries=2, wait_net=True, **kw)
    if r.status_code != 200:
        raise ProviderError(f"HTTP {r.status_code}: {r.text[:150]}", r.status_code)
    try:
        return r.json()
    except ValueError:
        raise ProviderError("JSON bo'lmagan javob", 502)


def _retry_after(r):
    try:
        return float(r.headers.get("retry-after", 0))
    except (TypeError, ValueError):
        return 0.0


class GeminiProvider(Provider):
    name = "gemini"

    def _keys(self):
        return self.cfg.list("GEMINI_API_KEYS")

    def _models(self):
        return self.cfg.list("GEMINI_MODELS")

    def discover(self, key):
        j = _get_json(f"{self.cfg.get('GEMINI_BASE')}/v1beta/models", params={"key": key, "pageSize": 200})
        found = []
        for m in j.get("models", []):
            mid = m.get("name", "").split("/")[-1]
            if not mid.startswith("gemini") or SKIP_ID.search(mid) or "pro" in mid:
                continue
            if "generateContent" not in (m.get("supportedGenerationMethods") or ["generateContent"]):
                continue
            ver = re.search(r"gemini-(\d+(?:\.\d+)?)", mid)
            tier = (1 if "lite" in mid else 0) + (10 if re.search(r"preview|exp", mid) else 0) \
                + (5 if mid.endswith("-latest") else 0)
            found.append((tier, -(float(ver.group(1)) if ver else 0), mid))
        return [m for _, _, m in sorted(found)]

    def call(self, key, model, system, prompt, json_mode, temperature, max_tokens):
        url = f"{self.cfg.get('GEMINI_BASE')}/v1beta/models/{model}:generateContent"
        gen = {"temperature": temperature, "maxOutputTokens": max_tokens}
        if json_mode:
            gen["responseMimeType"] = "application/json"
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": gen,
        }
        r = http("POST", url, params={"key": key}, json=body, timeout=(15, 180), retries=1, wait_net=True, up_retries=0)
        if r.status_code != 200:
            raise ProviderError(f"HTTP {r.status_code}: {r.text[:500]}", r.status_code, _retry_after(r))
        try:
            j = r.json()
            cands = j.get("candidates") or []
            if not cands:
                raise ProviderError(f"bo'sh javob: {str(j.get('promptFeedback'))[:150]}", 422)
            parts = cands[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        except ValueError:
            raise ProviderError("JSON bo'lmagan javob", 502)
        if not text.strip():
            raise ProviderError("bo'sh matn", 422)
        return text


class OpenAICompat(Provider):
    base_key = ""
    extra_headers: dict = {}

    def base(self):
        return self.cfg.get(self.base_key).rstrip("/")

    def url(self):
        return self.base() + "/chat/completions"

    def discover(self, key):
        headers = {"Authorization": f"Bearer {key}"} if key else {}
        j = _get_json(self.base() + "/models", headers=headers)
        found = []
        for m in j.get("data", []):
            mid = m.get("id", "")
            if not mid or SKIP_ID.search(mid) or m.get("active") is False:
                continue
            pr = m.get("pricing")
            if self.name == "openrouter":
                if not mid.endswith(":free") and mid != "openrouter/free":
                    continue
                if pr and (float(pr.get("prompt") or 0) or float(pr.get("completion") or 0)):
                    continue
                outs = (m.get("architecture") or {}).get("output_modalities") or ["text"]
                if "text" not in outs:
                    continue
            found.append((0 if mid == "openrouter/free" else 1, -_size_b(mid), -(m.get("context_length") or 0), mid))
        return [x[-1] for x in sorted(found)]

    def call(self, key, model, system, prompt, json_mode, temperature, max_tokens):
        body = {
            "model": model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        headers = dict(self.extra_headers)
        if key:
            headers["Authorization"] = f"Bearer {key}"
        use_json = json_mode
        for _ in range(2):
            b = dict(body)
            if use_json:
                b["response_format"] = {"type": "json_object"}
            r = http("POST", self.url(), json=b, headers=headers, timeout=(15, 180), retries=1, wait_net=True, up_retries=0)
            if r.status_code == 400 and use_json and "response_format" in r.text.lower():
                use_json = False
                continue
            break
        if r.status_code != 200:
            raise ProviderError(f"HTTP {r.status_code}: {r.text[:500]}", r.status_code, _retry_after(r))
        try:
            j = r.json()
            text = j["choices"][0]["message"]["content"] or ""
        except (ValueError, KeyError, IndexError, TypeError):
            raise ProviderError(f"kutilmagan javob: {r.text[:150]}", 502)
        text = THINK_RE.sub("", text)
        if not text.strip():
            raise ProviderError("bo'sh matn", 422)
        return text


class GroqProvider(OpenAICompat):
    name = "groq"
    base_key = "GROQ_BASE"

    def _keys(self):
        return self.cfg.list("GROQ_API_KEYS")

    def _models(self):
        return self.cfg.list("GROQ_MODELS")


class OpenRouterProvider(OpenAICompat):
    name = "openrouter"
    base_key = "OPENROUTER_BASE"
    extra_headers = {"HTTP-Referer": "https://github.com/aitube", "X-Title": "AITube"}

    def _keys(self):
        return self.cfg.list("OPENROUTER_API_KEYS")

    def _models(self):
        return self.cfg.list("OPENROUTER_MODELS")


class PollinationsProvider(OpenAICompat):
    name = "pollinations"
    needs_key = False

    def url(self):
        return self.cfg.get("POLLINATIONS_BASE")

    def _models(self):
        return self.cfg.list("POLLINATIONS_MODELS")


PROVIDERS = {c.name: c for c in (GeminiProvider, GroqProvider, OpenRouterProvider, PollinationsProvider)}


# --------------------------------------------------------------------------- asosiy sinf
class LLM:
    def __init__(self, cfg, mock=None):
        self.cfg = cfg
        self.mock = mock          # callable(system, prompt) -> str  (faqat sinov uchun)
        self.cooldown: dict = {}  # (provider,key) -> vaqt
        self.bad_keys: set = set()
        self.bad_models: set = set()
        self.empty: dict = {}
        self.discovered: dict = {}  # provayder -> topilgan modellar
        self.last_label = ""
        self.stats: dict = {}
        self.key_use: dict = {}   # (provayder, kalit raqami) -> nechta muvaffaqiyatli so'rov
        self._rr: dict = {}       # provayder -> navbatdagi kalit (aylanish)
        self.health: dict = {}    # (provayder, kalit) -> {ok, fail, streak, lat (EWMA soniya), last}
        self._lk = threading.Lock()
        self._cv = threading.Condition()

    def providers(self):
        out = []
        for name in self.cfg.list("LLM_ORDER"):
            cls = PROVIDERS.get(name.lower())
            if cls:
                p = cls(self.cfg)
                if p.available():
                    out.append(p)
        return out

    def reset_health(self):
        """Kalit/model o'zgartirilgach 'yaroqsiz' belgilarini tozalaydi."""
        self.bad_keys.clear()
        self.bad_models.clear()
        self.empty.clear()
        self.cooldown.clear()
        self.discovered.clear()
        self.wake()

    def discover(self, p, key="") -> list:
        keys = [key] if key else (p.keys or [""])
        last = None
        for k in keys:
            try:
                return p.discover(k)
            except Exception as e:  # noqa: BLE001
                last = e
        if last:
            raise last
        return []

    def _models_for(self, p, key):
        """Provayder modellari; hammasi o'lik bo'lsa jonli ro'yxatdan topadi va .env ga saqlaydi."""
        alive = [m for m in p.models if (p.name, m) not in self.bad_models]
        if alive or p.name == "pollinations" or not self.cfg.bool("LLM_AUTO_MODELS"):
            return alive
        if p.name not in self.discovered:
            try:
                found = self.discover(p, key)
            except Exception as e:  # noqa: BLE001
                log.warning("%s: yangi modellarni topib bo'lmadi: %s", p.name, e)
                found = []
            self.discovered[p.name] = [m for m in found if (p.name, m) not in self.bad_models][:4]
            if self.discovered[p.name]:
                log.warning("%s: eski modellar o'lik, yangilari topildi: %s", p.name, self.discovered[p.name])
                try:
                    self.cfg.set(f"{p.name.upper()}_MODELS", ",".join(self.discovered[p.name]))
                except Exception:  # noqa: BLE001
                    pass
        return [m for m in self.discovered[p.name] if (p.name, m) not in self.bad_models]

    def _model_stream(self, p, key):
        """Modellarni ketma-ket beradi; hammasi o'lik chiqsa, jonli ro'yxatdan yangilarini topib davom etadi."""
        tried = set()
        for _ in range(2):
            fresh = [m for m in self._models_for(p, key) if m not in tried]
            if not fresh:
                return
            for m in fresh:
                tried.add(m)
                yield m

    def test_key(self, p, key, model=None) -> tuple:
        """(ok, matn): bitta kalitni kichik so'rov bilan sinaydi (kalit hech qachon matnga kirmaydi)."""
        models = [model] if model else [m for m in p.models if (p.name, m) not in self.bad_models][:3]
        if not models:
            return False, "faol model yo'q"
        last = ""
        empty = 0
        for m in models:
            try:
                p.call(key, m, "Qisqa javob ber.", "Salom de.", False, 0.2, 60)
                return True, m
            except ProviderError as e:
                last = f"{m}: {str(e)[:90]}"
                if e.status in (401, 403):
                    return False, f"kalit yaroqsiz (HTTP {e.status})"
                if e.status == 429:
                    return True, f"{m}: kalit ishlaydi, hozir limit (429)"
                if e.status == 422:
                    empty += 1
            except Exception as e:  # noqa: BLE001
                last = f"{m}: {type(e).__name__}"
        if empty and empty == len(models):
            return True, "kalit ishlaydi, lekin model bo'sh javob qaytardi (/model find " + p.name + " bilan boshqa model toping)"
        return False, last

    def describe(self) -> str:
        if self.mock:
            return "mock"
        ps = self.providers()
        if not ps:
            return "hech qanday provayder sozlanmagan"
        return ", ".join(f"{p.name}({max(1, len(p.keys))} kalit)" for p in ps)

    def report(self) -> str:
        """Kalitlar sog'lig'i: nechta muvaffaqiyat/xato, o'rtacha javob vaqti va holati (admin paneli uchun)."""
        now = time.time()
        lines = []
        for p in self.providers():
            for i, key in enumerate(p.keys or [""], 1):
                h = self.health.get((p.name, key), {})
                ck = (p.name, key)
                if ck in self.bad_keys:
                    st = "❌ yaroqsiz"
                elif self.cooldown.get(ck, 0) > now:
                    st = f"⏸ {int(self.cooldown[ck] - now)}s dam"
                else:
                    st = "✅"
                if not h and st == "✅" and not self.key_use.get((p.name, i)):
                    continue
                lat = f" · {h.get('lat', 0):.1f}s" if h.get("lat") else ""
                lines.append(f"{st} {p.name}#{i}: {h.get('ok', 0)} ok / {h.get('fail', 0)} xato{lat}")
        return "\n".join(lines) or "hali so'rov bo'lmagan"

    # ---------------------------------------------------------------- kalitlar aylanishi
    def _rot(self, name: str, keys: list) -> list:
        """Kalitlarni NAVBAT BILAN aylantiradi: har yangi so'rov keyingi kalitdan boshlanadi.
        Parallel so'rovlar shu tarzda hamma kalitlarga teng taqsimlanadi (bitta kalit limiti tez tugamaydi)."""
        if len(keys) <= 1:
            return list(keys)
        with self._lk:
            i = self._rr.get(name, 0) % len(keys)
            self._rr[name] = (i + 1) % len(keys)
        return list(keys[i:]) + list(keys[:i])

    def wake(self):
        """Kutib turgan so'rovlarni darhol uyg'otadi (kalit/model o'zgarganda)."""
        with self._cv:
            self._cv.notify_all()

    def _nap(self, secs: float):
        """Faqat ZARUR bo'lganda kutadi (hamma variant xato bergan bo'lsa); wake() bilan darhol uyg'onadi."""
        with self._cv:
            self._cv.wait(timeout=max(0.0, secs))

    def _ok(self, p, key, model, text, t0, label_prefix="LLM ok"):
        label = f"{p.name}:{model}"
        self.last_label = label
        self.stats[label] = self.stats.get(label, 0) + 1
        try:
            ki = (p.keys.index(key) + 1) if key in p.keys else 0
        except ValueError:
            ki = 0
        kk = (p.name, ki)
        self.key_use[kk] = self.key_use.get(kk, 0) + 1
        h = self.health.setdefault((p.name, key), {"ok": 0, "fail": 0, "streak": 0, "lat": 0.0, "last": 0.0})
        h["ok"] += 1
        h["streak"] = 0
        dt = time.time() - t0
        h["lat"] = dt if not h["lat"] else 0.7 * h["lat"] + 0.3 * dt
        h["last"] = time.time()
        log.info("%s %s#%d (%.1fs, %d belgi)", label_prefix, label, ki, time.time() - t0, len(text))
        return text, label

    def complete(self, system: str, prompt: str, json_mode=False, temperature=None,
                 max_tokens=8192) -> tuple:
        """(matn, 'provayder:model') qaytaradi yoki LLMError.
        Kalitlar navbat bilan almashadi; xatoda KUTMASDAN keyingi kalit/modelga o'tadi (kutish faqat hamma variant
        yiqilgandagina, qisqa va hodisaga asoslangan)."""
        if self.mock:
            self.last_label = "mock:mock"
            return self.mock(system, prompt), "mock:mock"
        temperature = self.cfg.float("LLM_TEMPERATURE") if temperature is None else temperature
        errors = []
        providers = self.providers()
        if not providers:
            raise LLMError("Hech bir LLM provayder sozlanmagan (GEMINI_API_KEYS, GROQ_API_KEYS ... yoki "
                           "kalitsiz pollinations).")
        try:
            passes = max(1, int(self.cfg.get("LLM_PASSES") or 2))
            max_cd_wait = float(self.cfg.get("LLM_WAIT") or 25)
        except (TypeError, ValueError):
            passes, max_cd_wait = 2, 25.0
        for pass_no in range(passes):
            transient = False          # 5xx / tarmoq xatosi bo'ldi: qayta urinishga arziydi
            tried = 0
            soonest = 0.0              # eng yaqin 'dam olish' tugashi
            for p in providers:
                for key in self._rot(p.name, p.keys or [""]):
                    ck = (p.name, key)
                    if ck in self.bad_keys:
                        continue
                    cd = self.cooldown.get(ck, 0)
                    if cd > time.time():
                        errors.append(f"{p.name}: kalit dam olmoqda")
                        soonest = cd if not soonest else min(soonest, cd)
                        continue
                    for model in self._model_stream(p, key):
                        mk = (p.name, model)
                        if mk in self.bad_models:
                            continue
                        tried += 1
                        t0 = time.time()
                        try:
                            text = p.call(key, model, system, prompt, json_mode, temperature, max_tokens)
                            return self._ok(p, key, model, text, t0)
                        except ProviderError as e:
                            errors.append(f"{p.name}/{model}: {e}")
                            log.warning("LLM xato %s/%s: %s", p.name, model, e)
                            self._note_error(p, key, model, e)
                            if e.status >= 500 or e.status in (0, 408, 409, 425):
                                transient = True
                        except Exception as e:  # tarmoq va boshqalar
                            errors.append(f"{p.name}/{model}: {type(e).__name__}: {e}")
                            log.warning("LLM tarmoq xatosi %s/%s: %s", p.name, model, e)
                            transient = True
                        # kalit yaroqsiz yoki dam olmoqda bo'lsa — qolgan modellarni o'tkazib keyingi kalitga
                        if ck in self.bad_keys or self.cooldown.get(ck, 0) > time.time():
                            break
            if pass_no + 1 >= passes:
                break
            if tried == 0 and soonest:             # hamma kalit dam olmoqda: eng yaqinining tugashini kutamiz
                wait = soonest - time.time()
                if 0 < wait <= max_cd_wait:
                    self._nap(wait + 0.05)
                    continue
                break
            if transient:                          # hamma variant vaqtincha yiqildi: qisqa tanaffus, keyin yana
                self._nap(0.3 + 0.4 * pass_no)
                continue
            break
        raise LLMError("Barcha LLM provayderlar javob bermadi:\n" + "\n".join(errors[-8:]))

    def complete_many(self, jobs: list, workers: int = 0, **kw):
        """Ko'p so'rovni PARALLEL yuboradi; har biri tugashi bilan natija darhol beriladi (hammasini kutmasdan).
        jobs: [(system, prompt) yoki (system, prompt, {opsiyalar})]. Qaytaradi (generator): (indeks, matn, label, xato).
        Har so'rov kalitlarni navbat bilan oladi, shuning uchun yuk barcha kalitlarga taqsimlanadi."""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        n = len(jobs)
        if not n:
            return
        nkeys = sum(max(1, len(p.keys)) for p in self.providers()) or 1
        w = workers or max(2, min(n, 3 * nkeys, 16))

        def one(job):
            opts = dict(kw)
            if len(job) > 2 and job[2]:
                opts.update(job[2])
            return self.complete(job[0], job[1], **opts)

        with ThreadPoolExecutor(max_workers=w, thread_name_prefix="llm-many") as ex:
            futs = {ex.submit(one, j): i for i, j in enumerate(jobs)}
            for f in as_completed(futs):
                i = futs[f]
                try:
                    text, label = f.result()
                    yield i, text, label, None
                except Exception as e:  # noqa: BLE001
                    yield i, "", "", e

    def complete_json_many(self, jobs: list, workers: int = 0, **kw):
        """complete_many ning JSON varianti: har bir natija o'qilgan obyekt bilan: (indeks, obj, label, xato)."""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        n = len(jobs)
        if not n:
            return
        nkeys = sum(max(1, len(p.keys)) for p in self.providers()) or 1
        w = workers or max(2, min(n, 3 * nkeys, 16))

        def one(job):
            opts = dict(kw)
            if len(job) > 2 and job[2]:
                opts.update(job[2])
            return self.complete_json(job[0], job[1], **opts)

        with ThreadPoolExecutor(max_workers=w, thread_name_prefix="llm-many") as ex:
            futs = {ex.submit(one, j): i for i, j in enumerate(jobs)}
            for f in as_completed(futs):
                i = futs[f]
                try:
                    obj, label = f.result()
                    yield i, obj, label, None
                except Exception as e:  # noqa: BLE001
                    yield i, None, "", e

    def _note_error(self, p, key, model, e):
        """Provayder xatosiga qarab kalit/model holatini yangilaydi (complete() bilan bir xil qoidalar)."""
        ck, mk = (p.name, key), (p.name, model)
        h = self.health.setdefault(ck, {"ok": 0, "fail": 0, "streak": 0, "lat": 0.0, "last": 0.0})
        h["fail"] += 1
        h["streak"] += 1
        h["last"] = time.time()
        if h["streak"] >= 3 and e.status not in (401, 403, 404, 422) and e.status != 429:
            # ketma-ket vaqtinchalik xatolar (5xx/tarmoq): kalit eksponensial 'karantin'ga (20s -> 40s -> ... eng ko'pi 5 daqiqa);
            # keyingi muvaffaqiyatli so'rovda tozalanadi
            self.cooldown[ck] = max(self.cooldown.get(ck, 0), time.time() + min(300, 20 * 2 ** (h["streak"] - 3)))
        if e.status in (401, 403):
            self.bad_keys.add(ck)
        elif e.status == 404 or (e.status in (400, 410) and DEAD_RE.search(str(e))):
            self.bad_models.add(mk)
        elif e.status == 429 and re.search(r"limit:\s*0\b", str(e)):
            self.bad_models.add(mk)
        elif e.status == 429:
            self.cooldown[ck] = time.time() + min(120, max(20, e.retry_after or 45))
        elif e.status == 422:
            self.empty[mk] = self.empty.get(mk, 0) + 1
            if self.empty[mk] >= 2:
                self.bad_models.add(mk)

    def complete_race(self, system: str, prompt: str, n: int = 5, json_mode=True, temperature=None,
                      max_tokens=8192, wait: float = 150.0) -> tuple:
        """BIR VAQTDA n ta har xil provayder/model ishga tushadi; birinchi YAROQLI (JSON bo'lsa — o'qiladigan) javob olinadi,
        qolganlari tashlanadi. Hammasi muvaffaqiyatsiz bo'lsa LLMError. Qaytaradi: (text, label)."""
        import queue as _q
        import threading as _t
        temperature = self.cfg.float("LLM_TEMPERATURE") if temperature is None else temperature
        # barcha (provayder, kalit, model) variantlari; poyga guruhlari navbat bilan almashadi:
        # 1-bo'lak: 1..5-variant, 2-bo'lak: 6..10-variant, ... (tugasa boshidan)
        allc, seen = [], set()
        for p in self.providers():
            for key in (p.keys or [""]):
                ck = (p.name, key)
                if ck in self.bad_keys or self.cooldown.get(ck, 0) > time.time():
                    continue
                try:
                    models = self._models_for(p, key)[:3]
                except Exception:  # noqa: BLE001
                    models = []
                for m in models:
                    if (p.name, key, m) not in seen:
                        seen.add((p.name, key, m))
                        allc.append((p, key, m))
        if not allc:
            raise LLMError("Poyga uchun yaroqli provayder yo'q")
        # xilma-xillik uchun provayderlarni aralashtiramiz: p1,p2,p3,p1,p2,p3...
        byp: dict = {}
        for c in allc:
            byp.setdefault(c[0].name, []).append(c)
        order = []
        while any(byp.values()):
            for nm in list(byp):
                if byp[nm]:
                    order.append(byp[nm].pop(0))
        n = max(1, n)
        start = getattr(self, "_race_cur", 0) % len(order)
        groups = []
        for g in range(max(1, -(-len(order) // n))):
            groups.append([order[(start + g * n + i) % len(order)] for i in range(min(n, len(order)))])
        self._race_cur = (start + n) % len(order)
        out: _q.Queue = _q.Queue()

        def work(p, key, model):
            t0 = time.time()
            try:
                text = p.call(key, model, system, prompt, json_mode, temperature, max_tokens)
                if json_mode:
                    extract_json(text)
                _, label = self._ok(p, key, model, text, t0, "LLM poyga g'olibi")
                out.put((True, text, label))
            except ProviderError as e:
                self._note_error(p, key, model, e)
                out.put((False, f"{p.name}/{model}: {e}", ""))
            except Exception as e:  # noqa: BLE001
                out.put((False, f"{p.name}/{model}: {type(e).__name__}: {e}", ""))

        errs, started, finished = [], 0, 0
        t_start = time.time()
        deadline = t_start + wait
        hedge = 45.0                       # javob kelmasa har 45s da keyingi guruh qo'shiladi (oldingilari to'xtatilmaydi)
        gi = 0
        while True:
            # yangi guruhni ishga tushirish: birinchisi darhol; keyingilari kechikish yoki hamma yiqilganda
            if gi < len(groups) and (gi == 0 or finished >= started or time.time() - t_start >= gi * hedge):
                for p, key, m in groups[gi]:
                    _t.Thread(target=work, args=(p, key, m), daemon=True, name="llm-race").start()
                    started += 1
                gi += 1
            if finished >= started and gi >= len(groups):
                break
            if time.time() > deadline:
                break
            try:
                ok_, text, label = out.get(timeout=1.0)
            except _q.Empty:
                continue
            finished += 1
            if ok_:
                return text, label
            errs.append(text)
        raise LLMError("Poygada hech kim yaroqli javob bermadi: " + "; ".join(errs[-5:]))

    def complete_json(self, system: str, prompt: str, tries=3, race: int = 0, **kw) -> tuple:
        """JSON qaytaradi: (obj, label). race=n: n ta har xil AI bir vaqtda, eng tez yaroqli javob olinadi."""
        last = None
        if race and not self.mock:
            try:
                text, label = self.complete_race(system, prompt, n=race, **kw)
                return extract_json(text), label
            except Exception as e:  # noqa: BLE001
                log.warning("LLM poygasi muvaffaqiyatsiz (%s) — oddiy tartibga o'tiladi", str(e)[:200])
        for i in range(tries):
            text, label = self.complete(system, prompt, json_mode=True, **kw)
            try:
                return extract_json(text), label
            except ValueError as e:
                last = e
                log.warning("JSON o'qib bo'lmadi (%s), qayta urinish %d/%d", e, i + 1, tries)
                prompt = prompt + "\n\nESLATMA: faqat TO'G'RI JSON qaytar, hech qanday izoh yoki ``` belgisiz."
        raise LLMError(f"LLM yaroqli JSON qaytarmadi: {last}")
