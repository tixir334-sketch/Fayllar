"""Tizim salomatligini tekshirish."""
from __future__ import annotations

import importlib
import sys

from .render import get_font
from .util import disk_free_mb, esc, http, run

OK, WARN, BAD = "✅", "⚠️", "❌"


def check(app, network=False) -> list:
    cfg = app.cfg
    items = []

    def add(level, name, detail=""):
        items.append((level, name, detail))

    add(OK if sys.version_info >= (3, 8) else BAD, "Python", sys.version.split()[0])
    for mod in ("PIL", "requests"):
        try:
            m = importlib.import_module(mod)
            add(OK, mod, getattr(m, "__version__", ""))
        except ImportError:
            add(BAD, mod, "o'rnatilmagan")
    try:
        importlib.import_module("edge_tts")
        add(OK, "edge-tts", "o'rnatilgan (sifatli ovoz)")
    except ImportError:
        add(WARN, "edge-tts", "yo'q → Google TTS ishlatiladi (pip install edge-tts)")
    rc, out, _ = run(["ffmpeg", "-version"], timeout=15)
    if rc == 0:
        add(OK, "ffmpeg", out.splitlines()[0][:60])
        rc2, enc, _ = run(["ffmpeg", "-hide_banner", "-encoders"], timeout=15)
        add(OK if "libx264" in enc else WARN, "libx264", "bor" if "libx264" in enc else "yo'q (mpeg4 ishlatiladi)")
        try:                                           # video kodlash: GPU (NVENC/QSV/AMF) yoki CPU
            from .hwenc import HW
            HW.bind(cfg)
            st = HW.status()
            gpu = st["active"] != "cpu"
            want_gpu = st["mode"] not in ("auto", "cpu")
            detail = f"{st['label']} · rejim: {st['mode']}" + (f" · sessiyalar {HW.sessions(st['active'])}" if gpu else "")
            add(OK if (gpu or not want_gpu) else WARN, "Kodlash", detail + ("" if gpu or not want_gpu else " (GPU ishlamadi → CPU)"))
        except Exception as e:  # noqa: BLE001
            add(WARN, "Kodlash", f"tekshirilmadi: {str(e)[:60]}")
    else:
        add(BAD, "ffmpeg", "topilmadi (pkg install ffmpeg)")
    try:
        f = get_font(cfg.fonts_dir, "bold", 20)
        add(OK if hasattr(f, "path") or True else WARN, "Shriftlar", getattr(f, "path", "standart"))
    except Exception as e:
        add(BAD, "Shriftlar", str(e))
    free = disk_free_mb(cfg.data)
    add(OK if free > 1500 else (WARN if free > 400 else BAD), "Disk", f"{free} MB bo'sh")
    add(OK if app.tg.enabled() else BAD, "Telegram", "token va ADMIN_ID bor" if app.tg.enabled()
        else "TELEGRAM_BOT_TOKEN yoki ADMIN_ID yo'q")
    add(OK if app.llm.providers() else BAD, "LLM", app.llm.describe())
    add(OK, "Ovoz", ", ".join(app.tts.providers()) or "yo'q")
    if not app.yt.configured():
        add(WARN, "YouTube", "YT_CLIENT_ID/SECRET yo'q → videolar faqat Telegramga yuboriladi")
    elif not app.yt.authorized():
        add(WARN, "YouTube", "sozlangan, lekin /auth qilinmagan")
    else:
        add(OK, "YouTube", "avtorizatsiya bor")
    add(OK if cfg.list("UPLOAD_TIMES") else WARN, "Jadval", f"{cfg.get('UPLOAD_TIMES')} (UTC+{cfg.get('TZ_OFFSET')})")
    halt = app.db.kv_get("halt_reason")
    if halt:
        add(BAD, "To'xtatilgan", halt)
    if network:
        for name, url in (("Internet", "https://www.google.com/generate_204"),
                          ("Telegram API", cfg.get("TG_API_BASE")), ("YouTube API", cfg.get("YT_API_BASE"))):
            try:
                r = http("GET", url, retries=1, timeout=(8, 10))
                add(OK, name, f"HTTP {r.status_code}")
            except Exception as e:
                add(BAD, name, f"{type(e).__name__}")
        if app.tg.enabled():
            try:
                me = app.tg.me()
                add(OK, "Bot", "@" + me.get("username", "?"))
            except Exception as e:
                add(BAD, "Bot", app.tg._clean(e)[:80])
    return items


def format_report(items) -> str:
    lines = ["🩺 <b>Salomatlik tekshiruvi</b>"]
    for lvl, name, detail in items:
        lines.append(f"{lvl} <b>{esc(name)}</b>" + (f": {esc(detail)}" if detail else ""))
    bad = sum(1 for i in items if i[0] == BAD)
    warn = sum(1 for i in items if i[0] == WARN)
    lines.append(f"\nNatija: {bad} ta xato, {warn} ta ogohlantirish.")
    return "\n".join(lines)


def signature(items) -> str:
    return "|".join(f"{n}:{l}" for l, n, _ in items if l == BAD)
