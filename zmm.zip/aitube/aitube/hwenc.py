"""Video kodlash menejeri: GPU (NVIDIA NVENC, Intel QSV, AMD AMF, Apple VideoToolbox, Android MediaCodec — telefon) -> CPU (libx264) -> mpeg4.

Nima uchun kerak: stream va video kodlash CPU da sekin. Bu modul:
  * qaysi kodlovchi HAQIQATAN ishlashini bir marta qisqa sinov bilan aniqlaydi (`ffmpeg -encoders` ro'yxatida
    bo'lishi yetarli emas: videokarta/drayver bo'lmasa kodlovchi ishga tushmaydi);
  * har bir kodlovchi uchun SIFATI BELGILANGAN parametrlar beradi (doimiy sifat CQ/CRF + bitrate chegarasi),
    shuning uchun stream sifati kodlovchiga qarab tushib ketmaydi;
  * parallel GPU sessiyalar sonini cheklaydi (GeForce drayverlarida sessiya chegarasi bor) va haqiqiy chegarani o'lchaydi;
  * GPU xato bersa avtomatik CPU ga o'tadi va birozdan keyin GPU ni qayta sinaydi.

Telefon (Termux; MediaTek/Qualcomm/Exynos): ffmpeg `h264_mediacodec` (NDK MediaCodec) — chip nomi (getprop) bo'yicha apparat
kodlovchi nomi bilan ochiladi, natija PSNR bilan tekshiriladi (buzuq rang/o'lcham rad etiladi), osilib qolsa tez to'xtatiladi.

Sozlamalar (.env): ENCODER=auto|nvenc|qsv|amf|videotoolbox|mediacodec|cpu  ·  ENC_SESSIONS=0 (0 = o'lchab aniqlash).
"""
from __future__ import annotations

import os
import re
import threading
import time
from contextlib import contextmanager

from .util import log, run

NAMES = {"nvenc": "h264_nvenc", "qsv": "h264_qsv", "amf": "h264_amf", "videotoolbox": "h264_videotoolbox",
         "mediacodec": "h264_mediacodec", "cpu": "libx264"}
LABEL = {"nvenc": "NVIDIA NVENC", "qsv": "Intel QuickSync (QSV)", "amf": "AMD AMF", "videotoolbox": "Apple VideoToolbox",
         "mediacodec": "Android MediaCodec (telefon GPU/video chipi)", "cpu": "CPU (libx264)", "mpeg4": "CPU (mpeg4)"}
ORDER = ("nvenc", "qsv", "amf", "videotoolbox", "mediacodec")         # avto-tanlash tartibi
ALIASES = {"nvidia": "nvenc", "cuda": "nvenc", "h264_nvenc": "nvenc", "intel": "qsv", "h264_qsv": "qsv",
           "quicksync": "qsv", "amd": "amf", "h264_amf": "amf", "apple": "videotoolbox", "vt": "videotoolbox",
           "h264_videotoolbox": "videotoolbox", "mediacodec": "mediacodec", "h264_mediacodec": "mediacodec",
           "android": "mediacodec", "phone": "mediacodec", "telefon": "mediacodec", "mali": "mediacodec",
           "mediatek": "mediacodec", "mtk": "mediacodec", "helio": "mediacodec", "x264": "cpu", "libx264": "cpu", "software": "cpu", "soft": "cpu",
           "off": "cpu", "0": "cpu", "gpu": "auto", "": "auto", "1": "auto", "on": "auto"}
MODES = ("auto", "nvenc", "qsv", "amf", "videotoolbox", "mediacodec", "cpu")
DEFAULT_SESSIONS = {"nvenc": 3, "qsv": 4, "amf": 4, "videotoolbox": 3, "mediacodec": 3}
PIXFMT = {"nvenc": "yuv420p", "qsv": "nv12", "amf": "yuv420p", "videotoolbox": "yuv420p", "mediacodec": "nv12",
          "cpu": "yuv420p"}
MC_BOOST = 1.25        # telefon apparat kodlovchisi bir xil bitrate da x264 dan zaifroq: avto-bitrate shuncha oshiriladi (sifat uchun)

# GPU/drayver bilan bog'liq xatolar (kodlovchi ishga tushmadi / sessiya chegarasi)
HW_ERR = re.compile(r"OpenEncodeSession|No capable devices|out of memory|Cannot load lib|libcuda|cuda|nvenc|NVENC|"
                    r"InitializeEncoder|incompatible client key|Driver does not support|Device creation failed|"
                    r"Error initializing|Could not open encoder|Error while opening encoder|MFX|mfx|qsv|QSV|VAAPI|"
                    r"AMF|amf|hwaccel|Unsupported|not supported|Function not implemented|Invalid argument|"
                    r"Cannot allocate|encoder not found|Unknown encoder|Unrecognized option|Option .* not found|"
                    r"MediaCodec|AMediaCodec|createCodecByName|Failed to (start|configure|create|init)|"
                    r"Unable to parse option|codec_name|ndk_codec|bitrate_mode|PSNR", re.I)
SESSION_ERR = re.compile(r"OpenEncodeSession|out of memory|incompatible client key|No capable devices|"
                         r"too many|Resource.*unavailable|device.*busy|insufficient resources|no free|max(imum)? instances|"
                         r"Failed to start", re.I)


def is_android() -> bool:
    """Termux/Android muhitimi (telefon)."""
    return bool(os.environ.get("TERMUX_VERSION") or "com.termux" in os.environ.get("PREFIX", "")
                or os.environ.get("ANDROID_ROOT") or os.path.exists("/system/build.prop"))


def auto_kbps(res: int, fps: int) -> int:
    """Ko'rsatilmagan bo'lsa: YouTube tavsiyasiga yaqin, sifat tushmaydigan bitrate (kbit/s)."""
    base = {480: 1500, 720: 3200, 1080: 5500}.get(int(res), 3200 if res < 1000 else 5500)
    if fps > 30:
        base = int(base * 1.4)
    return base


class Slots:
    """O'lchami o'zgaradigan semafor (GPU sessiyalar uchun)."""

    def __init__(self, limit: int):
        self.limit = max(1, int(limit))
        self.active = 0
        self.cv = threading.Condition()

    def acquire(self, timeout: float | None = None) -> bool:
        end = None if timeout is None else time.time() + timeout
        with self.cv:
            while self.active >= self.limit:
                left = None if end is None else end - time.time()
                if left is not None and left <= 0:
                    return False
                self.cv.wait(left)
            self.active += 1
            return True

    def release(self):
        with self.cv:
            self.active = max(0, self.active - 1)
            self.cv.notify()

    def set_limit(self, n: int):
        with self.cv:
            self.limit = max(1, int(n))
            self.cv.notify_all()


class HwEnc:
    MC_TIMEOUT = 25      # telefon kodlovchisi sinovi uchun bir urinish vaqti (osilib qolsa shuncha kutiladi, so'ng to'xtatiladi)

    def __init__(self):
        self.cfg = None
        self.lock = threading.RLock()
        self._listed: set | None = None
        self._probe: dict = {}            # (nom, tur) -> {ok, tier, msg, ms}
        self._probed = False
        self._slots: dict = {}
        self._limit: dict = {}            # o'lchangan sessiyalar soni
        self._fails: dict = {}            # nom -> [vaqtlar]
        self._off_until: dict = {}        # nom -> vaqt (shundan keyin yana sinaladi)
        self.version = ""
        self.events: list = []
        self.used: dict = {}              # nom -> nechta kodlash muvaffaqiyatli bajarilgan
        self.fallbacks = 0
        self._dev: dict | None = None     # Android qurilma ma'lumoti (getprop)

    # ------------------------------------------------------------------ sozlama
    def bind(self, cfg):
        self.cfg = cfg

    def _get(self, key: str, default: str = "") -> str:
        try:
            if self.cfg is not None:
                v = self.cfg.get(key)
                return v if v not in (None, "") else default
        except Exception:  # noqa: BLE001
            pass
        return os.environ.get(key) or default

    def mode(self) -> str:
        v = self._get("ENCODER", "auto").strip().lower()
        v = ALIASES.get(v, v)
        return v if v in MODES else "auto"

    def _event(self, text: str):
        self.events.append((time.time(), text))
        del self.events[:-40]
        log.info("Kodlash: %s", text)

    # ------------------------------------------------------------------ telefon (Android/Termux)
    def device(self) -> dict:
        """Android qurilma ma'lumoti: model, chip (SoC), Android versiyasi (getprop). Boshqa tizimlarda bo'sh lug'at."""
        if self._dev is not None:
            return self._dev
        d: dict = {}
        if is_android():
            props = {"soc": "ro.soc.model", "manu": "ro.soc.manufacturer", "platform": "ro.board.platform",
                     "hw": "ro.hardware", "model": "ro.product.model", "sdk": "ro.build.version.sdk",
                     "release": "ro.build.version.release", "egl": "ro.hardware.egl"}
            for key, prop in props.items():
                try:
                    rc, out, _ = run(["getprop", prop], timeout=5)
                except Exception:  # noqa: BLE001
                    rc, out = 1, ""
                if rc == 0 and (out or "").strip():
                    d[key] = out.strip()
            d["android"] = "1"
        self._dev = d
        return d

    def android_sdk(self) -> int:
        try:
            return int(self.device().get("sdk", "0") or 0)
        except ValueError:
            return 0

    def _mc_names(self) -> list:
        """Chip ishlab chiqaruvchisiga qarab APPARAT H.264 kodlovchi nomlari. Nom bilan ochiladi: Android tasodifan dasturiy
        'c2.android.avc.encoder' ni tanlab qo'ymasin. Noma'lum chip bo'lsa — bo'sh (Android o'zi tanlaydi)."""
        d = self.device()
        txt = " ".join(str(d.get(k, "")) for k in ("soc", "manu", "platform", "hw")).lower()
        if "mediatek" in txt or "mtk" in txt or re.search(r"\bmt\d{3,4}", txt):
            return ["c2.mtk.avc.encoder", "OMX.MTK.VIDEO.ENCODER.AVC"]
        if "qualcomm" in txt or "qcom" in txt or re.search(r"\b(sm|sdm|msm)\d{3,4}|kona|lahaina|taro|kalama|lito|bengal", txt):
            return ["c2.qti.avc.encoder", "OMX.qcom.video.encoder.avc"]
        if "exynos" in txt or "samsung" in txt:
            return ["c2.exynos.h264.encoder", "OMX.Exynos.AVC.Encoder"]
        return []

    def peek(self) -> str:
        """Hozirgi kodlovchi nomi — SINAB KO'RMASDAN (sinov hali o'tmagan bo'lsa 'cpu'). UI/hisob-kitob uchun, kutdirmaydi."""
        if not self._probed:
            return "cpu"
        try:
            return self.pick()
        except Exception:  # noqa: BLE001
            return "cpu"

    # ------------------------------------------------------------------ ffmpeg imkoniyatlari
    def listed(self) -> set:
        with self.lock:
            if self._listed is None:
                rc, out, err = run(["ffmpeg", "-hide_banner", "-encoders"], timeout=30)
                names = set()
                for ln in (out or "").splitlines():
                    parts = ln.split()
                    if len(parts) >= 2 and parts[0].startswith("V"):
                        names.add(parts[1])
                self._listed = names
                rc2, out2, _ = run(["ffmpeg", "-hide_banner", "-version"], timeout=15)
                self.version = (out2.splitlines()[0] if out2 else "")[:80]
            return self._listed

    def has_x264(self) -> bool:
        return "libx264" in self.listed()

    # ------------------------------------------------------------------ parametrlar to'plami
    @staticmethod
    def _gop(fps: int) -> str:
        return str(max(1, int(round(fps * 2))))

    def _cpu_args(self, kind: str, fps: int, kbps: int, crf: int, preset: str | None, still: bool) -> list:
        gop = self._gop(fps)
        if not self.has_x264():
            return ["-c:v", "mpeg4", "-q:v", "5", "-pix_fmt", "yuv420p", "-g", gop]
        a = ["-c:v", "libx264", "-preset", preset or ("superfast" if kind == "stream" else "veryfast")]
        if still:                                  # statik tasvir (kuting lavhasi, slayd) uchun
            a += ["-tune", "stillimage"]
        a += ["-crf", str(crf)]
        if kind == "stream" and kbps:
            a += ["-maxrate", f"{kbps}k", "-bufsize", f"{2 * kbps}k"]
        if kind == "stream":
            a += ["-x264-params", "ref=1:bframes=0:rc-lookahead=0:weightp=0:mbtree=0:scenecut=0:subme=1"]
        return a + ["-pix_fmt", "yuv420p", "-g", gop]

    def _tiers(self, name: str, kind: str, fps: int, kbps: int, crf: int, res: int = 720) -> list:
        """Eng yaxshisidan oddiygacha parametr variantlari. Sinov birinchi ishlaganini tanlaydi
        (eski ffmpeg/drayverlarda ba'zi parametrlar bo'lmasligi mumkin)."""
        gop = self._gop(fps)
        stream = kind == "stream"
        k = int(kbps or auto_kbps(res, fps))
        mr, bs = int(k * 1.25), int(k * 2)
        vk = int(kbps or (9000 if res >= 1000 else 5000))          # video (YouTube'ga yuklanadigan) uchun
        vmr, vbs = int(vk * 1.6), int(vk * 3)
        cq = str(max(12, min(40, int(crf) - 2)))                   # NVENC CQ: x264 CRF dan ozroq (sifat saqlanadi)
        if name == "nvenc":
            pix = ["-pix_fmt", "yuv420p", "-g", gop]
            if stream:
                rc = ["-rc", "vbr", "-cq", cq, "-b:v", f"{k}k", "-maxrate", f"{mr}k", "-bufsize", f"{bs}k", "-bf", "0"]
                return [["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-profile:v", "high"] + rc
                        + ["-spatial-aq", "1", "-forced-idr", "1"] + pix,
                        ["-c:v", "h264_nvenc", "-preset", "p4", "-profile:v", "high"] + rc + pix,
                        ["-c:v", "h264_nvenc", "-preset", "fast", "-b:v", f"{k}k", "-maxrate", f"{mr}k",
                         "-bufsize", f"{bs}k"] + pix,
                        ["-c:v", "h264_nvenc", "-b:v", f"{k}k"] + pix]
            rc = ["-rc", "vbr", "-cq", cq, "-b:v", "0", "-maxrate", f"{vmr}k", "-bufsize", f"{vbs}k"]
            return [["-c:v", "h264_nvenc", "-preset", "p6", "-tune", "hq", "-profile:v", "high"] + rc
                    + ["-bf", "2", "-b_ref_mode", "middle", "-spatial-aq", "1", "-forced-idr", "1"] + pix,
                    ["-c:v", "h264_nvenc", "-preset", "p5", "-profile:v", "high"] + rc + ["-bf", "2"] + pix,
                    ["-c:v", "h264_nvenc", "-preset", "slow", "-b:v", f"{vk}k", "-maxrate", f"{vmr}k",
                     "-bufsize", f"{vbs}k"] + pix,
                    ["-c:v", "h264_nvenc", "-b:v", f"{vk}k"] + pix]
        if name == "qsv":
            pix = ["-pix_fmt", "nv12", "-g", gop]
            gq = str(max(12, min(40, int(crf))))
            if stream:
                rc = ["-b:v", f"{k}k", "-maxrate", f"{mr}k", "-bufsize", f"{bs}k", "-bf", "0"]
                return [["-c:v", "h264_qsv", "-preset", "medium", "-profile:v", "high"] + rc + ["-forced_idr", "1"] + pix,
                        ["-c:v", "h264_qsv", "-profile:v", "high"] + rc + pix,
                        ["-c:v", "h264_qsv", "-b:v", f"{k}k"] + pix]
            return [["-c:v", "h264_qsv", "-preset", "slow", "-profile:v", "high", "-global_quality", gq] + pix,
                    ["-c:v", "h264_qsv", "-preset", "medium", "-b:v", f"{vk}k", "-maxrate", f"{vmr}k",
                     "-bufsize", f"{vbs}k"] + pix,
                    ["-c:v", "h264_qsv", "-b:v", f"{vk}k"] + pix]
        if name == "amf":
            pix = ["-pix_fmt", "yuv420p", "-g", gop]
            b, m, s = (k, mr, bs) if stream else (vk, vmr, vbs)
            return [["-c:v", "h264_amf", "-usage", "transcoding", "-quality", "quality", "-rc", "vbr_peak",
                     "-b:v", f"{b}k", "-maxrate", f"{m}k", "-bufsize", f"{s}k", "-profile:v", "high"]
                    + (["-bf", "0"] if stream else []) + pix,
                    ["-c:v", "h264_amf", "-quality", "quality", "-b:v", f"{b}k", "-maxrate", f"{m}k"] + pix,
                    ["-c:v", "h264_amf", "-b:v", f"{b}k"] + pix]
        if name == "videotoolbox":
            pix = ["-pix_fmt", "yuv420p", "-g", gop]
            b = k if stream else vk
            return [["-c:v", "h264_videotoolbox", "-profile:v", "high", "-b:v", f"{b}k", "-realtime", "0"] + pix,
                    ["-c:v", "h264_videotoolbox", "-b:v", f"{b}k"] + pix]
        if name == "mediacodec":
            # Telefon (Android MediaCodec, NDK): CQ rejimini ko'p chiplar qo'llamaydi — bitrate rejimi (stream: CBR, video: VBR).
            # B-kadrsiz, kalit kadr har 2 s, nv12. Eng yaxshisidan oddiygacha: chip nomi + High profil -> nomsiz -> eng oddiy.
            pix = ["-pix_fmt", "nv12", "-g", gop]
            b = int(kbps or (k if stream else vk))
            rate = ["-b:v", f"{b}k"]
            m0, m1 = ("cbr", "vbr") if stream else ("vbr", "cbr")
            base = ["-c:v", "h264_mediacodec"]
            hi = ["-profile:v", "high"]
            tiers = []
            for nm in self._mc_names():
                nm_opt = ["-codec_name", nm]
                tiers.append(base + nm_opt + ["-ndk_codec", "1", "-bitrate_mode", m0] + hi + rate + pix)
                tiers.append(base + nm_opt + ["-ndk_codec", "1", "-bitrate_mode", m0] + rate + pix)
            tiers += [base + ["-ndk_codec", "1", "-bitrate_mode", m0] + hi + rate + pix,
                      base + ["-ndk_codec", "1", "-bitrate_mode", m0] + rate + pix,
                      base + ["-bitrate_mode", m1] + rate + pix,
                      base + rate + pix]
            return tiers
        return []

    # ------------------------------------------------------------------ sinov
    @staticmethod
    def _short_err(err: str) -> str:
        """ffmpeg xabaridan eng ma'noli qatorni ajratadi (foydalanuvchiga ko'rsatish uchun)."""
        lines = [ln.strip() for ln in (err or "").splitlines() if ln.strip()]
        lines = [ln for ln in lines if "Nothing was written" not in ln and not ln.startswith("Conversion failed")]
        for ln in lines:
            if HW_ERR.search(ln):
                return re.sub(r"^\[[^\]]*\]\s*", "", ln)[:140]
        return re.sub(r"^\[[^\]]*\]\s*", "", lines[-1])[:140] if lines else ""

    @staticmethod
    def _probe_cmd(args: list, frames: int = 12, realtime: bool = False, size: str = "1280x720", out=None) -> list:
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin"]
        if realtime:
            cmd += ["-re"]
        cmd += ["-f", "lavfi", "-i", f"testsrc2=s={size}:r=30", "-frames:v", str(frames)] + list(args)
        cmd += ["-f", "mp4", str(out)] if out else ["-f", "null", "-"]
        return cmd

    def _probe_size(self, name: str, kind: str) -> str:
        """Sinov kadri o'lchami. Telefon kodlovchilarida o'lcham 16 ga karrali bo'lmasa (1080 balandlik, 854 kenglik) muammo
        chiqishi mumkin (MediaTek: 16x16 tekislash) — shuning uchun HAQIQIY ish o'lchamida sinaladi. Boshqalarda 1280x720."""
        if name != "mediacodec" or self.cfg is None:
            return "1280x720"
        try:
            if kind == "stream":
                res = int(self._get("STREAM_RES", "720") or 720)
                res = 480 if res <= 480 else 1080 if res >= 1080 else 720
                w = {480: 854, 720: 1280, 1080: 1920}[res]
                if self._get("STREAM_FORMAT", "landscape").lower().startswith("short"):
                    return f"{res}x{w}"
                return f"{w}x{res}"
            bw, bh = self.cfg.base_size
            return f"{int(bw)}x{int(bh)}"
        except Exception:  # noqa: BLE001
            return "1280x720"

    def _verify_output(self, path, size: str, frames: int = 15) -> tuple:
        """Telefon kodlovchisi natijasini asl tasvir (testsrc2) bilan PSNR orqali solishtiradi: buzuq rang (yashil/pushti ekran),
        siljish yoki noto'g'ri o'lcham bo'lsa rad etadi. (ok, sabab). Tekshirib bo'lmasa — qabul qilinadi."""
        try:
            if not path.exists() or path.stat().st_size < 1000:
                return False, "chiqish fayli bo'sh"
            cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-f", "lavfi", "-i", f"testsrc2=s={size}:r=30", "-i", str(path),
                   "-frames:v", str(frames), "-lavfi", "[0:v][1:v]psnr", "-f", "null", "-"]
            rc, _, err = run(cmd, timeout=60)
            if rc != 0:
                if re.search(r"do not match|parameters", err or "", re.I):
                    return False, "chiqish o'lchami mos emas (tekislash)"
                return True, "tekshirib bo'lmadi"
            m = re.findall(r"average:([0-9.]+|inf)", err or "")
            if not m:
                return True, "PSNR yo'q"
            v = 99.0 if m[-1] == "inf" else float(m[-1])
            if v < 24.0:
                return False, f"chiqish buzuq (PSNR {v:.1f} dB): rang/o'lcham noto'g'ri"
            return True, f"PSNR {v:.1f} dB"
        except Exception as e:  # noqa: BLE001
            return True, f"tekshirilmadi: {e}"

    def _probe_one(self, name: str, kind: str) -> dict:
        """Kodlovchi `name` ni `kind` ('stream'|'video') parametrlari bilan sinaydi: birinchi ishlagan variant tanlanadi.
        Telefon (mediacodec): haqiqiy ish o'lchamida faylga kodlaydi va PSNR bilan tekshiradi; osilib qolsa darhol to'xtaydi."""
        res = {"ok": False, "tier": -1, "msg": "", "ms": 0}
        enc = NAMES.get(name)
        if name == "cpu":
            res.update(ok=True, tier=0, msg="libx264" if self.has_x264() else "mpeg4")
            return res
        if enc not in self.listed():
            res["msg"] = "ffmpeg da yo'q (" + enc + ")"
            return res
        t0 = time.time()
        last = ""
        mc = name == "mediacodec"
        size = self._probe_size(name, kind)
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory(prefix="aitube_probe_") as td:
            for i, args in enumerate(self._tiers(name, kind, 30, 3000, 20, 720)):
                out = Path(td) / f"p{i}.mp4" if mc else None
                rc, _, err = run(self._probe_cmd(args, frames=(20 if mc else 12), size=size, out=out),
                                 timeout=(self.MC_TIMEOUT if mc else 45))
                if rc == 124 and mc:
                    last = "javob bermadi (osilib qoldi)"
                    break                                   # osilish: qolgan variantlarni urinish bilan vaqt yo'qotilmaydi
                if rc == 0 and mc:
                    good, why = self._verify_output(out, size)
                    if not good:
                        last = why
                        continue
                if rc == 0:
                    res.update(ok=True, tier=i, msg="ishlayapti", ms=int((time.time() - t0) * 1000))
                    return res
                last = self._short_err(err) or f"kod {rc}"
        res.update(msg=last or "ishga tushmadi", ms=int((time.time() - t0) * 1000))
        return res

    def _measure_sessions(self, name: str, kind: str = "stream", upto: int = 8) -> int:
        """Bir vaqtda nechta kodlash sessiyasi ochilishini o'lchaydi (GeForce drayver chegarasi: 3..8; telefon: 2..6)."""
        tier = self._probe.get((name, kind), {}).get("tier", -1)
        if tier < 0:
            return DEFAULT_SESSIONS.get(name, 2)
        if name == "mediacodec":
            upto = min(upto, 6)
        size = self._probe_size(name, kind)
        args = self._tiers(name, kind, 30, 3000, 20, 720)[tier]
        import subprocess
        procs = []
        try:
            for _ in range(upto):
                procs.append(subprocess.Popen(self._probe_cmd(args, frames=40, realtime=True, size=size),
                                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL))
            ok = 0
            for p in procs:
                try:
                    if p.wait(timeout=60) == 0:
                        ok += 1
                except Exception:  # noqa: BLE001
                    p.kill()
            return max(1, ok)
        except Exception as e:  # noqa: BLE001
            log.warning("Sessiyalarni o'lchab bo'lmadi (%s): %s", name, e)
            return DEFAULT_SESSIONS.get(name, 2)
        finally:
            for p in procs:
                if p.poll() is None:
                    try:
                        p.kill()
                    except OSError:
                        pass

    def _probe_encoder(self, nm: str) -> bool:
        """Bitta kodlovchini to'liq sinaydi (stream + video + sessiyalar). Natija _probe da saqlanadi."""
        with self.lock:
            if NAMES[nm] not in self.listed():
                self._probe[(nm, "stream")] = {"ok": False, "tier": -1, "msg": "ffmpeg da yo'q", "ms": 0}
                return False
            r = self._probe_one(nm, "stream")
            self._probe[(nm, "stream")] = r
            if r["ok"]:
                self._probe[(nm, "video")] = self._probe_one(nm, "video")
                if int(self._get("ENC_SESSIONS", "0") or 0) <= 0 and nm not in self._limit:
                    self._limit[nm] = self._measure_sessions(nm)
                self._event(f"{LABEL[nm]} ishlayapti (variant {r['tier']}, sessiyalar: {self.sessions(nm)})")
            else:
                self._event(f"{LABEL[nm]} ishlamadi: {r['msg']}")
            return bool(r["ok"])

    def detect(self, force: bool = False, everything: bool = False) -> dict:
        """Kodlovchilarni sinaydi (bir marta; natija eslab qolinadi). everything=True: hammasini (panel/CLI uchun)."""
        with self.lock:
            if self._probed and not force and not everything:
                return self._probe
            if force:
                self._probe.clear()
                self._off_until.clear()
                self._fails.clear()
                self._limit.clear()
                self._slots.clear()
                self._listed = None
            mode = self.mode()
            names: list
            if mode == "cpu":
                names = []
            elif mode == "auto":
                names = list(ORDER)
            else:
                names = [mode]
            self.listed()
            found = None
            for nm in names:
                if (nm, "stream") in self._probe and not force:
                    if self._probe[(nm, "stream")]["ok"] and found is None:
                        found = nm
                    continue
                if found is not None and not everything:
                    break
                if self._probe_encoder(nm) and found is None:
                    found = nm
            self._probed = True
            return self._probe

    # ------------------------------------------------------------------ tanlash
    def _usable(self, name: str) -> bool:
        if self._off_until.get(name, 0) > time.time():
            return False
        r = self._probe.get((name, "stream"))
        if r is None:                       # hali sinalmagan (masalan, ENCODER keyin o'zgargan): hozir sinaymiz
            self._probe_encoder(name)
            r = self._probe.get((name, "stream"))
        return bool(r and r["ok"])

    def pick(self, force_cpu: bool = False) -> str:
        """Hozir ishlatiladigan kodlovchi nomi: 'nvenc'|'qsv'|'amf'|'videotoolbox'|'cpu'."""
        if force_cpu or self.mode() == "cpu":
            return "cpu"
        self.detect()
        mode = self.mode()
        order = ORDER if mode == "auto" else (mode,)
        for nm in order:
            if self._usable(nm):
                return nm
        return "cpu"

    def name_of(self, args) -> str:
        s = " ".join(args) if not isinstance(args, str) else args
        for nm, enc in NAMES.items():
            if nm != "cpu" and enc in s:
                return nm
        return "cpu"

    def is_hw(self, args) -> bool:
        return self.name_of(args) != "cpu"

    def venc(self, kind: str = "stream", fps: int = 30, kbps: int = 0, crf: int = 20, preset: str | None = None,
             res: int = 720, still: bool = False, force_cpu: bool = False, name: str | None = None) -> list:
        """Kodlovchi argumentlari (kodek + sifat + piksel formati + kalit kadr oralig'i). `-r` ni chaqiruvchi qo'shadi."""
        nm = name or self.pick(force_cpu=force_cpu)
        if nm == "cpu" or force_cpu:
            return self._cpu_args(kind, fps, int(kbps or 0), int(crf), preset, still)
        tiers = self._tiers(nm, kind, fps, kbps, int(crf), res)
        key = (nm, kind)
        r = self._probe.get(key)
        if r is None:
            with self.lock:
                r = self._probe.get(key) or self._probe.setdefault(key, self._probe_one(nm, kind))
        if not r["ok"] or not (0 <= r["tier"] < len(tiers)):
            return self._cpu_args(kind, fps, int(kbps or 0), int(crf), preset, still)
        return tiers[r["tier"]]

    def label(self, name: str | None = None) -> str:
        nm = name or self.pick()
        if nm == "cpu" and not self.has_x264():
            return LABEL["mpeg4"]
        return LABEL.get(nm, nm)

    # ------------------------------------------------------------------ sessiyalar
    def sessions(self, name: str) -> int:
        try:
            v = int(self._get("ENC_SESSIONS", "0") or 0)
        except ValueError:
            v = 0
        if v > 0:
            return min(32, v)
        return self._limit.get(name) or DEFAULT_SESSIONS.get(name, 2)

    def _slot(self, name: str) -> Slots:
        with self.lock:
            s = self._slots.get(name)
            if s is None:
                s = self._slots[name] = Slots(self.sessions(name))
            return s

    @contextmanager
    def session(self, enc, cancel=None):
        """GPU kodlash sessiyasi uchun joy oladi (CPU uchun hech narsa kutilmaydi). `enc`: nom yoki argumentlar."""
        name = enc if isinstance(enc, str) else self.name_of(enc)
        if name == "cpu" or not name:
            yield
            return
        slot = self._slot(name)
        while not slot.acquire(timeout=0.5):
            if cancel and cancel():
                raise RuntimeError("bekor qilindi")
        try:
            yield
        finally:
            slot.release()

    # ------------------------------------------------------------------ natijani qayd etish
    def report(self, enc, ok: bool, err: str = "") -> str:
        """Kodlash natijasi. GPU xato bersa: hisoblanadi; 2 marta ketma-ket bo'lsa 10 daqiqaga CPU ga o'tiladi.
        Qaytaradi: 'ok' | 'hw_error' | 'other'."""
        name = enc if isinstance(enc, str) else self.name_of(enc)
        if name == "cpu":
            return "ok" if ok else "other"
        if ok:
            self._fails.pop(name, None)
            self.used[name] = self.used.get(name, 0) + 1
            return "ok"
        if not HW_ERR.search(err or ""):
            return "other"
        now = time.time()
        with self.lock:
            lst = [t for t in self._fails.get(name, []) if now - t < 300] + [now]
            self._fails[name] = lst
            if SESSION_ERR.search(err or "") and self.sessions(name) > 1 and int(self._get("ENC_SESSIONS", "0") or 0) <= 0:
                self._limit[name] = max(1, self.sessions(name) - 1)
                self._slot(name).set_limit(self._limit[name])
                self._event(f"{LABEL[name]}: sessiya chegarasi {self._limit[name]} ga tushirildi")
            if len(lst) >= 2:
                self._off_until[name] = now + 600
                self._fails.pop(name, None)
                self.fallbacks += 1
                self._event(f"{LABEL[name]} ketma-ket xato berdi — 10 daqiqaga CPU ishlatiladi ({(err or '').strip()[-120:]})")
        return "hw_error"

    # ------------------------------------------------------------------ holat
    def status(self) -> dict:
        self.detect()
        now = time.time()
        return {"mode": self.mode(), "active": self.pick(), "label": self.label(), "ffmpeg": self.version,
                "x264": self.has_x264(), "device": dict(self.device()),
                "probe": {f"{n}/{k}": dict(v) for (n, k), v in sorted(self._probe.items())},
                "sessions": {n: self.sessions(n) for n in ORDER if (n, "stream") in self._probe and self._probe[(n, "stream")]["ok"]},
                "off": {n: int(t - now) for n, t in self._off_until.items() if t > now},
                "used": dict(self.used), "fallbacks": self.fallbacks,
                "events": [(int(now - t), s) for t, s in self.events[-6:]]}

    def describe(self, html: bool = True) -> str:
        """Qisqa matn: panel va /gpu uchun."""
        st = self.status()
        b = (lambda s: f"<b>{s}</b>") if html else (lambda s: s)
        lines = [f"🎞 Kodlash: {b(st['label'])}" + (" · GPU" if st["active"] != "cpu" else " · CPU")
                 + f" · rejim: {b(st['mode'])}"]
        for nm in ORDER:
            r = st["probe"].get(f"{nm}/stream")
            if r is None:
                continue
            mark = "✅" if r["ok"] else "❌"
            extra = f" · sessiyalar {st['sessions'].get(nm, '-')}" if r["ok"] else f" · {r['msg']}"
            off = f" · ⏸ {st['off'][nm]}s CPU" if nm in st["off"] else ""
            lines.append(f"{mark} {LABEL[nm]}{extra}{off}")
        lines.append(f"{'✅' if st['x264'] else '⚠️'} CPU libx264" + ("" if st["x264"] else " yo'q (mpeg4)"))
        dev = st.get("device") or {}
        if dev:
            chip = dev.get("soc") or dev.get("platform") or dev.get("hw") or "?"
            lines.append(f"📱 Qurilma: {dev.get('model', '?')} · chip {chip} · Android {dev.get('release', '?')}")
            mc = st["probe"].get("mediacodec/stream")
            if mc is not None and not mc["ok"] and self.android_sdk() >= 35:
                lines.append("ℹ️ Android 15+ da Termux (JVM'siz) NDK MediaCodec ishlamasligi mumkin — shuning uchun CPU ishlatiladi.")
            elif mc is None and "h264_mediacodec" not in self.listed():
                lines.append("ℹ️ Bu ffmpeg da h264_mediacodec yo'q: Termux'da `pkg upgrade ffmpeg` qiling.")
        if st["used"]:
            lines.append("📈 Kodlashlar: " + ", ".join(f"{LABEL.get(k, k)}×{v}" for k, v in st["used"].items()))
        return "\n".join(lines)


HW = HwEnc()
