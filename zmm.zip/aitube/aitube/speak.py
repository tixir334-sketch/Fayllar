"""Talaffuz filtri: ekranda yozilgan matnni diktor aniq o'qiy oladigan shaklga o'giradi.

Misol: `.pdf` -> "pi di ef", `main.py` -> "main nuqta pay", `API'lar` -> "ey pi ay lar",
`getUserName` -> "get user name", `5GB` -> "5 gigabayt", `3.11` -> "3 nuqta 11".

Ekrandagi (subtitr) matn o'zgarmaydi: har bir ko'rinadigan so'z uchun alohida "aytilishi" qaytariladi,
shuning uchun subtitr va ovoz so'zma-so'z mos tushadi.
"""
from __future__ import annotations

import re

from .enwords import EN

# Epizod/foydalanuvchi lug'ati (LLM aniqlagan va /pron bilan qo'shilgan so'zlar): kichik harf -> aytilishi
ACTIVE: dict = {}

# O'zbek qo'shimchalari: "Pythonda", "CSVga", "shape'ni" kabi shakllarni tanish uchun
_CASES = ["", "ni", "ning", "ga", "ka", "qa", "da", "dan", "dagi", "i", "si", "imiz", "ingiz", "dek", "day",
          "cha", "li", "siz", "lik", "ligi", "chi", "dir", "mi", "ham", "ni", "ing", "im", "ini"]
SUFFIXES = set()
for _c in _CASES:
    SUFFIXES.add(_c)
    for _pl in ("lar", "lari"):
        SUFFIXES.add(_pl + _c)
SUFFIXES.discard("")
SUFFIXES.update({"ga", "da", "dan", "ni", "ning"})

# O'zbek qo'shimchasi bilan ham aytiladigan, lekin lug'atda yo'q ingliz so'zlar uchun yordamchi tanish
_JOIN_OK = re.compile(r"^[a-z]+$")


def set_pron(d: dict | None):
    """Qo'shimcha aytilish lug'atini o'rnatadi (kalit: kichik harfdagi so'z)."""
    global ACTIVE
    ACTIVE = {str(k).strip().lower(): str(v).strip() for k, v in (d or {}).items() if k and v}


def lookup_en(low: str):
    """So'zning ingliz aytilishi (o'zbekcha yozuvda) yoki None. Avval epizod/foydalanuvchi lug'ati."""
    return ACTIVE.get(low) or EN.get(low)


def _en_suffixed(core: str):
    """'Pythonda' -> 'paytonda', 'shape'ni' -> 'sheypni'. Topilmasa None."""
    low = core.lower()
    if "'" in low:
        base, _, suf = low.partition("'")
        if suf in SUFFIXES or suf.replace("'", "") in SUFFIXES:
            p = lookup_en(base)
            if p:
                return p + suf.replace("'", "")
    if not _JOIN_OK.match(low):
        return None
    for cut in range(len(low) - 1, 2, -1):
        suf = low[cut:]
        if suf in SUFFIXES:
            p = lookup_en(low[:cut])
            if p:
                return p + suf
    return None

_VOICELESS_END = ("p", "t", "k", "f", "s", "sh", "ch", "x")


def _plural(p: str) -> str:
    if p.endswith(("s", "z", "sh", "ch", "j")):
        return p + "iz"
    return p + ("s" if p.endswith(("p", "t", "k", "f")) else "z")


def _past(p: str) -> str:
    if p.endswith(("t", "d")):
        return p + "id"
    return p + ("t" if p.endswith(("p", "k", "f", "s", "sh", "ch")) else "d")


def _en_inflect(low: str):
    """Ingliz shakllari: files, copied, running, runner, quickly -> lug'atdagi asosdan quriladi."""
    if len(low) < 4 or not low.isalpha():
        return None
    look = lookup_en
    cands = []
    if low.endswith("ies"):
        cands.append((low[:-3] + "y", _plural))
    if low.endswith("es"):
        cands.append((low[:-2], _plural))
    if low.endswith("s") and not low.endswith("ss"):
        cands.append((low[:-1], _plural))
    if low.endswith("ied"):
        cands.append((low[:-3] + "y", _past))
    if low.endswith("ed"):
        cands += [(low[:-2], _past), (low[:-1], _past)]
        if len(low) > 5 and low[-3] == low[-4]:
            cands.append((low[:-3], _past))
    if low.endswith("ing"):
        b = low[:-3]
        cands += [(b, lambda p: p + "ing"), (b + "e", lambda p: p + "ing")]
        if len(b) > 2 and b[-1] == b[-2]:
            cands.append((b[:-1], lambda p: p + "ing"))
    if low.endswith("ers"):
        cands += [(low[:-3], lambda p: p + "erz"), (low[:-2], lambda p: p + "rz")]
    if low.endswith("er"):
        cands += [(low[:-2], lambda p: p + "er"), (low[:-1], lambda p: p + "r")]
        if len(low) > 4 and low[-3] == low[-4]:
            cands.append((low[:-3], lambda p: p + "er"))
    if low.endswith("ly"):
        cands.append((low[:-2], lambda p: p + "li"))
    for base, fn in cands:
        if len(base) >= 3:
            p = look(base)
            if p and " " not in p.strip() or (p and len(p.split()) <= 2):
                return fn(p)
    return None


# O'zbek (lotin) imlosida ingliz harflarining nomi
LETTERS = {
    "a": "ey", "b": "bi", "c": "si", "d": "di", "e": "i", "f": "ef", "g": "ji", "h": "eych", "i": "ay",
    "j": "jey", "k": "key", "l": "el", "m": "em", "n": "en", "o": "o", "p": "pi", "q": "kyu", "r": "ar",
    "s": "es", "t": "ti", "u": "yu", "v": "vi", "w": "dabilyu", "x": "eks", "y": "uay", "z": "zed",
}
DIGITS = {"0": "nol", "1": "bir", "2": "ikki", "3": "uch", "4": "to'rt", "5": "besh", "6": "olti",
          "7": "yetti", "8": "sakkiz", "9": "to'qqiz"}

# Fayl kengaytmalari va qisqartmalar: nom -> aytilishi
ACR = {
    "pdf": "pi di ef", "html": "eych ti em el", "css": "si es es", "sql": "es kyu el", "json": "jeyson",
    "api": "ey pi ay", "url": "yu ar el", "uri": "yu ar ay", "cpu": "si pi yu", "gpu": "ji pi yu",
    "usb": "yu es bi", "ssh": "es es eych", "http": "eych ti ti pi", "https": "eych ti ti pi es",
    "png": "pi en ji", "jpg": "jey pi ji", "jpeg": "jey pi i ji", "csv": "si es vi", "xml": "eks em el",
    "yaml": "yaml", "yml": "yaml", "svg": "es vi ji", "gif": "gif", "mp3": "em pi uch", "mp4": "em pi to'rt",
    "ssd": "es es di", "hdd": "eych di di", "vpn": "vi pi en", "dns": "di en es", "tcp": "ti si pi",
    "udp": "yu di pi", "ftp": "ef ti pi", "rgb": "ar ji bi", "ocr": "o si ar", "sdk": "es di key",
    "cli": "si el ay", "gui": "ji yu ay", "ide": "ay di i", "ssl": "es es el", "tls": "ti el es",
    "pc": "pi si", "db": "di bi", "wifi": "vay fay", "ram": "ram", "rom": "rom", "bios": "bayos",
    "py": "pay", "js": "jey es", "ts": "ti es", "jsx": "jey es eks", "tsx": "ti es eks", "md": "em di",
    "sh": "es eych", "bat": "bat", "cpp": "si pi pi", "c": "si", "h": "eych", "hpp": "eych pi pi",
    "java": "java", "go": "go", "rs": "ar es", "rb": "ar bi", "php": "pi eych pi", "kt": "key ti",
    "toml": "toml", "ini": "ay en ay", "env": "env", "cfg": "si ef ji", "conf": "konf", "zip": "zip",
    "rar": "rar", "exe": "i eks i", "apk": "ey pi key", "iso": "ay es o", "txt": "ti eks ti",
    "log": "log", "doc": "dok", "docx": "dok eks", "xls": "eks el es", "xlsx": "eks el es eks",
    "ppt": "pi pi ti", "pptx": "pi pi ti eks", "wav": "vev", "ogg": "og", "mov": "mov", "mkv": "em key vi",
    "avi": "ey vi ay", "webp": "veb pi", "ico": "ay si o", "ttf": "ti ti ef", "dll": "di el el",
    "lock": "lok", "db3": "di bi uch", "sqlite": "es kyu el layt", "ipynb": "ay pi en bi",
    "ui": "yu ay", "ux": "yu eks", "ai": "ey ay", "ip": "ay pi", "os": "o es", "id": "ay di",
    "ml": "em el", "ar": "ey ar", "vr": "vi ar", "tv": "ti vi", "ok": "o key", "faq": "ef ey kyu",
    "df": "di ef", "np": "en pi", "pd": "pi di", "plt": "pi el ti", "sns": "es en es", "sys": "sis",
    "tf": "ti ef", "nn": "en en", "pk": "pi key", "ax": "eks", "fig": "fig",
    "ci": "si ay", "cd": "si di", "io": "ay o", "cv": "si vi", "gps": "ji pi es", "lcd": "el si di",
    "led": "led", "usd": "yu es di", "hr": "eych ar", "pr": "pi ar", "qa": "kyu ey", "seo": "es i o",
    "crud": "krud", "rest": "rest", "jwt": "jey dabilyu ti", "oop": "o o pi", "mvc": "em vi si",
    "gpt": "ji pi ti", "llm": "el el em", "nlp": "en el pi", "ssr": "es es ar", "spa": "es pi ey",
    "cdn": "si di en", "orm": "o ar em", "ssh2": "es es eych ikki", "tcp/ip": "ti si pi ay pi",
}
# Kichik harfda yozilganda ham qisqartma deb qabul qilinadiganlar (o'zbekcha so'z bilan to'qnashmaydi)
SAFE_LOWER = {
    "pdf", "html", "css", "sql", "json", "api", "url", "uri", "cpu", "gpu", "usb", "ssh", "http", "https",
    "png", "jpg", "jpeg", "csv", "xml", "yaml", "yml", "svg", "gif", "mp3", "mp4", "ssd", "hdd", "vpn",
    "dns", "tcp", "udp", "ftp", "rgb", "ocr", "sdk", "cli", "gui", "ssl", "tls", "pc", "db", "wifi",
    "jsx", "tsx", "cpp", "ipynb", "jwt", "gpt", "llm", "nlp", "faq", "mvc", "cdn", "orm", "seo", "gps",
    "df", "np", "pd", "plt", "sns", "tf", "nn", "dbms", "ddos", "csrf", "xss", "dhcp", "smtp", "imap", "grpc",
}
# Fayl kengaytmasi sifatida (nuqtadan keyin) tan olinadiganlar
EXT_OK = {k for k in ACR if k not in {
    "ai", "ip", "os", "id", "ml", "ar", "vr", "tv", "ok", "faq", "ci", "cd", "io", "cv", "gps", "lcd", "led",
    "usd", "hr", "pr", "qa", "seo", "crud", "rest", "jwt", "oop", "mvc", "gpt", "llm", "nlp", "ssr", "spa",
    "cdn", "orm", "ssh2", "tcp/ip", "ui", "ux", "pc", "ide", "cli", "gui", "sdk", "api", "url", "uri",
    "ssl", "tls", "dns", "vpn", "tcp", "udp", "ftp", "ocr", "rgb", "cpu", "gpu", "usb", "ssd", "hdd",
    "ram", "rom", "bios", "wifi"}} | {"c", "h", "go", "py", "js", "ts", "md", "sh", "rb", "rs", "kt"}

SPECIAL = {
    "c++": "si plyus plyus", "c#": "si sharp", "f#": "ef sharp", ".net": "dot net", "asp.net": "ey es pi dot net",
    "wi-fi": "vay fay", "ci/cd": "si ay si di", "i/o": "ay o", "ai/ml": "ey ay em el", "tcp/ip": "ti si pi ay pi",
    "ml/ai": "em el ey ay", "a/b": "ey bi", "24/7": "yigirma to'rt yetti", "node.js": "node jey es",
    "vue.js": "vyu jey es", "next.js": "nekst jey es", "react.js": "riakt jey es", "express.js": "ekspress jey es",
    "three.js": "tri jey es", "nuxt.js": "nakst jey es", "d3.js": "di uch jey es", "chart.js": "chart jey es",
    "github": "git hab", "youtube": "yutub", "javascript": "java script", "typescript": "type script",
    "ios": "ay o es", "macos": "mak o es", "linkedin": "linkdin", "openai": "open ey ay",
    "chatgpt": "chat ji pi ti", "postgresql": "postgres es kyu el", "mysql": "may es kyu el",
    "nosql": "no es kyu el", "graphql": "graf kyu el", "sqlite": "es kyu el layt", "pytorch": "pay torch",
    "tensorflow": "tensor flou", "numpy": "nampay", "matplotlib": "metplotlib",
    "scikit-learn": "sayket lern", "vscode": "vi es kod", "nginx": "enjin eks", "kubernetes": "kubernetis",
    "oauth": "o avt", "iot": "ay o ti", "saas": "sas", "devops": "dev opsh", "ux/ui": "yu eks yu ay",
}
UNITS = {
    "gb": "gigabayt", "mb": "megabayt", "kb": "kilobayt", "tb": "terabayt", "hz": "gers", "khz": "kilogers",
    "mhz": "megagers", "ghz": "gigagers", "ms": "millisekund", "px": "piksel", "fps": "ef pi es",
    "kbps": "kilobit sekundiga", "mbps": "megabit sekundiga", "gbps": "gigabit sekundiga",
    "%": "foiz", "kg": "kilogramm", "km": "kilometr", "cm": "santimetr", "mm": "millimetr",
}
OPS = {
    "==": "teng", "===": "qat'iy teng", "!=": "teng emas", "!==": "qat'iy teng emas", ">=": "katta yoki teng",
    "<=": "kichik yoki teng", "&&": "va", "||": "yoki", "++": "plyus plyus", "--": "minus minus",
    "=": "teng", "+": "plyus", "%": "foiz", "<": "kichik", ">": "katta", "::": "", "~": "", "^": "",
    "/": "", "\\": "", "@": "et", "$": "dollar", "#": "", "*": "", "|": "", "_": "", "-": "", "—": "", "–": "",
    "...": "", "…": "", "→": "keyin", "->": "keyin", "=>": "keyin",
}
TLDS = {"com": "kom", "org": "org", "net": "net", "io": "ay o", "dev": "dev", "app": "app", "uz": "uz",
        "ru": "ru", "ai": "ey ay", "me": "mi", "co": "ko", "info": "info", "edu": "edu", "gov": "gov",
        "tv": "ti vi"}

_LEAD = re.compile(r"^[\"'«“‘(\[{<]+")
_TRAIL = re.compile(r"[\"'»”’)\]}>.,;:!?…—–-]+$")
_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")
_NUM_UNIT = re.compile(r"^(\d+(?:[.,]\d+)?)(%|[A-Za-z]{1,4})$")
_VERSION = re.compile(r"^\d+(?:\.\d+)+$")
_EXT_ONLY = re.compile(r"^\.([A-Za-z0-9]{1,6})$")
_FILE = re.compile(r"^([\w][\w\-]*(?:\.[\w\-]+)*?)\.([A-Za-z0-9]{1,6})$")
_DOMAIN = re.compile(r"^((?:[\w\-]+\.)+)(com|org|net|io|dev|app|uz|ru|ai|me|co|info|edu|gov|tv)$", re.I)
_ACRO_SUFFIX = re.compile(r"^([A-Za-z0-9]{2,8})['’ʼ‘]([A-Za-z]{1,8})$")
_VOWELS = set("aeiouAEIOU")


def spell(s: str) -> str:
    out = []
    for ch in s:
        low = ch.lower()
        if low in LETTERS:
            out.append(LETTERS[low])
        elif ch in DIGITS:
            out.append(DIGITS[ch])
        elif ch.strip():
            out.append(ch)
    return " ".join(out)


def _acronym(core: str, force: bool = False) -> str | None:
    """Qisqartma bo'lsa aytilishini qaytaradi, aks holda None."""
    low = core.lower()
    if low in ACR and (core.isupper() or force or low in SAFE_LOWER or any(c.isdigit() for c in core)):
        return ACR[low]
    if core.isupper() and core.isalpha() and 2 <= len(core) <= 3:
        return spell(core)
    if core.isupper() and core.isalpha() and len(core) == 4 and not (set(core) & _VOWELS):
        return spell(core)
    if re.fullmatch(r"[A-Z][A-Z0-9]{1,4}", core) and any(c.isdigit() for c in core) and any(c.isalpha() for c in core):
        return spell(core)
    return None


def _identifier(core: str) -> str:
    """snake_case / camelCase / PascalCase ni so'zlarga ajratadi, qisqartmalarni harflab o'qiydi."""
    low = core.lower()
    if low in SPECIAL:
        return SPECIAL[low]
    if not re.fullmatch(r"[A-Za-z0-9_]+", core):
        return core
    parts = []
    for chunk in core.split("_"):
        if not chunk:
            continue
        if re.search(r"[a-z]", chunk) and re.search(r"[A-Z]", chunk[1:]):
            parts.extend(p for p in _CAMEL.split(chunk) if p)
        else:
            parts.append(chunk)
    out = []
    for p in parts:
        acr = _acronym(p) if len(parts) > 1 or p.isupper() else None
        if p.lower() in SPECIAL:
            out.append(SPECIAL[p.lower()])
        elif acr is not None:
            out.append(acr)
        elif p.lower() in SAFE_LOWER:
            out.append(ACR[p.lower()])
        elif lookup_en(p.lower()):
            out.append(lookup_en(p.lower()))
        else:
            out.append(p.lower() if len(parts) > 1 else p)
    return " ".join(out)


def _ext_spoken(ext: str) -> str:
    low = ext.lower()
    if low in ACR:
        return ACR[low]
    if ext.isalpha() and len(ext) <= 3:
        return spell(ext)
    return low


def _speak_core(core: str, prev_is_num: bool = False) -> str:
    if not core:
        return ""
    low = core.lower()
    if low in SPECIAL:
        return SPECIAL[low]
    if low in OPS:
        return OPS[low]
    if len(core) == 1 and core.isalpha() and core.isascii():     # 'w', x, f, i (kodda bir harfli nomlar)
        return LETTERS[low]
    if prev_is_num and low in UNITS:
        return UNITS[low]
    if low in ("gb", "mb", "kb", "tb", "kbps", "mbps", "gbps", "khz", "mhz", "ghz"):
        return UNITS[low]
    # 3.11, 192.168.0.1
    if _VERSION.match(core):
        return core.replace(".", " nuqta ")
    m = _NUM_UNIT.match(core)
    if m and (m.group(2) == "%" or m.group(2).lower() in UNITS):
        return f"{m.group(1)} {UNITS[m.group(2).lower()]}"
    m = re.fullmatch(r"(\d+)([A-Z])", core)         # 3D, 4K, 5G
    if m:
        return f"{m.group(1)} {LETTERS[m.group(2).lower()]}"
    m = _EXT_ONLY.match(core)                       # .pdf
    if m:
        ext = m.group(1)
        if ext.lower() in ACR:
            return ACR[ext.lower()]
        if ext.isalpha() and len(ext) <= 3:
            return spell(ext)
        return "nuqta " + _identifier(ext)
    if core.startswith(("/", "~/", "./", "../")) and re.search(r"[A-Za-z]", core):   # yo'l
        out = []
        for part in core.replace("~", "tilda/", 1).split("/"):
            if part:
                out.append(_speak_core(part))
        return " slesh ".join(o for o in out if o) if out else core
    m = _DOMAIN.match(core)                         # github.com
    if m:
        host = [h for h in m.group(1).split(".") if h]
        return " nuqta ".join([_identifier(h) for h in host] + [TLDS[m.group(2).lower()]])
    m = _FILE.match(core)                           # main.py, Node.js
    if m and m.group(2).lower() in EXT_OK:
        name, ext = m.group(1), m.group(2)
        if f"{name}.{ext}".lower() in SPECIAL:
            return SPECIAL[f"{name}.{ext}".lower()]
        product = name[:1].isupper() and ext.lower() in ("js", "ts", "py", "rs", "go")
        sep = " " if product else " nuqta "
        return _speak_core(name) + sep + _ext_spoken(ext)
    m = _ACRO_SUFFIX.match(core)                    # API'lar
    if m and (m.group(1).isupper() or m.group(1).lower() in SAFE_LOWER):
        acr = _acronym(m.group(1), force=True)
        if acr:
            return f"{acr} {m.group(2)}"
    m = re.fullmatch(r"([A-Za-z_][\w.]*)=(?!=)(.+)", core)                       # indent=2, encoding='utf-8'
    if m:
        return f"{_speak_core(m.group(1))} teng {_speak_core(m.group(2).strip(chr(39) + chr(34)))}"
    if re.fullmatch(r"[A-Za-z]+(?:-[A-Za-z]+)+", core) and any(lookup_en(x.lower()) for x in core.split("-")):
        return " ".join(_speak_core(x) for x in core.split("-"))                    # data-frame, open-source
    if core.endswith("()"):
        return _speak_core(core[:-2])
    if re.fullmatch(r"[A-Za-z]+", core) and lookup_en(low) and not (core.isupper() and len(core) <= 4
                                                                    and _acronym(core)):
        return lookup_en(low)
    if re.fullmatch(r"[A-Za-z']+", core):
        sx = _en_suffixed(core)
        if sx:
            return sx
        inf = _en_inflect(low) if "'" not in core else None
        if inf:
            return inf
        m = re.fullmatch(r"([A-Z]{2,6})([a-z]{1,8})", core)                         # CSVga, JSONdan
        if m and m.group(2) in SUFFIXES and _acronym(m.group(1), force=True):
            return f"{_acronym(m.group(1), force=True)} {m.group(2)}"
    acr = _acronym(core)
    if acr is not None:
        return acr
    if "." in core and re.fullmatch(r"[\w.]+", core) and not core.endswith("."):   # a.b.c (kod)
        return " nuqta ".join(_speak_core(p) for p in core.split(".") if p)
    if "/" in core and re.fullmatch(r"[\w/]+", core):                               # va/yoki, input/output
        return " ".join(_speak_core(p) for p in core.split("/") if p)
    if re.fullmatch(r"[A-Za-z0-9_]+", core):
        return _identifier(core)
    if re.search(r"[()\[\]{}=\"<>:,;/\\|]", core) and re.search(r"[A-Za-z]", core):   # open('data.csv', f(x)
        chunks = re.findall(r"[A-Za-z_][\w.]*|\d+(?:\.\d+)?", core)
        return " ".join(_speak_core(c) for c in chunks)
    return core


def speak_words(text: str) -> list:
    """Ko'rinadigan matnni so'zlarga bo'ladi: [{"w": ekrandagi so'z, "s": aytilishi}].
    "s" tinish belgilarini saqlaydi (pauza uchun); bo'sh bo'lishi mumkin (aytilmaydigan belgi)."""
    toks = str(text or "").split()
    out = []
    prev_num = False
    for tok in toks:
        raw = tok
        if raw.lower() in SPECIAL or raw.lower() in OPS:
            core, trail = raw, ""
        else:
            lead = _LEAD.match(raw)
            body = raw[lead.end():] if lead else raw
            tr = _TRAIL.search(body)
            trail = tr.group(0) if tr else ""
            core = body[: len(body) - len(trail)] if trail else body
            # "c++", "c#", ".net", "3.11" kabilar tinish belgisi bilan tugamasligi uchun
            if trail and (core + trail).lower() in SPECIAL:
                core, trail = core + trail, ""
            if core == "" and body in OPS:
                core, trail = body, ""
        spoken = _speak_core(core, prev_num)
        prev_num = bool(re.fullmatch(r"\d+(?:[.,]\d+)?", core))
        punct = ""
        if trail:
            if any(c in trail for c in "!?"):
                punct = "!" if "!" in trail else "?"
            elif "…" in trail or "..." in trail:
                punct = "..."
            elif "." in trail:
                punct = "."
            elif ";" in trail:
                punct = ";"
            elif ":" in trail:
                punct = ":"
            elif "," in trail or ")" in trail or any(c in trail for c in "—–"):
                punct = ","
        if not spoken.strip():
            # aytilmaydigan belgi (masalan "—"): oldingi so'zdan keyin pauza qo'shamiz
            if punct == "" and core in ("—", "–", "-", "|") and out and out[-1]["s"] and out[-1]["s"][-1] not in ".,;:!?":
                out[-1]["s"] += ","
            out.append({"w": raw, "s": ""})
            continue
        out.append({"w": raw, "s": spoken.strip() + punct})
    return out


def speak_text(text: str) -> str:
    """Butun matnning aytilishi (bitta qator)."""
    return " ".join(w["s"] for w in speak_words(text) if w["s"])
