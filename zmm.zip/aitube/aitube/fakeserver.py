"""Sinov uchun mahalliy soxta Telegram / YouTube / OAuth / LLM / TTS server (faqat selftest)."""
from __future__ import annotations

import json
import re
import subprocess
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .mockllm import mock_llm


def _mp3_bytes() -> bytes:
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "s.mp3"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        "sine=frequency=300:duration=1.2", "-c:a", "libmp3lame", str(out)], check=False)
        return out.read_bytes() if out.exists() else b""


class State:
    def __init__(self):
        self.tg_calls = []          # (method, params)
        self.updates = []           # navbatdagi update lar
        self.videos = {}            # id -> {"snippet":..,"status":..}
        self.uploads = {}           # session -> {"meta":.., "data": bytearray, "total": n}
        self.thumbs = []
        self.playlists = []
        self.lives = {}
        self.live_streams = {}
        self.playlist_items = []
        self.deleted_playlists = set()
        self.next_id = 1
        self.mp3 = _mp3_bytes()
        self.fail_upload_once = False
        self.img_requests = []      # AI rasm so'rovlari (query)
        self.file_bytes = b"{}"
        self.lock = threading.Lock()


def make_handler(st: State, base_url_holder: dict):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _body(self):
            n = int(self.headers.get("Content-Length", 0) or 0)
            return self.rfile.read(n) if n else b""

        def _send(self, code, obj=None, headers=None, raw=None, ctype="application/json"):
            body = raw if raw is not None else (json.dumps(obj).encode() if obj is not None else b"")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body:
                self.wfile.write(body)

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")

        def do_PUT(self):
            self._route("PUT")

        def _route(self, method):
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            path = u.path
            body = self._body()
            base = base_url_holder["url"]
            if path.startswith("/file/bot"):
                return self._send(200, raw=st.file_bytes, ctype="application/json")
            # ---------------- Telegram
            m = re.match(r"/bot([^/]+)/(\w+)", path)
            if m:
                return self._telegram(m.group(2), body)
            # ---------------- OAuth
            if path == "/device/code":
                return self._send(200, {"device_code": "DEV", "user_code": "ABCD-EFGH",
                                        "verification_url": "https://example.com/device", "expires_in": 600, "interval": 1})
            if path == "/token":
                form = parse_qs(body.decode())
                if form.get("grant_type", [""])[0] in ("authorization_code",) or form.get("grant_type", [""])[0].startswith("urn:"):
                    return self._send(200, {"access_token": "AT", "refresh_token": "RT", "expires_in": 3600})
                return self._send(200, {"access_token": "AT2", "expires_in": 3600})
            # ---------------- LLM (OpenAI mos)
            if path == "/v1beta/models" and method == "GET":
                return self._send(200, {"models": [
                    {"name": "models/gemini-9-flash", "supportedGenerationMethods": ["generateContent"]},
                    {"name": "models/gemini-9-flash-lite", "supportedGenerationMethods": ["generateContent"]},
                    {"name": "models/gemini-9-pro", "supportedGenerationMethods": ["generateContent"]},
                    {"name": "models/gemini-embedding-1", "supportedGenerationMethods": ["embedContent"]},
                    {"name": "models/gemini-9-flash-preview-tts", "supportedGenerationMethods": ["generateContent"]}]})
            if path.endswith("/models") and method == "GET":
                return self._send(200, {"data": [
                    {"id": "whisper-large-v3", "active": True}, {"id": "small-8b-chat", "active": True},
                    {"id": "big-120b-chat", "active": True}, {"id": "orpheus-tts", "active": True},
                    {"id": "free/x-70b:free", "pricing": {"prompt": "0", "completion": "0"}, "context_length": 1000},
                    {"id": "paid/y-70b", "pricing": {"prompt": "0.1", "completion": "0.1"}}]})
            if path.endswith("/chat/completions"):
                req = json.loads(body)
                if req.get("model") == "dead404":
                    return self._send(404, {"error": {"message": "model_not_found"}})
                if req.get("model") == "dead400":
                    return self._send(400, {"error": {"message": "The model has been decommissioned"}})
                msgs = req["messages"]
                text = mock_llm(msgs[0]["content"], msgs[1]["content"])
                return self._send(200, {"choices": [{"message": {"content": text}}]})
            # ---------------- AI rasm (Pollinations)
            if path.startswith("/prompt/"):
                import io
                import random as _r
                from PIL import Image, ImageDraw
                st.img_requests.append(dict(q, _path=path))
                w, h = int(q.get("width", 640)), int(q.get("height", 360))
                rnd = _r.Random(int(q.get("seed", 1)))
                im = Image.new("RGB", (w, h), (rnd.randrange(60), rnd.randrange(60), rnd.randrange(90)))
                dr = ImageDraw.Draw(im)
                for _ in range(30):
                    x, y, rr = rnd.randrange(w), rnd.randrange(h), rnd.randrange(20, 160)
                    dr.ellipse([x - rr, y - rr, x + rr, y + rr], fill=(rnd.randrange(255), rnd.randrange(255), rnd.randrange(255)))
                buf = io.BytesIO()
                im.save(buf, "PNG")
                return self._send(200, raw=buf.getvalue(), ctype="image/png")
            # ---------------- TTS
            if path.endswith("/translate_tts"):
                return self._send(200, raw=st.mp3, ctype="audio/mpeg")
            # ---------------- YouTube
            if path == "/upload/youtube/v3/videos" and method == "POST":
                if st.fail_upload_once:
                    st.fail_upload_once = False
                    return self._send(403, {"error": {"code": 403, "message": "quota",
                                                      "errors": [{"reason": "quotaExceeded"}]}})
                meta = json.loads(body)
                with st.lock:
                    sid = f"S{st.next_id}"
                    st.next_id += 1
                    st.uploads[sid] = {"meta": meta, "data": bytearray(), "total": int(self.headers["X-Upload-Content-Length"])}
                return self._send(200, {}, headers={"Location": f"{base}/upload-session/{sid}"})
            m = re.match(r"/upload-session/(\w+)", path)
            if m and method == "PUT":
                up = st.uploads[m.group(1)]
                cr = self.headers.get("Content-Range", "")
                if cr.startswith("bytes */"):
                    n = len(up["data"])
                    return self._send(308, headers={"Range": f"bytes=0-{n - 1}"} if n else {})
                mm = re.match(r"bytes (\d+)-(\d+)/(\d+)", cr)
                start = int(mm.group(1))
                assert start == len(up["data"]), f"noto'g'ri offset {start} != {len(up['data'])}"
                up["data"].extend(body)
                if len(up["data"]) >= up["total"]:
                    vid = f"VID{st.next_id}"
                    st.next_id += 1
                    st.videos[vid] = {"id": vid, "snippet": dict(up["meta"]["snippet"], categoryId="28"),
                                      "status": {"privacyStatus": "private",
                                                 "publicStatsViewable": up["meta"]["status"].get("publicStatsViewable", True),
                                                 **({"publishAt": up["meta"]["status"]["publishAt"]}
                                                    if up["meta"]["status"].get("publishAt") else {})},
                                      "size": len(up["data"]),
                                      "req_privacy": up["meta"]["status"]["privacyStatus"],
                                      "synthetic": up["meta"]["status"].get("containsSyntheticMedia")}
                    return self._send(200, {"id": vid, "status": {"privacyStatus": "private"}})
                return self._send(308, headers={"Range": f"bytes=0-{len(up['data']) - 1}"})
            if path == "/upload/youtube/v3/thumbnails/set":
                st.thumbs.append((q["videoId"], len(body)))
                return self._send(200, {"items": []})
            if path == "/youtube/v3/videos" and method == "GET":
                ids = q.get("id", "").split(",")
                if q.get("part") == "statistics":
                    return self._send(200, {"items": [{"id": i, "statistics": {"viewCount": "42", "likeCount": "5",
                                                                               "commentCount": "1"}} for i in ids if i in st.videos]})
                return self._send(200, {"items": [st.videos[i] for i in ids if i in st.videos]})
            if path == "/youtube/v3/videos" and method == "PUT":
                j = json.loads(body)
                v = st.videos[j["id"]]
                if "snippet" in j:
                    v["snippet"].update(j["snippet"])
                if "status" in j:
                    s2 = j["status"]
                    v["status"] = {k: x for k, x in v["status"].items() if k in ("privacyStatus",)}
                    v["status"]["privacyStatus"] = s2.get("privacyStatus", "private")
                    v["status"]["publicStatsViewable"] = s2.get("publicStatsViewable", True)
                    if s2.get("publishAt"):
                        v["status"]["publishAt"] = s2["publishAt"]
                    st.status_puts = getattr(st, "status_puts", 0) + 1
                return self._send(200, v)
            if path == "/youtube/v3/liveBroadcasts" and method == "POST":
                j = json.loads(body)
                bid = f"LB{len(st.lives) + 1}"
                st.lives[bid] = {"id": bid, "snippet": j.get("snippet", {}), "life": "created", "stream": None,
                                 "transitions": []}
                return self._send(200, {"id": bid, "status": {"lifeCycleStatus": "created"}})
            if path == "/youtube/v3/liveStreams" and method == "POST":
                sid = f"LS{len(st.live_streams) + 1}"
                st.live_streams[sid] = {"id": sid, "active": False}
                return self._send(200, {"id": sid, "cdn": {"ingestionInfo": {
                    "ingestionAddress": "rtmp://fake.invalid/live2", "streamName": "fakekey-" + sid}}})
            if path == "/youtube/v3/liveBroadcasts/bind" and method == "POST":
                st.lives[q["id"]]["stream"] = q.get("streamId")
                st.live_streams[q["streamId"]]["active"] = True
                return self._send(200, {"id": q["id"]})
            if path == "/youtube/v3/liveBroadcasts/transition" and method == "POST":
                b = st.lives[q["id"]]
                b["transitions"].append(q["broadcastStatus"])
                b["life"] = q["broadcastStatus"]
                return self._send(200, {"id": q["id"], "status": {"lifeCycleStatus": b["life"]}})
            if path == "/youtube/v3/liveBroadcasts" and method == "GET":
                b = st.lives.get(q.get("id", ""))
                return self._send(200, {"items": [{"id": b["id"], "status": {"lifeCycleStatus": b["life"]},
                                                   "contentDetails": {"boundStreamId": b["stream"]}}] if b else []})
            if path == "/youtube/v3/liveStreams" and method == "GET":
                return self._send(200, {"items": [{"id": q.get("id"), "status": {
                    "streamStatus": "active", "healthStatus": {"status": "good"}}}]})
            if path == "/youtube/v3/playlists" and method == "POST":
                st.playlists.append(json.loads(body))
                return self._send(200, {"id": f"PL{len(st.playlists)}"})
            nf = {"error": {"code": 404, "message": "Playlist not found.", "errors": [{"reason": "playlistNotFound"}]}}
            if path == "/youtube/v3/playlists" and method == "GET":
                pid = q.get("id", "")
                ok_ = pid.startswith("PL") and pid not in st.deleted_playlists and \
                    int(pid[2:] or 0) <= len(st.playlists)
                return self._send(200, {"items": [{"id": pid}] if ok_ else []})
            if path == "/youtube/v3/playlistItems" and method == "GET":
                pid = q.get("playlistId", "")
                if pid in st.deleted_playlists:
                    return self._send(404, nf)
                return self._send(200, {"items": [{"contentDetails": {"videoId": it["snippet"]["resourceId"]["videoId"]}}
                                                  for it in st.playlist_items if it["snippet"]["playlistId"] == pid]})
            if path == "/youtube/v3/playlistItems" and method == "POST":
                j = json.loads(body)
                if j["snippet"]["playlistId"] in st.deleted_playlists:
                    return self._send(404, nf)
                st.playlist_items.append(j)
                return self._send(200, {"id": "PI"})
            if path == "/youtube/v3/channels":
                return self._send(200, {"items": [{"id": "UC1", "snippet": {"title": "Test kanal"},
                                                   "statistics": {"subscriberCount": "7", "viewCount": "100", "videoCount": "2"}}]})
            if path == "/youtube/v3/commentThreads":
                return self._send(200, {"items": [{"id": "c1", "snippet": {"topLevelComment": {"snippet": {
                    "authorDisplayName": "Ali", "textDisplay": "Zo'r video!", "likeCount": 1}}}}]})
            self._send(404, {"error": {"message": f"yo'q: {method} {path}"}})

        def _telegram(self, method, body):
            ctype = self.headers.get("Content-Type", "")
            params = {}
            if "json" in ctype:
                params = json.loads(body or b"{}")
            elif "multipart" in ctype:
                params = {"_multipart_bytes": len(body)}
                for mm in re.finditer(rb'name="(\w+)"\r\n\r\n(.*?)\r\n--', body, re.S):
                    params[mm.group(1).decode()] = mm.group(2).decode("utf-8", "replace")
            with st.lock:
                st.tg_calls.append((method, params))
            if method == "getUpdates":
                with st.lock:
                    ups, st.updates = st.updates, []
                if not ups:
                    import time
                    time.sleep(0.3)
                return self._send(200, {"ok": True, "result": ups})
            if method == "getFile":
                return self._send(200, {"ok": True, "result": {"file_path": "docs/client.json"}})
            if method == "getMe":
                return self._send(200, {"ok": True, "result": {"username": "fake_bot"}})
            if method.startswith("send") or method == "editMessageText":
                return self._send(200, {"ok": True, "result": {"message_id": len(st.tg_calls)}})
            return self._send(200, {"ok": True, "result": True})

    return H


class FakeServer:
    def __init__(self):
        self.state = State()
        self.holder = {"url": ""}
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.state, self.holder))
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self.holder["url"] = self.url
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self.thread.start()
        return self

    def stop(self):
        self.httpd.shutdown()

    def tg_texts(self):
        return [p.get("text", p.get("caption", "")) for m, p in self.state.tg_calls
                if m.startswith("send") or m == "editMessageText"]
