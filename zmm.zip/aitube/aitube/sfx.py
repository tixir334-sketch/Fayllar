"""Video uchun shaffof effekt ovozlari: sahna o'tishlari (whoosh), band paydo bo'lishi (pop), kod yozilishi
(tiqillash), sxema impulslari (blip), yakuniy akkord. Faqat standart kutubxona (numpy kerak emas).
Hammasi past balandlikda: nutq ustidan eshitilmaydi, lekin videoni jonlantiradi."""
from __future__ import annotations

import math
import random
import wave
from array import array
from functools import lru_cache

SR = 44100
TAU = 2 * math.pi


def _env(i, n, a=0.02, r=0.6):
    """Tez ko'tarilib, silliq so'nadigan konvert (0..1)."""
    t = i / max(1, n - 1)
    if t < a:
        return t / a
    return (1 - (t - a) / (1 - a)) ** (1 + 2 * r)


@lru_cache(maxsize=64)
def whoosh(kind: int, dur: float = 0.55):
    """Filtrlangan shovqin: kind 0 yuqoriga, 1 pastga, 2 qisqa 'swish', 3 shisha."""
    n = int(SR * dur)
    rnd = random.Random(1000 + kind)
    out = array("f", bytes(4 * n))
    lp = 0.0
    lp2 = 0.0
    for i in range(n):
        t = i / n
        if kind == 0:
            fc = 300 + 5200 * t ** 1.6
            e = math.sin(math.pi * t) ** 1.5
        elif kind == 1:
            fc = 4800 - 4300 * t ** 0.8
            e = math.sin(math.pi * t) ** 1.5
        elif kind == 2:
            fc = 1500 + 3500 * math.sin(math.pi * t)
            e = math.sin(math.pi * t) ** 2.4
        else:
            fc = 2600 + 2400 * t
            e = math.sin(math.pi * t) ** 3
        a = 1 - math.exp(-TAU * fc / SR)
        x = rnd.uniform(-1, 1)
        lp += a * (x - lp)
        lp2 += a * (lp - lp2)
        v = lp2 * 3.2 * e
        if kind == 3:
            v += 0.35 * math.sin(TAU * (900 + 1500 * t) * i / SR) * e * 0.5
        out[i] = v
    return out


@lru_cache(maxsize=64)
def pop(freq: float, dur: float = 0.14):
    n = int(SR * dur)
    out = array("f", bytes(4 * n))
    for i in range(n):
        t = i / SR
        f = freq * (1 + 0.5 * math.exp(-t * 55))
        out[i] = math.sin(TAU * f * t) * math.exp(-t * 32) + 0.25 * math.sin(TAU * f * 2 * t) * math.exp(-t * 60)
    return out


@lru_cache(maxsize=32)
def boing(freq: float, dur: float = 0.30):
    """Ikonka 'sakrab' chiqishi: balandlik pastdan ko'tarilib, yumshoq so'nadi."""
    n = int(SR * dur)
    out = array("f", bytes(4 * n))
    ph = 0.0
    for i in range(n):
        t = i / SR
        f = freq * (0.72 + 0.42 * (1 - math.exp(-t * 26)) + 0.03 * math.sin(TAU * 18 * t))
        ph += TAU * f / SR
        out[i] = (math.sin(ph) + 0.22 * math.sin(2 * ph)) * math.exp(-t * 11) * min(1.0, t * 500)
    return out


@lru_cache(maxsize=32)
def sparkle(freq: float):
    """Quyosh nuri yaltirashi: yuqori 'ting' + titrovchi obertonlar."""
    n = int(SR * 0.55)
    out = array("f", bytes(4 * n))
    for i in range(n):
        t = i / SR
        e = math.exp(-t * 7.5) * min(1.0, t * 700)
        v = math.sin(TAU * freq * t) + 0.5 * math.sin(TAU * freq * 2.76 * t) * math.exp(-t * 9) + 0.3 * math.sin(TAU * freq * 5.4 * t) * math.exp(-t * 14)
        out[i] = v * e * (0.85 + 0.15 * math.sin(TAU * 22 * t))
    return out


@lru_cache(maxsize=16)
def ding(freq: float):
    """Yumshoq qo'ng'iroq: tushuncha ta'rifi paydo bo'lganda."""
    n = int(SR * 0.9)
    out = array("f", bytes(4 * n))
    for i in range(n):
        t = i / SR
        e = math.exp(-t * 4.2) * min(1.0, t * 400)
        out[i] = (math.sin(TAU * freq * t) + 0.4 * math.sin(TAU * freq * 2.0 * t) + 0.18 * math.sin(TAU * freq * 3.01 * t)) * e * 0.6
    return out


@lru_cache(maxsize=16)
def tick(seed: int = 0):
    n = int(SR * 0.035)
    rnd = random.Random(seed)
    out = array("f", bytes(4 * n))
    prev = 0.0
    for i in range(n):
        x = rnd.uniform(-1, 1)
        hp = x - prev * 0.6          # oddiy yuqori o'tkazgich
        prev = x
        out[i] = hp * math.exp(-i / SR * 170) * 0.7 + 0.3 * math.sin(TAU * (1800 + 90 * seed) * i / SR) * math.exp(-i / SR * 220)
    return out


@lru_cache(maxsize=16)
def blip(freq: float):
    n = int(SR * 0.16)
    out = array("f", bytes(4 * n))
    for i in range(n):
        t = i / SR
        f = freq if t < 0.06 else freq * 1.5
        out[i] = math.sin(TAU * f * t) * math.exp(-t * 20) * min(1.0, t * 400)
    return out


@lru_cache(maxsize=8)
def chime(root: float, minor: bool = False):
    n = int(SR * 1.5)
    out = array("f", bytes(4 * n))
    third = 6 / 5 if minor else 5 / 4
    notes = ((0.0, 1.0), (0.11, third), (0.22, 1.5), (0.34, 2.0))
    for off, ratio in notes:
        s0 = int(off * SR)
        f = root * ratio
        for i in range(n - s0):
            t = i / SR
            e = math.exp(-t * 3.2) * min(1.0, t * 300)
            out[s0 + i] += (math.sin(TAU * f * t) + 0.3 * math.sin(TAU * f * 2.01 * t)) * e * 0.5
    return out


@lru_cache(maxsize=4)
def riser(dur: float = 1.3):
    n = int(SR * dur)
    rnd = random.Random(5)
    out = array("f", bytes(4 * n))
    lp = 0.0
    for i in range(n):
        t = i / n
        f = 180 * (1 + 9 * t ** 2)
        a = 1 - math.exp(-TAU * (400 + 3500 * t) / SR)
        lp += a * (rnd.uniform(-1, 1) - lp)
        out[i] = (math.sin(TAU * f * i / SR) * 0.5 + lp * 1.6) * (t ** 1.5) * (1 - t ** 8)
    return out


@lru_cache(maxsize=4)
def thud(freq: float = 62.0):
    n = int(SR * 0.5)
    out = array("f", bytes(4 * n))
    for i in range(n):
        t = i / SR
        out[i] = math.sin(TAU * freq * (1 + 1.4 * math.exp(-t * 22)) * t) * math.exp(-t * 9)
    return out


def _add(buf: array, start: int, snd, gain: float):
    if start < 0:
        snd = snd[-start:]
        start = 0
    n = min(len(snd), len(buf) - start)
    g = gain * 32767
    for i in range(n):
        v = buf[start + i] + int(snd[i] * g)
        buf[start + i] = 32767 if v > 32767 else -32768 if v < -32768 else v


def plan_events(scenes: list, seed: int = 0) -> list:
    """[(vaqt_soniya, nom, parametr, kuch)] - sahna turi va bo'lakcha vaqtlariga qarab."""
    rnd = random.Random(seed * 7919 + 13)
    ev = []
    last = len(scenes) - 1
    for i, sc in enumerate(scenes):
        fps = sc.get("fps") or 25
        t0 = sc.get("start", 0.0)
        lead = sc.get("lead_f", 0) / fps
        typ = sc.get("type")
        if i == 0:
            ev.append((t0 + 0.05, "riser", 0, 0.5))
            ev.append((t0 + 1.3, "thud", 0, 0.6))
        else:
            ev.append((max(0.0, t0 - 0.14), "whoosh", rnd.choice((0, 1, 2, 3, 0, 2)), 0.55))
        rel, anim = sc.get("unit_rel") or [], sc.get("unit_anim") or []
        base = t0 + lead
        for k, r in enumerate(rel):
            t = base + r
            if typ in ("bullets", "flow"):
                ev.append((t, "pop", 520 * 2 ** ((k % 6) / 12.0 * 2), 0.5))
            elif typ == "code":
                ln = anim[k] if k < len(anim) else 0.3
                nt = max(2, int(ln / 0.055))
                for j in range(nt):
                    ev.append((t + j * ln / nt + rnd.uniform(0, 0.012), "tick", rnd.randrange(6), 0.32))
            elif typ == "diagram":
                ev.append((t, "blip", 660 * 2 ** ((k % 5) / 12.0 * 2), 0.5))
            elif typ == "compare":
                ev.append((t, "pop", 440 if k % 2 == 0 else 587, 0.45))
            elif typ == "parts":                                  # 3D karta sakrab chiqadi + quyosh nuri 'ting'
                f = 392 * 2 ** ((k % 6) / 12.0 * 2)
                ev.append((t, "boing", f, 0.5))
                ev.append((t + 0.10, "sparkle", f * 4, 0.26))
            elif typ == "explain":
                if k == 0:
                    ev.append((t, "ding", 523.25, 0.5))
                elif k == 1:
                    ev.append((t, "boing", 440, 0.45))
                    ev.append((t + 0.12, "sparkle", 1760, 0.3))
                else:
                    ev.append((t, "pop", 600 + 80 * k, 0.4))
                    ev.append((t + 0.06, "sparkle", 2093, 0.18))
        if typ == "recap":
            ev.append((base + 0.2, "pop", 392, 0.4))
        if i == last or typ == "outro":
            ev.append((base + 0.3, "chime", 261.63 * (1.0 if seed % 2 else 1.122), 0.55))
    return ev


def synth_events(events: list, total: float) -> array:
    n = int((total + 1.5) * SR)
    buf = array("h", bytes(2 * n))
    for t, name, p, gain in events:
        s = int(t * SR)
        if s >= n or t > total:
            continue
        if name == "whoosh":
            snd, g = whoosh(int(p)), 0.30
        elif name == "pop":
            snd, g = pop(float(round(p, 1))), 0.30
        elif name == "tick":
            snd, g = tick(int(p)), 0.20
        elif name == "blip":
            snd, g = blip(float(round(p, 1))), 0.25
        elif name == "chime":
            snd, g = chime(float(round(p, 2))), 0.30
        elif name == "riser":
            snd, g = riser(), 0.22
        elif name == "thud":
            snd, g = thud(), 0.45
        elif name == "boing":
            snd, g = boing(float(round(p, 1))), 0.28
        elif name == "sparkle":
            snd, g = sparkle(float(round(p, 1))), 0.16
        elif name == "ding":
            snd, g = ding(float(round(p, 2))), 0.30
        else:
            continue
        _add(buf, s, snd, g * gain)
    return buf


def make_sfx(path, scenes: list, total: float, seed: int = 0) -> bool:
    """sfx.wav (mono, 44100 Hz, 16 bit) yaratadi; xato bo'lsa False (video SFX siz davom etadi)."""
    try:
        buf = synth_events(plan_events(scenes, seed), total)
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes(buf.tobytes())
        return True
    except Exception:  # noqa: BLE001
        return False
