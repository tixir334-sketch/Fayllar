"""Ingliz/chet so'zlarni o'zbekcha ovoz to'g'ri o'qishi uchun talaffuz lug'ati.

Qatlamlar (yuqoridan pastga ustuvor):
  1) foydalanuvchi lug'ati (/pron bilan qo'shilgan)  - hech qachon avtomatik o'zgarmaydi
  2) LLM aniqlagan so'zlar (har epizodda bir marta so'raladi, bazaga saqlanadi - keyingi epizodlarda tayyor)
  3) o'rnatilgan lug'at (enwords.py) va qoidalar (speak.py)
"""
from __future__ import annotations

import re

from . import speak
from .enwords import EN
from .text import clean_narration
from .util import log

KV_AUTO, KV_USER = "pron_auto", "pron_user"
_KEY = re.compile(r"^[A-Za-z][A-Za-z0-9_+#.\-]{0,38}$")
_VAL = re.compile(r"^[a-z0-9' \-]{1,60}$")

SYSTEM = ("Siz o'zbek tilidagi ovozli dasturlash darslari uchun talaffuz yordamchisisiz. "
          "Diktor o'zbek ovozi bo'lgani uchun ingliz so'zlarni o'zbek harflari bilan o'qib buzib yuboradi. "
          "Siz ingliz so'zni TO'G'RI INGLIZ TALAFFUZIGA mos o'zbek lotin yozuviga o'girasiz.")

PROMPT = """Quyidagi matn o'zbek tilida, lekin ichida ingliz (yoki boshqa chet tilidagi) so'zlar, texnik atamalar, \
kod identifikatorlari va brend nomlari bor.

VAZIFA: matndagi har bir CHET TILIDAGI so'zni toping (o'zbekcha so'zlarni QO'SHMANG) va uning ingliz tilidagi \
to'g'ri aytilishini o'zbek lotin harflarida yozib bering.

Yozuv qoidalari: ey=/eɪ/ (shape→sheyp), ay=/aɪ/ (type→tayp), ou=/oʊ/ (open→oupen), au=/aʊ/ (output→autput), \
i=/iː/ (key→ki), u/yu=/uː, juː/ (use→yuz, value→velyu), e=/e, æ/ (class→kles, data→deyta), a=/ʌ, ə/ (function→fankshn), \
sh=/ʃ/, ch=/tʃ/, j=/dʒ/ (merge→merj), uay/ua=/w/ (while→uayl, with→uit), th=/θ, ð/ ni s/z bilan (the→ze), \
r oxirida yengil (server→server). Faqat a-z, bo'sh joy, apostrof va defis ishlating.
Misollar: Python→payton, pandas→pendas, DataFrame→deyta freym, shape→sheyp, JSON→jeyson, file→fayl, \
index→indeks, lambda→lemda, async→eysink, GitHub→git hab, YouTube→yutub, tuple→tyupl, dict→dikt.

Bir necha so'zdan iborat kod nomlari (snake_case, camelCase) bo'lsa, so'zlar bo'yicha yozing \
(read_csv→rid si es vi, DataFrame→deyta freym).
Allaqachon ma'lum so'zlarni (quyidagi ro'yxat) takrorlamang: {known}

FAQAT JSON qaytaring: {{"so'z": "aytilishi", ...}}. Kalit matndagi yozilishi (kichik harfda).

MATN:
{text}
"""


def _clean_map(obj, text_low: str) -> dict:
    """LLM javobini tekshiradi: faqat matnda haqiqatan bor, shakli to'g'ri yozuvlar qoladi."""
    if isinstance(obj, dict) and isinstance(obj.get("words"), dict):
        obj = obj["words"]
    out = {}
    if not isinstance(obj, dict):
        return out
    for k, v in obj.items():
        if not isinstance(k, str) or not isinstance(v, str):
            continue
        k = k.strip()
        v = v.strip().lower()
        kl = k.lower()
        if not _KEY.match(k) or not _VAL.match(v) or kl == v or "'" in k or "ʻ" in k:
            continue
        if kl not in text_low:           # matnda yo'q (to'qib chiqarilgan)
            continue
        out[kl] = v
    return out


def candidates_text(scenes: list) -> str:
    parts = []
    for sc in scenes:
        n = sc.get("narration")
        if n:
            parts.append(clean_narration(n))
    return "\n".join(parts)


def load(db) -> dict:
    """Barcha qo'shimcha lug'at (LLM + foydalanuvchi) - foydalanuvchi ustun."""
    d = dict(db.kv_json(KV_AUTO, {}) or {})
    d.update(db.kv_json(KV_USER, {}) or {})
    return d


def activate(db):
    speak.set_pron(load(db))


def build(cfg, db, llm, scenes: list) -> dict:
    """Epizod matnidagi yangi chet so'zlarni LLM dan so'raydi, bazaga saqlaydi va faollashtiradi."""
    text = candidates_text(scenes)
    auto = dict(db.kv_json(KV_AUTO, {}) or {})
    user = db.kv_json(KV_USER, {}) or {}
    if cfg.bool("PRON_LLM") and text.strip():
        low = text.lower()
        known = sorted(set(auto) | set(user) | set(EN))
        # faqat shu matnda uchraydigan ma'lumlarni ro'yxatga kiritamiz (so'rov qisqa bo'lsin)
        present = [w for w in known if re.search(r"\b" + re.escape(w) + r"\b", low)][:150]
        try:
            obj, label = llm.complete_json(SYSTEM, PROMPT.format(known=", ".join(present) or "(yo'q)", text=text[:9000]),
                                           tries=2, max_tokens=3000, temperature=0.1)
            new = _clean_map(obj, low)
            fresh = {k: v for k, v in new.items() if k not in auto and k not in user and k not in EN}
            if fresh:
                auto.update(fresh)
                db.kv_set_json(KV_AUTO, dict(list(auto.items())[-3000:]))
            log.info("Talaffuz lug'ati: %d yangi so'z (%s)", len(fresh), label)
        except Exception as e:  # noqa: BLE001  LLM bo'lmasa o'rnatilgan lug'at bilan davom etadi
            log.warning("Talaffuz lug'ati LLM dan olinmadi: %s", str(e)[:200])
    speak.set_pron({**auto, **user})
    return {**auto, **user}
