"""Jonli translatsiya (YouTube Live) boshqaruvi: hammasi tugmalar (`st:`) yoki /stream buyruqlari orqali.
Qoralama yaratish (nom, tavsif, rasm), navbat (tayyor video, yuborilgan video, AI bo'laklar), sifat/FPS/format,
boshlash, to'xtatish, "Efir tugasinmi?" javobi."""
from __future__ import annotations

import threading
import time
from pathlib import Path

from .hwenc import HW, LABEL
from .stream import StreamError, valid_fps
from .streamsys import PROFILES, PROFILE_INFO, apply_profile
from .tg import PANELS
from .util import clip, esc, fmt_dur, log

SEG_CHOICES = [1, 2, 4, 6, 12, 0]
LOCKED = ("STREAM_RES", "STREAM_FPS", "STREAM_FORMAT", "STREAM_BITRATE", "STREAM_SEG_SEC", "STREAM_PRESET", "STREAM_WORKERS",
          "STREAM_PART_SEC", "STREAM_CRF", "ENCODER", "STREAM_PROFILE")
PAGE = 8


def _cycle(cur, options):
    try:
        return options[(options.index(cur) + 1) % len(options)]
    except ValueError:
        return options[0]


class StreamMixin:
    # ------------------------------------------------------------------ asosiy panel
    def c_stream(self, arg, chat):
        """/stream · /stream tizim · /stream profil <nom> · /stream vaqt HH:MM|off"""
        parts = (arg or "").split()
        if parts:
            cmd = parts[0].lower()
            if cmd in ("tizim", "sys", "system"):
                return self._st_sys(chat)
            if cmd in ("profil", "profile"):
                if len(parts) < 2:
                    return self._st_profiles(chat)
                return self._st_apply_profile(parts[1], chat)
            if cmd in ("vaqt", "at", "soat"):
                val = parts[1].strip() if len(parts) > 1 else ""
                return self._st_schedule(val, chat)
        self.st_home(chat)

    def st_home(self, chat):
        a = self.app
        stm = a.stream
        text = stm.status_text()
        rows = []
        st = stm.state
        if not stm.s.get("id") or st == "ended":
            if st == "ended" and stm.s.get("note"):
                text += "\n<i>" + esc(stm.s["note"]) + "</i>"
            rows.append([("➕ Yangi translatsiya", "st:new"), ("⚙️ Sifat", "st:cfg")])
            rows.append([("🎚 Profil", "st:prof"), ("📊 Tizim", "st:sys")])
        elif st == "draft":
            rows += [[("▶️ Efirni boshlash", "st:go")],
                     [("🎬 Tayyor video", "st:addv:0"), ("🤖 AI bo'lak", "st:addg")],
                     [("📤 Video yuborish", "st:upl"), ("📋 Navbat", "st:q")],
                     [("🖼 Rasm", "st:pic"), ("✏️ Nomi", "st:ren"), ("📝 Tavsif", "st:desc")],
                     [("⚙️ Sifat / FPS / format", "st:cfg"), ("🎚 Profil", "st:prof")],
                     [("📊 Tizim", "st:sys"), ("🗑 Qoralamani o'chirish", "st:del")]]
        else:
            rows += [[("🔄 Yangilash", "st:home"), ("⏭ O'tkazish", "st:skip")],
                     [("🎬 Video qo'shish", "st:addv:0"), ("🤖 AI qo'shish", "st:addg")],
                     [("📋 Navbat", "st:q"), ("📤 Video yuborish", "st:upl")],
                     [("📊 Tizim", "st:sys")]]
            if st == "starting":
                rows.insert(0, [("▶️ Hozir boshlash (tayyorlari bilan)", "st:now")])
            if not stm.stopping:
                rows.append([("⏹ To'xtatish", "st:stop")])
        rows.append([("⬅️ Menyu", "mn:main")])
        self._screen(chat, text, rows)
        if st in ("starting", "live"):
            self._st_watch_panel(chat)

    def _st_watch_panel(self, chat):
        """Panel xabarini efir ketayotganda har 8 soniyada yangilab turadi (bitta oqim)."""
        ls = getattr(self, "last_screen", None)
        if not ls:
            return
        self._st_panel = ls
        if getattr(self, "_st_thread", None) and self._st_thread.is_alive():
            return

        def loop():
            stm = self.app.stream
            while stm.state in ("starting", "live"):
                time.sleep(8)
                panel = getattr(self, "_st_panel", None)
                if not panel or panel != getattr(self, "last_screen", None) or not panel[1]:
                    return
                if PANELS.get(panel[0]) not in (None, panel[1]):
                    return                      # foydalanuvchi boshqa panelga o'tdi (yoki eskisi o'chirildi)
                try:
                    rows = [[("🔄 Yangilash", "st:home"), ("⏭ O'tkazish", "st:skip")],
                            [("🎬 Video qo'shish", "st:addv:0"), ("🤖 AI qo'shish", "st:addg")],
                            [("📋 Navbat", "st:q"), ("📤 Video yuborish", "st:upl")],
                            [("📊 Tizim", "st:sys")]]
                    if stm.state == "starting":
                        rows.insert(0, [("▶️ Hozir boshlash (tayyorlari bilan)", "st:now")])
                    if not stm.stopping:
                        rows.append([("⏹ To'xtatish", "st:stop")])
                    rows.append([("⬅️ Menyu", "mn:main")])
                    mk = {"inline_keyboard": [[{"text": t, "callback_data": c} for t, c in r] for r in rows]}
                    self.tg.edit(panel[1], stm.status_text(), chat=panel[0], markup=mk)
                except Exception as e:  # noqa: BLE001
                    log.debug("Stream panel yangilanmadi: %s", e)

        self._st_thread = threading.Thread(target=loop, daemon=True, name="stream-panel")
        self._st_thread.start()

    # ------------------------------------------------------------------ callbacklar
    def st_callback(self, val, chat):
        a = self.app
        stm = a.stream
        act, _, arg = val.partition(":")
        try:
            self._st_dispatch(act, arg, chat, stm)
        except StreamError as e:
            self.tg.send(f"⚠️ {esc(str(e))}", chat=chat)

    def _st_dispatch(self, act, arg, chat, stm):
        a = self.app
        if act == "home":
            return self.st_home(chat)
        if act == "new":
            if stm.active():
                return self.tg.send("ℹ️ Efir ketyapti. Avval to'xtating.", chat=chat)
            self.pending = ("st_title", None)
            return self._screen(chat, "📡 <b>Yangi translatsiya</b>\nTranslatsiya <b>nomini</b> yozing:",
                                [[("↩️ Bekor", "st:home")]])
        if act == "nodesc":
            self.pending = None
            return self._st_ask_pic(chat)
        if act == "pic":
            return self._st_ask_pic(chat)
        if act == "picsend":
            self.pending = ("st_photo", None)
            return self._screen(chat, "🖼 Efir uchun <b>rasm yuboring</b> (oddiy rasm sifatida).",
                                [[("↩️ Bekor", "st:home")]])
        if act == "picai":                 # AI rasm butunlay o'chirilgan (eski tugma bosilsa — rasm ekraniga qaytadi)
            return self._st_ask_pic(chat)
        if act == "picno":
            stm.set_thumb(None)
            return self.st_home(chat)
        if act == "ren":
            self.pending = ("st_ren", None)
            return self._screen(chat, "✏️ Yangi <b>nomni</b> yozing:", [[("↩️ Bekor", "st:home")]])
        if act == "desc":
            self.pending = ("st_desc2", None)
            return self._screen(chat, "📝 <b>Tavsifni</b> yozing (YouTube efir tavsifi):", [[("↩️ Bekor", "st:home")]])
        if act == "del":
            if stm.discard():
                self.tg.send("🗑 Qoralama o'chirildi.", chat=chat)
            return self.st_home(chat)
        if act == "cfg":
            return self._st_cfg(chat)
        if act == "sys":
            return self._st_sys(chat)
        if act == "prof":
            return self._st_profiles(chat)
        if act == "pset":
            return self._st_apply_profile(arg, chat)
        if act == "set":
            return self._st_set(arg, chat)
        if act == "key":
            self.pending = ("st_key", None)
            return self._screen(chat, "🔑 YouTube <b>oqim kaliti</b>ni (Stream key) yuboring. Xabar darhol o'chiriladi, "
                                      "kalit hech qachon ochiq ko'rsatilmaydi.", [[("↩️ Bekor", "st:cfg")]])
        if act == "url":
            self.pending = ("st_url", None)
            return self._screen(chat, "🌐 RTMP manzilini yuboring (masalan <code>rtmp://a.rtmp.youtube.com/live2</code>):",
                                [[("↩️ Bekor", "st:cfg")]])
        if act == "q":
            return self._st_queue(chat)
        if act in ("up", "dn", "rm"):
            if act == "rm":
                stm.remove(arg)
            else:
                stm.move(arg, -1 if act == "up" else 1)
            return self._st_queue(chat)
        if act == "clr":
            stm.clear_queue()
            return self._st_queue(chat)
        if act == "addv":
            return self._st_pick_video(int(arg or 0), chat)
        if act == "addvg":
            return self._st_add_ep(int(arg), chat)
        if act == "addg":
            self.pending = ("st_topic", None)
            topic = stm.s.get("topic") or stm.s.get("title") or ""
            rows = [[(f"📌 Efir mavzusi: {clip(topic, 28)}", "st:topic0")]] if topic else []
            rows.append([("↩️ Bekor", "st:home")])
            return self._screen(chat, "🤖 <b>AI bo'laklar</b>: nima haqida bo'lsin? Mavzuni yozing "
                                      "(masalan: <i>API nima va u qanday ishlaydi</i>):", rows)
        if act == "topic0":
            self.pending = None
            return self._st_ask_segs(stm.s.get("topic") or stm.s.get("title") or "mavzu", chat)
        if act == "gs":
            topic = getattr(self, "_st_topic", None)
            if not topic:
                return self.st_home(chat)
            it = stm.add_gen(topic, int(arg))
            self._st_topic = None
            self.tg.send(f"✅ Navbatga qo'shildi: 🤖 {esc(clip(topic, 50))} · "
                         f"{'cheksiz' if not it.get('segs') else str(it['segs']) + ' bo`lak'}", chat=chat)
            return self.st_home(chat)
        if act == "upl":
            self.pending = ("st_upl", None)
            return self._screen(chat, "📤 <b>Video fayl yuboring</b> (Telegram orqali, 20 MB gacha). "
                                      "Tayyor bo'lgach navbatga qo'shiladi. Katta videolar uchun «🎬 Tayyor video» dan foydalaning.",
                                [[("↩️ Bekor", "st:home")]])
        if act == "go":
            err = stm.start()
            if err:
                return self.tg.send(f"⚠️ {esc(err)}", chat=chat)
            return self.st_home(chat)
        if act == "now":
            ok = stm.go_now()
            self.tg.send("▶️ Tayyor bo'laklar bilan efir boshlanmoqda…" if ok
                         else "ℹ️ Hozir boshlab bo'lmaydi (tayyor bo'lak yo'q yoki efir allaqachon ketyapti).", chat=chat)
            return self.st_home(chat)
        if act == "skip":
            stm.skip()
            return self.tg.send("⏭ Joriy bo'lak o'tkazildi.", chat=chat)
        if act == "stop":
            return self._screen(chat, "⏹ <b>Efirni to'xtatamizmi?</b>\nJoriy bo'lak tugagach AI xayrlashuv bo'lagi qo'shiladi, "
                                      "so'ng efir tugaydi.",
                                [[("✅ Ha, xayrlashib tugat", "st:stopok")],
                                 [("⚡ Zudlik bilan (xayrlashuvsiz)", "st:kill")],
                                 [("↩️ Yo'q", "st:home")]])
        if act == "stopok":
            ok = stm.request_stop()
            self.tg.send("⏹ Xayrlashuv bo'lagi tayyorlanmoqda; efir u tugagach yopiladi." if ok
                         else "ℹ️ To'xtatib bo'lmadi (efir yo'q yoki allaqachon to'xtatilmoqda).", chat=chat)
            return self.st_home(chat)
        if act == "kill":
            stm.kill("admin zudlik bilan to'xtatdi", notify=False)
            self.tg.send("⚡ Efir zudlik bilan yopildi. Hamma vaqtinchalik videolar o'chirildi.", chat=chat)
            return self.st_home(chat)
        if act in ("cont", "end"):
            out = stm.answer(act == "cont")
            return self.tg.send(out, chat=chat)
        return self.st_home(chat)

    # ------------------------------------------------------------------ rasm
    def _st_ask_pic(self, chat):
        has = bool(self.app.stream.s.get("thumb"))
        rows = [[("🖼 Rasm yuborish", "st:picsend")]]
        if has:
            rows.append([("🚫 Rasmni olib tashlash", "st:picno")])
        rows.append([("⏭ Rasmsiz davom", "st:home")] if not has else [("✅ Tayyor", "st:home")])
        self._screen(chat, "🖼 <b>Efir rasmi</b> (muqova va fon uchun):", rows)

    def st_photo(self, msg):
        """Yuborilgan rasm efir rasmi bo'ladi."""
        a = self.app
        chat = msg["chat"]["id"]
        if not a.stream.s.get("id") or a.stream.state not in ("draft",):
            self.tg.send("ℹ️ Rasm faqat translatsiya qoralamasi uchun qabul qilinadi (/stream).", chat=chat)
            return
        ph = max(msg["photo"], key=lambda p: p.get("file_size", 0) or p.get("width", 0))
        tmp = a.cfg.dirs["work"] / "stream_upload.jpg"
        try:
            self.tg.download_file(ph["file_id"], tmp)
            a.stream.set_thumb(tmp)
        except Exception as e:  # noqa: BLE001
            self.tg.send(f"❌ Rasm o'qilmadi: {esc(str(e)[:150])}", chat=chat)
            return
        finally:
            tmp.unlink(missing_ok=True)
        self.pending = None
        self._cb_msg = None
        self.tg.send("✅ Efir rasmi saqlandi.", chat=chat)
        self.st_home(chat)

    def st_video_msg(self, msg):
        """Telegram orqali yuborilgan video (20 MB gacha) navbatga qo'shiladi."""
        a = self.app
        chat = msg["chat"]["id"]
        v = msg.get("video") or msg.get("document") or {}
        if a.stream.state not in ("draft", "live"):
            self.tg.send("ℹ️ Avval translatsiya yarating: /stream", chat=chat)
            return
        if v.get("file_size", 0) > 20 * 1024 * 1024:
            self.tg.send("⚠️ Telegram botlari 20 MB dan katta faylni ololmaydi. Katta videoni «🎬 Tayyor video» "
                         "orqali (epizod) yoki serverga qo'ying.", chat=chat)
            return
        d = a.cfg.dirs["work"] / "stream" / "uploads"
        d.mkdir(parents=True, exist_ok=True)
        name = (v.get("file_name") or f"video_{int(time.time())}.mp4")
        dest = d / f"{int(time.time())}_{Path(name).name}"

        def job():
            try:
                self.tg.download_file(v["file_id"], dest)
                it = a.stream.add_file(dest, title=Path(name).stem, owned=True)
                self.tg.send(f"✅ Navbatga qo'shildi: 🎬 {esc(it['title'])} · {fmt_dur(it['est'])}", chat=chat)
            except Exception as e:  # noqa: BLE001
                dest.unlink(missing_ok=True)
                self.tg.send(f"❌ Video qo'shilmadi: {esc(str(e)[:200])}", chat=chat)

        self.pending = None
        threading.Thread(target=job, daemon=True, name="stream-upload").start()

    # ------------------------------------------------------------------ navbat
    def _st_queue(self, chat):
        stm = self.app.stream
        q = stm.s.get("queue", [])
        lines = ["📋 <b>Translatsiya navbati</b>" + (f" · jami ~{fmt_dur(stm.remaining())}" if q and stm.remaining() != float("inf") else "")]
        rows = []
        for i, it in enumerate(q, 1):
            tag = "🤖" if it["kind"] == "gen" else "🎬"
            more = ("∞" if not it.get("segs") else f"{it['segs']} bo'lak") if it["kind"] == "gen" else fmt_dur(it.get("est", 0))
            lines.append(f"{i}. {tag} {esc(clip(it['title'], 40))} · {more}")
            rows.append([(f"⬆️ {i}", f"st:up:{it['id']}"), (f"⬇️ {i}", f"st:dn:{it['id']}"),
                         (f"❌ {i}", f"st:rm:{it['id']}")])
        if not q:
            lines.append("<i>Bo'sh.</i>")
        rows.append([("🎬 Tayyor video", "st:addv:0"), ("🤖 AI bo'lak", "st:addg")])
        if q:
            rows.append([("🧹 Hammasini tozalash", "st:clr")])
        rows.append([("⬅️ Panel", "st:home")])
        self._screen(chat, "\n".join(lines), rows)

    def _st_videos(self):
        a = self.app
        eps = [e for e in (a.db.uploaded(200) + a.pipeline.ready_episodes())
               if e.get("video_path") and Path(e["video_path"]).exists()]
        seen, out = set(), []
        for e in sorted(eps, key=lambda e: e["gno"]):
            if e["gno"] not in seen:
                seen.add(e["gno"])
                out.append(e)
        return out

    def _st_pick_video(self, page, chat):
        eps = self._st_videos()
        pages = max(1, (len(eps) + PAGE - 1) // PAGE)
        page = max(0, min(page, pages - 1))
        rows = []
        for e in eps[page * PAGE:(page + 1) * PAGE]:
            rows.append([(f"➕ #{e['gno']} {clip(e['title'], 26)} · {fmt_dur(e.get('duration') or 0)}",
                          f"st:addvg:{e['gno']}")])
        nav = []
        if page > 0:
            nav.append(("◀️", f"st:addv:{page - 1}"))
        if page < pages - 1:
            nav.append(("▶️", f"st:addv:{page + 1}"))
        if nav:
            rows.append(nav)
        rows.append([("📋 Navbat", "st:q"), ("⬅️ Panel", "st:home")])
        self._screen(chat, f"🎬 <b>Tayyor videolar</b> ({len(eps)} ta, {page + 1}/{pages}). Navbatga qo'shish uchun bosing:"
                     if eps else "ℹ️ Diskda tayyor video yo'q. Video yuboring (📤) yoki AI bo'lak qo'shing.", rows)

    def _st_add_ep(self, gno, chat):
        a = self.app
        e = a.db.ep_by_gno(gno)
        if not e or not e.get("video_path"):
            return self.tg.send("ℹ️ Video topilmadi.", chat=chat)
        it = a.stream.add_file(e["video_path"], title=f"#{gno} {e['title']}", gno=gno)
        self.tg.send(f"✅ Navbatga qo'shildi: 🎬 {esc(clip(it['title'], 50))} · {fmt_dur(it['est'])}", chat=chat)
        self._st_pick_video(0, chat)

    def _st_ask_segs(self, topic, chat):
        self._st_topic = topic[:300]
        d = self.app.cfg.int("STREAM_GEN_SEGS")
        sec = self.app.cfg.float("STREAM_SEG_SEC")
        rows = [[(("∞ cheksiz" if n == 0 else f"{n} × {fmt_dur(sec)}") + (" ●" if n == d else ""), f"st:gs:{n}")
                 for n in SEG_CHOICES[:3]],
                [(("∞ cheksiz" if n == 0 else f"{n} × {fmt_dur(sec)}") + (" ●" if n == d else ""), f"st:gs:{n}")
                 for n in SEG_CHOICES[3:]],
                [("↩️ Bekor", "st:home")]]
        self._screen(chat, f"🤖 <b>{esc(clip(topic, 60))}</b>\nNecha bo'lak AI video yaratilsin? "
                           f"(har biri ~{fmt_dur(sec)}, bir-birining davomi)", rows)

    # ------------------------------------------------------------------ sozlamalar
    def _st_cfg(self, chat):
        cfg, stm = self.app.cfg, self.app.stream
        locked = stm.active()
        p = lambda k: cfg.get(k)  # noqa: E731

        def mk(key, vals, fmt=lambda v: v):
            return [((f"● {fmt(v)}" if p(key).strip().lower() == str(v) else f"○ {fmt(v)}"), f"st:set:{key}:{v}")
                    for v in vals]

        key_state = "✅ kiritilgan" if cfg.get("STREAM_KEY") else "❌ yo'q"
        lines = ["⚙️ <b>Translatsiya sozlamalari</b>" + ("  🔒 efir paytida sifat o'zgarmaydi" if locked else ""),
                 f"Sifat: <b>{p('STREAM_RES')}p</b> · <b>{p('STREAM_FPS')} fps</b> · <b>{p('STREAM_FORMAT')}</b> · "
                 f"<b>{'avto' if cfg.int('STREAM_BITRATE') <= 0 else p('STREAM_BITRATE') + ' kbit/s'}</b> · CRF/CQ "
                 f"<b>{cfg.int('STREAM_CRF') or 20}</b> · profil: <b>{esc(p('STREAM_PROFILE') or 'custom')}</b>",
                 f"Kodlash: <b>{esc(HW.label())}</b> · rejim: <b>{esc(p('ENCODER'))}</b> (/gpu) · animatsiya: "
                 f"{'avto (fps ga teng)' if cfg.int('STREAM_BG_FPS') <= 0 else str(cfg.int('STREAM_BG_FPS')) + ' kadr/s'}",
                 f"Bo'lak: <b>{fmt_dur(cfg.float('STREAM_SEG_SEC'))}</b> · ogohlantirish: <b>{fmt_dur(cfg.float('STREAM_WARN_SEC'))}</b> "
                 f"qolganda · javob muddati <b>{fmt_dur(cfg.float('STREAM_ASK_TIMEOUT'))}</b>",
                 f"Rejim: <b>{p('STREAM_MODE')}</b> · maxfiylik: <b>{p('STREAM_PRIVACY')}</b> · kalit: {key_state}",
                 f"Oldindan tayyorlash: <b>{p('STREAM_PREROLL')}</b> bo'lak · zaxira: <b>{p('STREAM_BUFFER')}</b> · "
                 f"qism: <b>{p('STREAM_PART_SEC')}s</b> · kodlash: <b>{p('STREAM_PRESET')}</b> · ishchilar: <b>{p('STREAM_WORKERS')}</b> (0=avto)",
                 f"Gap o'rtasida uzish: {'✅' if cfg.bool('STREAM_MIDCUT') else '⬜'} · musiqa: {'✅' if cfg.bool('STREAM_MUSIC') else '⬜'}",
                 "", "<i>Telefon sekin bo'lsa 480p/15-20 fps tanlang: tayyorlash tezligi efir tezligidan past bo'lmasin.</i>"]
        rows = [mk("STREAM_RES", [480, 720, 1080], lambda v: f"{v}p"),
                mk("STREAM_FPS", [20, 25, 30, 60]),
                mk("STREAM_FORMAT", ["landscape", "shorts"], lambda v: "gorizontal" if v == "landscape" else "vertikal"),
                mk("STREAM_BITRATE", [0, 1500, 3000, 5500, 9000], lambda v: "avto" if v == 0 else str(v)),
                mk("STREAM_CRF", [18, 20, 22, 24], lambda v: f"CRF {v}"),
                mk("STREAM_SEG_SEC", [60, 120, 300, 600], lambda v: fmt_dur(v)),
                mk("STREAM_PREROLL", [1, 3, 5, 10], lambda v: f"preroll {v}"),
                mk("STREAM_BUFFER", [3, 5, 10, 15], lambda v: f"zaxira {v}"),
                mk("STREAM_PRESET", ["ultrafast", "superfast", "veryfast"], lambda v: f"CPU {v}"),
                mk("ENCODER", ["auto", "nvenc", "qsv", "mediacodec", "cpu"],
                   lambda v: {"auto": "GPU avto", "nvenc": "NVIDIA", "qsv": "Intel", "mediacodec": "Telefon", "cpu": "CPU"}[v]),
                mk("STREAM_MODE", ["api", "manual"], lambda v: "YouTube API" if v == "api" else "RTMP kalit"),
                [("🔑 Kalit", "st:key"), ("🌐 RTMP manzil", "st:url")],
                [(f"{'✅' if cfg.bool('STREAM_MIDCUT') else '⬜'} Gap o'rtasida uzish", "st:set:STREAM_MIDCUT:toggle"),
                 (f"{'✅' if cfg.bool('STREAM_MUSIC') else '⬜'} Musiqa", "st:set:STREAM_MUSIC:toggle")],
                mk("STREAM_PRIVACY", ["public", "unlisted", "private"]),
                [("⬅️ Panel", "st:home")]]
        self._screen(chat, "\n".join(lines), rows)

    # ------------------------------------------------------------------ tizim paneli, profillar, rejalashtirish
    def _st_sys(self, chat):
        stm = self.app.stream
        self._screen(chat, stm.sys.panel_text(), [[("🔄 Yangilash", "st:sys"), ("🎚 Profil", "st:prof")],
                                                  [("⬅️ Panel", "st:home")]])

    def _st_profiles(self, chat):
        cfg, stm = self.app.cfg, self.app.stream
        cur = (cfg.get("STREAM_PROFILE") or "custom").strip().lower()
        lines = ["🎚 <b>Sifat profillari</b>" + ("  🔒 efir paytida o'zgarmaydi" if stm.active() else ""),
                 f"Hozir: <b>{esc(cur)}</b> · kodlash: <b>{esc(HW.label())}</b>", ""]
        for name in PROFILES:
            lines.append(f"{'●' if name == cur else '○'} <b>{name}</b> — {esc(PROFILE_INFO[name])}")
        lines.append("")
        lines.append("<i>Profil o'lcham, FPS, bitrate va sifatni birdan belgilaydi (keyin qo'lda o'zgartirish mumkin).</i>")
        rows = [[((f"● {n}" if n == cur else f"○ {n}"), f"st:pset:{n}") for n in list(PROFILES)[:2]],
                [((f"● {n}" if n == cur else f"○ {n}"), f"st:pset:{n}") for n in list(PROFILES)[2:]],
                [("⚙️ Qo'lda sozlash", "st:cfg"), ("⬅️ Panel", "st:home")]]
        self._screen(chat, "\n".join(lines), rows)

    def _st_apply_profile(self, name, chat):
        stm = self.app.stream
        if stm.active():
            return self.tg.send("🔒 Efir paytida sifat o'zgartirilmaydi. Efir tugagach o'zgartiring.", chat=chat)
        err = apply_profile(self.app.cfg, name)
        if err:
            return self.tg.send(f"⚠️ {esc(err)}", chat=chat)
        self.tg.send(f"✅ Profil: <b>{esc(name.lower())}</b>", chat=chat)
        return self._st_cfg(chat)

    def _st_schedule(self, val, chat):
        cfg = self.app.cfg
        if val.lower() in ("", "off", "yoq", "o'chir", "0"):
            cfg.set("STREAM_AT", "")
            return self.tg.send("⏰ Rejalashtirilgan boshlanish bekor qilindi. Yozing: <code>/stream vaqt 21:30</code>", chat=chat)
        from .streamsys import Planner
        from .util import local_now
        t = Planner.parse(val, local_now(cfg))
        if t is None:
            return self.tg.send("⚠️ Format: <code>/stream vaqt 21:30</code> yoki <code>/stream vaqt 2026-11-05 21:30</code>", chat=chat)
        cfg.set("STREAM_AT", val)
        self.tg.send(f"⏰ Efir <b>{t.strftime('%Y-%m-%d %H:%M')}</b> da avtomatik boshlanadi (qoralama va navbat tayyor bo'lsa).", chat=chat)

    # ------------------------------------------------------------------ /gpu
    def c_gpu(self, arg, chat):
        """/gpu — kodlovchi holati · /gpu test · /gpu auto|nvenc|qsv|amf|mediacodec|cpu"""
        a = (arg or "").strip().lower()
        if a in ("test", "sinash"):
            return self._gpu_retest(chat)
        if a:
            return self._gpu_set(a, chat)
        self._gpu_panel(chat)

    def _gpu_panel(self, chat):
        cfg = self.app.cfg
        HW.bind(cfg)
        text = ("🎞 <b>Video kodlash (GPU/CPU)</b>\n" + HW.describe() +
                "\n\n<i>GPU kodlash CPU ga nisbatan juda tez; sifat belgilangan (doimiy sifat + bitrate chegarasi). "
                "GPU xato bersa avtomatik CPU ishlatiladi.</i>")
        cur = (cfg.get("ENCODER") or "auto").strip().lower()
        mk = lambda v, t: ((f"● {t}" if cur == v else f"○ {t}"), f"gpu:set:{v}")  # noqa: E731
        rows = [[("🔄 Qayta sinash", "gpu:test")],
                [mk("auto", "GPU avto"), mk("nvenc", "NVIDIA"), mk("qsv", "Intel")],
                [mk("amf", "AMD"), mk("mediacodec", "📱 Telefon"), mk("cpu", "CPU")],
                [("⬅️ Menyu", "mn:main")]]
        self._screen(chat, text, rows)

    def _gpu_retest(self, chat):
        self.tg.send("🔎 Kodlovchilar sinalmoqda (bir necha soniya)…", chat=chat)

        def job():
            try:
                HW.bind(self.app.cfg)
                HW.detect(force=True, everything=True)
            except Exception as e:  # noqa: BLE001
                log.warning("GPU sinovi xatosi: %s", e)
            self._gpu_panel(chat)

        threading.Thread(target=job, daemon=True, name="gpu-test").start()

    def _gpu_set(self, mode, chat):
        from .hwenc import ALIASES, MODES
        mode = ALIASES.get(mode, mode)
        if mode not in MODES:
            return self.tg.send("⚠️ Tanlov: auto · nvenc · qsv · amf · mediacodec (telefon) · cpu", chat=chat)
        if self.app.stream.active():
            return self.tg.send("🔒 Efir paytida kodlovchi o'zgartirilmaydi. Efir tugagach o'zgartiring.", chat=chat)
        self.app.cfg.set("ENCODER", mode)
        self._gpu_retest(chat)

    def gpu_callback(self, val, chat):
        act, _, arg = val.partition(":")
        if act == "test":
            return self._gpu_retest(chat)
        if act == "set":
            return self._gpu_set(arg, chat)
        self._gpu_panel(chat)

    def _st_set(self, arg, chat):
        cfg, stm = self.app.cfg, self.app.stream
        key, _, val = arg.partition(":")
        if key not in ("STREAM_RES", "STREAM_FPS", "STREAM_FORMAT", "STREAM_BITRATE", "STREAM_SEG_SEC", "STREAM_MODE",
                       "STREAM_PRIVACY", "STREAM_MIDCUT", "STREAM_MUSIC", "STREAM_PREROLL", "STREAM_BUFFER",
                       "STREAM_PRESET", "STREAM_WORKERS", "STREAM_PART_SEC", "STREAM_CRF", "ENCODER"):
            return self._st_cfg(chat)
        if key in LOCKED and stm.active():
            return self.tg.send("🔒 Efir paytida sifat o'zgartirilmaydi (ko'rinish buzilmasligi uchun). "
                                "Efir tugagach o'zgartiring.", chat=chat)
        if val == "toggle":
            val = "0" if cfg.bool(key) else "1"
        if key == "STREAM_FPS":
            val = str(valid_fps(val))
        cfg.set(key, val)
        if key in ("STREAM_RES", "STREAM_FPS", "STREAM_BITRATE", "STREAM_CRF"):
            cfg.set("STREAM_PROFILE", "custom")           # qo'lda o'zgartirildi: profil endi 'custom'
        if key == "ENCODER":
            HW.bind(cfg)
            HW.detect(force=True)
        self._st_cfg(chat)

    # ------------------------------------------------------------------ matn kiritish
    def st_pending(self, kind, data, text, msg, chat):
        a = self.app
        stm = a.stream
        text = text.strip()
        try:
            if kind == "st_title":
                stm.create(text)
                self.pending = ("st_desc", None)
                self._cb_msg = None
                return self._screen(chat, f"✅ Nom: <b>{esc(stm.s['title'])}</b>\n📝 Endi qisqa <b>tavsif</b> yozing "
                                          f"(YouTube efir tavsifi; AI mavzu sifatida ham foydalanadi):",
                                    [[("⏭ Tavsifsiz", "st:nodesc")]])
            if kind == "st_desc":
                stm.set_field("desc", text)
                stm.set_field("topic", f"{stm.s['title']}. {text}"[:300])
                self._cb_msg = None
                return self._st_ask_pic(chat)
            if kind == "st_desc2":
                stm.set_field("desc", text)
                self._cb_msg = None
                return self.st_home(chat)
            if kind == "st_ren":
                stm.set_field("title", text[:100])
                self._cb_msg = None
                return self.st_home(chat)
            if kind in ("st_key", "st_url"):
                if kind == "st_key":
                    try:
                        self.tg.api("deleteMessage", {"chat_id": chat, "message_id": msg["message_id"]}, retries=1)
                    except Exception:  # noqa: BLE001
                        pass
                a.cfg.set("STREAM_KEY" if kind == "st_key" else "STREAM_RTMP_URL", text)
                self.tg.send("✅ Saqlandi" + (" (kalit yashirin)." if kind == "st_key" else "."), chat=chat)
                self._cb_msg = None
                return self._st_cfg(chat)
            if kind == "st_topic":
                self._cb_msg = None
                return self._st_ask_segs(text, chat)
        except StreamError as e:
            self.tg.send(f"⚠️ {esc(str(e))}", chat=chat)
            return None
        return None
